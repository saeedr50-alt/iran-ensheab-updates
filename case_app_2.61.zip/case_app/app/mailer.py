"""ایمیل اطلاع‌رسانی تیکت برای پشتیبان. تنظیمات فقط در instance/mail.json می‌ماند (هرگز در Git/zip نمی‌رود):
{"user": "حساب Gmail فرستنده", "password": "رمز برنامهٔ Gmail", "to": "ایمیل گیرنده"}
اگر فایل نباشد یا ارسال خطا بدهد، بی‌صدا رد می‌شود و کار تیکت خراب نمی‌شود (علت در instance/mail.log)."""
import json
import os
import smtplib
import ssl
import threading
import time
from email.message import EmailMessage

from . import updater

HOST, PORT = "smtp.gmail.com", 465


def _path(app, name):
    return os.path.join(os.path.dirname(app.config["DATABASE"]), name)


def settings(app):
    try:
        with open(_path(app, "mail.json"), encoding="utf-8") as f:
            d = json.load(f)
        if d.get("user") and d.get("password") and d.get("to"):
            return {"user": d["user"].strip(), "password": d["password"].replace(" ", ""), "to": d["to"].strip()}
    except (OSError, ValueError, AttributeError):
        pass
    return None


def _log(app, text):
    try:
        with open(_path(app, "mail.log"), "a", encoding="utf-8") as f:
            f.write(time.strftime("%Y-%m-%d %H:%M:%S ") + text + "\n")
    except OSError:
        pass


def send_now(app, subject, body, attachment=None):
    """(ok, خطا). attachment = (نام، بایت‌ها) یا None."""
    st = settings(app)
    if not st:
        return False, "no-config"
    msg = EmailMessage()
    msg["From"], msg["To"], msg["Subject"] = st["user"], st["to"], subject
    msg.set_content(body)
    if attachment:
        msg.add_attachment(attachment[1], maintype="application", subtype="octet-stream", filename=attachment[0])
    try:
        with smtplib.SMTP_SSL(HOST, PORT, timeout=20, context=updater._ssl_context()) as s:
            s.login(st["user"], st["password"])
            s.send_message(msg)
        return True, ""
    except Exception as e:                        # noqa: BLE001
        _log(app, f"send failed: {type(e).__name__}: {e}")
        return False, f"{type(e).__name__}"


def notify(app, subject, body, attachment=None):
    """در پس‌زمینه می‌فرستد؛ هرگز جلوی کار برنامه را نمی‌گیرد."""
    if not settings(app) or app.config.get("MAIL_DISABLED"):
        return
    threading.Thread(target=send_now, args=(app, subject, body, attachment), daemon=True).start()
