(function () {
  // هشدار به‌روزرسانی: وقتی مدیر دکمهٔ بروزرسانی را می‌زند، بالای صفحهٔ بقیه شمارش معکوس دیده می‌شود.
  var me = document.currentScript, url = me && me.getAttribute('data-url');
  if (!url || !window.fetch) return;
  var bar = null, left = null, timer = null, updating = false, wasUpdating = false;
  function fa(n) { return String(n).replace(/\d/g, function (d) { return '۰۱۲۳۴۵۶۷۸۹'.charAt(+d); }); }
  function show(t) {
    if (!bar) {
      bar = document.createElement('div');
      bar.className = 'upd-banner'; bar.setAttribute('role', 'alert');
      document.body.appendChild(bar);
    }
    bar.textContent = t; bar.hidden = false;
  }
  function hide() { if (bar) bar.hidden = true; }
  function tick() {
    if (left === null) return;
    if (left > 0) { show('برنامه تا ' + fa(left) + ' ثانیهٔ دیگر به‌روز می‌شود؛ لطفاً کارتان را ذخیره کنید.'); left--; }
    else show('برنامه در حال به‌روزرسانی است؛ چند لحظهٔ دیگر دوباره باز می‌شود…');
  }
  function tk(n) {                                  // نشان «پاسخ جدید» کنار تیکت پشتیبانی
    var els = document.querySelectorAll('[data-tk]');
    for (var i = 0; i < els.length; i++) els[i].hidden = !(n > 0);
  }
  function poll() {
    fetch(url, { cache: 'no-store', credentials: 'same-origin' }).then(function (r) { return r.json(); }).then(function (d) {
      if (typeof d.tickets === 'number') tk(d.tickets);
      if (d.state === 'waiting') { left = d.left; updating = false; wasUpdating = true; tick(); }
      else if (d.state === 'updating') { left = 0; updating = true; wasUpdating = true; tick(); }
      else {
        left = null; hide();
        if (wasUpdating) { location.reload(); return; }      // به‌روزرسانی تمام شد یا لغو شد
      }
      setTimeout(poll, updating ? 3000 : (left !== null ? 5000 : 15000));
    }).catch(function () {
      if (wasUpdating) { show('برنامه در حال راه‌اندازی دوباره است…'); updating = true; }
      setTimeout(poll, 3000);
    });
  }
  timer = setInterval(tick, 1000);
  setTimeout(poll, 3000);
})();
