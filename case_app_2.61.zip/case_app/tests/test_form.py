"""تست‌های فرم کامل پرونده: فیلدها، ردیف‌های محصولات و رقبا، ویرایش، تداخل دو کاربر، گزینه‌ها."""
import os
import re
import sqlite3
import tempfile
import unittest
from unittest import mock

from app import auth, case_data, config, create_app, options
from app.db import connect, init_db
from app.jalali import normalize_jdate
from app.numbering import create_case

from tests.test_app import BaseCase


class JalaliDateTests(unittest.TestCase):
    def test_valid_and_normalized(self):
        self.assertEqual(normalize_jdate("1405/07/16"), "1405/07/16")
        self.assertEqual(normalize_jdate("۱۴۰۵/۷/۱۶"), "1405/07/16")
        self.assertEqual(normalize_jdate("1405-7-1"), "1405/07/01")
        self.assertEqual(normalize_jdate("1403/12/30"), "1403/12/30")   # سال کبیسه

    def test_invalid(self):
        for bad in ("", "abc", "1405/13/01", "1405/00/10", "1405/07/32", "1405/07/31",
                    "1404/12/30", "1405/7", "05/07/16", "2026/10/08"):
            self.assertIsNone(normalize_jdate(bad), bad)


class FormBase(BaseCase):
    def setUp(self):
        super().setUp()
        options.add_labels(self.db, "organization", "شرکت الف\nشرکت ب")
        options.add_labels(self.db, "source", "ایمیل\nتلفن")
        options.add_labels(self.db, "status", "در حال بررسی\nارسال شد")
        options.add_labels(self.db, "product_type", "شیر\nلوله")
        options.add_labels(self.db, "size", "۱ اینچ\n۲ اینچ")

    # ---- ابزارها
    def login(self, username):
        c = self.app.test_client()
        c.get("/login")
        with c.session_transaction() as s:
            t = s["csrf"]
        r = c.post("/login", data={"username": username, "password": "secret1", "csrf": t})
        self.assertEqual(r.status_code, 302)
        return c

    def token(self, c, path="/cases/new"):
        self.assertEqual(c.get(path).status_code, 200)
        with c.session_transaction() as s:
            return s["csrf"]

    def new_data(self, token, **over):
        data = {"csrf": token, "case_type": "tender"}
        data.update(over)
        return data

    def case_row(self, case_id=1):
        return self.db.execute("SELECT * FROM cases WHERE id = ?", (case_id,)).fetchone()


class FullFormTests(FormBase):
    def full_data(self, t):
        return self.new_data(
            t,
            received_date="۱۴۰۵/۷/۱۶", source="ایمیل", organization="شرکت الف",
            tender_type="", status="در حال بررسی", send_deadline="1405/08/01",
            physical_upload="14:30", opening_time="1405/08/10", decision="", result="بازنده",
            notes="توضیح آزمایشی",
            prod_uid=["new-1", "new-2"], prod_product_type=["شیر", "لوله"], prod_size=["۱ اینچ", ""],
            prod_quantity=["5", "1,200"], prod_model=["", ""], prod_sample=["", ""],
            comp_uid=["new-1", "new-2"], comp_name=["رقیب ۱", "رقیب ۲"],
            comp_price=["1,000,000", "0"], comp_note=["", "گران"], comp_won=["new-2"],
        )

    def test_everything_is_saved_in_one_go(self):
        c = self.login("entry1")
        t = self.token(c)
        r = c.post("/cases/new", data=self.full_data(t))
        self.assertEqual(r.status_code, 302)
        self.assertTrue(r.headers["Location"].endswith("/cases/1"))

        row = self.case_row()
        self.assertEqual((row["case_type"], row["serial_no"]), ("tender", 1))
        self.assertEqual(row["received_date"], "۱۴۰۵/۰۷/۱۶")       # بدون صفر -> استاندارد، ارقام فارسی
        self.assertEqual(row["organization"], "شرکت الف")
        self.assertEqual(row["notes"], "توضیح آزمایشی")
        prods = self.db.execute("SELECT * FROM case_products ORDER BY id").fetchall()
        self.assertEqual([(p["product_type"], p["size"], p["quantity"]) for p in prods],
                         [("شیر", "۱ اینچ", 5), ("لوله", "", 1200)])
        comps = self.db.execute("SELECT * FROM case_competitors ORDER BY id").fetchall()
        self.assertEqual([(x["name"], x["price"], x["won"]) for x in comps],
                         [("رقیب ۱", 1000000, 0), ("رقیب ۲", 0, 1)])

        html = c.get("/cases/1").get_data(as_text=True)
        for text in ("شرکت الف", "۱۴۰۵/۰۷/۱۶", "رقیب ۲", "۱,۲۰۰"):
            self.assertIn(text, html)

    def test_invalid_input_saves_nothing_and_does_not_burn_a_number(self):
        c = self.login("entry1")
        t = self.token(c)
        bad = self.full_data(t)
        bad["received_date"] = "1405/13/40"
        r = c.post("/cases/new", data=bad)
        self.assertEqual(r.status_code, 400)
        body = r.get_data(as_text=True)
        self.assertIn("تاریخ دریافت", body)
        self.assertEqual(self.count_cases(), 0)
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM counters").fetchone()[0], 0)
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM case_products").fetchone()[0], 0)

        good = self.full_data(t)
        c.post("/cases/new", data=good)
        self.assertEqual(self.case_row()["serial_no"], 1)

    def test_validation_rules(self):
        c = self.login("entry1")
        t = self.token(c)
        cases = {
            "organization not in list": {"organization": "ناشناس"},
            "bad quantity": {"prod_uid": ["new-1"], "prod_quantity": ["abc"], "prod_product_type": [""],
                             "prod_size": [""], "prod_model": [""], "prod_sample": [""]},
            "bad price": {"result": "بازنده", "comp_uid": ["new-1"], "comp_name": ["x"], "comp_price": ["12x"],
                          "comp_note": [""]},
            "competitor without name": {"result": "بازنده", "comp_uid": ["new-1"], "comp_name": [""], "comp_price": ["500"],
                                        "comp_note": [""]},
            "product option not in list": {"prod_uid": ["new-1"], "prod_product_type": ["ناشناس"],
                                           "prod_size": [""], "prod_quantity": ["1"],
                                           "prod_model": [""], "prod_sample": [""]},
            "foreign row id": {"prod_uid": ["7"], "prod_product_type": ["شیر"], "prod_size": [""],
                               "prod_quantity": ["1"], "prod_model": [""], "prod_sample": [""]},
            "too long notes": {"notes": "x" * 2001},
        }
        for name, extra in cases.items():
            r = c.post("/cases/new", data=self.new_data(t, **extra))
            self.assertEqual(r.status_code, 400, name)
        self.assertEqual(self.count_cases(), 0)

    def test_empty_new_rows_are_ignored(self):
        c = self.login("entry1")
        t = self.token(c)
        c.post("/cases/new", data=self.new_data(
            t, prod_uid=["new-1"], prod_product_type=[""], prod_size=[""], prod_quantity=["0"],
            prod_model=[""], prod_sample=[""],
            comp_uid=["new-1"], comp_name=[""], comp_price=["0"], comp_note=[""]))
        self.assertEqual(self.count_cases(), 1)
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM case_products").fetchone()[0], 0)
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM case_competitors").fetchone()[0], 0)

    def test_form_page_contains_all_access_fields(self):
        html = self.login("entry1").get("/cases/new").get_data(as_text=True)
        for label in ("نوع پرونده", "شماره شناسنامه", "تاریخ دریافت", "منبع دریافت", "سازمان / شرکت",
                      "نام محصول", "سایز", "تعداد", "مدل", "نمونه", "نوع برگزاری", "وضعیت پرونده",
                      "مهلت ارسال", "ساعت مهلت ارسال", "تصمیم مدیریتی", "نتیجه",
                      "نام رقیب", "قیمت", "برنده شد", "یادداشت",
                      "ذخیره", "بستن", "فهرست پرونده‌ها", "محصولات را وارد کنید"):
            self.assertIn(label, html, label)
        # همه فیلدهای وابسته تا انتخاب نوع پرونده قفل‌اند
        markup = html.split("<script>")[0]          # خود کد جاوااسکریپت را نشماریم
        self.assertGreaterEqual(markup.count("data-needs-type"), 12)
        self.assertEqual(markup.count("data-needs-type disabled"), markup.count("data-needs-type"))


class DatePickerTests(FormBase):
    def test_form_uses_calendar_picker_not_typed_example_dates(self):
        c = self.login("entry1")
        html = c.get("/cases/new").get_data(as_text=True)
        self.assertIn("jdatepicker.js", html)
        self.assertEqual(html.count('class="jdate"'), 5)             # اعلان آگهی، دریافت، مهلت ارسال، اعلام نتایج، بازگشایی
        self.assertNotIn("۱۴۰۵/۰۷/۱۶", html)                         # تاریخ نمونه داخل فیلد نیست
        js = c.get("/static/jdatepicker.js")
        self.assertEqual(js.status_code, 200)
        self.assertIn("jdp", js.get_data(as_text=True))

    def test_viewer_page_does_not_load_the_picker(self):
        create_case(self.db, "tender", self.entry, 1405)
        html = self.login("viewer1").get("/cases/1").get_data(as_text=True)
        self.assertNotIn("jdatepicker.js", html)


class EditTests(FormBase):
    def make_case(self, c=None):
        c = c or self.login("entry1")
        t = self.token(c)
        c.post("/cases/new", data=self.new_data(
            t, organization="شرکت الف",
            prod_uid=["new-1"], prod_product_type=["شیر"], prod_size=["۱ اینچ"], prod_quantity=["5"],
            prod_model=[""], prod_sample=[""],
            comp_uid=["new-1"], comp_name=["رقیب ۱"], comp_price=["100"], comp_note=[""]))
        return c

    def edit_data(self, c, case_id=1, **over):
        with c.session_transaction() as s:
            t = s["csrf"]
        case = case_data.load_case(self.db, case_id)
        data = {
            "csrf": t, "version": case["version"],
            "organization": case["organization"], "status": case["status"],
            "prod_uid": [str(p["id"]) for p in case["products"]],
            "prod_product_type": [p["product_type"] for p in case["products"]],
            "prod_size": [p["size"] for p in case["products"]],
            "prod_quantity": [str(p["quantity"]) for p in case["products"]],
            "prod_model": [p["model"] for p in case["products"]],
            "prod_sample": [p["sample"] for p in case["products"]],
            "comp_uid": [str(x["id"]) for x in case["competitors"]],
            "comp_name": [x["name"] for x in case["competitors"]],
            "comp_price": [str(x["price"]) for x in case["competitors"]],
            "comp_note": [x["note"] for x in case["competitors"]],
        }
        data.update(over)
        return data

    def test_edit_updates_fields_and_adds_rows_but_keeps_number(self):
        c = self.make_case()
        self.token(c, "/cases/1")
        d = self.edit_data(c, status="ارسال شد", result="برنده")
        d["prod_uid"] = d["prod_uid"] + ["new-9"]
        d["prod_product_type"] += ["لوله"]; d["prod_size"] += [""]; d["prod_quantity"] += ["2"]
        d["prod_model"] += [""]; d["prod_sample"] += [""]
        r = c.post("/cases/1", data=d)
        self.assertEqual(r.status_code, 302)
        row = self.case_row()
        self.assertEqual((row["case_type"], row["serial_no"]), ("tender", 1))   # نوع و شماره (بدون تغییر نوع) ثابت
        self.assertEqual((row["status"], row["result"]), ("نتیجه اعلام شد", "برنده"))
        self.assertEqual(row["version"], 2)
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM case_products").fetchone()[0], 2)

    def test_two_users_editing_the_same_case_never_overwrite_each_other(self):
        self.make_case()
        a, b = self.login("entry1"), self.login("entry2")
        self.token(a, "/cases/1"); self.token(b, "/cases/1")
        da, db_ = self.edit_data(a, status="ارسال شد"), self.edit_data(b, status="در حال بررسی",
                                                                       organization="شرکت ب")
        self.assertEqual(a.post("/cases/1", data=da).status_code, 302)       # اولی ذخیره می‌شود
        r = b.post("/cases/1", data=db_)                                       # دومی با نسخه کهنه
        self.assertEqual(r.status_code, 409)
        self.assertIn("کاربر دیگری", r.get_data(as_text=True))
        row = self.case_row()
        self.assertEqual((row["status"], row["organization"]), ("ارسال شد", "شرکت الف"))  # تغییر دومی نیامد

    def test_conflict_rolls_back_everything_including_rows(self):
        self.make_case()
        a, b = self.login("entry1"), self.login("entry2")
        self.token(a, "/cases/1"); self.token(b, "/cases/1")
        a.post("/cases/1", data=self.edit_data(a, status="ارسال شد"))
        stale = self.edit_data(b, status="در حال بررسی")
        stale["prod_uid"] = stale["prod_uid"] + ["new-1"]
        stale["prod_product_type"] += ["لوله"]; stale["prod_size"] += [""]; stale["prod_quantity"] += ["9"]
        stale["prod_model"] += [""]; stale["prod_sample"] += [""]
        stale["version"] = 1
        self.assertEqual(b.post("/cases/1", data=stale).status_code, 409)
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM case_products").fetchone()[0], 1)

    def test_saved_rows_cannot_be_blanked(self):
        c = self.make_case()
        self.token(c, "/cases/1")
        d = self.edit_data(c)
        d.update(prod_product_type=[""], prod_size=[""], prod_quantity=["0"])
        r = c.post("/cases/1", data=d)
        self.assertEqual(r.status_code, 400)
        self.assertIn("خالی", r.get_data(as_text=True))
        self.assertEqual(self.db.execute("SELECT quantity FROM case_products").fetchone()[0], 5)

    def test_cannot_touch_rows_of_another_case(self):
        c = self.make_case()
        self.make_case(c)            # پرونده دوم
        foreign_product_id = self.db.execute(
            "SELECT id FROM case_products WHERE case_id = 1").fetchone()[0]
        self.token(c, "/cases/2")
        d = self.edit_data(c, case_id=2)
        d["prod_uid"] = [str(foreign_product_id)]
        d.update(prod_product_type=["لوله"], prod_size=[""], prod_quantity=["99"],
                 prod_model=[""], prod_sample=[""])
        self.assertEqual(c.post("/cases/2", data=d).status_code, 400)
        self.assertEqual(self.db.execute(
            "SELECT quantity FROM case_products WHERE id = ?", (foreign_product_id,)).fetchone()[0], 5)

    def test_edit_requires_csrf_and_version(self):
        c = self.make_case()
        self.token(c, "/cases/1")
        d = self.edit_data(c)
        no_csrf = dict(d); no_csrf.pop("csrf")
        self.assertEqual(c.post("/cases/1", data=no_csrf).status_code, 400)
        no_version = dict(d); no_version.pop("version")
        self.assertEqual(c.post("/cases/1", data=no_version).status_code, 400)

    def test_missing_case_is_404(self):
        self.assertEqual(self.login("entry1").get("/cases/999").status_code, 404)

    def test_viewer_sees_read_only_page_and_cannot_post(self):
        self.make_case()
        v = self.login("viewer1")
        v.get("/")                                   # پاپ‌آپ خوش‌آمد (و اسکریپتش) فقط یک بار، همین‌جا مصرف می‌شود
        html = v.get("/cases/1").get_data(as_text=True)
        self.assertIn("شرکت الف", html)
        self.assertNotIn('id="save-btn"', html)
        self.assertNotIn("getElementById('case-form')", html)         # اسکریپت فرم ویرایش برای بیننده نیست
        self.assertIn("فقط اجازه مشاهده", html)
        with v.session_transaction() as s:
            t = s["csrf"]
        self.assertEqual(v.post("/cases/1", data={"csrf": t, "version": 1}).status_code, 403)
        self.assertEqual(self.case_row()["version"], 1)

    def test_deactivated_option_keeps_old_cases_editable(self):
        c = self.make_case()
        oid = self.db.execute("SELECT id FROM options WHERE label = 'شرکت الف'").fetchone()[0]
        options.set_active(self.db, oid, False)
        self.token(c, "/cases/1")
        self.assertEqual(c.post("/cases/1", data=self.edit_data(c, status="ارسال شد")).status_code, 302)
        # ولی برای پرونده جدید دیگر مجاز نیست
        t = self.token(c)
        self.assertEqual(c.post("/cases/new", data=self.new_data(t, organization="شرکت الف")).status_code, 400)


class ListTests(FormBase):
    def test_filter_and_search(self):
        c = self.login("entry1")
        t = self.token(c)
        c.post("/cases/new", data=self.new_data(t, organization="شرکت الف"))
        c.post("/cases/new", data=self.new_data(t, case_type="inquiry", organization="شرکت ب"))
        html = c.get("/cases?type=inquiry").get_data(as_text=True)
        self.assertIn("شرکت ب", html)
        self.assertNotIn("شرکت الف", html)
        html = c.get("/cases?q=الف").get_data(as_text=True)
        self.assertIn("شرکت الف", html)
        self.assertNotIn("شرکت ب", html)
        self.assertEqual(c.get("/cases?q=%25").status_code, 200)       # علامت % جستجوی ویژه نیست


class OptionsAdminTests(FormBase):
    def test_only_admin_can_manage_options(self):
        for user in ("entry1", "viewer1"):
            self.assertEqual(self.login(user).get("/admin/options").status_code, 403)
        a = self.login("admin1")
        self.assertEqual(a.get("/admin/options").status_code, 200)
        t = self.token(a, "/admin/options")
        r = a.post("/admin/options", data={"csrf": t, "action": "add", "grp": "model", "lines": "A1\n\nA1\n  B2  "})
        self.assertEqual(r.status_code, 302)
        self.assertEqual(options.active_labels(self.db, "model"), ["A۱", "B۲"])      # تکراری و خالی نیامد
        self.assertEqual(a.post("/admin/options", data={"action": "add", "grp": "model", "lines": "Z"}).status_code, 400)
        self.assertEqual(a.post("/admin/options", data={"csrf": t, "action": "add", "grp": "bogus", "lines": "Z"}).status_code, 400)

    def test_disable_and_enable(self):
        a = self.login("admin1")
        t = self.token(a, "/admin/options")
        oid = self.db.execute("SELECT id FROM options WHERE label = 'ایمیل'").fetchone()[0]
        a.post("/admin/options", data={"csrf": t, "action": "disable", "option_id": oid, "grp": "source"})
        self.assertNotIn("ایمیل", options.active_labels(self.db, "source"))
        a.post("/admin/options", data={"csrf": t, "action": "enable", "option_id": oid, "grp": "source"})
        self.assertIn("ایمیل", options.active_labels(self.db, "source"))

    def test_options_cannot_be_deleted_in_database(self):
        with self.assertRaises(sqlite3.DatabaseError):
            self.db.execute("DELETE FROM options")

    def test_default_result_options_exist(self):
        self.assertEqual(options.active_labels(self.db, "result"), ["برنده", "بازنده"])


class NoDeletionTests(FormBase):
    def test_rows_cannot_be_deleted_in_database(self):
        c = self.login("entry1")
        t = self.token(c)
        c.post("/cases/new", data=self.new_data(
            t, prod_uid=["new-1"], prod_product_type=["شیر"], prod_size=[""], prod_quantity=["1"],
            prod_model=[""], prod_sample=[""],
            result="بازنده", comp_uid=["new-1"], comp_name=["x"], comp_price=["1"], comp_note=[""]))
        for table in ("case_products", "case_competitors", "cases"):
            with self.assertRaises(sqlite3.DatabaseError):
                self.db.execute(f"DELETE FROM {table}")


class BackupTests(FormBase):
    def test_backup_contains_the_saved_cases(self):
        import backup
        create_case(self.db, "tender", self.entry, 1405)
        with tempfile.TemporaryDirectory() as d:
            path = backup.make_backup(self.app.config["DATABASE"], d)
            self.assertTrue(os.path.exists(path))
            copy = connect(path)
            self.assertEqual(copy.execute("SELECT COUNT(*) FROM cases").fetchone()[0], 1)
            copy.close()

    def test_backup_of_missing_database_gives_clear_error(self):
        import backup
        with self.assertRaises(FileNotFoundError):
            backup.make_backup("/nonexistent/cases.sqlite", tempfile.gettempdir())


class UpgradeFromVersion1Tests(unittest.TestCase):
    """دیتابیس نسخه ۱ (که کاربر الان روی مک دارد) باید با اطلاعاتش به نسخه جدید ارتقا پیدا کند."""
    V1_SCHEMA = """
    CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL UNIQUE,
        password_hash TEXT NOT NULL, role TEXT NOT NULL CHECK (role IN ('admin','entry','viewer')),
        created_at TEXT NOT NULL DEFAULT (datetime('now')));
    CREATE TABLE counters (case_type TEXT NOT NULL, year INTEGER NOT NULL, last_no INTEGER NOT NULL,
        PRIMARY KEY (case_type, year));
    CREATE TABLE cases (id INTEGER PRIMARY KEY AUTOINCREMENT, case_type TEXT NOT NULL, year INTEGER NOT NULL,
        serial_no INTEGER NOT NULL, created_by INTEGER NOT NULL REFERENCES users(id),
        created_at TEXT NOT NULL DEFAULT (datetime('now')), UNIQUE (case_type, year, serial_no));
    CREATE TRIGGER cases_no_delete BEFORE DELETE ON cases BEGIN SELECT RAISE(ABORT, 'x'); END;
    CREATE TRIGGER cases_no_renumber BEFORE UPDATE OF case_type, year, serial_no ON cases
        BEGIN SELECT RAISE(ABORT, 'x'); END;
    """

    def test_upgrade_keeps_data_and_numbering(self):
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, "old.sqlite")
            old = sqlite3.connect(path)
            old.executescript(self.V1_SCHEMA)
            old.execute("INSERT INTO users (username, password_hash, role) VALUES ('ali', 'h', 'entry')")
            old.execute("INSERT INTO counters VALUES ('tender', 1405, 2)")
            old.execute("INSERT INTO cases (case_type, year, serial_no, created_by) VALUES ('tender',1405,1,1)")
            old.execute("INSERT INTO cases (case_type, year, serial_no, created_by) VALUES ('tender',1405,2,1)")
            old.commit(); old.close()

            init_db(path)
            init_db(path)                       # دوبار اجرا هم مشکلی ندارد

            conn = connect(path)
            cols = {r["name"] for r in conn.execute("PRAGMA table_info(cases)")}
            for col in ("organization", "notes", "version", "received_date", "result"):
                self.assertIn(col, cols)
            self.assertEqual(conn.execute("SELECT COUNT(*) FROM cases").fetchone()[0], 2)
            case = case_data.load_case(conn, 1)
            self.assertEqual((case["serial_no"], case["organization"], case["version"]), (1, "", 1))
            # شماره‌گذاری از جایی که بود ادامه پیدا می‌کند
            self.assertEqual(create_case(conn, "tender", 1, 1405)["serial_no"], 3)
            self.assertEqual(options.active_labels(conn, "result"), ["برنده", "بازنده"])
            conn.close()


if __name__ == "__main__":
    unittest.main()


class FieldRulesTests(FormBase):
    """قوانین جدید: علت بایگانی، رقبا فقط برای بازنده، ساعت، بازگشایی شمسی، مرتب‌سازی لیست."""

    def post_new(self, c, **over):
        t = self.token(c)
        return c.post("/cases/new", data=self.new_data(t, **over))

    def test_archive_requires_reason_and_reason_is_remembered(self):
        c = self.login("entry1")
        self.assertEqual(self.post_new(c, decision="عدم تایید و بایگانی").status_code, 400)
        self.assertEqual(self.count_cases(), 0)
        r = self.post_new(c, decision="عدم تایید و بایگانی", archive_reason="  مهلت  گذشته  ")
        self.assertEqual(r.status_code, 302)
        self.assertEqual(self.case_row()["archive_reason"], "مهلت گذشته")
        self.assertIn("مهلت گذشته", options.active_labels(self.db, "archive_reason"))
        # در پرونده بعدی به‌صورت گزینه آماده است
        html = c.get("/cases/new").get_data(as_text=True)
        self.assertIn('<option value="مهلت گذشته"', html)

    def test_reason_is_cleared_when_not_archived(self):
        c = self.login("entry1")
        self.post_new(c, decision="عدم تایید و بایگانی", archive_reason="علت الف")
        t = self.token(c, "/cases/1")
        v = self.case_row()["version"]
        r = c.post("/cases/1", data={"csrf": t, "version": v, "decision": "", "archive_reason": "علت الف"})
        self.assertEqual(r.status_code, 302)
        self.assertEqual(self.case_row()["archive_reason"], "")
        self.assertIn("علت الف", options.active_labels(self.db, "archive_reason"))   # لیست علت‌ها حفظ می‌شود

    def test_archive_option_always_exists(self):
        self.assertIn("عدم تایید و بایگانی", options.active_labels(self.db, "decision"))
        self.assertIn("بازنده", options.active_labels(self.db, "result"))

    def test_competitors_only_saved_for_loser(self):
        c = self.login("entry1")
        rows = dict(comp_uid=["new-1"], comp_name=["رقیب"], comp_price=["5"], comp_note=[""])
        self.post_new(c, result="برنده", **rows)
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM case_competitors").fetchone()[0], 0)
        self.post_new(c, result="بازنده", **rows)
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM case_competitors").fetchone()[0], 1)

    def test_saved_competitors_survive_result_change_and_show_again(self):
        c = self.login("entry1")
        self.post_new(c, result="بازنده", comp_uid=["new-1"], comp_name=["رقیب مهم"],
                      comp_price=["5"], comp_note=[""])
        t = self.token(c, "/cases/1")
        v = self.case_row()["version"]
        # نتیجه عوض می‌شود؛ بخش رقبا در فرم نبوده پس چیزی ارسال نمی‌شود
        self.assertEqual(c.post("/cases/1", data={"csrf": t, "version": v, "result": "برنده"}).status_code, 302)
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM case_competitors").fetchone()[0], 1)
        html = c.get("/cases/1").get_data(as_text=True)
        self.assertIn('id="box-competitors"', html)
        self.assertRegex(html, r'id="box-competitors"[^>]*hidden')       # پنهان
        self.assertIn("رقیب مهم", html)                                  # ولی از بین نرفته

    def test_conditional_boxes_visibility_in_page(self):
        c = self.login("entry1")
        self.post_new(c, decision="عدم تایید و بایگانی", archive_reason="x", result="بازنده")
        html = c.get("/cases/1").get_data(as_text=True)
        self.assertNotRegex(html, r'id="box-archive"[^>]*hidden')
        self.assertRegex(html, r'id="box-competitors"[^>]*hidden')      # عدم‌تایید: نتیجه ندارد، پس رقبا هم نیست
        self.post_new(c)
        html = c.get("/cases/2").get_data(as_text=True)
        self.assertRegex(html, r'id="box-archive"[^>]*hidden')

    def test_field_order_in_form(self):
        html = self.login("entry1").get("/cases/new").get_data(as_text=True).split("<script>")[0]
        order = ["نوع برگزاری", "تصمیم مدیریتی", "علت بایگانی",
                 "وضعیت پرونده", ">نتیجه<", "رقیب / رقبا"]
        pos = [html.index(x, html.index("cols5")) for x in order]
        self.assertEqual(pos, sorted(pos))

    def test_persian_digits_in_quantity_saved_correctly(self):
        c = self.login("entry1")
        t = self.token(c)
        c.post("/cases/new", data=self.new_data(
            t, prod_uid=["new-1", "new-2"], prod_product_type=["شیر", "شیر"], prod_size=["", ""],
            prod_quantity=["۸۹۹", "۱,۲۰۰"], prod_model=["", ""], prod_sample=["", ""]))
        qs = [r[0] for r in self.db.execute("SELECT quantity FROM case_products ORDER BY id")]
        self.assertEqual(qs, [899, 1200])

    def test_time_and_opening_date_validation(self):
        c = self.login("entry1")
        self.assertEqual(self.post_new(c, send_deadline="۱۴۰۵/۱۲/۲۰", physical_upload="25:99").status_code, 400)
        self.assertEqual(self.post_new(c, opening_time="سلام").status_code, 400)
        self.assertEqual(self.count_cases(), 0)
        self.post_new(c, send_deadline="۱۴۰۵/۱۲/۲۰", physical_upload="۹:05", opening_time="۱۴۰۵/۱۲/۲۹")
        row = self.case_row()
        self.assertEqual((row["physical_upload"], row["opening_time"]), ("۰۹:۰۵", "۱۴۰۵/۱۲/۲۹"))

    def test_old_free_text_values_stay_editable(self):
        c = self.login("entry1")
        self.post_new(c)
        self.db.execute("UPDATE cases SET send_deadline='۱۴۰۵/۰۸/۰۱', physical_upload='با پیک', opening_time='ظهر' WHERE id=1")
        t = self.token(c, "/cases/1")
        v = self.case_row()["version"]
        r = c.post("/cases/1", data={"csrf": t, "version": v, "send_deadline": "۱۴۰۵/۰۸/۰۱", "physical_upload": "با پیک",
                                      "opening_time": "ظهر", "notes": "n"})
        self.assertEqual(r.status_code, 302)

    def test_list_sorting_is_whitelisted_and_works(self):
        c = self.login("entry1")
        self.post_new(c, organization="شرکت ب", send_deadline="1405/09/01")
        self.post_new(c, organization="شرکت الف", send_deadline="1405/08/01")
        self.post_new(c, organization="")
        html = c.get("/cases?sort=deadline&dir=asc").get_data(as_text=True)
        self.assertLess(html.index("۱۴۰۵/۰۸/۰۱"), html.index("۱۴۰۵/۰۹/۰۱"))
        html = c.get("/cases?sort=deadline&dir=desc").get_data(as_text=True)
        self.assertLess(html.index("۱۴۰۵/۰۹/۰۱"), html.index("۱۴۰۵/۰۸/۰۱"))
        html = c.get("/cases?sort=org&dir=asc").get_data(as_text=True)
        self.assertLess(html.index("شرکت الف"), html.index("شرکت ب"))
        for bad in ("sort=1;DROP TABLE cases", "sort=c.id&dir=asc", "sort=&dir=zzz"):
            self.assertEqual(c.get("/cases?" + bad).status_code, 200)
        self.assertEqual(self.count_cases(), 3)
        for col in ("نوع پرونده", "شماره شناسنامه", "تاریخ دریافت", "مهلت ارسال", "وضعیت پرونده", "سازمان", "تصمیم مدیریتی", "ویرایش"):
            self.assertIn(col, html)


class PickerBugRegressionTests(FormBase):
    def test_picker_keeps_month_year_lists_usable_and_open(self):
        js = self.login("entry1").get("/static/jdatepicker.js").get_data(as_text=True)
        self.assertIn("SELECT|OPTION", js)     # لیست ماه/سال نباید با preventDefault قفل شود
        self.assertIn("jdpHandled", js)        # کلیک روی فلش‌ها نباید تقویم را ببندد


class FlexibleMatchTests(FormBase):
    def test_archived_variants_also_show_reason_field(self):
        options.add_labels(self.db, "decision", "عدم تایید و بايگانی شد")        # با «ي» عربی؛ فارسی‌سازی می‌شود
        self.assertIn("عدم تایید و بایگانی شد", options.active_labels(self.db, "decision"))
        c = self.login("entry1")
        t = self.token(c)
        self.assertEqual(c.post("/cases/new", data=self.new_data(t, decision="عدم تایید و بایگانی شد")).status_code, 400)
        r = c.post("/cases/new", data=self.new_data(t, decision="عدم تایید و بایگانی شد", archive_reason="علت"))
        self.assertEqual(r.status_code, 302)
        html = c.get("/cases/1").get_data(as_text=True)
        self.assertNotRegex(html, r'id="box-archive"[^>]*hidden')


class ResetDataTests(FormBase):
    def test_reset_empties_cases_keeps_users_and_options_and_backs_up(self):
        import reset_data, tempfile
        c = self.login("entry1")
        t = self.token(c)
        c.post("/cases/new", data=self.new_data(t, organization="شرکت الف"))
        self.assertEqual(self.count_cases(), 1)
        path = self.app.config["DATABASE"]
        folder = tempfile.mkdtemp()
        self.db.close()
        self.assertIsNotNone(reset_data.reset(path, folder, ask=lambda _: "YES"))
        db = sqlite3.connect(path)
        self.assertEqual(db.execute("SELECT COUNT(*) FROM cases").fetchone()[0], 0)
        self.assertEqual(db.execute("SELECT COUNT(*) FROM counters").fetchone()[0], 0)
        self.assertGreaterEqual(db.execute("SELECT COUNT(*) FROM users").fetchone()[0], 1)
        self.assertEqual(db.execute("SELECT COUNT(*) FROM options WHERE label='شرکت الف'").fetchone()[0], 1)
        db.close()
        backup = [f for f in os.listdir(folder)][0]
        b = sqlite3.connect(os.path.join(folder, backup))
        self.assertEqual(b.execute("SELECT COUNT(*) FROM cases").fetchone()[0], 1)    # بکاپ کامل
        b.close()
        # بدون تأیید هیچ اتفاقی نمی‌افتد
        self.assertIsNone(reset_data.reset(path, folder, ask=lambda _: "no"))

    def test_after_reset_numbering_restarts_at_one(self):
        import reset_data, tempfile
        c = self.login("entry1")
        t = self.token(c)
        c.post("/cases/new", data=self.new_data(t))
        c.post("/cases/new", data=self.new_data(t))
        self.db.close()
        reset_data.reset(self.app.config["DATABASE"], tempfile.mkdtemp(), ask=lambda _: "YES")
        c = self.login("entry1")
        t = self.token(c)
        c.post("/cases/new", data=self.new_data(t))
        db = sqlite3.connect(self.app.config["DATABASE"])
        self.assertEqual(db.execute("SELECT serial_no FROM cases").fetchone()[0], 1)
        db.close()


class InAppBackupTests(FormBase):
    def setUp(self):
        super().setUp()
        self.home = os.path.join(self.tmp.name, "home")
        os.makedirs(self.home)
        patcher = mock.patch.dict(os.environ, {"HOME": self.home, "USERPROFILE": self.home})
        patcher.start()
        self.addCleanup(patcher.stop)
        self.bdir = os.path.join(self.tmp.name, "bk")
        self.extra = os.path.join(self.tmp.name, "dropbox")
        os.makedirs(self.extra)
        self.app.config["BACKUP_DIR"] = self.bdir
        self.app.config["BACKUP_SETTINGS_FILE"] = os.path.join(self.tmp.name, "s.json")

    def admin_login(self):
        c = self.login("admin1")
        return c, self.token(c, "/admin/backup")

    def test_only_admin_sees_backup_page(self):
        self.assertEqual(self.login("entry1").get("/admin/backup").status_code, 403)
        self.assertEqual(self.login("viewer1").get("/admin/backup/download/cases-2026-01-01_00-00-00.sqlite").status_code, 403)
        self.assertEqual(self.login("admin1").get("/admin/backup").status_code, 200)

    def test_user_chooses_main_folder_and_extra_folders(self):
        c, t = self.admin_login()
        chosen = os.path.join(self.tmp.name, "my", "chosen")           # پوشهٔ دلخواه (ساخته می‌شود)
        os.makedirs(os.path.dirname(chosen))
        c.post("/admin/backup", data={"csrf": t, "action": "settings", "dir": chosen,
                                      "folders": self.extra + "\n/no/such/dir"})
        c.post("/admin/backup", data={"csrf": t, "action": "run"})
        self.assertEqual(len(os.listdir(chosen)), 1)                   # پوشهٔ اصلی انتخابی
        self.assertEqual(len(os.listdir(self.extra)), 1)               # نسخهٔ اضافه
        self.assertFalse(os.path.exists(self.bdir))                    # پوشهٔ پیش‌فرض استفاده نشد
        name = os.listdir(chosen)[0]
        self.assertIn(name, c.get("/admin/backup").get_data(as_text=True))
        d = c.get("/admin/backup/download/" + name)
        self.assertTrue(d.data.startswith(b"SQLite format 3"))
        d.close()
        self.assertEqual(c.get("/admin/backup/download/..%2Fetc%2Fpasswd").status_code, 404)
        self.assertEqual(c.get("/admin/backup/download/evil.sqlite").status_code, 404)

    def test_onedrive_and_dropbox_are_active_by_default(self):
        os.makedirs(os.path.join(self.home, "Dropbox"))
        os.makedirs(os.path.join(self.home, "Library", "CloudStorage", "OneDrive-Company"))
        c, t = self.admin_login()
        c.post("/admin/backup", data={"csrf": t, "action": "run"})
        for base in (os.path.join(self.home, "Dropbox"),
                     os.path.join(self.home, "Library", "CloudStorage", "OneDrive-Company")):
            files = os.listdir(os.path.join(base, "IranEnsheab-Backups"))
            self.assertEqual(len(files), 1, base)
        html = c.get("/admin/backup").get_data(as_text=True)
        self.assertIn("Dropbox", html)

    def test_restore_from_list_brings_old_data_back_and_keeps_safety_copy(self):
        c = self.login("admin1")
        t = self.token(c, "/admin/backup")
        c.post("/cases/new", data=self.new_data(t, organization="شرکت الف"))     # پرونده ۱
        c.post("/admin/backup", data={"csrf": t, "action": "run"})
        name = os.listdir(self.bdir)[0]
        c.post("/cases/new", data=self.new_data(t, organization="شرکت ب"))        # پرونده ۲، بعد از بکاپ
        self.assertEqual(self.count_cases(), 2)
        r = c.post("/admin/backup", data={"csrf": t, "action": "restore", "name": name, "confirm": "YES"})
        self.assertEqual(r.status_code, 302)
        self.assertEqual(self.count_cases(), 1)
        files = sorted(os.listdir(self.bdir))
        self.assertEqual(len(files), 2)                                         # بکاپ ایمنی ساخته شد
        counts = []
        for f in files:
            conn = sqlite3.connect(os.path.join(self.bdir, f))
            counts.append(conn.execute("SELECT COUNT(*) FROM cases").fetchone()[0])
            conn.close()
        self.assertEqual(sorted(counts), [1, 2])               # بکاپ قبلی (۱ پرونده) + نسخهٔ ایمنی (۲ پرونده)
        # برنامه بعد از بازگردانی سالم کار می‌کند و شماره‌گذاری ادامه می‌دهد
        c = self.login("admin1")
        t = self.token(c)
        c.post("/cases/new", data=self.new_data(t))
        self.assertEqual(self.db.execute("SELECT MAX(serial_no) FROM cases").fetchone()[0], 2)

    def test_restore_needs_yes_and_valid_name(self):
        c, t = self.admin_login()
        c.post("/admin/backup", data={"csrf": t, "action": "run"})
        name = os.listdir(self.bdir)[0]
        c.post("/cases/new", data=self.new_data(t))
        c.post("/admin/backup", data={"csrf": t, "action": "restore", "name": name, "confirm": "no"})
        self.assertEqual(self.count_cases(), 1)                                  # بدون YES تغییری نیست
        r = c.post("/admin/backup", data={"csrf": t, "action": "restore", "name": "../x.sqlite", "confirm": "YES"})
        self.assertEqual(r.status_code, 400)
        self.assertEqual(self.count_cases(), 1)

    def test_restore_from_uploaded_file_and_rejects_garbage(self):
        import io
        c, t = self.admin_login()
        c.post("/admin/backup", data={"csrf": t, "action": "run"})
        good = open(os.path.join(self.bdir, os.listdir(self.bdir)[0]), "rb").read()
        c.post("/cases/new", data=self.new_data(t))
        self.assertEqual(self.count_cases(), 1)
        # فایل خراب: اطلاعات فعلی دست‌نخورده می‌ماند
        c.post("/admin/backup", data={"csrf": t, "action": "restore", "confirm": "YES",
                                      "file": (io.BytesIO(b"this is not a database"), "x.sqlite")},
               content_type="multipart/form-data")
        self.assertEqual(self.count_cases(), 1)
        # فایل سالم
        c.post("/admin/backup", data={"csrf": t, "action": "restore", "confirm": "YES",
                                      "file": (io.BytesIO(good), "old.sqlite")},
               content_type="multipart/form-data")
        self.assertEqual(self.count_cases(), 0)
        self.assertEqual([f for f in os.listdir(self.bdir) if f.endswith(".sqlite") and not f.startswith("cases-")], [])

    def test_backup_when_app_opens_and_daily(self):
        folder = os.path.join(self.tmp.name, "auto")
        app = create_app({"TESTING": True, "SECRET_KEY": "x", "AUTO_BACKUP": True,
                          "DATABASE": self.app.config["DATABASE"], "BACKUP_DIR": folder,
                          "BACKUP_SETTINGS_FILE": os.path.join(self.tmp.name, "s2.json")})
        self.assertEqual(len(os.listdir(folder)), 1)               # هنگام باز شدن برنامه
        c = app.test_client()
        c.get("/login")
        c.get("/login")
        self.assertEqual(len(os.listdir(folder)), 1)               # همان روز دوباره نمی‌سازد


class SeedOptionsTests(FormBase):
    def test_organizations_from_access_are_loaded_once_without_duplicates(self):
        from app.seed_options import SEED_OPTIONS
        orgs = SEED_OPTIONS["organization"]
        self.assertEqual(len(orgs), 38)
        self.assertEqual(len(set(orgs)), 38)
        self.assertIn("شرکت آب و فاضلاب استان سمنان", options.active_labels(self.db, "organization"))
        n = self.db.execute("SELECT COUNT(*) FROM options WHERE grp='organization'").fetchone()[0]
        self.assertGreaterEqual(n, 38)
        # باز شدن دوباره برنامه چیزی را تکراری نمی‌کند و گزینهٔ غیرفعال‌شده را فعال نمی‌کند
        self.db.execute("UPDATE options SET active=0 WHERE label=?", (orgs[0],))
        init_db(self.app.config["DATABASE"])
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM options WHERE grp='organization'").fetchone()[0], n)
        self.assertNotIn(orgs[0], options.active_labels(self.db, "organization"))


class SearchableComboTests(FormBase):
    def test_form_loads_search_script_and_keeps_real_selects_for_submission(self):
        c = self.login("entry1")
        html = c.get("/cases/new").get_data(as_text=True)
        self.assertIn("searchable-select.js", html)
        js = c.get("/static/searchable-select.js")
        self.assertEqual(js.status_code, 200)
        text = js.get_data(as_text=True)
        js.close()
        self.assertIn("ي", text)                                # جستجو ی/ي عربی را یکی می‌گیرد
        self.assertIn('name="organization"', html)             # خود select برای ارسال فرم سر جایش است
        # فرم برای بیننده (فقط‌خواندنی) اسکریپت را نمی‌گیرد
        self.assertNotIn("searchable-select.js", self.login("viewer1").get("/cases/new").get_data(as_text=True))


class QuickAddOptionTests(FormBase):
    def post_add(self, c, t, grp, label):
        return c.post("/api/options/add", data={"csrf": t, "grp": grp, "label": label})

    def test_plus_button_adds_option_for_next_cases_without_duplicates(self):
        c = self.login("entry1")
        t = self.token(c)
        r = self.post_add(c, t, "size", "  ۲۲   اینچ ")
        self.assertEqual(r.get_json(), {"ok": True, "label": "۲۲ اینچ", "existed": False})
        self.assertTrue(self.post_add(c, t, "size", "۲۲ اینچ").get_json()["existed"])
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM options WHERE grp='size' AND label='۲۲ اینچ'").fetchone()[0], 1)
        # بلافاصله قابل ذخیره در پرونده است
        self.assertEqual(c.post("/cases/new", data=self.new_data(t, prod_uid=["new-1"], prod_size=["۲۲ اینچ"],
                         prod_product_type=[""], prod_quantity=["1"], prod_model=[""], prod_sample=[""])).status_code, 302)
        self.assertIn("۲۲ اینچ", c.get("/cases/new").get_data(as_text=True))

    def test_plus_button_rules(self):
        c = self.login("entry1")
        t = self.token(c)
        self.assertEqual(self.post_add(c, t, "size", "   ").status_code, 400)
        self.assertEqual(self.post_add(c, t, "nope", "x").status_code, 400)
        self.assertEqual(self.post_add(c, t, "archive_reason", "علت آزمایشی").status_code, 200)
        self.assertEqual(c.post("/api/options/add", data={"grp": "size", "label": "x"}).status_code, 400)   # بدون CSRF
        v = self.login("viewer1")
        self.assertEqual(v.post("/api/options/add", data={"csrf": "x", "grp": "size", "label": "x"}).status_code, 403)
        html = c.get("/cases/new").get_data(as_text=True)
        self.assertIn('data-grp="organization"', html)
        self.assertIn('data-add-url="/api/options/add"', html)

    def test_access_lists_are_preloaded(self):
        for grp, n, sample in (("product_type", 15, "سیم پلمپ"), ("size", 18, "۲-۱.۲"),
                               ("tender_type", 3, "ارزیابی کیفی")):
            labels = options.active_labels(self.db, grp)
            self.assertGreaterEqual(len(labels), n, grp)
            self.assertIn(sample, labels)
        self.assertEqual(config.OPTION_GROUPS["tender_type"], "نوع برگزاری")


class RenameOptionTests(FormBase):
    def post_rename(self, c, t, grp, old, new):
        return c.post("/api/options/rename", data={"csrf": t, "grp": grp, "old": old, "label": new})

    def make_case(self, c, t, **extra):
        return c.post("/cases/new", data=self.new_data(t, **extra))

    def test_rename_updates_option_and_every_case_and_product_row(self):
        c = self.login("entry1")
        t = self.token(c)
        self.make_case(c, t, organization="شرکت الف", prod_uid=["new-1"], prod_size=["۱ اینچ"],
                       prod_product_type=[""], prod_quantity=["1"], prod_model=[""], prod_sample=[""])
        self.make_case(c, t, organization="شرکت الف")
        self.make_case(c, t, organization="شرکت ب")
        r = self.post_rename(c, t, "organization", "شرکت الف", "شرکت آلفا")
        self.assertEqual(r.get_json(), {"ok": True, "label": "شرکت آلفا", "updated": 2, "active": None})
        orgs = [r["organization"] for r in self.db.execute("SELECT organization FROM cases ORDER BY id")]
        self.assertEqual(orgs, ["شرکت آلفا", "شرکت آلفا", "شرکت ب"])
        self.assertIn("شرکت آلفا", options.active_labels(self.db, "organization"))
        self.assertNotIn("شرکت الف", options.active_labels(self.db, "organization"))
        self.assertEqual(self.post_rename(c, t, "size", "۱ اینچ", "یک اینچ").get_json()["updated"], 1)
        self.assertEqual(self.db.execute("SELECT size FROM case_products").fetchone()[0], "یک اینچ")
        # پرونده بعد از تغییر نام هنوز قابل ویرایش و ذخیره است
        t = self.token(c, "/cases/1")
        v = self.case_row()["version"]
        self.assertEqual(c.post("/cases/1", data={"csrf": t, "version": v, "organization": "شرکت آلفا"}).status_code, 302)

    def test_rename_rules(self):
        c = self.login("entry1")
        t = self.token(c)
        self.assertEqual(self.post_rename(c, t, "organization", "شرکت الف", "شرکت ب").status_code, 400)   # تکراری
        self.assertEqual(self.post_rename(c, t, "organization", "نیست", "x").status_code, 400)
        self.assertEqual(self.post_rename(c, t, "organization", "شرکت الف", "  ").status_code, 400)
        self.assertEqual(self.post_rename(c, t, "archive_reason", "a", "b").status_code, 400)
        self.assertEqual(c.post("/api/options/rename", data={"grp": "size", "old": "a", "label": "b"}).status_code, 400)
        v = self.login("viewer1")
        self.assertEqual(v.post("/api/options/rename", data={"csrf": "x"}).status_code, 403)
        self.assertEqual(self.post_rename(c, t, "organization", "شرکت الف", "شرکت الف").get_json()["updated"], 0)
        self.assertIn("شرکت الف", options.active_labels(self.db, "organization"))

    def test_renamed_seed_option_is_not_resurrected_on_restart(self):
        c = self.login("entry1")
        t = self.token(c)
        self.assertTrue(self.post_rename(c, t, "tender_type", "یک مرحله ای", "یک‌مرحله‌ای").get_json()["ok"])
        init_db(self.app.config["DATABASE"])                      # مثل باز شدن دوبارهٔ برنامه
        labels = options.active_labels(self.db, "tender_type")
        self.assertIn("یک‌مرحله‌ای", labels)
        self.assertNotIn("یک مرحله ای", labels)
        self.assertEqual(len(labels), 3)

    def test_form_has_rename_endpoint_for_js(self):
        html = self.login("entry1").get("/cases/new").get_data(as_text=True)
        self.assertIn('data-rename-url="/api/options/rename"', html)


class ProfilePopupTests(FormBase):
    make_case = EditTests.make_case

    def test_profile_save_report_and_prices(self):
        c = self.login("entry1"); self.make_case(c)
        t = self.token(c)
        pid = self.db.execute("SELECT id FROM case_products").fetchone()[0]
        data = {"csrf": t, "pversion": "0", "subject": "موضوع آزمایشی", "issue_date": "۱۴۰۵/۰۷/۰۸",
                "warranty": "3 سال", f"price_{pid}": "۱,۲۰۰"}
        r = c.post("/cases/1/profile", data=data)
        self.assertEqual(r.get_json()["version"], 1)
        row = self.db.execute("SELECT subject, issue_date FROM case_profile").fetchone()
        self.assertEqual((row[0], row[1]), ("موضوع آزمایشی", "۱۴۰۵/۰۷/۰۸"))
        self.assertEqual(self.db.execute("SELECT price FROM case_products").fetchone()[0], 1200)
        html = c.get("/cases/1/report").get_data(as_text=True)
        self.assertIn("موضوع آزمایشی", html)
        self.assertIn("۱,۲۰۰", html)
        self.assertIn("شرکت الف", html)

    def test_profile_conflict_bad_date_and_bad_option(self):
        c = self.login("entry1"); self.make_case(c)
        t = self.token(c)
        self.assertEqual(c.post("/cases/1/profile", data={"csrf": t, "pversion": "0"}).status_code, 200)
        self.assertEqual(c.post("/cases/1/profile", data={"csrf": t, "pversion": "0"}).status_code, 409)
        self.assertEqual(c.post("/cases/1/profile", data={"csrf": t, "pversion": "1", "issue_date": "سلام"}).status_code, 400)
        self.assertEqual(c.post("/cases/1/profile", data={"csrf": t, "pversion": "1", "advance": "نامعتبر"}).status_code, 400)
        self.assertEqual(c.post("/cases/1/profile", data={"pversion": "1"}).status_code, 400)   # بدون CSRF

    def test_viewer_cannot_save_profile(self):
        self.make_case(self.login("entry1"))
        v = self.login("viewer1")
        self.assertEqual(v.post("/cases/1/profile", data={"pversion": "0"}).status_code, 403)
        self.assertEqual(v.get("/cases/1/report").status_code, 200)

    def test_size_fraction_text_and_today(self):
        from app.profile import size_text
        from app.jalali import today_jalali
        from datetime import date
        self.assertEqual([size_text(x) for x in ("1.2", "1-1.4", "2-1.2", "2")], ["1/2", "1-1/4", "2-1/2", "2"])
        self.assertEqual(today_jalali(date(2026, 9, 30)), "1405/07/08")

    def test_popup_not_on_new_form(self):
        html = self.login("entry1").get("/cases/new").get_data(as_text=True)
        self.assertNotIn('id="pf-modal"', html)

    def test_pdf_report_and_list_column(self):
        c = self.login("entry1"); self.make_case(c)
        self.assertNotIn("✓ دارد", c.get("/cases").get_data(as_text=True))
        c.post("/cases/1/profile", data={"csrf": self.token(c), "pversion": "0", "subject": "موضوع"})
        self.assertIn("✓ دارد", c.get("/cases").get_data(as_text=True))
        r = c.get("/cases/1/report.pdf")
        self.assertEqual(r.mimetype, "application/pdf")
        self.assertTrue(r.data.startswith(b"%PDF"))
        r = c.post("/cases/1/report/open", data={"csrf": self.token(c)})
        self.assertTrue(r.get_json()["ok"])
        self.assertEqual(c.post("/cases/1/report/open", data={}).status_code, 400)

    def test_shaper_joins_letters(self):
        from app import pdfreport
        self.assertNotEqual(pdfreport.shape("سلام"), "سلام")
        self.assertEqual(pdfreport.visual(pdfreport.shape("1405/07/19"))[:4], "۱۴۰۵")


class SeatsAndUsersTests(FormBase):
    def test_third_editor_is_view_only(self):
        a, b, c = self.login("entry1"), self.login("entry2"), self.login("admin1")
        self.assertEqual(a.get("/cases/new").status_code, 200)
        self.assertEqual(b.get("/cases/new").status_code, 200)
        r = c.get("/cases/new")                       # ظرفیت ۲ پر است
        self.assertEqual(r.status_code, 302)
        self.make_case_via(a)
        r = c.get("/cases/1")
        html = r.get_data(as_text=True)
        self.assertIn("حالت فقط‌مشاهده", html)
        self.assertNotIn('id="save-btn"', html)
        # ذخیره هم رد می‌شود و اطلاعات تغییر نمی‌کند
        data = {"csrf": self.token(c, "/cases/1"), "version": "1", "organization": "شرکت ب"}
        self.assertEqual(c.post("/cases/1", data=data).status_code, 423)
        self.assertNotEqual(self.case_row()["organization"], "شرکت ب")

    def make_case_via(self, client):
        client.post("/cases/new", data=self.new_data(self.token(client), organization="شرکت الف"))

    def test_seat_freed_on_logout_and_timeout_and_admin_free(self):
        from app import seats
        a, b, c = self.login("entry1"), self.login("entry2"), self.login("admin1")
        a.get("/cases/new"); b.get("/cases/new")
        self.assertEqual(c.get("/cases/new").status_code, 302)
        with a.session_transaction() as s:
            t = s["csrf"]
        a.post("/logout", data={"csrf": t})                    # خروج -> جا آزاد
        self.assertEqual(c.get("/cases/new").status_code, 200)
        # بی‌فعالیتی: ۱۱ دقیقه قبل
        self.db.execute("UPDATE edit_seats SET last_seen = last_seen - 700")
        self.assertEqual(seats.holders(self.db), [])
        # آزاد کردن توسط مدیر
        b.get("/cases/new")
        ct = self.token(c, "/admin/users")
        c.post("/admin/users", data={"csrf": ct, "action": "free_seat", "user_id": str(self.entry2)})
        self.assertFalse(seats.has_seat(self.db, self.entry2))

    def test_viewer_never_gets_seat_and_ping(self):
        v = self.login("viewer1")
        self.assertEqual(v.get("/cases/new").status_code, 403)
        with v.session_transaction() as s:
            pass
        v.get("/")
        with v.session_transaction() as s:
            t = s["csrf"]
        self.assertFalse(v.post("/api/seat/ping", data={"csrf": t}).get_json()["held"])
        e = self.login("entry1"); e.get("/")
        with e.session_transaction() as s:
            t = s["csrf"]
        self.assertTrue(e.post("/api/seat/ping", data={"csrf": t}).get_json()["held"])
        self.assertEqual(e.post("/api/seat/ping", data={}).status_code, 400)

    def test_option_and_profile_endpoints_need_seat(self):
        a, b, c = self.login("entry1"), self.login("entry2"), self.login("admin1")
        self.make_case_via(a); b.get("/cases/new")
        with c.session_transaction() as s:
            s["csrf"] = "tok"
        c.get("/")
        with c.session_transaction() as s:
            t = s["csrf"]
        r = c.post("/api/options/add", data={"csrf": t, "grp": "source", "label": "x"})
        self.assertEqual(r.status_code, 423)
        r = c.post("/cases/1/profile", data={"csrf": t, "pversion": "0"})
        self.assertEqual(r.status_code, 423)

    def test_admin_user_management_rules(self):
        c = self.login("admin1"); t = self.token(c, "/admin/users")
        def post(**kw):
            return c.post("/admin/users", data={"csrf": t, **kw}, follow_redirects=True).get_data(as_text=True)
        self.assertIn("ساخته شد", post(action="create", username="ali", password="Abc12345", role="entry", full_name="علی"))
        self.assertIn("قبلاً ساخته", post(action="create", username="ALI", password="Abc12345", role="entry"))
        self.assertIn("حداقل ۸", post(action="create", username="bob", password="123", role="entry"))
        self.assertIn("نقش خودتان", post(action="set_role", user_id=str(self.admin), role="viewer"))
        self.assertIn("خودتان را", post(action="disable", user_id=str(self.admin)))
        # کاربر غیرفعال نمی‌تواند وارد شود و حذفی در کار نیست
        post(action="disable", user_id=str(self.viewer))
        cl = self.app.test_client(); cl.get("/login")
        with cl.session_transaction() as s:
            tk = s["csrf"]
        r = cl.post("/login", data={"username": "viewer1", "password": "secret1", "csrf": tk}, follow_redirects=True)
        self.assertIn("غیرفعال", r.get_data(as_text=True))
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM users WHERE username='viewer1'").fetchone()[0], 1)
        # تغییر رمز
        post(action="reset_password", user_id=str(self.entry), password="NewPass12")
        cl2 = self.app.test_client(); cl2.get("/login")
        with cl2.session_transaction() as s:
            tk = s["csrf"]
        self.assertEqual(cl2.post("/login", data={"username": "entry1", "password": "NewPass12", "csrf": tk}).status_code, 302)

    def test_last_admin_protected_and_non_admin_forbidden(self):
        from app import users
        with self.assertRaises(users.UserError):
            users.set_active(self.db, self.entry, self.admin, False)
        with self.assertRaises(users.UserError):
            users.set_role(self.db, self.entry, self.admin, "entry")
        self.assertEqual(self.login("entry1").get("/admin/users").status_code, 403)

    def test_max_editors_setting(self):
        from app import seats
        c = self.login("admin1"); t = self.token(c, "/admin/users")
        c.post("/admin/users", data={"csrf": t, "action": "set_max", "max_editors": "3"})
        self.assertEqual(seats.get_max(self.db), 3)
        c.post("/admin/users", data={"csrf": t, "action": "set_max", "max_editors": "99"})
        self.assertEqual(seats.get_max(self.db), 3)


class DashboardTests(FormBase):
    def seed(self, c):
        for org, result, rd in (("شرکت الف", "برنده", "1405/05/10"), ("شرکت الف", "بازنده", "1405/06/11"),
                                ("شرکت ب", "", "1405/06/20")):
            data = self.new_data(self.token(c), organization=org, result=result, received_date=rd,
                                 send_deadline="1405/07/20", prod_uid=["new-1"], prod_product_type=["شیر"],
                                 prod_size=[""], prod_quantity=["10"], prod_model=[""], prod_sample=[""])
            if result == "بازنده":
                data.update(comp_uid=["new-1"], comp_name=["رقیب ۱"], comp_price=["500"], comp_note=[""])
            self.assertEqual(c.post("/cases/new", data=data).status_code, 302)

    def test_dashboard_numbers_and_filters(self):
        from app import dashboard
        c = self.login("entry1"); self.seed(c)
        d = dashboard.build(self.db, {})
        k = d["kpi"]
        self.assertEqual((k["total"], k["won"], k["lost"], k["open"]), (3, 1, 1, 1))
        self.assertEqual(k["win_rate"], 50.0)
        self.assertEqual(k["qty"], 30)
        self.assertEqual(d["orgs"][0]["label"], "شرکت الف")
        self.assertEqual(d["competitors"][0]["name"], "رقیب ۱")
        self.assertEqual(sum(sum(s["values"]) for s in d["trend"]["series"]), 3)
        self.assertEqual(dashboard.build(self.db, {"org": "شرکت ب"})["kpi"]["total"], 1)
        self.assertEqual(dashboard.build(self.db, {"result": "برنده"})["kpi"]["total"], 1)
        self.assertEqual(dashboard.build(self.db, {"ym": "1405/06"})["kpi"]["total"], 2)
        self.assertEqual(dashboard.build(self.db, {"year": "1404"})["kpi"]["total"], 0)
        self.assertEqual(dashboard.build(self.db, {"type": "bogus"})["kpi"]["total"], 3)   # فیلتر نامعتبر نادیده

    def test_dashboard_api_and_page(self):
        c = self.login("viewer1")
        self.assertEqual(c.get("/").status_code, 200)
        r = c.get("/api/dashboard?type=tender")
        self.assertEqual(r.status_code, 200)
        self.assertIn("kpi", r.get_json())
        self.assertEqual(self.app.test_client().get("/api/dashboard").status_code, 302)   # بدون ورود

    def test_jalali_to_gregorian(self):
        from app.jalali import jdate_to_date
        from datetime import date
        self.assertEqual(jdate_to_date("1405/07/19"), date(2026, 10, 11))
        self.assertIsNone(jdate_to_date("سلام"))


class AuditLogTests(EditTests):
    def rows(self):
        return [dict(r) for r in self.db.execute("SELECT * FROM audit_log ORDER BY id")]

    def test_login_create_edit_logout_are_logged_with_who_and_diff(self):
        c = self.make_case()                         # entry1: ورود + ثبت
        c.post("/cases/1", data=self.edit_data(c, status="ارسال شد", organization="شرکت ب"))
        acts = [(r["action"], r["username"]) for r in self.rows()]
        self.assertIn(("login", "entry1"), acts)
        self.assertIn(("case_create", "entry1"), acts)
        edit = [r for r in self.rows() if r["action"] == "case_edit"][0]
        self.assertIn("شرکت ب", edit["detail"])
        self.assertIn("وضعیت پرونده", edit["detail"])
        self.assertTrue(edit["at"].startswith("20"))
        c.post("/logout", data={"csrf": self.token(c, "/")})
        self.assertEqual(self.rows()[-1]["action"], "logout")

    def test_no_change_edit_not_logged_and_failed_login_logged(self):
        c = self.make_case()
        n = len([r for r in self.rows() if r["action"] == "case_edit"])
        c.post("/cases/1", data=self.edit_data(c))
        self.assertEqual(len([r for r in self.rows() if r["action"] == "case_edit"]), n)
        x = self.app.test_client(); x.get("/login")
        with x.session_transaction() as s: t = s["csrf"]
        x.post("/login", data={"username": "entry1", "password": "bad", "csrf": t})
        self.assertEqual(self.rows()[-1]["action"], "login_fail")

    def test_log_cannot_be_changed_or_deleted(self):
        self.login("entry1")
        import sqlite3
        with self.assertRaises(sqlite3.DatabaseError):
            self.db.execute("DELETE FROM audit_log")
        with self.assertRaises(sqlite3.DatabaseError):
            self.db.execute("UPDATE audit_log SET username='x'")

    def test_admin_page_filter_csv_and_access(self):
        a = self.make_case()
        ad = self.login("admin1")
        r = ad.get("/admin/logs")
        self.assertEqual(r.status_code, 200)
        self.assertIn("ثبت پرونده", r.get_data(as_text=True))
        self.assertIn("entry1", ad.get("/admin/logs?user=2&cat=پرونده").get_data(as_text=True))
        self.assertIn("ثبت پرونده", ad.get("/admin/logs.csv").get_data(as_text=True))
        self.assertEqual(a.get("/admin/logs").status_code, 403)
        self.assertEqual(self.login("viewer1").get("/admin/logs.csv").status_code, 403)

    def test_admin_actions_logged(self):
        ad = self.login("admin1")
        ad.post("/admin/users", data={"csrf": self.token(ad, "/admin/users"), "action": "set_max", "max_editors": "3"})
        ad.post("/admin/options", data={"csrf": self.token(ad, "/admin/options"), "action": "add",
                                        "grp": "source", "lines": "پیک"})
        acts = [r["action"] for r in self.rows()]
        self.assertIn("seats_max", acts)
        self.assertIn("option_add", acts)


class WelcomeVersionTests(EditTests):
    def test_welcome_popup_once_after_login_and_version_shown(self):
        from app import config
        c = self.login("entry1")
        html = c.get("/").get_data(as_text=True)
        self.assertIn('id="wl-modal"', html)
        self.assertIn("خوش آمدید", html)
        self.assertIn("ایران انشعاب", html)
        self.assertIn(config.APP_VERSION, html)
        self.assertNotIn('id="wl-modal"', c.get("/").get_data(as_text=True))     # فقط یک بار
        x = self.app.test_client()
        self.assertIn("v" + config.APP_VERSION, x.get("/login").get_data(as_text=True))

    def test_readme_mentions_current_version(self):
        from app import config
        txt = open(os.path.join(os.path.dirname(__file__), "..", "README.md"), encoding="utf-8").read()
        fa = config.APP_VERSION.translate(str.maketrans("0123456789", "۰۱۲۳۴۵۶۷۸۹"))
        self.assertIn("نسخه " + fa, txt)


class PersianDigitsAndOrderTests(EditTests):
    def test_ascii_and_arabic_digits_are_stored_persian(self):
        c = self.login("entry1")
        t = self.token(c)
        c.post("/cases/new", data=self.new_data(
            t, organization="شرکت الف", notes="تماس 021-123 و ٤٥٦", received_date="1405/7/5", send_deadline="1405/7/9", physical_upload="9:05",
            result="بازنده", prod_uid=["new-1"], prod_product_type=["شیر"], prod_size=["1 اینچ"], prod_quantity=["12"],
            prod_model=[""], prod_sample=[""], comp_uid=["new-1"], comp_name=["رقیب 2"], comp_price=["1,500"],
            comp_note=["نمونه 3"]))
        row = self.case_row()
        self.assertEqual(row["notes"], "تماس ۰۲۱-۱۲۳ و ۴۵۶")
        self.assertEqual((row["received_date"], row["physical_upload"]), ("۱۴۰۵/۰۷/۰۵", "۰۹:۰۵"))
        comp = self.db.execute("SELECT name, price, note FROM case_competitors").fetchone()
        self.assertEqual((comp["name"], comp["price"], comp["note"]), ("رقیب ۲", 1500, "نمونه ۳"))
        prod = self.db.execute("SELECT size, quantity FROM case_products").fetchone()
        self.assertEqual((prod["size"], prod["quantity"]), ("۱ اینچ", 12))      # گزینهٔ ثبت‌شده با ارقام فارسی
        html = c.get("/cases/1").get_data(as_text=True)
        self.assertIn('value="۱۲"', html)
        self.assertIn('value="۱,۵۰۰"', html)                         # جداکنندهٔ سه‌رقمی
        lst = c.get("/cases?q=021").get_data(as_text=True)          # جستجو با رقم انگلیسی هم پیدا می‌کند
        self.assertEqual(lst.count('class="case-table"'), 1)

    def test_product_rows_keep_their_order_and_middle_insert(self):
        c = self.login("entry1")
        t = self.token(c)
        base = dict(prod_product_type=["شیر", "لوله", "شیر"], prod_size=["", "", ""], prod_quantity=["1", "2", "3"],
                    prod_model=["", "", ""], prod_sample=["", "", ""])
        c.post("/cases/new", data=self.new_data(t, organization="شرکت الف", prod_uid=["new-1", "new-2", "new-3"], **base))
        qty = lambda: [p["quantity"] for p in case_data.load_case(self.db, 1)["products"]]
        self.assertEqual(qty(), [1, 2, 3])
        ids = [p["id"] for p in case_data.load_case(self.db, 1)["products"]]
        # ترتیب برعکس + یک ردیف جدید وسط
        order = [str(ids[2]), "new-9", str(ids[1]), str(ids[0])]
        data = self.edit_data(c, prod_uid=order, prod_product_type=["شیر", "شیر", "لوله", "شیر"], prod_size=["", "", "", ""],
                              prod_quantity=["3", "50", "2", "1"], prod_model=["", "", "", ""], prod_sample=["", "", "", ""])
        r = c.post("/cases/1", data=data)
        self.assertEqual(r.status_code, 302)
        self.assertEqual(qty(), [3, 50, 2, 1])

    def test_old_ascii_data_is_converted_once_and_seeds_are_not_duplicated(self):
        from app import db as dbm
        self.make_case()
        self.db.execute("UPDATE cases SET notes='رقم 123', received_date='1405/07/05' WHERE id=1")
        self.db.execute("UPDATE case_products SET size='1.2'")
        self.db.execute("INSERT INTO options (grp, label) VALUES ('model', 'M12')")
        self.db.execute("DELETE FROM settings WHERE key = 'digits_fa'")
        path = self.app.config["DATABASE"]
        dbm.init_db(path)
        n = self.db.execute("SELECT COUNT(*) FROM options").fetchone()[0]
        dbm.init_db(path)                                             # بار دوم: چیزی تکراری اضافه نمی‌شود
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM options").fetchone()[0], n)
        row = self.case_row()
        self.assertEqual((row["notes"], row["received_date"]), ("رقم ۱۲۳", "۱۴۰۵/۰۷/۰۵"))
        self.assertEqual(self.db.execute("SELECT size FROM case_products").fetchone()[0], "۱.۲")
        self.assertIn("M۱۲", options.active_labels(self.db, "model"))
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM options WHERE grp='size' AND label='1.2'").fetchone()[0], 0)

    def test_date_input_is_typable_and_calendar_selects_are_native(self):
        js = self.login("entry1").get("/static/jdatepicker.js").get_data(as_text=True)
        self.assertIn("readOnly = false", js)
        self.assertEqual(js.count("data-native"), 2)        # لیست ماه/سال تقویم نباید به کمبوی جستجودار تبدیل شود
        self.assertIn("maskValue", js)


class NumberFormatAndMessagesTests(EditTests):
    def test_fa_num_filter(self):
        from app.jalali import fa_num
        self.assertEqual(fa_num(1200000), "۱,۲۰۰,۰۰۰")
        self.assertEqual(fa_num("1,500"), "۱,۵۰۰")
        self.assertEqual(fa_num(0), "۰")
        self.assertEqual(fa_num(None), "")
        self.assertEqual(fa_num("abc 12"), "abc ۱۲")

    def test_thousands_input_is_accepted_and_font_and_messages_shipped(self):
        c = self.login("entry1")
        c.post("/cases/new", data=self.new_data(self.token(c), organization="شرکت الف", prod_uid=["new-1"],
               prod_product_type=["شیر"], prod_size=[""], prod_quantity=["۱,۲۰۰,۰۰۰"], prod_model=[""], prod_sample=[""]))
        self.assertEqual(self.db.execute("SELECT quantity FROM case_products").fetchone()[0], 1200000)
        self.assertIn('class="num"', c.get("/cases/1").get_data(as_text=True))
        self.assertEqual(c.get("/static/fonts/Vazirmatn-Regular.ttf").status_code, 200)
        js = c.get("/static/jdatepicker.js").get_data(as_text=True)
        self.assertIn("فقط", js)
        self.assertIn("function explain", js)


class V222Tests(FormBase):
    def post_new(self, c, **over):
        return c.post("/cases/new", data=self.new_data(self.token(c), **over))

    def test_five_types_have_separate_numbering(self):
        c = self.login("entry1")
        html = c.get("/cases/new").get_data(as_text=True)
        for label in ("مناقصه", "استعلام", "مزایده", "فراخوان ارزیابی کیفی", "برآورد قیمت"):
            self.assertIn(label, html)
        self.assertNotIn('value="tender_mech"', html)            # نوع‌های قدیمی قابل انتخاب نیستند
        for t in ("tender", "quality_call", "inquiry", "price_estimate", "auction"):
            self.assertEqual(self.post_new(c, case_type=t).status_code, 302)
        self.post_new(c, case_type="auction")
        rows = {r["case_type"]: r["serial_no"] for r in self.db.execute("SELECT case_type, MAX(serial_no) serial_no FROM cases GROUP BY case_type")}
        self.assertEqual(rows, {"tender": 1, "quality_call": 1, "inquiry": 1, "price_estimate": 1, "auction": 2})
        self.post_new(c, case_type="tender_mech")                # قدیمی برای پروندهٔ جدید پذیرفته نمی‌شود
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM cases WHERE case_type = 'tender_mech'").fetchone()[0], 0)

    def test_type_group_and_flag_controls(self):
        c = self.login("entry1")
        html = c.get("/cases/new").get_data(as_text=True)
        self.assertIn('id="type_group"', html)
        self.assertIn('id="type_flag"', html)
        self.assertEqual(config.report_flag("quality_call"), ("فراخوان ارزیابی کیفی", True))
        self.assertEqual(config.report_flag("tender"), ("فراخوان ارزیابی کیفی", False))
        self.assertEqual(config.report_flag("price_estimate"), ("برآورد قیمت", True))
        self.assertIsNone(config.report_flag("auction"))
        self.assertEqual(config.report_title("quality_call"), "مناقصه")
        self.assertEqual(config.report_title("tender_mech"), "مناقصه کنتورهای مکانیکی")

    def test_clock_is_manually_editable(self):
        c = self.login("entry1")
        html = c.get("/cases/new").get_data(as_text=True)
        self.assertNotRegex(html, r'id="physical_upload"[^>]*readonly')
        self.assertIn("ساعت مهلت ارسال", html)
        self.post_new(c, send_deadline="۱۴۰۵/۰۸/۰۱", physical_upload="۰۹:۱۵")
        self.assertEqual(self.case_row()["physical_upload"], "۰۹:۱۵")                      # دستی وارد شده می‌ماند
        self.post_new(c, send_deadline="", physical_upload="۱۰:۳۰")
        self.assertEqual(self.db.execute("SELECT physical_upload FROM cases WHERE id=2").fetchone()[0], "")

    def test_sample_quantity_only_when_sample_is_yes(self):
        c = self.login("entry1")
        base = dict(prod_uid=["new-1", "new-2"], prod_product_type=["شیر", "لوله"], prod_size=["", ""],
                    prod_quantity=["۱۰", "۲۰"], prod_model=["", ""])
        self.post_new(c, prod_sample=["دارد", "ندارد"], prod_sample_qty=["۳,۰۰۰", "۷"], **base)
        qs = [r[0] for r in self.db.execute("SELECT sample_qty FROM case_products ORDER BY id")]
        self.assertEqual(qs, [3000, 0])                             # «ندارد» تعداد نمونه نمی‌گیرد
        html = c.get("/cases/1").get_data(as_text=True)
        self.assertIn("تعداد نمونه", html)
        self.assertIn('value="۳,۰۰۰"', html)
        self.assertEqual(self.post_new(c, prod_sample=["دارد", ""], prod_sample_qty=["abc", ""], **base).status_code, 400)

    def test_archive_decision_rules(self):
        c = self.login("entry1")
        self.post_new(c, decision="عدم تایید و بایگانی", archive_reason="مهلت گذشته", status="در حال بررسی",
                      opening_time="۱۴۰۵/۰۸/۱۰", result="برنده")
        row = self.case_row()
        self.assertEqual((row["status"], row["result"]), ("", ""))
        self.assertEqual(row["opening_time"], "۱۴۰۵/۰۸/۱۰")          # بازگشایی دیگر به تصمیم وابسته نیست
        self.assertEqual(row["archive_reason"], "مهلت گذشته")
        html = c.get("/cases/1").get_data(as_text=True)
        self.assertRegex(html, r'<select name="archive_reason"')      # کمبو است نه متن آزاد
        self.assertIn("تایید", options.active_labels(self.db, "decision"))
        self.post_new(c, decision="تایید", archive_reason="x", result="برنده")
        self.assertEqual(self.db.execute("SELECT archive_reason, result FROM cases WHERE id=2").fetchone()[:], ("", "برنده"))

    def test_old_archive_option_is_migrated(self):
        from app import db as dbm
        self.db.execute("DELETE FROM settings WHERE key='archive_v222'") if False else None
        c = self.login("entry1")
        self.db.execute("DROP TRIGGER IF EXISTS options_no_delete")
        self.db.execute("UPDATE options SET label='بایگانی' WHERE grp='decision' AND label='عدم تایید و بایگانی'")
        self.post_new(c)
        self.db.execute("UPDATE cases SET decision='بایگانی', archive_reason='x' WHERE id=1")
        self.db.execute("DELETE FROM settings WHERE key='archive_v222'")
        dbm.init_db(self.app.config["DATABASE"])
        self.assertEqual(self.case_row()["decision"], "عدم تایید و بایگانی")
        self.assertIn("عدم تایید و بایگانی", options.active_labels(self.db, "decision"))
        self.assertNotIn("بایگانی", options.active_labels(self.db, "decision"))


class V223Tests(FormBase):
    def post_new(self, c, **over):
        return c.post("/cases/new", data=self.new_data(self.token(c), **over))

    def test_notes_and_opening_fields_removed_but_old_data_kept(self):
        c = self.login("entry1")
        html = c.get("/cases/new").get_data(as_text=True)
        self.assertNotIn('name="notes"', html)
        self.assertIn('name="opening_time"', html)
        self.post_new(c)
        self.db.execute("UPDATE cases SET notes='قدیمی', opening_time='۱۴۰۵/۰۸/۰۱' WHERE id=1")
        t = self.token(c, "/cases/1")
        v = self.case_row()["version"]
        self.assertEqual(c.post("/cases/1", data={"csrf": t, "version": v, "organization": ""}).status_code, 302)
        row = self.case_row()
        self.assertEqual(row["notes"], "قدیمی")

    def test_saved_popup_shown_once_for_create_and_edit(self):
        c = self.login("entry1")
        c.get("/")                                           # پاپ‌آپ خوش‌آمد مصرف شود
        r = self.post_new(c, case_type="auction")
        html = c.get(r.headers["Location"]).get_data(as_text=True)
        self.assertIn('id="sv-modal"', html)
        self.assertIn("پرونده مزایده با شماره ۱ ثبت شد.", html)
        self.assertNotIn('id="sv-modal"', c.get("/cases/1").get_data(as_text=True))      # فقط یک بار
        t = self.token(c, "/cases/1"); v = self.case_row()["version"]
        r = c.post("/cases/1", data={"csrf": t, "version": v})
        html = c.get(r.headers["Location"]).get_data(as_text=True)
        self.assertIn("تغییرات پرونده مزایده با شماره ۱ ذخیره شد.", html)
        self.assertIn("تغییرات ذخیره شد.", html)             # نوار سبز مثل قبل

    def test_inquiry_replaces_tender_type_with_source(self):
        c = self.login("entry1")
        options.add_labels(self.db, "tender_type", "عمومی")
        self.post_new(c, case_type="inquiry", tender_type="عمومی", source="ایمیل")
        row = self.case_row()
        self.assertEqual((row["tender_type"], row["source"]), ("", "ایمیل"))
        html = c.get("/cases/1").get_data(as_text=True)
        self.assertRegex(html, r'data-grp-hide="inquiry" hidden')

    def test_profile_fields_per_type(self):
        from app import profile
        inq = {f[0] for f in profile.fields_for("price_estimate")}
        ten = {f[0] for f in profile.fields_for("tender")}
        auc = {f[0] for f in profile.fields_for("auction")}
        self.assertIn("need_no", inq)
        for k in ("subject", "call_no", "tender_no", "contract_period", "advance", "clearance",
                  "bid_guarantee", "perf_guarantee"):
            self.assertNotIn(k, inq)
            self.assertIn(k, ten)
        self.assertNotIn("need_no", ten)
        self.assertNotIn("need_no", auc)
        self.assertNotIn("sent_date", inq | ten)

    def test_profile_popup_and_report_follow_type(self):
        c = self.login("entry1")
        self.post_new(c, case_type="inquiry", source="ایمیل")
        html = c.get("/cases/1").get_data(as_text=True)
        self.assertIn('name="need_no"', html)
        self.assertNotIn('name="call_no"', html)
        self.assertNotIn('name="tender_no"', html)
        self.assertNotIn('name="sent_date"', html)
        rep = c.get("/cases/1/report").get_data(as_text=True)
        self.assertIn("شماره نیاز", rep)
        self.assertNotIn("شماره فراخوان", rep)
        self.assertNotIn("مبلغ ضمانت نامه", rep)
        self.assertIn("منبع دریافت", rep)
        self.post_new(c, case_type="quality_call")
        html = c.get("/cases/2").get_data(as_text=True)
        self.assertIn('name="call_no"', html)
        self.assertNotIn('name="need_no"', html)
        self.assertNotIn("شماره نیاز", c.get("/cases/2/report").get_data(as_text=True))

    def test_glass_popups_css(self):
        css = self.login("entry1").get("/static/style.css").get_data(as_text=True)
        self.assertIn("backdrop-filter", css)



class V229Tests(FormBase):
    def post_new(self, c, **over):
        return c.post("/cases/new", data=self.new_data(self.token(c), **over))

    def test_result_sets_status_and_date(self):
        c = self.login("entry1")
        self.post_new(c, decision="تایید", status="ارسال شد", result="برنده", result_date="")
        row = self.case_row()
        self.assertEqual(row["status"], "نتیجه اعلام شد")
        self.assertNotEqual(row["result_date"], "")

    def test_no_result_clears_result_date_and_inquiry_has_no_opening(self):
        c = self.login("entry1")
        self.post_new(c, decision="تایید", status="ارسال شد", result="", result_date="۱۴۰۵/۰۱/۰۱")
        self.assertEqual(self.case_row()["result_date"], "")
        self.post_new(c, case_type="inquiry", decision="تایید", opening_time="۱۴۰۵/۰۱/۰۱")
        self.assertEqual(self.case_row(2)["opening_time"], "")

    def test_org_pages(self):
        c = self.login("entry1")
        self.db.execute("INSERT INTO options (grp, label) VALUES ('organization', 'شرکت آزمون')")
        self.post_new(c, organization="شرکت آزمون")
        oid = self.db.execute("SELECT id FROM options WHERE grp='organization' AND label='شرکت آزمون'").fetchone()[0]
        self.assertEqual(c.get("/organizations").status_code, 200)
        self.assertEqual(c.get(f"/organizations/by-name?name=شرکت آزمون").status_code, 302)
        t = self.token(c, f"/organizations/{oid}")
        r = c.post(f"/organizations/{oid}", data={"csrf": t, "phone": "021-123", "address": "example-address"})
        self.assertEqual(r.status_code, 302)
        html = c.get(f"/organizations/{oid}").get_data(as_text=True)
        self.assertIn("example-address", html)
        v = self.login("viewer1")
        self.assertEqual(v.post(f"/organizations/{oid}", data={"csrf": "x", "phone": "1"}).status_code, 403)

    def test_update_progress_endpoints_admin_only(self):
        c = self.login("entry1")
        self.assertEqual(c.get("/admin/update/progress").status_code, 403)
        self.assertEqual(c.post("/admin/shutdown", data={}).status_code, 403)


class V230Tests(FormBase):
    def test_news_popup_until_checked(self):
        from app import config
        old = config.WHATS_NEW
        config.WHATS_NEW = {"version": "9.9", "items": ["مورد تازه"]}
        try:
            c = self.login("entry1")
            html = c.get("/").get_data(as_text=True)
            self.assertIn('id="nw-modal"', html)
            self.assertIn("مورد تازه", html)
            self.assertNotIn('id="nw-modal"', c.get("/").get_data(as_text=True))      # فقط بعد از ورود
            t = self.token(c)
            self.assertEqual(c.post("/api/news/seen", data={"csrf": t}).status_code, 200)
            c2 = self.login("entry1")
            self.assertNotIn('id="nw-modal"', c2.get("/").get_data(as_text=True))
        finally:
            config.WHATS_NEW = old

    def test_fetch_latest_falls_back_to_mirror(self):
        from app import updater
        import http.server, threading, json
        class H(http.server.BaseHTTPRequestHandler):
            def do_GET(self):
                b = json.dumps({"version": "9.0", "files": {}}).encode()
                self.send_response(200); self.end_headers(); self.wfile.write(b)
            def log_message(self, *a): pass
        srv = http.server.HTTPServer(("127.0.0.1", 0), H)
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        info = updater.fetch_latest(["http://127.0.0.1:1", f"http://127.0.0.1:{srv.server_address[1]}"])
        srv.shutdown()
        self.assertEqual(info["version"], "9.0")


class V240Tests(FormBase):
    def test_org_list_has_search(self):
        c = self.login("entry1")
        self.assertIn('id="org-q"', c.get("/organizations").get_data(as_text=True))
        import winapp
        self.assertNotIn("fullscreen", open(winapp.__file__, encoding="utf-8").read().split("def open_window")[1].split("def port_busy")[0])


class V243Tests(FormBase):
    def test_org_search_script_is_in_body(self):
        html = self.login("entry1").get("/organizations").get_data(as_text=True)
        self.assertLess(html.index('<main'), html.index("getElementById('org-q')"))


class V247Tests(FormBase):
    def test_zoom_controls_present(self):
        html = self.login("entry1").get("/").get_data(as_text=True)
        for i in ("zm-in", "zm-out", "zm-val"):
            self.assertIn(f'id="{i}"', html)


class V248Tests(FormBase):
    def test_org_api_and_ajax_save(self):
        c = self.login("entry1")
        self.db.execute("INSERT INTO options (grp, label) VALUES ('organization', 'شرکت پاپ‌آپ')")
        d = c.get("/api/org?name=شرکت پاپ‌آپ").get_json()
        self.assertTrue(d["ok"]); self.assertTrue(d["can_edit"])
        t = self.token(c)
        r = c.post(f"/organizations/{d['id']}", data={"csrf": t, "phone": "1", "website": "a.ir"}, headers={"X-Requested-With": "fetch"})
        self.assertEqual(r.get_json(), {"ok": True})
        self.assertEqual(c.get("/api/org?name=نیست").status_code, 404)
        self.assertFalse(self.login("viewer1").get("/api/org?name=شرکت پاپ‌آپ").get_json()["can_edit"])


class V249Tests(FormBase):
    def test_org_contacts_add_edit_no_delete(self):
        c = self.login("entry1")
        self.db.execute("INSERT INTO options (grp, label) VALUES ('organization', 'شرکت نفرات')")
        oid = self.db.execute("SELECT id FROM options WHERE label='شرکت نفرات'").fetchone()[0]
        t = self.token(c)
        data = {"csrf": t, "address": "تهران", "phone": "021",
                "contact_id": ["new", "new"], "contact_name": ["الف", ""], "contact_unit": ["فنی", ""],
                "contact_position": ["مدیر", ""], "contact_phone": ["0912", ""], "contact_ext": ["12", ""]}
        self.assertEqual(c.post(f"/organizations/{oid}", data=data).status_code, 302)
        rows = self.db.execute("SELECT * FROM org_contacts WHERE option_id=?", (oid,)).fetchall()
        self.assertEqual(len(rows), 1)                                   # ردیف کاملاً خالی ذخیره نمی‌شود
        cid = rows[0]["id"]
        t = self.token(c, f"/organizations/{oid}")
        data.update({"csrf": t, "contact_id": [str(cid)], "contact_name": ["الف ب"], "contact_unit": ["فنی"],
                     "contact_position": ["مدیر"], "contact_phone": ["0912"], "contact_ext": ["12"]})
        c.post(f"/organizations/{oid}", data=data)
        self.assertEqual(self.db.execute("SELECT name FROM org_contacts WHERE id=?", (cid,)).fetchone()[0], "الف ب")
        d = c.get(f"/api/org?name=شرکت نفرات").get_json()
        self.assertEqual(len(d["contacts"]), 1)
        self.assertEqual([x["key"] for x in d["fields"]],
                         ["address", "national_id", "postal_code", "reg_no", "phone", "email", "website"])
        html = c.get(f"/organizations/{oid}").get_data(as_text=True)
        self.assertIn("داخلی (در صورت تماس با آبفا)", html)


class V251Tests(FormBase):
    def test_settings_and_company(self):
        c = self.login("admin1")
        self.assertIn("اطلاعات شرکت", c.get("/settings").get_data(as_text=True))
        t = self.token(c, "/settings/company")
        c.post("/settings/company", data={"csrf": t, "name": "شرکت آزمایشی", "phone": "021"})
        self.assertIn("شرکت آزمایشی", c.get("/").get_data(as_text=True))

    def test_non_admin_cannot_open_settings(self):
        c = self.login("entry1")
        self.assertEqual(c.get("/settings").status_code, 403)

    def test_dashboard_hidden_sections(self):
        c = self.login("admin1")
        t = self.token(c, "/admin/users")
        uid = self.db.execute("SELECT id FROM users WHERE username='entry1'").fetchone()["id"]
        c.post("/admin/users", data={"csrf": t, "action": "set_dash", "user_id": uid, "show": ["kpis", "c-trend"]})
        h = self.db.execute("SELECT dash_hidden FROM users WHERE id=?", (uid,)).fetchone()["dash_hidden"]
        self.assertIn("c-orgs", h)
        self.assertNotIn("kpis", h)
        e = self.login("entry1")
        self.assertIn("#c-orgs", e.get("/").get_data(as_text=True))

    def test_exit_page_and_footer(self):
        c = self.login("admin1")
        self.assertIn("پیشرو سیستم", c.get("/").get_data(as_text=True))
        t = self.token(c, "/")
        r = c.post("/logout", data={"csrf": t, "exit": "1"})
        self.assertIn("window.close", r.get_data(as_text=True))

    def test_option_active_toggle(self):
        c = self.login("admin1")
        t = self.token(c)
        c.application = self.app
        r = c.post("/api/options/rename", data={"csrf": t, "grp": "source", "old": "ایمیل", "label": "ایمیل", "active": "0"})
        self.assertTrue(r.get_json().get("ok"), r.get_data(as_text=True))
        self.assertEqual(self.db.execute("SELECT active FROM options WHERE grp='source' AND label='ایمیل'").fetchone()[0], 0)
        r = c.post("/api/options/rename", data={"csrf": t, "grp": "source", "old": "ایمیل", "label": "ایمیل", "active": "1"})
        self.assertEqual(self.db.execute("SELECT active FROM options WHERE grp='source' AND label='ایمیل'").fetchone()[0], 1)

    def test_periodic_backup_skips_when_unchanged(self):
        from app import backups
        src = self.app.config["DATABASE"]
        st = {"sig": backups.db_signature(src)}
        sf = os.path.join(os.path.dirname(src), "s.json"); d = os.path.join(os.path.dirname(src), "bk")
        self.assertFalse(backups.periodic_backup_once(src, sf, d, st))
        os.utime(src, (1, 1))
        self.assertTrue(backups.periodic_backup_once(src, sf, d, st))
        self.assertFalse(backups.periodic_backup_once(src, sf, d, st))

    def test_result_date_between_status_and_result(self):
        c = self.login("admin1")
        html = c.get("/cases/new").get_data(as_text=True)
        self.assertLess(html.index('id="box-status"'), html.index('id="box-resultdate"'))
        self.assertLess(html.index('id="box-resultdate"'), html.index('id="box-result"'))


class V252Tests(FormBase):
    def _post(self, c, subject="مشکل", body="متن"):
        t = self.token(c, "/tickets")
        return c.post("/tickets", data={"csrf": t, "subject": subject, "body": body, "contact": "0912"})

    def test_ticket_sent_and_reply_synced(self):
        from app import tickets
        calls = []

        def fake(app, method, path, payload=None):
            calls.append((method, path))
            if method == "POST" and path.endswith("/issues"):
                self.assertIn("شمارهٔ تیکت در برنامه", payload["body"])
                return {"number": 7}
            if path.endswith("/issues/7"):
                return {"state": "closed"}
            if path.endswith("/comments?per_page=100"):
                return [{"id": 1, "user": {"login": config.TICKET_SUPPORT_LOGIN}, "body": "جواب شما", "created_at": "2026-10-21T10:00:00Z"},
                        {"id": 2, "user": {"login": "other"}, "body": "x", "created_at": "2026-10-21T10:01:00Z"}]
            raise AssertionError(path)
        c = self.login("entry1")
        with mock.patch.object(tickets, "_call", fake):
            r = self._post(c)
            self.assertEqual(r.status_code, 302)
            html = c.get(r.headers["Location"]).get_data(as_text=True)
        self.assertIn("جواب شما", html)
        self.assertIn("بسته شد", html)
        self.assertEqual(self.db.execute("SELECT gh_number FROM tickets").fetchone()[0], 7)
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM ticket_comments").fetchone()[0], 1)

    def test_ticket_offline_stays_pending_then_retries(self):
        from app import tickets
        c = self.login("entry1")

        def down(app, method, path, payload=None):
            raise tickets.TicketError("x")
        with mock.patch.object(tickets, "_call", down):
            self._post(c)
        self.assertIsNone(self.db.execute("SELECT gh_number FROM tickets").fetchone()[0])
        with mock.patch.object(tickets, "_call", lambda *a, **k: {"number": 9}):
            c.get("/tickets")
        self.assertEqual(self.db.execute("SELECT gh_number FROM tickets").fetchone()[0], 9)

    def test_other_user_cannot_see_ticket(self):
        from app import tickets
        c = self.login("entry1")
        with mock.patch.object(tickets, "_call", lambda *a, **k: {"number": 1}):
            self._post(c)
        tid = self.db.execute("SELECT id FROM tickets").fetchone()[0]
        v = self.login("viewer1")
        self.assertEqual(v.get(f"/tickets/{tid}").status_code, 404)
        self.assertEqual(self.login("admin1").get(f"/tickets/{tid}").status_code, 200)

    def test_token_not_in_repo_files(self):
        import subprocess
        out = subprocess.run(["grep", "-rl", "--include=*.py", "--include=*.md", "github" + "_pat_1", "app", "tests", "README.md"], capture_output=True, text=True).stdout
        self.assertEqual(out.strip(), "")


class V253Tests(FormBase):
    def test_new_case_types_each_start_from_one(self):
        c = self.login("entry1")
        for t in ("quality_call", "price_estimate"):
            tok = self.token(c)
            r = c.post("/cases/new", data=self.new_data(tok, case_type=t))
            self.assertEqual(r.status_code, 302, t)
        rows = {r["case_type"]: r["serial_no"] for r in self.db.execute("SELECT case_type, serial_no FROM cases")}
        self.assertEqual(rows, {"quality_call": 1, "price_estimate": 1})
        html = c.get("/cases/new").get_data(as_text=True)
        self.assertIn("فراخوان ارزیابی کیفی", html)
        self.assertIn("برآورد قیمت", html)


class V253TypeChangeTests(FormBase):
    def _make(self, c, t):
        tok = self.token(c)
        c.post("/cases/new", data=self.new_data(tok, case_type=t))

    def test_change_type_assigns_next_number_of_new_type(self):
        c = self.login("entry1")
        self._make(c, "tender")      # tender_mech #1
        self._make(c, "tender")      # tender_mech #2
        self._make(c, "auction")          # auction #1
        row = self.case_row(1)
        tok = self.token(c, "/cases/1")
        r = c.post("/cases/1", data={"csrf": tok, "version": row["version"], "case_type": "auction"})
        self.assertEqual(r.status_code, 302, r.get_data(as_text=True)[:300])
        new = self.case_row(1)
        self.assertEqual((new["case_type"], new["serial_no"]), ("auction", 2))
        # شمارهٔ قبلی tender_mech #1 دوباره استفاده نمی‌شود: پرونده بعدی tender_mech شمارهٔ ۳ می‌گیرد
        self._make(c, "tender")
        self.assertEqual(self.db.execute("SELECT serial_no FROM cases WHERE id=4").fetchone()[0], 3)
        log = self.db.execute("SELECT * FROM audit_log ORDER BY id DESC LIMIT 5").fetchall()
        self.assertTrue(any("نوع پرونده" in str(dict(r)) for r in log))

    def test_invalid_type_rejected_and_same_type_keeps_number(self):
        c = self.login("entry1")
        self._make(c, "tender")
        row = self.case_row(1)
        tok = self.token(c, "/cases/1")
        r = c.post("/cases/1", data={"csrf": tok, "version": row["version"], "case_type": "bogus"})
        self.assertEqual(r.status_code, 400)
        tok = self.token(c, "/cases/1")
        r = c.post("/cases/1", data={"csrf": tok, "version": row["version"], "case_type": "tender"})
        self.assertEqual(r.status_code, 302)
        self.assertEqual(self.case_row(1)["serial_no"], 1)
        self.assertIn('name="case_type"', c.get("/cases/1").get_data(as_text=True))


class V253MoneyTests(FormBase):
    def test_guarantee_amounts_are_grouped_by_three(self):
        c = self.login("entry1")
        c.post("/cases/new", data=self.new_data(self.token(c)))
        t = self.token(c)
        c.post("/cases/1/profile", data={"csrf": t, "pversion": "0", "bid_guarantee": "1200000", "perf_guarantee": "۵۰۰٬۰۰۰ ریال"})
        row = self.db.execute("SELECT bid_guarantee, perf_guarantee FROM case_profile").fetchone()
        self.assertEqual((row[0], row[1]), ("۱,۲۰۰,۰۰۰", "۵۰۰,۰۰۰"))
        html = c.get("/cases/1").get_data(as_text=True)
        self.assertIn('value="۱,۲۰۰,۰۰۰"', html)


class V253BackupPageTests(FormBase):
    def test_backup_page_has_separate_boxes_and_saves_targets(self):
        import tempfile
        c = self.login("admin1")
        html = c.get("/admin/backup").get_data(as_text=True)
        for t in ("ذخیره در این دستگاه", "iCloud Drive", "OneDrive"):
            self.assertIn(t, html)
        d = tempfile.mkdtemp()
        tok = self.token(c, "/admin/backup")
        c.post("/admin/backup", data={"csrf": tok, "action": "settings", "dir": d,
                                      "t_onedrive_on": "1", "t_onedrive_path": d + "/od", "t_icloud_path": ""})
        from app import backups
        st = backups.read_settings(self.app.config["BACKUP_SETTINGS_FILE"], d)
        self.assertEqual(st["extras"], [d + "/od"])
        v = backups.cloud_view(st)
        self.assertTrue(v["targets"]["onedrive"]["on"])
        self.assertFalse(v["targets"]["icloud"]["on"])


class V253GroupTests(FormBase):
    def test_price_estimate_behaves_like_inquiry_and_quality_call_like_tender(self):
        from app import profile
        self.assertNotIn("subject", [f[0] for f in profile.fields_for("price_estimate")])
        self.assertIn("need_no", [f[0] for f in profile.fields_for("price_estimate")])
        self.assertIn("subject", [f[0] for f in profile.fields_for("quality_call")])
        self.assertNotIn("need_no", [f[0] for f in profile.fields_for("quality_call")])
        options.add_labels(self.db, "tender_type", "عمومی")
        c = self.login("entry1")
        r = c.post("/cases/new", data=self.new_data(self.token(c), case_type="price_estimate", tender_type="عمومی",
                                                    source="ایمیل", decision="تایید", opening_time="۱۴۰۵/۰۱/۰۱"))
        self.assertEqual(r.status_code, 302, re.findall(r"<li>([^<]+)", r.get_data(as_text=True)))
        row = self.case_row(1)
        self.assertEqual((row["tender_type"], row["opening_time"], row["source"]), ("", "", "ایمیل"))
        html = c.get("/cases/1").get_data(as_text=True)
        self.assertIn("INQ_TYPES = [", html)
        self.assertIn('"price_estimate"', html)
        self.assertNotIn('"quality_call"', html.split("INQ_TYPES = ")[1].split(";")[0])


class V253PickFolderTests(FormBase):
    def test_pick_folder_local_only(self):
        c = self.login("admin1")
        tok = self.token(c, "/admin/backup")
        with mock.patch("app.backups.pick_folder_dialog", return_value="/Users/x/Backups"):
            r = c.post("/admin/backup/pick", data={"csrf": tok})
        self.assertEqual(r.get_json(), {"ok": True, "path": "/Users/x/Backups"})
        r = c.post("/admin/backup/pick", data={"csrf": tok}, environ_overrides={"REMOTE_ADDR": "10.0.0.5"})
        self.assertEqual(r.status_code, 400)
        self.assertIn("data-pick", c.get("/admin/backup").get_data(as_text=True))


class V253RSizeTests(FormBase):
    def test_r_size_combo_saved_and_in_options_page(self):
        options.add_labels(self.db, "r_size", "R100\n۲۵۰\nنیم‌اینچ")
        c = self.login("admin1")
        t = self.token(c)
        r = c.post("/cases/new", data=self.new_data(t, prod_uid=["new-1"], prod_product_type=["شیر"], prod_r_size=["R100"],
                                                    prod_size=[""], prod_quantity=["2"], prod_model=[""], prod_sample=[""]))
        self.assertEqual(r.status_code, 302)
        self.assertEqual(self.db.execute("SELECT r_size FROM case_products").fetchone()[0], "R۱۰۰")
        html = c.get("/cases/1").get_data(as_text=True)
        self.assertIn("اندازه R", html)
        self.assertIn('name="prod_r_size"', html)
        self.assertIn("اندازه R", c.get("/admin/options").get_data(as_text=True))
        bad = c.post("/cases/new", data=self.new_data(self.token(c), prod_uid=["new-1"], prod_product_type=["شیر"], prod_r_size=["ناموجود"],
                                                      prod_size=[""], prod_quantity=["2"], prod_model=[""], prod_sample=[""]))
        self.assertEqual(bad.status_code, 400)


class V254Tests(FormBase):
    def test_dates_in_one_row_before_source_and_org(self):
        html = self.login("entry1").get("/cases/new").get_data(as_text=True).split("<script>")[0]
        order = ["شماره شناسنامه", "تاریخ اعلان آگهی", "تاریخ دریافت اسناد", "تاریخ صدور شناسنامه", "مهلت ارسال اسناد", "ساعت مهلت ارسال", "تاریخ بازگشایی پاکات",
                 "منبع دریافت", "سازمان / شرکت"]
        pos = [html.index(x) for x in order]
        self.assertEqual(pos, sorted(pos))

    def test_source_is_single_field_for_every_type(self):
        c = self.login("entry1")
        for t in ("tender", "inquiry", "price_estimate", "price_estimate"):
            html = c.get("/cases/new").get_data(as_text=True).split("<script>")[0]
            self.assertEqual(html.count('name="source"'), 1, t)
        t = self.token(c)
        r = c.post("/cases/new", data=self.new_data(t, case_type="inquiry", source="ایمیل"))
        self.assertEqual(r.status_code, 302)
        self.assertEqual(self.case_row()["source"], "ایمیل")

    def test_announce_date_flows_to_profile_read_only(self):
        c = self.login("entry1")
        t = self.token(c)
        c.post("/cases/new", data=self.new_data(t, announce_date="1405/08/03"))
        self.assertEqual(self.case_row()["announce_date"], "۱۴۰۵/۰۸/۰۳")
        html = c.get("/cases/1").get_data(as_text=True)
        self.assertIn("۱۴۰۵/۰۸/۰۳", html.split('id="pf-form"')[1])
        self.assertRegex(html.split('id="pf-form"')[1], r'<input class="jdate-ro"[^>]*readonly disabled')
        # پست مستقیم به شناسنامه نمی‌تواند تاریخ اعلان آگهی را عوض کند
        t = self.token(c, "/cases/1")
        self.assertEqual(c.post("/cases/1/profile", data={"csrf": t, "pversion": "0", "announce_date": "1399/01/01"}).status_code, 200)
        self.assertEqual(self.db.execute("SELECT announce_date FROM case_profile").fetchone()[0], "۱۴۰۵/۰۸/۰۳")
        self.assertEqual(self.case_row()["announce_date"], "۱۴۰۵/۰۸/۰۳")

    def test_org_page_new_fields_and_phonebook(self):
        c = self.login("admin1")
        t = self.token(c)
        options.add_labels(self.db, "organization", "شرکت دفترچه")
        oid = self.db.execute("SELECT id FROM options WHERE label='شرکت دفترچه'").fetchone()[0]
        t = self.token(c, f"/organizations/{oid}")
        r = c.post(f"/organizations/{oid}", data={
            "csrf": t, "address": "تهران", "national_id": "1234567890", "postal_code": "1111111111", "reg_no": "555",
            "email": "a@b.ir", "website": "b.ir",
            "contact_id": ["new"], "contact_center_phone": ["021-1"], "contact_name": ["علی"], "contact_unit": ["فنی"],
            "contact_position": ["مدیر"], "contact_phone": ["021-2"], "contact_ext": ["12"], "contact_mobile": ["0912"]})
        self.assertIn(r.status_code, (200, 302))
        d = c.get("/api/org?name=شرکت دفترچه").get_json()
        vals = {x["key"]: x["value"] for x in d["fields"]}
        self.assertEqual(vals["email"], "a@b.ir")
        self.assertEqual(vals["national_id"], "۱۲۳۴۵۶۷۸۹۰")
        self.assertEqual(d["contacts"][0]["mobile"], "۰۹۱۲")
        self.assertEqual(d["contacts"][0]["center_phone"], "۰۲۱-۱")
        html = c.get(f"/organizations/{oid}").get_data(as_text=True)
        self.assertIn("دفترچه تلفن", html)
        self.assertIn("تلفن همراه", html)
        self.assertNotIn("صفحهٔ این شرکت", c.get("/cases/new").get_data(as_text=True))


class V255PermTests(FormBase):
    def mk_user(self, name="entry2"):
        return self.db.execute("SELECT id FROM users WHERE username=?", (name,)).fetchone()[0]

    def lock(self, uid, keys):
        from app import perms
        perms.set_locked(self.db, uid, keys)

    def test_admin_page_sets_locks_and_audits(self):
        a = self.login("admin1")
        uid = self.mk_user()
        t = self.token(a, "/admin/users")
        html = a.get("/admin/users").get_data(as_text=True)
        self.assertIn('name="allow"', html)
        self.assertIn("دسترسی فیلدها", html)
        # فقط «سازمان / شرکت» و «جدول محصولات» تیک دارند؛ بقیه قفل
        from app import perms
        allow = ["organization", "products"]
        r = a.post("/admin/users", data={"csrf": t, "action": "set_fields", "user_id": str(uid), "allow": allow})
        self.assertEqual(r.status_code, 302)
        locked = self.db.execute("SELECT field_locked FROM users WHERE id=?", (uid,)).fetchone()[0].split(",")
        self.assertNotIn("organization", locked)
        self.assertIn("decision", locked)
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM audit_log WHERE action='user_fields'").fetchone()[0], 1)

    def test_locked_field_cannot_be_changed_server_side(self):
        uid = self.mk_user()
        self.lock(uid, ["decision", "result"])
        c = self.login("entry2")
        t = self.token(c)
        r = c.post("/cases/new", data=self.new_data(t, organization="شرکت الف", decision="تایید"))
        self.assertEqual(r.status_code, 302)
        self.assertEqual(self.case_row()["decision"], "")                      # قفل بود: تغییر نکرد
        self.assertEqual(self.case_row()["organization"], "شرکت الف")        # آزاد بود
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM audit_log WHERE action='perm_denied'").fetchone()[0], 1)
        # مدیر مقدار را می‌گذارد؛ کاربر قفل‌شده نمی‌تواند عوضش کند
        a = self.login("admin1")
        ta = self.token(a, "/cases/1")
        v = self.case_row()["version"]
        a.post("/cases/1", data=self.new_data(ta, case_type="tender", organization="شرکت الف", decision="تایید", version=str(v)))
        self.assertEqual(self.case_row()["decision"], "تایید")
        c = self.login("entry2")
        t = self.token(c, "/cases/1")
        v = self.case_row()["version"]
        c.post("/cases/1", data=self.new_data(t, organization="شرکت الف", decision="عدم تایید و بایگانی", archive_reason="x", version=str(v)))
        self.assertEqual(self.case_row()["decision"], "تایید")

    def test_locked_products_table_and_profile_fields(self):
        uid = self.mk_user()
        a = self.login("admin1")
        ta = self.token(a)
        a.post("/cases/new", data=self.new_data(ta, organization="شرکت الف", prod_uid=["new-1"], prod_product_type=["شیر"],
                                                prod_size=["۱ اینچ"], prod_quantity=["5"], prod_model=[""], prod_sample=[""]))
        self.lock(uid, ["products", "p_subject", "p_prices"])
        c = self.login("entry2")
        t = self.token(c, "/cases/1")
        v = self.case_row()["version"]
        c.post("/cases/1", data=self.new_data(t, case_type="tender", organization="شرکت الف", version=str(v),
               prod_uid=["1", "new-1"], prod_product_type=["دریچه", "شیر"], prod_size=["", ""], prod_quantity=["99", "5"],
               prod_model=["", ""], prod_sample=["", ""]))
        rows = self.db.execute("SELECT product_type, quantity FROM case_products").fetchall()
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["quantity"], 5)
        t = self.token(c, "/cases/1")
        r = c.post("/cases/1/profile", data={"csrf": t, "pversion": "0", "subject": "عوض شد", "call_no": "۷", "price_1": "500"})
        self.assertEqual(r.status_code, 200)
        p = self.db.execute("SELECT subject, call_no FROM case_profile").fetchone()
        self.assertEqual((p["subject"], p["call_no"]), ("", "۷"))             # موضوع قفل بود، شماره فراخوان آزاد
        self.assertEqual(self.db.execute("SELECT price FROM case_products").fetchone()[0], 0)

    def test_locked_products_disabled_fields_not_posted(self):
        """کاربر فقط‌تأییدکننده: مرورگر فیلدهای غیرفعال جدول محصولات/رقبا را نمی‌فرستد (فقط uid پنهان)؛ نباید خطا بدهد."""
        uid = self.mk_user()
        a = self.login("admin1")
        ta = self.token(a)
        a.post("/cases/new", data=self.new_data(ta, case_type="inquiry", organization="شرکت الف", prod_uid=["new-1"],
                                                prod_product_type=["شیر"], prod_size=["۱ اینچ"], prod_quantity=["5"],
                                                prod_model=[""], prod_sample=["دارد"], prod_sample_qty=["3"],
                                                decision="", result="بازنده", comp_uid=["new-1"], comp_name=["رقیب"],
                                                comp_price=["100"], comp_note=["ن"]))
        self.assertEqual(self.db.execute("SELECT sample_qty FROM case_products").fetchone()[0], 3)
        self.lock(uid, ["products", "competitors"])
        c = self.login("entry2")
        t = self.token(c, "/cases/1")
        v = self.case_row()["version"]
        data = self.new_data(t, case_type="inquiry", organization="شرکت الف", version=str(v), decision="تایید",
                             result="بازنده", prod_uid=["1"], comp_uid=["1"])
        for k in ("prod_product_type", "prod_size", "prod_quantity", "prod_model", "prod_sample", "prod_sample_qty",
                  "comp_name", "comp_price", "comp_note", "comp_won"):
            data.pop(k, None)
        r = c.post("/cases/1", data=data)
        self.assertNotIn("نمی‌تواند خالی شود", r.get_data(as_text=True))
        self.assertEqual(self.case_row()["decision"], "تایید")
        row = self.db.execute("SELECT product_type, quantity, sample, sample_qty FROM case_products").fetchone()
        self.assertEqual((row["product_type"], row["quantity"], row["sample"], row["sample_qty"]), ("شیر", 5, "دارد", 3))
        self.assertEqual(self.db.execute("SELECT name, price FROM case_competitors").fetchone()["name"], "رقیب")

    def test_form_marks_locked_fields(self):
        uid = self.mk_user()
        self.lock(uid, ["decision"])
        html = self.login("entry2").get("/cases/new").get_data(as_text=True)
        self.assertIn('var PERM_LOCKED = ["decision"]', html)
        self.assertNotIn("PERM_LOCKED = [\"decision\"]", self.login("admin1").get("/cases/new").get_data(as_text=True))


class V253TicketFileTests(FormBase):
    def _post_file(self, c, name="shot.png", data=b"\x89PNG-data", body="متن"):
        import io
        t = self.token(c, "/tickets")
        return c.post("/tickets", data={"csrf": t, "subject": "مشکل", "body": body, "contact": "",
                                         "file": (io.BytesIO(data), name)}, content_type="multipart/form-data")

    def test_attachment_uploaded_and_linked_in_issue(self):
        from app import tickets
        calls = []

        def fake(app, method, path, payload=None, timeout=15):
            calls.append((method, path))
            if method == "PUT":
                import base64
                self.assertEqual(base64.b64decode(payload["content"]), b"\x89PNG-data")
                return {"content": {"html_url": "https://github.com/x/y/blob/main/a.png"}}
            if path.endswith("/issues"):
                self.assertIn("پیوست: [shot.png](https://github.com/x/y/blob/main/a.png)", payload["body"])
                return {"number": 5}
            raise AssertionError(path)
        c = self.login("entry1")
        with mock.patch.object(tickets, "_call", fake):
            self._post_file(c)
        self.assertEqual([m for m, _ in calls], ["PUT", "POST"])
        tid = self.db.execute("SELECT id FROM tickets").fetchone()[0]
        page = c.get(f"/tickets/{tid}")
        self.assertIn("shot.png", page.get_data(as_text=True))
        fid = self.db.execute("SELECT id FROM ticket_files").fetchone()[0]
        d = c.get(f"/tickets/{tid}/file/{fid}")
        self.assertEqual(d.data, b"\x89PNG-data")
        self.assertIn("attachment", d.headers["Content-Disposition"])
        self.assertEqual(self.login("viewer1").get(f"/tickets/{tid}/file/{fid}").status_code, 404)

    def test_bad_type_and_big_file_rejected(self):
        c = self.login("entry1")
        r = self._post_file(c, name="virus.exe")
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM tickets").fetchone()[0], 0)
        r = self._post_file(c, name="big.pdf", data=b"x" * (10 * 1024 * 1024 + 5))
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM tickets").fetchone()[0], 0)

    def test_offline_keeps_file_and_retries(self):
        from app import tickets
        c = self.login("entry1")

        def down(*a, **k):
            raise tickets.TicketError("x")
        with mock.patch.object(tickets, "_call", down):
            self._post_file(c)
        self.assertIsNone(self.db.execute("SELECT gh_number FROM tickets").fetchone()[0])
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM ticket_files").fetchone()[0], 1)

        def ok(app, method, path, payload=None, timeout=15):
            return {"number": 3} if method == "POST" else {"content": {"html_url": "https://u"}}
        with mock.patch.object(tickets, "_call", ok):
            c.get("/tickets")
        self.assertEqual(self.db.execute("SELECT gh_number FROM tickets").fetchone()[0], 3)
        self.assertEqual(self.db.execute("SELECT gh_url FROM ticket_files").fetchone()[0], "https://u")

    def test_reply_with_attachment(self):
        import io
        from app import tickets

        def ok(app, method, path, payload=None, timeout=15):
            if method == "PUT":
                return {"content": {"html_url": "https://u2"}}
            if path.endswith("/issues"):
                return {"number": 4}
            if method == "GET":
                return [] if "comments" in path else {"state": "open"}
            return {"id": 11, "created_at": "2026-11-03T10:00:00Z"}
        c = self.login("entry1")
        with mock.patch.object(tickets, "_call", ok):
            self._post_file(c, name="a.txt", data=b"hi")
            tid = self.db.execute("SELECT id FROM tickets").fetchone()[0]
            t = self.token(c, f"/tickets/{tid}")
            c.post(f"/tickets/{tid}", data={"csrf": t, "body": "پاسخ", "file": (io.BytesIO(b"log"), "e.log")},
                   content_type="multipart/form-data")
        row = self.db.execute("SELECT comment_id FROM ticket_files WHERE name = 'e.log'").fetchone()
        self.assertIsNotNone(row[0])
        with mock.patch.object(tickets, "_call", ok):
            self.assertIn("e.log", c.get(f"/tickets/{tid}").get_data(as_text=True))

    def test_upload_failure_still_sends_ticket(self):
        from app import tickets

        def fake(app, method, path, payload=None, timeout=15):
            if method == "PUT":
                raise tickets.TicketError("کلید تیکت اجازهٔ ذخیرهٔ فایل را ندارد")
            if method == "GET":
                return [] if "comments" in path else {"state": "open"}
            self.assertIn("پیوست ارسال نشد", payload["body"])
            return {"number": 8}
        c = self.login("entry1")
        with mock.patch.object(tickets, "_call", fake):
            r = self._post_file(c)
            page = c.get(r.headers["Location"], follow_redirects=True).get_data(as_text=True)
        self.assertEqual(self.db.execute("SELECT gh_number FROM tickets").fetchone()[0], 8)
        self.assertIn("پیوست ارسال نشد", page)
        self.assertIn("shot.png", page)

    def test_form_shows_file_status(self):
        c = self.login("entry1")
        html = c.get("/tickets").get_data(as_text=True)
        self.assertIn("data-file-status", html)
        self.assertIn("ticket_file.js", html)


class V254NoCreateTests(FormBase):
    def test_user_with_locked_case_type_cannot_create(self):
        from app import perms
        admin = self.login("admin1")
        keys = ",".join(sorted(perms.all_keys() - {"decision"}))
        self.db.execute("UPDATE users SET field_locked = ? WHERE username = 'entry1'", (keys,))
        self.db.commit()
        c = self.login("entry1")
        r = c.get("/cases/new")
        self.assertEqual(r.status_code, 302)
        self.assertTrue(r.headers["Location"].endswith("/cases"))
        t = self.token(c, "/cases")
        self.assertEqual(c.post("/cases/new", data={"csrf": t, "case_type": "tender"}).status_code, 302)
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM cases").fetchone()[0], 0)
        self.assertNotIn("ایجاد پرونده", c.get("/cases").get_data(as_text=True).split('class="content"')[0])


class V256Tests(FormBase):
    def _uid(self, name="entry1"):
        return self.db.execute("SELECT id FROM users WHERE username=?", (name,)).fetchone()[0]

    def _lock(self, name, keys):
        from app import perms
        perms.set_locked(self.db, self._uid(name), keys)
        self.db.commit()

    def _new(self, c, **over):
        return c.post("/cases/new", data=self.new_data(self.token(c), **over))

    def test_title_and_product_column_order(self):
        html = self.login("admin1").get("/cases/new").get_data(as_text=True)
        self.assertIn("<h1>فرم شناسنامه</h1>", html)
        self.assertNotIn("فرم مناقصات و استعلامات", html)
        self.assertLess(html.index("<th>مدل</th>"), html.index("<th>تعداد</th>"))

    def test_sent_date_is_automatic_and_never_changes(self):
        c = self.login("entry1")
        self.assertEqual(self._new(c, decision="تایید", status="ارسال شد", sent_at="۱۳۰۰/۰۱/۰۱",
                                   sent_guarantee="1", sent_docs="1", sent_sample="1").status_code, 302)
        row = self.case_row()
        self.assertTrue(row["sent_at"])
        self.assertNotIn("۱۳۰۰", row["sent_at"])                  # تاریخ از مرورگر پذیرفته نمی‌شود
        self.assertEqual((row["sent_guarantee"], row["sent_docs"], row["sent_sample"]), ("۱", "۱", ""))   # نمونه = دارد نبود
        first = row["sent_at"]
        t = self.token(c, "/cases/1")
        c.post("/cases/1", data={"csrf": t, "version": str(row["version"]), "decision": "تایید", "status": "ارسال شد",
                                 "sent_at": "۱۴۰۰/۰۱/۰۱"})
        self.assertEqual(self.case_row()["sent_at"], first)       # عوض نمی‌شود

    def test_sent_checkboxes_only_when_sent_and_sample_needs_yes(self):
        c = self.login("entry1")
        self._new(c, decision="تایید", status="", sent_guarantee="1")
        self.assertEqual(self.case_row()["sent_guarantee"], "")
        self.assertEqual(self.case_row()["sent_at"], "")
        self._new(c, decision="تایید", status="ارسال شد", sent_sample="1",
                  prod_uid="new", prod_quantity="2", prod_sample="دارد", prod_sample_qty="1")
        self.assertEqual(self.case_row(2)["sent_sample"], "۱")

    def test_form_has_round_sent_checkboxes(self):
        html = self.login("entry1").get("/cases/new").get_data(as_text=True)
        for n in ("sent_guarantee", "sent_sample", "sent_docs"):
            self.assertIn(f'name="{n}"', html)
        self.assertIn("ضمانت‌نامه", html)

    def test_type_permission_blocks_creation_of_locked_type(self):
        self._lock("entry1", ["type_auction"])
        c = self.login("entry1")
        self.assertEqual(self._new(c, case_type="auction").status_code, 400)
        self.assertEqual(self.count_cases(), 0)
        self.assertEqual(self._new(c, case_type="tender").status_code, 302)
        self.assertEqual(self._new(c, case_type="quality_call").status_code, 302)     # چک‌باکس همان گروه مناقصه
        html = c.get("/cases/new").get_data(as_text=True)
        self.assertRegex(html, r'<option value="auction"[^>]*disabled')

    def test_all_types_locked_cannot_create(self):
        self._lock("entry1", ["type_tender", "type_inquiry", "type_auction"])
        c = self.login("entry1")
        self.assertEqual(c.get("/cases/new").status_code, 302)
        self.assertNotIn("ایجاد پرونده", c.get("/cases").get_data(as_text=True).split('class="content"')[0])

    def test_edit_cannot_move_case_to_locked_type(self):
        c = self.login("entry1")
        self._new(c, case_type="tender")
        self._lock("entry1", ["type_auction"])
        t = self.token(c, "/cases/1")
        c.post("/cases/1", data={"csrf": t, "version": "1", "case_type": "auction"})
        self.assertEqual(self.case_row()["case_type"], "tender")

    def test_list_buttons_follow_permissions(self):
        a = self.login("admin1")
        self._new(a)
        html = a.get("/cases").get_data(as_text=True)
        self.assertIn("ویرایش</a>", html)
        self.assertIn(">نمایش</a>", html)
        self._lock("entry1", ["ui_view"])
        e = self.login("entry1")
        html = e.get("/cases").get_data(as_text=True)
        self.assertIn("ویرایش</a>", html)
        self.assertNotIn(">نمایش</a>", html)
        self._lock("entry1", ["ui_edit"])
        e = self.login("entry1")
        html = e.get("/cases").get_data(as_text=True)
        self.assertNotIn("ویرایش</a>", html)
        self.assertIn(">نمایش</a>", html)

    def test_user_without_edit_permission_cannot_save(self):
        a = self.login("admin1")
        self._new(a)
        self._lock("entry1", ["ui_edit"])
        e = self.login("entry1")
        t = self.token(e, "/cases")
        self.assertEqual(e.post("/cases/1", data={"csrf": t, "version": "1", "notes": "x"}).status_code, 403)
        self.assertEqual(e.get("/cases/1").status_code, 200)         # فقط می‌بیند

    def test_admin_users_page_lists_new_permission_groups(self):
        html = self.login("admin1").get("/admin/users").get_data(as_text=True)
        for k in ("type_tender", "type_inquiry", "type_auction", "ui_edit", "ui_view"):
            self.assertIn(f'value="{k}"', html)


class V256HelpTests(FormBase):
    def test_help_page_for_every_role_and_admin_sections_hidden(self):
        self.assertEqual(self.app.test_client().get("/help").status_code, 302)       # بدون ورود
        ent = self.login("entry1").get("/help")
        self.assertEqual(ent.status_code, 200)
        html = ent.get_data(as_text=True)
        self.assertIn("کمبوباکس", html)
        self.assertIn('id="h-combo-edit"', html)
        self.assertNotIn('id="s-admin-users"', html)           # بخش مدیر برای ثبت‌کننده نیست
        adm = self.login("admin1").get("/help").get_data(as_text=True)
        self.assertIn('id="s-admin-users"', adm)
        self.assertIn('id="s-admin-backup"', adm)
        self.assertIn("/help", html)                             # لینک راهنما در منو

    def test_help_has_changelog_for_current_version(self):
        from app import config, help_content
        self.assertIn(config.APP_VERSION, [v for v, _ in help_content.CHANGELOG],
                      "برای نسخهٔ فعلی در app/help_content.py (CHANGELOG) مورد اضافه کنید")

    def test_help_item_ids_are_unique(self):
        from app import help_content
        ids = [i[0] for s in help_content.SECTIONS for i in s[3]]
        self.assertEqual(len(ids), len(set(ids)))


class V257OpeningTests(FormBase):
    def test_opening_always_shown_for_tender_and_auction_not_inquiry(self):
        c = self.login("entry1")
        html = c.get("/cases/new").get_data(as_text=True)
        import re
        m = re.search(r'<div class="field" id="box-opening"[^>]*>', html)
        self.assertIsNotNone(m)
        self.assertNotIn("hidden", m.group(0))                  # بدون هیچ شرطی دیده می‌شود
        self.assertIn("vis('box-opening', !inqNow", html)       # در جاوااسکریپت هم فقط به استعلام وابسته است

    def test_opening_saved_without_decision_but_cleared_for_inquiry(self):
        c = self.login("entry1")
        c.post("/cases/new", data=self.new_data(self.token(c), decision="", opening_time="۱۴۰۵/۰۹/۰۱"))
        self.assertEqual(self.case_row(1)["opening_time"], "۱۴۰۵/۰۹/۰۱")
        c.post("/cases/new", data=self.new_data(self.token(c), case_type="inquiry", decision="", opening_time="۱۴۰۵/۰۹/۰۱"))
        self.assertEqual(self.case_row(2)["opening_time"], "")


class V257SampleQtyReportTests(FormBase):
    def test_report_shows_sample_quantity(self):
        a = self.login("admin1")
        a.post("/cases/new", data=self.new_data(self.token(a), case_type="inquiry", organization="شرکت الف",
               prod_uid=["new-1", "new-2"], prod_product_type=["شیر", "شیر"], prod_size=["", ""], prod_quantity=["5", "2"],
               prod_model=["", ""], prod_sample=["دارد", "دارد"], prod_sample_qty=["3", "4"]))
        html = a.get("/cases/1/report").get_data(as_text=True)
        self.assertIn("تعداد نمونه: ۷", html)
        self.assertEqual(a.get("/cases/1/report.pdf").status_code, 200)


class V258ListDecisionTests(FormBase):
    def test_list_shows_decision_instead_of_notes(self):
        a = self.login("admin1")
        a.post("/cases/new", data=self.new_data(self.token(a), organization="شرکت الف", decision="تایید"))
        a.post("/cases/new", data=self.new_data(self.token(a), organization="شرکت ب", decision="عدم تایید و بایگانی", archive_reason="x"))
        html = a.get("/cases").get_data(as_text=True)
        self.assertIn("تصمیم مدیریتی", html)
        self.assertNotIn(">یادداشت<", html)
        self.assertIn("عدم تایید و بایگانی", html)
        r = a.get("/cases?sort=decision&dir=asc")
        self.assertEqual(r.status_code, 200)
        self.assertLess(r.get_data(as_text=True).index("شرکت الف"), r.get_data(as_text=True).index("شرکت ب"))   # «تایید» قبل از «عدم تایید…»


class V258InstallableAppTests(FormBase):
    def test_manifest_and_service_worker_are_public_and_page_links_manifest(self):
        c = self.app.test_client()
        r = c.get("/manifest.webmanifest")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.get_json()["display"], "standalone")
        self.assertEqual(c.get("/sw.js").status_code, 200)
        self.assertIn("manifest", c.get("/login").get_data(as_text=True))
        self.assertEqual(c.get("/static/app-icon-512.png").status_code, 200)
        self.assertEqual(c.get("/apple-touch-icon.png").status_code, 200)
        self.assertIn("apple-touch-icon", c.get("/login").get_data(as_text=True))


class V259AccountTests(FormBase):
    def _login(self, user, pw):
        c = self.app.test_client()
        r = c.post("/login", data={"username": user, "password": pw, "csrf": self.token(c, "/login")})
        return c, r

    def test_user_changes_own_password(self):
        c, r = self._login("entry1", "secret1")
        self.assertEqual(r.status_code, 302)
        self.assertEqual(c.get("/account").status_code, 200)
        bad = c.post("/account", data={"current": "WRONG", "password": "NewPass1x", "password2": "NewPass1x", "csrf": self.token(c, "/account")})
        self.assertIn("رمز فعلی درست نیست", bad.get_data(as_text=True))
        ok = c.post("/account", data={"current": "secret1", "password": "NewPass1x", "password2": "NewPass1x", "csrf": self.token(c, "/account")})
        self.assertEqual(ok.status_code, 302)
        self.assertEqual(self._login("entry1", "NewPass1x")[1].status_code, 302)
        self.assertEqual(self._login("entry1", "secret1")[1].status_code, 200)

    def test_account_requires_login_and_checks_confirmation(self):
        self.assertEqual(self.app.test_client().get("/account").status_code, 302)
        c, _ = self._login("entry1", "secret1")
        r = c.post("/account", data={"current": "secret1", "password": "NewPass1x", "password2": "Other123x", "csrf": self.token(c, "/account")})
        self.assertIn("یکی نیست", r.get_data(as_text=True))

    def test_admin_renames_username(self):
        from app import users
        db = self.db
        uid = db.execute("SELECT id FROM users WHERE username = 'entry1'").fetchone()[0]
        with self.assertRaises(users.UserError):
            users.set_username(db, uid, "ADMIN1")          # تکراری (بدون توجه به حروف)
        with self.assertRaises(users.UserError):
            users.set_username(db, uid, "a b")             # فاصله
        old, new = users.set_username(db, uid, "ali.rezaei")
        db.commit()
        self.assertEqual((old, new), ("entry1", "ali.rezaei"))
        self.assertEqual(self._login("ali.rezaei", "secret1")[1].status_code, 302)

    def test_brand_name_and_mobile_menu_css(self):
        c, _ = self._login("entry1", "secret1")
        html = c.get("/").get_data(as_text=True)
        self.assertIn("پیشرو سیستم", html)
        self.assertNotIn("سامانه پرونده", html)
        self.assertEqual(c.get("/manifest.webmanifest").get_json()["name"], "پیشرو سیستم")


class V259SideToggleTests(FormBase):
    def test_sidebar_has_hamburger_toggle_and_icon_titles(self):
        c = self.login("entry1")
        html = c.get("/").get_data(as_text=True)
        self.assertIn('id="side-toggle"', html)
        self.assertIn('class="nl"', html)
        self.assertIn('title="داشبورد"', html)
        self.assertEqual(c.get("/static/side.js").status_code, 200)


class V260PasswordRuleTests(FormBase):
    def test_rule(self):
        from app import users
        for bad in ("", "Ab1", "abcdefg1", "ABCDEFG1", "Abcdefgh", "abcd1234", "12345678"):
            with self.assertRaises(users.UserError, msg=bad):
                users._check_password(bad)
        for ok in ("Abcdef12", "aB3@#xyz", "Pass1234", "Ab1" + "x" * 30, "Az9!"+"q"*10):
            users._check_password(ok)

    def test_own_change_enforces_rule_and_symbols_optional(self):
        c = self.app.test_client()
        c.post("/login", data={"username": "entry1", "password": "secret1", "csrf": self.token(c, "/login")})
        weak = c.post("/account", data={"current": "secret1", "password": "newpass1", "password2": "newpass1", "csrf": self.token(c, "/account")})
        self.assertIn("حرف کوچک و بزرگ", weak.get_data(as_text=True))
        ok = c.post("/account", data={"current": "secret1", "password": "Good@Pass1", "password2": "Good@Pass1", "csrf": self.token(c, "/account")})
        self.assertEqual(ok.status_code, 302)
