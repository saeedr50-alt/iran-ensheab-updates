import json
import os
import unittest
from unittest import mock

from app import mailer
from tests.test_app import BaseCase


class MailerTests(BaseCase):
    def cfg(self):
        p = os.path.join(os.path.dirname(self.app.config["DATABASE"]), "mail.json")
        with open(p, "w", encoding="utf-8") as f:
            json.dump({"user": "a@gmail.com", "password": "abcd efgh ijkl mnop", "to": "me@x.com"}, f)

    def test_no_config_is_silent(self):
        self.assertIsNone(mailer.settings(self.app))
        self.assertEqual(mailer.send_now(self.app, "s", "b"), (False, "no-config"))

    def test_sends_with_attachment_and_strips_password_spaces(self):
        self.cfg()
        self.assertEqual(mailer.settings(self.app)["password"], "abcdefghijklmnop")
        with mock.patch("app.mailer.smtplib.SMTP_SSL") as smtp:
            ok, err = mailer.send_now(self.app, "موضوع", "متن", ("a.png", b"xx"))
        self.assertTrue(ok, err)
        inst = smtp.return_value.__enter__.return_value
        inst.login.assert_called_once_with("a@gmail.com", "abcdefghijklmnop")
        msg = inst.send_message.call_args[0][0]
        self.assertEqual(msg["To"], "me@x.com")
        self.assertEqual(len(list(msg.iter_attachments())), 1)

    def test_failure_is_logged_not_raised(self):
        self.cfg()
        with mock.patch("app.mailer.smtplib.SMTP_SSL", side_effect=OSError("down")):
            ok, _ = mailer.send_now(self.app, "s", "b")
        self.assertFalse(ok)
        log = os.path.join(os.path.dirname(self.app.config["DATABASE"]), "mail.log")
        self.assertIn("down", open(log, encoding="utf-8").read())
        self.assertNotIn("abcd", open(log, encoding="utf-8").read())


if __name__ == "__main__":
    unittest.main()


class TicketUnreadTests(BaseCase):
    def login(self, name):
        c = self.app.test_client()
        c.get("/login")
        with c.session_transaction() as s:
            t = s["csrf"]
        c.post("/login", data={"username": name, "password": "secret1", "csrf": t})
        return c

    def mk(self, uid):
        cur = self.db.execute("INSERT INTO tickets (user_id, username, subject, body, gh_number) VALUES (?,?,?,?,5)", (uid, "u", "موضوع تست", "متن"))
        self.db.commit()
        return cur.lastrowid

    def reply(self, tid, who="support"):
        self.db.execute("INSERT INTO ticket_comments (ticket_id, gh_id, author, body, created_at) VALUES (?,?,?,?,?)",
                        (tid, self.db.execute("SELECT COALESCE(MAX(gh_id),0)+1 FROM ticket_comments").fetchone()[0], who, "پاسخ", "2026-11-15 10:00"))
        self.db.commit()

    def test_unread_flow(self):
        from app import tickets as tk
        tid = self.mk(self.entry)
        c = self.login("entry1")
        self.assertEqual(c.get("/update-notice").get_json()["tickets"], 0)
        self.reply(tid, "user")                                   # پیام خود کاربر «جدید» حساب نمی‌شود
        self.assertEqual(tk.unread_ids(self.db, self.entry), [])
        self.reply(tid)
        self.assertEqual(tk.unread_ids(self.db, self.entry), [tid])
        self.assertEqual(c.get("/update-notice").get_json()["tickets"], 1)
        page = c.get("/tickets").get_data(as_text=True)
        self.assertIn("پاسخ جدید", page)
        self.assertIn("tk-unread", page)
        self.assertIn("پاسخ جدید", c.get("/").get_data(as_text=True))       # نشان در منو
        c.get(f"/tickets/{tid}")                                  # باز کردن تیکت = دیده شد
        self.assertEqual(tk.unread_ids(self.db, self.entry), [])
        self.assertNotIn("tk-unread", c.get("/tickets").get_data(as_text=True))
        self.reply(tid)                                           # پاسخ دوم دوباره نشان می‌دهد
        self.assertEqual(tk.unread_ids(self.db, self.entry), [tid])

    def test_admin_opening_others_ticket_does_not_mark_seen(self):
        from app import tickets as tk
        tid = self.mk(self.entry)
        self.reply(tid)
        a = self.login("admin1")
        a.get(f"/tickets/{tid}")
        self.assertEqual(tk.unread_ids(self.db, self.entry), [tid])
