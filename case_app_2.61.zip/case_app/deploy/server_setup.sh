#!/bin/bash
# اجرا روی سرور (توسط push.sh): نصب و بروزرسانی. چند بار اجرا شدنش مشکلی ندارد و اطلاعات را پاک نمی‌کند.
set -e
SRC="$(cd "$(dirname "$0")/.." && pwd)"
APP=/opt/ensheab/app
export DEBIAN_FRONTEND=noninteractive NEEDRESTART_MODE=a

if [ ! -x /opt/ensheab/venv/bin/python ] || ! /opt/ensheab/venv/bin/python -c 'import flask,reportlab,waitress' 2>/dev/null; then
  rm -rf /opt/ensheab/venv
  echo ">> نصب بسته‌های سیستم (چند دقیقه)..."
  apt-get update -qq
  apt-get install -y -qq python3-venv python3-flask python3-reportlab python3-waitress python3-certifi python3-pil nginx certbot python3-certbot-nginx ufw rsync sqlite3 curl fail2ban >/dev/null
  timedatectl set-timezone Asia/Tehran || true
  id ensheab >/dev/null 2>&1 || useradd --system --home /opt/ensheab --shell /usr/sbin/nologin ensheab
  mkdir -p /opt/ensheab
  python3 -m venv --system-site-packages /opt/ensheab/venv   # پکیج‌ها از apt (به PyPI نیازی نیست)
  [ -f /etc/ensheab.env ] || printf 'CASE_APP_PROXY=1\nCASE_APP_HTTPS=0\n' > /etc/ensheab.env
fi

echo ">> کپی برنامه..."
mkdir -p $APP
rsync -a --delete --exclude=instance --exclude=backups "$SRC"/ $APP/
mkdir -p $APP/instance $APP/backups
chown -R ensheab:ensheab /opt/ensheab

cat > /etc/systemd/system/ensheab.service <<UNIT
[Unit]
Description=Iran Ensheab web app
After=network.target
[Service]
User=ensheab
WorkingDirectory=$APP
EnvironmentFile=/etc/ensheab.env
ExecStart=/opt/ensheab/venv/bin/python -m waitress --listen=127.0.0.1:5001 --threads=8 run:app
Restart=always
RestartSec=3
[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload
systemctl enable ensheab >/dev/null 2>&1
systemctl restart ensheab

if [ ! -f /etc/nginx/sites-available/ensheab ]; then
cat > /etc/nginx/sites-available/ensheab <<'NG'
server {
    listen 80 default_server;
    server_name _;
    client_max_body_size 50m;
    location / {
        proxy_pass http://127.0.0.1:5001;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $remote_addr;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_read_timeout 300s;
    }
}
NG
  ln -sf /etc/nginx/sites-available/ensheab /etc/nginx/sites-enabled/ensheab
  rm -f /etc/nginx/sites-enabled/default
fi
nginx -t && systemctl reload nginx

# فایروال: فقط SSH (پورت واقعی سرور) و وب
SSHP=$(ss -tlnp 2>/dev/null | awk '/sshd/ {n=split($4,a,":"); print a[n]}' | sort -u | head -3)
if ! ufw status | grep -q "Status: active"; then
  for p in $SSHP 3031; do ufw allow "$p"/tcp >/dev/null; done
  ufw allow 80/tcp >/dev/null; ufw allow 443/tcp >/dev/null
  ufw --force enable >/dev/null
fi

CODE=000
for i in $(seq 1 40); do
  CODE=$(curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:5001/login || true)
  [ "$CODE" = "200" ] || [ "$CODE" = "302" ] && break
  sleep 1
done
if [ "$CODE" = "200" ] || [ "$CODE" = "302" ]; then
  echo "=================================================="
  echo " برنامه روی سرور بالا آمد (کد $CODE)."
  echo " آدرس موقت:  http://$(hostname -I | awk '{print $1}')"
  echo "=================================================="
else
  echo "!! برنامه بالا نیامد (کد $CODE). آخرین خطاها:"
  journalctl -u ensheab -n 40 --no-pager
  exit 1
fi
