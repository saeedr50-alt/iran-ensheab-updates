#!/bin/bash
# اجرا روی سرور بعد از ثبت رکورد A:   bash /opt/ensheab/app/deploy/domain.sh app.example.ir you@example.com
set -e
D="$1"; M="$2"
[ -n "$D" ] && [ -n "$M" ] || { echo "استفاده: domain.sh آدرس ایمیل"; exit 1; }
sed -i "s/server_name .*/server_name $D;/" /etc/nginx/sites-available/ensheab
nginx -t && systemctl reload nginx
certbot --nginx -d "$D" -m "$M" --agree-tos --no-eff-email --redirect -n
sed -i 's/^CASE_APP_HTTPS=.*/CASE_APP_HTTPS=1/' /etc/ensheab.env
systemctl restart ensheab
echo "انجام شد: https://$D"
