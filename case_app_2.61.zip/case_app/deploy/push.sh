#!/bin/bash
# اجرا روی مک: برنامه را به سرور می‌فرستد و نصب/بروزرسانی می‌کند.
#   bash case_app/deploy/push.sh            (اولین بار: IP و پورت را از فایل server.conf می‌خواند)
cd "$(dirname "$0")/.." || exit 1
CONF="$HOME/.ensheab_server"
[ -f "$CONF" ] || printf 'SRV_IP=45.159.114.63\nSRV_PORT=3031\nSRV_USER=root\n' > "$CONF"
. "$CONF"
SSH_OPTS="-p $SRV_PORT -o StrictHostKeyChecking=accept-new"
# کلید ورود: یک بار ساخته می‌شود تا رمز دوباره و دوباره پرسیده نشود
[ -f "$HOME/.ssh/id_ed25519" ] || ssh-keygen -q -t ed25519 -N "" -f "$HOME/.ssh/id_ed25519"
if ! ssh $SSH_OPTS -o BatchMode=yes "$SRV_USER@$SRV_IP" true 2>/dev/null; then
  echo ">> یک بار رمز سرور را بزنید (برای ساخت ورود بدون رمز):"
  ssh-copy-id -p "$SRV_PORT" -o StrictHostKeyChecking=accept-new "$SRV_USER@$SRV_IP" || exit 1
fi
echo ">> ارسال برنامه به سرور..."
tar --exclude=instance --exclude=backups --exclude=__pycache__ --exclude='*.pyc' --exclude=.git \
    --exclude=tests -czf /tmp/ensheab_up.tgz . || exit 1
scp -P "$SRV_PORT" /tmp/ensheab_up.tgz "$SRV_USER@$SRV_IP:/root/ensheab_up.tgz" || exit 1
ssh $SSH_OPTS "$SRV_USER@$SRV_IP" 'rm -rf /root/ensheab_src && mkdir /root/ensheab_src && tar -xzf /root/ensheab_up.tgz -C /root/ensheab_src && bash /root/ensheab_src/deploy/server_setup.sh'
