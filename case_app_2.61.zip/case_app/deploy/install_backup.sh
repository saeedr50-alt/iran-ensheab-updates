#!/bin/bash
# اجرا روی سرور: بکاپ شبانهٔ رمزگذاری‌شده به مخزن خصوصی گیت‌هاب (iran-ensheab-backups).
# فقط بکاپ را نصب می‌کند؛ به خود برنامه و اطلاعات دست نمی‌زند. چند بار اجرا شدنش مشکلی ندارد.
set -e
[ -s /root/.backup_token ] || { echo "ERROR: /root/.backup_token نیست. اول توکن را ذخیره کنید."; exit 1; }
export DEBIAN_FRONTEND=noninteractive
command -v git >/dev/null && command -v sqlite3 >/dev/null && command -v openssl >/dev/null || apt-get install -y -qq git sqlite3 openssl >/dev/null

NEWPASS=0
if [ ! -s /root/.backup_pass ]; then
  ( umask 077; head -c 24 /dev/urandom | base64 | tr -d '/+=\n' > /root/.backup_pass )
  NEWPASS=1
fi

cat > /usr/local/bin/ensheab-offsite-backup <<'EOS'
#!/bin/bash
set -e
REPO=saeedr50-alt/iran-ensheab-backups
DB=/opt/ensheab/app/instance/cases.sqlite
WORK=/root/backup_repo
KEEP=30
export GIT_TERMINAL_PROMPT=0 GIT_ASKPASS=/root/.git_askpass
printf '#!/bin/sh\ncat /root/.backup_token\n' > /root/.git_askpass; chmod 700 /root/.git_askpass
mkdir -p "$WORK"
STAMP=$(date +%Y%m%d_%H%M)
TMP=$(mktemp)
sqlite3 "$DB" ".backup '$TMP'"
openssl enc -aes-256-cbc -pbkdf2 -salt -pass file:/root/.backup_pass -in "$TMP" -out "$WORK/ensheab_$STAMP.db.enc"
rm -f "$TMP"
ls -1t "$WORK"/*.enc | tail -n +$((KEEP+1)) | xargs -r rm -f
cat > "$WORK/README.txt" <<'TXT'
Encrypted daily backups of the Iran Ensheab database (SQLite).
Restore: openssl enc -d -aes-256-cbc -pbkdf2 -in ensheab_XXXX.db.enc -out cases.sqlite -pass pass:YOUR_PASSPHRASE
Then put cases.sqlite in the app's instance folder (stop the app first). Keep only the last 30 files.
TXT
cd "$WORK"
rm -rf .git
git init -q -b main
git config user.name "ensheab-backup"; git config user.email "backup@localhost"
git add -A
git commit -q -m "backup $STAMP"
git remote add origin "https://x-access-token@github.com/$REPO.git"
git push -q --force origin main
echo "$(date '+%F %T') OK ensheab_$STAMP.db.enc ($(du -h "$WORK/ensheab_$STAMP.db.enc" | cut -f1))"
EOS
chmod 700 /usr/local/bin/ensheab-offsite-backup
printf '30 2 * * * root /usr/local/bin/ensheab-offsite-backup >> /var/log/ensheab_backup.log 2>&1\n' > /etc/cron.d/ensheab-offsite
chmod 644 /etc/cron.d/ensheab-offsite

echo ">> یک بکاپ آزمایشی همین حالا گرفته و ارسال می‌شود..."
if OUT=$(/usr/local/bin/ensheab-offsite-backup 2>&1); then
  echo "$OUT" | tail -1
  echo "=========== موفق: بکاپ به گیت‌هاب رفت. هر شب ساعت ۲:۳۰ خودکار تکرار می‌شود. ==========="
else
  echo "=========== ناموفق. خطا (چند خط آخر): ==========="
  echo "$OUT" | tail -8
  exit 1
fi
if [ "$NEWPASS" = 1 ]; then
  echo
  echo "################ رمز رمزگذاری بکاپ (فقط همین یک بار نشان داده می‌شود) ################"
  echo " $(cat /root/.backup_pass)"
  echo "این را همین الان جای امن (مدیریت رمز) ذخیره کنید. بدون آن بکاپ‌ها باز نمی‌شوند. در چت ننویسید."
  echo "##############################################################################"
fi
