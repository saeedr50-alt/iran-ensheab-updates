/* ارقام فارسی در کل برنامه:
 * ۱) هر عددی که در فیلدها تایپ شود (انگلیسی یا عربی) همان لحظه فارسی می‌شود؛
 * ۲) هر عددی که روی صفحه نمایش داده شود (جدول، نمودار، پیام) فارسی دیده می‌شود؛
 * ۳) فیلد ساعت (class="jtime") قالب ۱۴:۳۰ را خودکار می‌گذارد.
 * جاهایی که نباید عوض شوند: data-keep-digits (مثلاً IP)، رمز عبور و نام کاربری. */
(function () {
  'use strict';
  var FA = '۰۱۲۳۴۵۶۷۸۹';
  function toFa(s) {
    return String(s).replace(/[0-9]/g, function (c) { return FA.charAt(+c); })
                    .replace(/[٠-٩]/g, function (c) { return FA.charAt(c.charCodeAt(0) - 1632); });
  }
  function toAscii(s) {
    return String(s).replace(/[۰-۹]/g, function (c) { return c.charCodeAt(0) - 1776; })
                    .replace(/[٠-٩]/g, function (c) { return c.charCodeAt(0) - 1632; });
  }
  window.faDigits = toFa;

  // ---------- ۱) تایپ در فیلدها
  var SKIP_TYPES = /^(password|email|url|number|date|time|file|checkbox|radio|hidden|submit|button)$/;
  function typable(el) {
    if (!el || el.readOnly || el.disabled || el.hasAttribute('data-keep-digits')) return false;
    if (el.tagName === 'TEXTAREA') return true;
    if (el.tagName !== 'INPUT') return false;
    if (SKIP_TYPES.test(el.type || 'text')) return false;
    return !/^(username|csrf|password|password2)$/.test(el.name || '');
  }
  document.addEventListener('input', function (e) {
    var el = e.target;
    if (!typable(el)) return;
    var v = el.value, nv = toFa(v);
    if (nv === v) return;
    var a = el.selectionStart, b = el.selectionEnd;
    el.value = nv;
    try { el.setSelectionRange(a, b); } catch (err) { /* برخی نوع‌ها انتخاب ندارند */ }
  }, true);

  // ---------- پیام خطای زیر فیلد (مشترک با تقویم)
  function showMsg(el, text) {
    var m = el.parentNode.querySelector('.jdate-msg[data-for="' + (el.name || '') + '"]');
    if (!text) { if (m) m.hidden = true; return; }
    if (!m) {
      m = document.createElement('small');
      m.className = 'jdate-msg'; m.setAttribute('role', 'alert'); m.setAttribute('data-for', el.name || '');
      el.parentNode.insertBefore(m, el.nextSibling);
    }
    m.textContent = text; m.hidden = false;
  }
  window.faFieldMsg = showMsg;

  // ---------- عددهای پول و تعداد: جداکردن سه‌رقم‌سه‌رقم (۱,۲۰۰,۰۰۰)
  document.addEventListener('input', function (e) {
    var el = e.target;
    if (!el.classList || !el.classList.contains('num') || el.disabled) return;
    var pos = el.selectionStart, before = el.value.slice(0, pos);
    var digitsBefore = toAscii(before).replace(/[^0-9]/g, '').length;
    var d = toAscii(el.value).replace(/[^0-9]/g, '').replace(/^0+(?=\d)/, '');
    var out = toFa(d.replace(/\B(?=(\d{3})+(?!\d))/g, ','));
    if (out === el.value) return;
    el.value = out;
    var n = 0, i = 0;
    if (digitsBefore > 0) { for (i = 0; i < out.length && n < digitsBefore; i++) { if (out.charAt(i) !== ',') n++; } }
    try { el.setSelectionRange(i, i); } catch (err) { /* ignore */ }
  }, true);

  // ---------- ساعت: ۱۴:۳۰
  document.addEventListener('input', function (e) {
    var el = e.target;
    if (!el.classList || !el.classList.contains('jtime')) return;
    var s = toAscii(el.value).replace(/[^0-9:]/g, '');
    var grow = !(e.inputType && e.inputType.indexOf('delete') === 0);
    if (s.indexOf(':') === -1 && s.length > 2) s = s.slice(0, 2) + ':' + s.slice(2);
    else if (grow && s.indexOf(':') === -1 && s.length === 2) s += ':';
    el.value = toFa(s.slice(0, 5));
    el.classList.remove('jdate-bad'); showMsg(el, '');
  }, true);
  document.addEventListener('focusout', function (e) {
    var el = e.target;
    if (!el.classList || !el.classList.contains('jtime') || !el.value) return;
    var m = /^(\d{1,2}):(\d{1,2})$/.exec(toAscii(el.value));
    var ok = m && +m[1] < 24 && +m[2] < 60;
    if (ok) {
      var good = toFa(('0' + m[1]).slice(-2) + ':' + ('0' + m[2]).slice(-2));
      if (good !== el.value) { el.value = good; el.dispatchEvent(new Event('change', { bubbles: true })); }
      el.classList.remove('jdate-bad'); showMsg(el, '');
    } else {
      el.classList.add('jdate-bad');
      showMsg(el, 'ساعت را درست بنویسید؛ مثل ' + toFa('14:30') + ' (ساعت ' + toFa('00') + ' تا ' + toFa('23') + '، دقیقه ' + toFa('00') + ' تا ' + toFa('59') + ').');
    }
  });

  // ---------- ۲) متن‌های نمایش‌داده‌شده
  var SKIP_TAGS = /^(SCRIPT|STYLE|TEXTAREA|INPUT|CODE|PRE|NOSCRIPT)$/;
  function skip(node) {
    for (var p = node.parentNode; p && p.nodeType === 1; p = p.parentNode) {
      if (SKIP_TAGS.test(p.tagName) || p.hasAttribute('data-keep-digits')) return true;
    }
    return false;
  }
  function fixNode(n) {
    if (n.nodeType === 3) {
      if (/[0-9٠-٩]/.test(n.nodeValue) && !skip(n)) n.nodeValue = toFa(n.nodeValue);
    } else if (n.nodeType === 1 && !SKIP_TAGS.test(n.tagName) && !n.hasAttribute('data-keep-digits')) {
      var w = document.createTreeWalker(n, NodeFilter.SHOW_TEXT, null), t, list = [];
      while ((t = w.nextNode())) list.push(t);
      for (var i = 0; i < list.length; i++) fixNode(list[i]);
    }
  }
  function start() {
    fixNode(document.body);
    if (/[0-9]/.test(document.title)) document.title = toFa(document.title);
    new MutationObserver(function (muts) {
      for (var i = 0; i < muts.length; i++) {
        var m = muts[i];
        if (m.type === 'characterData') fixNode(m.target);
        else for (var j = 0; j < m.addedNodes.length; j++) fixNode(m.addedNodes[j]);
      }
    }).observe(document.body, { childList: true, subtree: true, characterData: true });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
})();
