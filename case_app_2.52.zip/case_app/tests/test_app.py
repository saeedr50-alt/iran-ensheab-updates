import os
import sqlite3
import tempfile
import threading
import unittest
from datetime import date
from unittest import mock

from app import auth, config, create_app
from app.db import connect
from app.jalali import current_jalali_year, gregorian_to_jalali_year
from app.numbering import InvalidCaseType, create_case, peek_next_number


class BaseCase(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.app = create_app({
            "TESTING": True,
            "SECRET_KEY": "test",
            "DATABASE": os.path.join(self.tmp.name, "t.sqlite"),
        })
        self.db = connect(self.app.config["DATABASE"])
        self.admin = auth.create_user(self.db, "admin1", "secret1", "admin")
        self.entry = auth.create_user(self.db, "entry1", "secret1", "entry")
        self.entry2 = auth.create_user(self.db, "entry2", "secret1", "entry")
        self.viewer = auth.create_user(self.db, "viewer1", "secret1", "viewer")

    def tearDown(self):
        self.db.close()
        self.tmp.cleanup()

    def count_cases(self):
        return self.db.execute("SELECT COUNT(*) FROM cases").fetchone()[0]


# ---------------------------------------------------------------- شماره‌گذاری

class NumberingTests(BaseCase):
    def test_each_type_counts_separately_from_one(self):
        # مثال خود کاربر: ۱۰ مناقصه => ۱..۱۰، و اولین استعلام => ۱
        tender = [create_case(self.db, "tender", self.entry, 1405)["serial_no"] for _ in range(10)]
        self.assertEqual(tender, list(range(1, 11)))
        inquiry = create_case(self.db, "inquiry", self.entry, 1405)
        self.assertEqual(inquiry["serial_no"], 1)
        self.assertEqual(create_case(self.db, "tender", self.entry, 1405)["serial_no"], 11)
        self.assertEqual(create_case(self.db, "inquiry", self.entry, 1405)["serial_no"], 2)

    def test_numbering_restarts_each_year(self):
        create_case(self.db, "tender", self.entry, 1404)
        create_case(self.db, "tender", self.entry, 1404)
        self.assertEqual(create_case(self.db, "tender", self.entry, 1405)["serial_no"], 1)
        self.assertEqual(create_case(self.db, "tender", self.entry, 1404)["serial_no"], 3)

    def test_continuous_numbering_when_yearly_reset_is_off(self):
        with mock.patch.object(config, "RESET_NUMBERING_YEARLY", False):
            a = create_case(self.db, "tender", self.entry, 1404)
            b = create_case(self.db, "tender", self.entry, 1405)
        self.assertEqual((a["serial_no"], b["serial_no"]), (1, 2))

    def test_peek_does_not_consume_a_number(self):
        self.assertEqual(peek_next_number(self.db, "tender", 1405), 1)
        self.assertEqual(peek_next_number(self.db, "tender", 1405), 1)
        self.assertEqual(create_case(self.db, "tender", self.entry, 1405)["serial_no"], 1)
        self.assertEqual(peek_next_number(self.db, "tender", 1405), 2)

    def test_invalid_type_is_rejected_and_nothing_is_saved(self):
        for bad in ("", "bogus", None):
            with self.assertRaises(InvalidCaseType):
                create_case(self.db, bad, self.entry, 1405)
        self.assertEqual(self.count_cases(), 0)
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM counters").fetchone()[0], 0)

    def test_failed_save_does_not_burn_a_number(self):
        create_case(self.db, "tender", self.entry, 1405)
        with self.assertRaises(sqlite3.IntegrityError):
            create_case(self.db, "tender", 99999, 1405)  # کاربر ناموجود
        self.assertEqual(create_case(self.db, "tender", self.entry, 1405)["serial_no"], 2)

    def test_two_users_saving_at_the_same_time_never_get_duplicates(self):
        path = self.app.config["DATABASE"]
        results, errors = [], []
        barrier = threading.Barrier(8)

        def worker(user_id, case_type):
            conn = connect(path)
            try:
                barrier.wait()
                for _ in range(15):
                    results.append((case_type, create_case(conn, case_type, user_id, 1405)["serial_no"]))
            except Exception as e:  # pragma: no cover
                errors.append(e)
            finally:
                conn.close()

        threads = [
            threading.Thread(target=worker, args=(uid, t))
            for uid in (self.entry, self.entry2)
            for t in ("tender", "inquiry")
            for _ in range(2)
        ]
        for t in threads: t.start()
        for t in threads: t.join()

        self.assertEqual(errors, [])
        for case_type in ("tender", "inquiry"):
            nums = sorted(n for t, n in results if t == case_type)
            self.assertEqual(nums, list(range(1, 61)), f"{case_type}: شماره تکراری یا جا افتاده")


# ------------------------------------------------------------ قوانین دیتابیس

class DatabaseRuleTests(BaseCase):
    def test_cases_cannot_be_deleted(self):
        create_case(self.db, "tender", self.entry, 1405)
        with self.assertRaises(sqlite3.DatabaseError):
            self.db.execute("DELETE FROM cases")
        self.assertEqual(self.count_cases(), 1)

    def test_case_number_and_type_cannot_be_changed(self):
        create_case(self.db, "tender", self.entry, 1405)
        for col, val in (("serial_no", 5), ("case_type", "inquiry"), ("year", 1)):
            with self.assertRaises(sqlite3.DatabaseError):
                self.db.execute(f"UPDATE cases SET {col} = ?", (val,))
        row = self.db.execute("SELECT case_type, year, serial_no FROM cases").fetchone()
        self.assertEqual(tuple(row), ("tender", 1405, 1))

    def test_duplicate_number_is_blocked_by_the_database_itself(self):
        create_case(self.db, "tender", self.entry, 1405)
        with self.assertRaises(sqlite3.IntegrityError):
            self.db.execute(
                "INSERT INTO cases (case_type, year, serial_no, created_by) VALUES ('tender', 1405, 1, ?)",
                (self.entry,),
            )


# ------------------------------------------------------------------ تاریخ

class JalaliTests(unittest.TestCase):
    def test_known_dates(self):
        cases = [
            (date(2024, 3, 19), 1402), (date(2024, 3, 20), 1403),
            (date(2025, 3, 20), 1403), (date(2025, 3, 21), 1404),
            (date(2026, 3, 20), 1404), (date(2026, 3, 21), 1405),
            (date(2026, 10, 8), 1405), (date(2027, 3, 20), 1405), (date(2027, 3, 21), 1406),
        ]
        for d, expected in cases:
            self.assertEqual(gregorian_to_jalali_year(d.year, d.month, d.day), expected, d)

    def test_current_year_helper(self):
        self.assertEqual(current_jalali_year(date(2026, 10, 8)), 1405)


# ------------------------------------------------------- اجرای واقعی (بدون تنظیمات تست)

class RealStartupTests(unittest.TestCase):
    def test_app_starts_with_its_own_secret_key_and_keeps_it(self):
        with tempfile.TemporaryDirectory() as d:
            app1 = create_app(instance_path=d)           # مثل run.py، بدون SECRET_KEY دستی
            self.assertEqual(app1.test_client().get("/setup").status_code, 200)     # برنامهٔ خام: راه‌اندازی اولیه
            key1 = app1.config["SECRET_KEY"]
            self.assertTrue(key1)
            app2 = create_app(instance_path=d)           # بعد از ری‌استارت همان کلید (لاگین‌ها نپرند)
            self.assertEqual(app2.config["SECRET_KEY"], key1)


class FirstRunSetupTests(unittest.TestCase):
    def test_blank_app_asks_for_first_admin_once(self):
        with tempfile.TemporaryDirectory() as d:
            app = create_app({"AUTO_BACKUP": False}, instance_path=d)
            c = app.test_client()
            r = c.get("/login")
            self.assertEqual((r.status_code, r.headers["Location"]), (302, "/setup"))
            self.assertEqual(c.get("/").status_code, 302)
            c.get("/setup")
            with c.session_transaction() as s:
                t = s["csrf"]
            bad = c.post("/setup", data={"csrf": t, "username": "boss", "password": "abcdef", "password2": "x"})
            self.assertEqual(bad.status_code, 200)
            short = c.post("/setup", data={"csrf": t, "username": "boss", "password": "abc", "password2": "abc"})
            self.assertEqual(short.status_code, 200)
            ok = c.post("/setup", data={"csrf": t, "username": "boss", "full_name": "مدیر", "password": "abcdef",
                                        "password2": "abcdef"})
            self.assertEqual(ok.headers["Location"], "/login")
            self.assertEqual(c.get("/login").status_code, 200)
            self.assertEqual(c.get("/setup").headers["Location"], "/login")          # دیگر باز نمی‌شود
            r = c.post("/setup", data={"csrf": t, "username": "evil", "password": "abcdef", "password2": "abcdef"})
            self.assertEqual(r.status_code, 302)
            from app.db import connect
            db = connect(app.config["DATABASE"])
            self.assertEqual([x["username"] for x in db.execute("SELECT username FROM users")], ["boss"])
            self.assertEqual(db.execute("SELECT role FROM users").fetchone()["role"], "admin")
            self.assertEqual(db.execute("SELECT COUNT(*) FROM cases").fetchone()[0], 0)


# ---------------------------------------------------------------- وب (لاگین، دسترسی، فرم)

class WebTests(BaseCase):
    def client_for(self, username=None, password="secret1"):
        c = self.app.test_client()
        if username:
            r = c.post("/login", data={"username": username, "password": password, "csrf": self.token(c)})
            self.assertEqual(r.status_code, 302, "login failed")
        return c

    def token(self, c):
        c.get("/login")
        with c.session_transaction() as s:
            return s["csrf"]

    def form_token(self, c):
        """مثل کاربر واقعی: اول صفحه فرم باز می‌شود، سپس فرم ارسال می‌شود."""
        self.assertEqual(c.get("/cases/new").status_code, 200)
        with c.session_transaction() as s:
            return s["csrf"]

    # --- ورود
    def test_pages_require_login(self):
        c = self.app.test_client()
        for path in ("/", "/cases", "/cases/new", "/api/next-number?case_type=tender"):
            r = c.get(path)
            self.assertEqual(r.status_code, 302, path)
            self.assertIn("/login", r.headers["Location"])

    def test_wrong_password_is_rejected(self):
        c = self.app.test_client()
        r = c.post("/login", data={"username": "entry1", "password": "bad", "csrf": self.token(c)})
        self.assertEqual(r.status_code, 200)
        self.assertIn("اشتباه", r.get_data(as_text=True))
        self.assertEqual(c.get("/").status_code, 302)

    def test_login_without_csrf_is_rejected(self):
        c = self.app.test_client()
        r = c.post("/login", data={"username": "entry1", "password": "secret1"})
        self.assertEqual(r.status_code, 400)

    def test_login_does_not_redirect_to_other_sites(self):
        c = self.app.test_client()
        r = c.post("/login?next=//evil.example", data={
            "username": "entry1", "password": "secret1", "csrf": self.token(c)})
        self.assertNotIn("evil", r.headers["Location"])

    def test_logout(self):
        c = self.client_for("entry1")
        self.assertEqual(c.get("/").status_code, 200)
        with c.session_transaction() as s:
            t = s["csrf"]
        c.post("/logout", data={"csrf": t})
        self.assertEqual(c.get("/").status_code, 302)

    # --- سطح دسترسی
    def test_viewer_cannot_create_cases(self):
        c = self.client_for("viewer1")
        self.assertEqual(c.get("/cases/new").status_code, 403)
        with c.session_transaction() as s:
            t = s["csrf"]
        r = c.post("/cases/new", data={"case_type": "tender", "csrf": t})
        self.assertEqual(r.status_code, 403)
        self.assertEqual(self.count_cases(), 0)

    def test_viewer_can_see_dashboard_and_list(self):
        c = self.client_for("viewer1")
        self.assertEqual(c.get("/").status_code, 200)
        self.assertEqual(c.get("/cases").status_code, 200)

    def test_dashboard_shows_create_button_only_to_allowed_roles(self):
        self.assertIn('href="/cases/new"', self.client_for("entry1").get("/").get_data(as_text=True))
        self.assertNotIn('href="/cases/new"', self.client_for("viewer1").get("/").get_data(as_text=True))

    # --- فرم
    def test_form_cannot_be_saved_without_case_type(self):
        c = self.client_for("entry1")
        t = self.form_token(c)
        for data in ({"csrf": t}, {"csrf": t, "case_type": ""}, {"csrf": t, "case_type": "weird"}):
            r = c.post("/cases/new", data=data)
            self.assertEqual(r.status_code, 400)
            self.assertIn("نوع پرونده", r.get_data(as_text=True))
        self.assertEqual(self.count_cases(), 0)

    def test_form_without_csrf_is_rejected(self):
        c = self.client_for("entry1")
        r = c.post("/cases/new", data={"case_type": "tender"})
        self.assertEqual(r.status_code, 400)
        self.assertEqual(self.count_cases(), 0)

    def test_saving_through_the_form_numbers_each_type_separately(self):
        c = self.client_for("entry1")
        t = self.form_token(c)
        for _ in range(3):
            r = c.post("/cases/new", data={"case_type": "tender", "csrf": t}, follow_redirects=True)
            self.assertEqual(r.status_code, 200)
        r = c.post("/cases/new", data={"case_type": "inquiry", "csrf": t}, follow_redirects=True)
        body = r.get_data(as_text=True)
        self.assertIn("استعلام", body)
        rows = self.db.execute("SELECT case_type, serial_no FROM cases ORDER BY id").fetchall()
        self.assertEqual([tuple(x) for x in rows],
                         [("tender", 1), ("tender", 2), ("tender", 3), ("inquiry", 1)])

    def test_form_page_has_no_delete_option_and_locks_save_until_type_chosen(self):
        html = self.client_for("entry1").get("/cases/new").get_data(as_text=True)
        self.assertIn('id="save-btn"', html)
        self.assertIn("disabled>ذخیره", html.replace("\n", ""))
        for word in ("حذف", "delete"):
            self.assertNotIn(word, html)
        self.assertNotIn('name="delete"', html)
        self.assertEqual(self.client_for("entry1").delete("/cases/new").status_code, 405)

    def test_next_number_api(self):
        c = self.client_for("entry1")
        self.assertEqual(c.get("/api/next-number?case_type=tender").get_json(), {"next": 1})
        create_case(self.db, "tender", self.entry)
        self.assertEqual(c.get("/api/next-number?case_type=tender").get_json(), {"next": 2})
        self.assertEqual(c.get("/api/next-number?case_type=inquiry").get_json(), {"next": 1})
        self.assertEqual(c.get("/api/next-number?case_type=zzz").status_code, 400)

    def test_list_shows_saved_cases(self):
        create_case(self.db, "tender", self.entry)
        html = self.client_for("viewer1").get("/cases").get_data(as_text=True)
        self.assertIn("مناقصه", html)
        self.assertIn('href="/cases/1"', html)


if __name__ == "__main__":
    unittest.main()
