"""تست‌های فرم کامل پرونده: فیلدها، ردیف‌های محصولات و رقبا، ویرایش، تداخل دو کاربر، گزینه‌ها."""
import os
import sqlite3
import tempfile
import unittest
from unittest import mock

from app import auth, case_data, config, create_app, options
from app.db import connect, init_db
from app.jalali import normalize_jdate
from app.numbering import create_case

from tests.test_app import BaseCase


class JalaliDateTests(unittest.TestCase):
    def test_valid_and_normalized(self):
        self.assertEqual(normalize_jdate("1405/07/16"), "1405/07/16")
        self.assertEqual(normalize_jdate("۱۴۰۵/۷/۱۶"), "1405/07/16")
        self.assertEqual(normalize_jdate("1405-7-1"), "1405/07/01")
        self.assertEqual(normalize_jdate("1403/12/30"), "1403/12/30")   # سال کبیسه

    def test_invalid(self):
        for bad in ("", "abc", "1405/13/01", "1405/00/10", "1405/07/32", "1405/07/31",
                    "1404/12/30", "1405/7", "05/07/16", "2026/10/08"):
            self.assertIsNone(normalize_jdate(bad), bad)


class FormBase(BaseCase):
    def setUp(self):
        super().setUp()
        options.add_labels(self.db, "organization", "شرکت الف\nشرکت ب")
        options.add_labels(self.db, "source", "ایمیل\nتلفن")
        options.add_labels(self.db, "status", "در حال بررسی\nارسال شد")
        options.add_labels(self.db, "product_type", "شیر\nلوله")
        options.add_labels(self.db, "size", "۱ اینچ\n۲ اینچ")

    # ---- ابزارها
    def login(self, username):
        c = self.app.test_client()
        c.get("/login")
        with c.session_transaction() as s:
            t = s["csrf"]
        r = c.post("/login", data={"username": username, "password": "secret1", "csrf": t})
        self.assertEqual(r.status_code, 302)
        return c

    def token(self, c, path="/cases/new"):
        self.assertEqual(c.get(path).status_code, 200)
        with c.session_transaction() as s:
            return s["csrf"]

    def new_data(self, token, **over):
        data = {"csrf": token, "case_type": "tender"}
        data.update(over)
        return data

    def case_row(self, case_id=1):
        return self.db.execute("SELECT * FROM cases WHERE id = ?", (case_id,)).fetchone()


class FullFormTests(FormBase):
    def full_data(self, t):
        return self.new_data(
            t,
            received_date="۱۴۰۵/۷/۱۶", source="ایمیل", organization="شرکت الف",
            tender_type="", status="در حال بررسی", send_deadline="1405/08/01",
            physical_upload="14:30", opening_time="1405/08/10", decision="", result="بازنده",
            notes="توضیح آزمایشی",
            prod_uid=["new-1", "new-2"], prod_product_type=["شیر", "لوله"], prod_size=["۱ اینچ", ""],
            prod_quantity=["5", "1,200"], prod_model=["", ""], prod_sample=["", ""],
            comp_uid=["new-1", "new-2"], comp_name=["رقیب ۱", "رقیب ۲"],
            comp_price=["1,000,000", "0"], comp_note=["", "گران"], comp_won=["new-2"],
        )

    def test_everything_is_saved_in_one_go(self):
        c = self.login("entry1")
        t = self.token(c)
        r = c.post("/cases/new", data=self.full_data(t))
        self.assertEqual(r.status_code, 302)
        self.assertTrue(r.headers["Location"].endswith("/cases/1"))

        row = self.case_row()
        self.assertEqual((row["case_type"], row["serial_no"]), ("tender", 1))
        self.assertEqual(row["received_date"], "۱۴۰۵/۰۷/۱۶")       # بدون صفر -> استاندارد، ارقام فارسی
        self.assertEqual(row["organization"], "شرکت الف")
        self.assertEqual(row["notes"], "توضیح آزمایشی")
        prods = self.db.execute("SELECT * FROM case_products ORDER BY id").fetchall()
        self.assertEqual([(p["product_type"], p["size"], p["quantity"]) for p in prods],
                         [("شیر", "۱ اینچ", 5), ("لوله", "", 1200)])
        comps = self.db.execute("SELECT * FROM case_competitors ORDER BY id").fetchall()
        self.assertEqual([(x["name"], x["price"], x["won"]) for x in comps],
                         [("رقیب ۱", 1000000, 0), ("رقیب ۲", 0, 1)])

        html = c.get("/cases/1").get_data(as_text=True)
        for text in ("شرکت الف", "۱۴۰۵/۰۷/۱۶", "رقیب ۲", "۱,۲۰۰"):
            self.assertIn(text, html)

    def test_invalid_input_saves_nothing_and_does_not_burn_a_number(self):
        c = self.login("entry1")
        t = self.token(c)
        bad = self.full_data(t)
        bad["received_date"] = "1405/13/40"
        r = c.post("/cases/new", data=bad)
        self.assertEqual(r.status_code, 400)
        body = r.get_data(as_text=True)
        self.assertIn("تاریخ دریافت", body)
        self.assertEqual(self.count_cases(), 0)
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM counters").fetchone()[0], 0)
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM case_products").fetchone()[0], 0)

        good = self.full_data(t)
        c.post("/cases/new", data=good)
        self.assertEqual(self.case_row()["serial_no"], 1)

    def test_validation_rules(self):
        c = self.login("entry1")
        t = self.token(c)
        cases = {
            "organization not in list": {"organization": "ناشناس"},
            "bad quantity": {"prod_uid": ["new-1"], "prod_quantity": ["abc"], "prod_product_type": [""],
                             "prod_size": [""], "prod_model": [""], "prod_sample": [""]},
            "bad price": {"result": "بازنده", "comp_uid": ["new-1"], "comp_name": ["x"], "comp_price": ["12x"],
                          "comp_note": [""]},
            "competitor without name": {"result": "بازنده", "comp_uid": ["new-1"], "comp_name": [""], "comp_price": ["500"],
                                        "comp_note": [""]},
            "product option not in list": {"prod_uid": ["new-1"], "prod_product_type": ["ناشناس"],
                                           "prod_size": [""], "prod_quantity": ["1"],
                                           "prod_model": [""], "prod_sample": [""]},
            "foreign row id": {"prod_uid": ["7"], "prod_product_type": ["شیر"], "prod_size": [""],
                               "prod_quantity": ["1"], "prod_model": [""], "prod_sample": [""]},
            "too long notes": {"notes": "x" * 2001},
        }
        for name, extra in cases.items():
            r = c.post("/cases/new", data=self.new_data(t, **extra))
            self.assertEqual(r.status_code, 400, name)
        self.assertEqual(self.count_cases(), 0)

    def test_empty_new_rows_are_ignored(self):
        c = self.login("entry1")
        t = self.token(c)
        c.post("/cases/new", data=self.new_data(
            t, prod_uid=["new-1"], prod_product_type=[""], prod_size=[""], prod_quantity=["0"],
            prod_model=[""], prod_sample=[""],
            comp_uid=["new-1"], comp_name=[""], comp_price=["0"], comp_note=[""]))
        self.assertEqual(self.count_cases(), 1)
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM case_products").fetchone()[0], 0)
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM case_competitors").fetchone()[0], 0)

    def test_form_page_contains_all_access_fields(self):
        html = self.login("entry1").get("/cases/new").get_data(as_text=True)
        for label in ("نوع پرونده", "شماره شناسنامه", "تاریخ دریافت", "منبع دریافت", "سازمان / شرکت",
                      "نام محصول", "سایز", "تعداد", "مدل", "نمونه", "نوع برگزاری", "وضعیت پرونده",
                      "مهلت ارسال", "ساعت مهلت ارسال اسناد", "تصمیم مدیریتی", "نتیجه",
                      "نام رقیب", "قیمت", "برنده شد", "یادداشت",
                      "ذخیره", "بستن", "فهرست پرونده‌ها", "محصولات را وارد کنید"):
            self.assertIn(label, html, label)
        # همه فیلدهای وابسته تا انتخاب نوع پرونده قفل‌اند
        markup = html.split("<script>")[0]          # خود کد جاوااسکریپت را نشماریم
        self.assertGreaterEqual(markup.count("data-needs-type"), 12)
        self.assertEqual(markup.count("data-needs-type disabled"), markup.count("data-needs-type"))


class DatePickerTests(FormBase):
    def test_form_uses_calendar_picker_not_typed_example_dates(self):
        c = self.login("entry1")
        html = c.get("/cases/new").get_data(as_text=True)
        self.assertIn("jdatepicker.js", html)
        self.assertEqual(html.count('class="jdate"'), 4)             # دریافت، مهلت ارسال، اعلام نتایج، بازگشایی
        self.assertNotIn("۱۴۰۵/۰۷/۱۶", html)                         # تاریخ نمونه داخل فیلد نیست
        js = c.get("/static/jdatepicker.js")
        self.assertEqual(js.status_code, 200)
        self.assertIn("jdp", js.get_data(as_text=True))

    def test_viewer_page_does_not_load_the_picker(self):
        create_case(self.db, "tender", self.entry, 1405)
        html = self.login("viewer1").get("/cases/1").get_data(as_text=True)
        self.assertNotIn("jdatepicker.js", html)


class EditTests(FormBase):
    def make_case(self, c=None):
        c = c or self.login("entry1")
        t = self.token(c)
        c.post("/cases/new", data=self.new_data(
            t, organization="شرکت الف",
            prod_uid=["new-1"], prod_product_type=["شیر"], prod_size=["۱ اینچ"], prod_quantity=["5"],
            prod_model=[""], prod_sample=[""],
            comp_uid=["new-1"], comp_name=["رقیب ۱"], comp_price=["100"], comp_note=[""]))
        return c

    def edit_data(self, c, case_id=1, **over):
        with c.session_transaction() as s:
            t = s["csrf"]
        case = case_data.load_case(self.db, case_id)
        data = {
            "csrf": t, "version": case["version"],
            "organization": case["organization"], "status": case["status"],
            "prod_uid": [str(p["id"]) for p in case["products"]],
            "prod_product_type": [p["product_type"] for p in case["products"]],
            "prod_size": [p["size"] for p in case["products"]],
            "prod_quantity": [str(p["quantity"]) for p in case["products"]],
            "prod_model": [p["model"] for p in case["products"]],
            "prod_sample": [p["sample"] for p in case["products"]],
            "comp_uid": [str(x["id"]) for x in case["competitors"]],
            "comp_name": [x["name"] for x in case["competitors"]],
            "comp_price": [str(x["price"]) for x in case["competitors"]],
            "comp_note": [x["note"] for x in case["competitors"]],
        }
        data.update(over)
        return data

    def test_edit_updates_fields_and_adds_rows_but_keeps_number(self):
        c = self.make_case()
        self.token(c, "/cases/1")
        d = self.edit_data(c, status="ارسال شد", result="برنده", case_type="inquiry")
        d["prod_uid"] = d["prod_uid"] + ["new-9"]
        d["prod_product_type"] += ["لوله"]; d["prod_size"] += [""]; d["prod_quantity"] += ["2"]
        d["prod_model"] += [""]; d["prod_sample"] += [""]
        r = c.post("/cases/1", data=d)
        self.assertEqual(r.status_code, 302)
        row = self.case_row()
        self.assertEqual((row["case_type"], row["serial_no"]), ("tender", 1))   # نوع و شماره ثابت
        self.assertEqual((row["status"], row["result"]), ("نتیجه اعلام شد", "برنده"))
        self.assertEqual(row["version"], 2)
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM case_products").fetchone()[0], 2)

    def test_two_users_editing_the_same_case_never_overwrite_each_other(self):
        self.make_case()
        a, b = self.login("entry1"), self.login("entry2")
        self.token(a, "/cases/1"); self.token(b, "/cases/1")
        da, db_ = self.edit_data(a, status="ارسال شد"), self.edit_data(b, status="در حال بررسی",
                                                                       organization="شرکت ب")
        self.assertEqual(a.post("/cases/1", data=da).status_code, 302)       # اولی ذخیره می‌شود
        r = b.post("/cases/1", data=db_)                                       # دومی با نسخه کهنه
        self.assertEqual(r.status_code, 409)
        self.assertIn("کاربر دیگری", r.get_data(as_text=True))
        row = self.case_row()
        self.assertEqual((row["status"], row["organization"]), ("ارسال شد", "شرکت الف"))  # تغییر دومی نیامد

    def test_conflict_rolls_back_everything_including_rows(self):
        self.make_case()
        a, b = self.login("entry1"), self.login("entry2")
        self.token(a, "/cases/1"); self.token(b, "/cases/1")
        a.post("/cases/1", data=self.edit_data(a, status="ارسال شد"))
        stale = self.edit_data(b, status="در حال بررسی")
        stale["prod_uid"] = stale["prod_uid"] + ["new-1"]
        stale["prod_product_type"] += ["لوله"]; stale["prod_size"] += [""]; stale["prod_quantity"] += ["9"]
        stale["prod_model"] += [""]; stale["prod_sample"] += [""]
        stale["version"] = 1
        self.assertEqual(b.post("/cases/1", data=stale).status_code, 409)
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM case_products").fetchone()[0], 1)

    def test_saved_rows_cannot_be_blanked(self):
        c = self.make_case()
        self.token(c, "/cases/1")
        d = self.edit_data(c)
        d.update(prod_product_type=[""], prod_size=[""], prod_quantity=["0"])
        r = c.post("/cases/1", data=d)
        self.assertEqual(r.status_code, 400)
        self.assertIn("خالی", r.get_data(as_text=True))
        self.assertEqual(self.db.execute("SELECT quantity FROM case_products").fetchone()[0], 5)

    def test_cannot_touch_rows_of_another_case(self):
        c = self.make_case()
        self.make_case(c)            # پرونده دوم
        foreign_product_id = self.db.execute(
            "SELECT id FROM case_products WHERE case_id = 1").fetchone()[0]
        self.token(c, "/cases/2")
        d = self.edit_data(c, case_id=2)
        d["prod_uid"] = [str(foreign_product_id)]
        d.update(prod_product_type=["لوله"], prod_size=[""], prod_quantity=["99"],
                 prod_model=[""], prod_sample=[""])
        self.assertEqual(c.post("/cases/2", data=d).status_code, 400)
        self.assertEqual(self.db.execute(
            "SELECT quantity FROM case_products WHERE id = ?", (foreign_product_id,)).fetchone()[0], 5)

    def test_edit_requires_csrf_and_version(self):
        c = self.make_case()
        self.token(c, "/cases/1")
        d = self.edit_data(c)
        no_csrf = dict(d); no_csrf.pop("csrf")
        self.assertEqual(c.post("/cases/1", data=no_csrf).status_code, 400)
        no_version = dict(d); no_version.pop("version")
        self.assertEqual(c.post("/cases/1", data=no_version).status_code, 400)

    def test_missing_case_is_404(self):
        self.assertEqual(self.login("entry1").get("/cases/999").status_code, 404)

    def test_viewer_sees_read_only_page_and_cannot_post(self):
        self.make_case()
        v = self.login("viewer1")
        v.get("/")                                   # پاپ‌آپ خوش‌آمد (و اسکریپتش) فقط یک بار، همین‌جا مصرف می‌شود
        html = v.get("/cases/1").get_data(as_text=True)
        self.assertIn("شرکت الف", html)
        self.assertNotIn('id="save-btn"', html)
        self.assertNotIn("getElementById('case-form')", html)         # اسکریپت فرم ویرایش برای بیننده نیست
        self.assertIn("فقط اجازه مشاهده", html)
        with v.session_transaction() as s:
            t = s["csrf"]
        self.assertEqual(v.post("/cases/1", data={"csrf": t, "version": 1}).status_code, 403)
        self.assertEqual(self.case_row()["version"], 1)

    def test_deactivated_option_keeps_old_cases_editable(self):
        c = self.make_case()
        oid = self.db.execute("SELECT id FROM options WHERE label = 'شرکت الف'").fetchone()[0]
        options.set_active(self.db, oid, False)
        self.token(c, "/cases/1")
        self.assertEqual(c.post("/cases/1", data=self.edit_data(c, status="ارسال شد")).status_code, 302)
        # ولی برای پرونده جدید دیگر مجاز نیست
        t = self.token(c)
        self.assertEqual(c.post("/cases/new", data=self.new_data(t, organization="شرکت الف")).status_code, 400)


class ListTests(FormBase):
    def test_filter_and_search(self):
        c = self.login("entry1")
        t = self.token(c)
        c.post("/cases/new", data=self.new_data(t, organization="شرکت الف"))
        c.post("/cases/new", data=self.new_data(t, case_type="inquiry", organization="شرکت ب"))
        html = c.get("/cases?type=inquiry").get_data(as_text=True)
        self.assertIn("شرکت ب", html)
        self.assertNotIn("شرکت الف", html)
        html = c.get("/cases?q=الف").get_data(as_text=True)
        self.assertIn("شرکت الف", html)
        self.assertNotIn("شرکت ب", html)
        self.assertEqual(c.get("/cases?q=%25").status_code, 200)       # علامت % جستجوی ویژه نیست


class OptionsAdminTests(FormBase):
    def test_only_admin_can_manage_options(self):
        for user in ("entry1", "viewer1"):
            self.assertEqual(self.login(user).get("/admin/options").status_code, 403)
        a = self.login("admin1")
        self.assertEqual(a.get("/admin/options").status_code, 200)
        t = self.token(a, "/admin/options")
        r = a.post("/admin/options", data={"csrf": t, "action": "add", "grp": "model", "lines": "A1\n\nA1\n  B2  "})
        self.assertEqual(r.status_code, 302)
        self.assertEqual(options.active_labels(self.db, "model"), ["A۱", "B۲"])      # تکراری و خالی نیامد
        self.assertEqual(a.post("/admin/options", data={"action": "add", "grp": "model", "lines": "Z"}).status_code, 400)
        self.assertEqual(a.post("/admin/options", data={"csrf": t, "action": "add", "grp": "bogus", "lines": "Z"}).status_code, 400)

    def test_disable_and_enable(self):
        a = self.login("admin1")
        t = self.token(a, "/admin/options")
        oid = self.db.execute("SELECT id FROM options WHERE label = 'ایمیل'").fetchone()[0]
        a.post("/admin/options", data={"csrf": t, "action": "disable", "option_id": oid, "grp": "source"})
        self.assertNotIn("ایمیل", options.active_labels(self.db, "source"))
        a.post("/admin/options", data={"csrf": t, "action": "enable", "option_id": oid, "grp": "source"})
        self.assertIn("ایمیل", options.active_labels(self.db, "source"))

    def test_options_cannot_be_deleted_in_database(self):
        with self.assertRaises(sqlite3.DatabaseError):
            self.db.execute("DELETE FROM options")

    def test_default_result_options_exist(self):
        self.assertEqual(options.active_labels(self.db, "result"), ["برنده", "بازنده"])


class NoDeletionTests(FormBase):
    def test_rows_cannot_be_deleted_in_database(self):
        c = self.login("entry1")
        t = self.token(c)
        c.post("/cases/new", data=self.new_data(
            t, prod_uid=["new-1"], prod_product_type=["شیر"], prod_size=[""], prod_quantity=["1"],
            prod_model=[""], prod_sample=[""],
            result="بازنده", comp_uid=["new-1"], comp_name=["x"], comp_price=["1"], comp_note=[""]))
        for table in ("case_products", "case_competitors", "cases"):
            with self.assertRaises(sqlite3.DatabaseError):
                self.db.execute(f"DELETE FROM {table}")


class BackupTests(FormBase):
    def test_backup_contains_the_saved_cases(self):
        import backup
        create_case(self.db, "tender", self.entry, 1405)
        with tempfile.TemporaryDirectory() as d:
            path = backup.make_backup(self.app.config["DATABASE"], d)
            self.assertTrue(os.path.exists(path))
            copy = connect(path)
            self.assertEqual(copy.execute("SELECT COUNT(*) FROM cases").fetchone()[0], 1)
            copy.close()

    def test_backup_of_missing_database_gives_clear_error(self):
        import backup
        with self.assertRaises(FileNotFoundError):
            backup.make_backup("/nonexistent/cases.sqlite", tempfile.gettempdir())


class UpgradeFromVersion1Tests(unittest.TestCase):
    """دیتابیس نسخه ۱ (که کاربر الان روی مک دارد) باید با اطلاعاتش به نسخه جدید ارتقا پیدا کند."""
    V1_SCHEMA = """
    CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL UNIQUE,
        password_hash TEXT NOT NULL, role TEXT NOT NULL CHECK (role IN ('admin','entry','viewer')),
        created_at TEXT NOT NULL DEFAULT (datetime('now')));
    CREATE TABLE counters (case_type TEXT NOT NULL, year INTEGER NOT NULL, last_no INTEGER NOT NULL,
        PRIMARY KEY (case_type, year));
    CREATE TABLE cases (id INTEGER PRIMARY KEY AUTOINCREMENT, case_type TEXT NOT NULL, year INTEGER NOT NULL,
        serial_no INTEGER NOT NULL, created_by INTEGER NOT NULL REFERENCES users(id),
        created_at TEXT NOT NULL DEFAULT (datetime('now')), UNIQUE (case_type, year, serial_no));
    CREATE TRIGGER cases_no_delete BEFORE DELETE ON cases BEGIN SELECT RAISE(ABORT, 'x'); END;
    CREATE TRIGGER cases_no_renumber BEFORE UPDATE OF case_type, year, serial_no ON cases
        BEGIN SELECT RAISE(ABORT, 'x'); END;
    """

    def test_upgrade_keeps_data_and_numbering(self):
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, "old.sqlite")
            old = sqlite3.connect(path)
            old.executescript(self.V1_SCHEMA)
            old.execute("INSERT INTO users (username, password_hash, role) VALUES ('ali', 'h', 'entry')")
            old.execute("INSERT INTO counters VALUES ('tender', 1405, 2)")
            old.execute("INSERT INTO cases (case_type, year, serial_no, created_by) VALUES ('tender',1405,1,1)")
            old.execute("INSERT INTO cases (case_type, year, serial_no, created_by) VALUES ('tender',1405,2,1)")
            old.commit(); old.close()

            init_db(path)
            init_db(path)                       # دوبار اجرا هم مشکلی ندارد

            conn = connect(path)
            cols = {r["name"] for r in conn.execute("PRAGMA table_info(cases)")}
            for col in ("organization", "notes", "version", "received_date", "result"):
                self.assertIn(col, cols)
            self.assertEqual(conn.execute("SELECT COUNT(*) FROM cases").fetchone()[0], 2)
            case = case_data.load_case(conn, 1)
            self.assertEqual((case["serial_no"], case["organization"], case["version"]), (1, "", 1))
            # شماره‌گذاری از جایی که بود ادامه پیدا می‌کند
            self.assertEqual(create_case(conn, "tender", 1, 1405)["serial_no"], 3)
            self.assertEqual(options.active_labels(conn, "result"), ["برنده", "بازنده"])
            conn.close()


if __name__ == "__main__":
    unittest.main()


class FieldRulesTests(FormBase):
    """قوانین جدید: علت بایگانی، رقبا فقط برای بازنده، ساعت، بازگشایی شمسی، مرتب‌سازی لیست."""

    def post_new(self, c, **over):
        t = self.token(c)
        return c.post("/cases/new", data=self.new_data(t, **over))

    def test_archive_requires_reason_and_reason_is_remembered(self):
        c = self.login("entry1")
        self.assertEqual(self.post_new(c, decision="عدم تایید و بایگانی").status_code, 400)
        self.assertEqual(self.count_cases(), 0)
        r = self.post_new(c, decision="عدم تایید و بایگانی", archive_reason="  مهلت  گذشته  ")
        self.assertEqual(r.status_code, 302)
        self.assertEqual(self.case_row()["archive_reason"], "مهلت گذشته")
        self.assertIn("مهلت گذشته", options.active_labels(self.db, "archive_reason"))
        # در پرونده بعدی به‌صورت گزینه آماده است
        html = c.get("/cases/new").get_data(as_text=True)
        self.assertIn('<option value="مهلت گذشته"', html)

    def test_reason_is_cleared_when_not_archived(self):
        c = self.login("entry1")
        self.post_new(c, decision="عدم تایید و بایگانی", archive_reason="علت الف")
        t = self.token(c, "/cases/1")
        v = self.case_row()["version"]
        r = c.post("/cases/1", data={"csrf": t, "version": v, "decision": "", "archive_reason": "علت الف"})
        self.assertEqual(r.status_code, 302)
        self.assertEqual(self.case_row()["archive_reason"], "")
        self.assertIn("علت الف", options.active_labels(self.db, "archive_reason"))   # لیست علت‌ها حفظ می‌شود

    def test_archive_option_always_exists(self):
        self.assertIn("عدم تایید و بایگانی", options.active_labels(self.db, "decision"))
        self.assertIn("بازنده", options.active_labels(self.db, "result"))

    def test_competitors_only_saved_for_loser(self):
        c = self.login("entry1")
        rows = dict(comp_uid=["new-1"], comp_name=["رقیب"], comp_price=["5"], comp_note=[""])
        self.post_new(c, result="برنده", **rows)
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM case_competitors").fetchone()[0], 0)
        self.post_new(c, result="بازنده", **rows)
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM case_competitors").fetchone()[0], 1)

    def test_saved_competitors_survive_result_change_and_show_again(self):
        c = self.login("entry1")
        self.post_new(c, result="بازنده", comp_uid=["new-1"], comp_name=["رقیب مهم"],
                      comp_price=["5"], comp_note=[""])
        t = self.token(c, "/cases/1")
        v = self.case_row()["version"]
        # نتیجه عوض می‌شود؛ بخش رقبا در فرم نبوده پس چیزی ارسال نمی‌شود
        self.assertEqual(c.post("/cases/1", data={"csrf": t, "version": v, "result": "برنده"}).status_code, 302)
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM case_competitors").fetchone()[0], 1)
        html = c.get("/cases/1").get_data(as_text=True)
        self.assertIn('id="box-competitors"', html)
        self.assertRegex(html, r'id="box-competitors"[^>]*hidden')       # پنهان
        self.assertIn("رقیب مهم", html)                                  # ولی از بین نرفته

    def test_conditional_boxes_visibility_in_page(self):
        c = self.login("entry1")
        self.post_new(c, decision="عدم تایید و بایگانی", archive_reason="x", result="بازنده")
        html = c.get("/cases/1").get_data(as_text=True)
        self.assertNotRegex(html, r'id="box-archive"[^>]*hidden')
        self.assertRegex(html, r'id="box-competitors"[^>]*hidden')      # عدم‌تایید: نتیجه ندارد، پس رقبا هم نیست
        self.post_new(c)
        html = c.get("/cases/2").get_data(as_text=True)
        self.assertRegex(html, r'id="box-archive"[^>]*hidden')

    def test_field_order_in_form(self):
        html = self.login("entry1").get("/cases/new").get_data(as_text=True).split("<script>")[0]
        order = ["نوع برگزاری", "مهلت ارسال (شمسی)", "ساعت مهلت ارسال اسناد", "تصمیم مدیریتی", "علت بایگانی",
                 "وضعیت پرونده", ">نتیجه<", "رقیب / رقبا"]
        pos = [html.index(x, html.index("cols5")) for x in order]
        self.assertEqual(pos, sorted(pos))

    def test_persian_digits_in_quantity_saved_correctly(self):
        c = self.login("entry1")
        t = self.token(c)
        c.post("/cases/new", data=self.new_data(
            t, prod_uid=["new-1", "new-2"], prod_product_type=["شیر", "شیر"], prod_size=["", ""],
            prod_quantity=["۸۹۹", "۱,۲۰۰"], prod_model=["", ""], prod_sample=["", ""]))
        qs = [r[0] for r in self.db.execute("SELECT quantity FROM case_products ORDER BY id")]
        self.assertEqual(qs, [899, 1200])

    def test_time_and_opening_date_validation(self):
        c = self.login("entry1")
        self.assertEqual(self.post_new(c, send_deadline="۱۴۰۵/۱۲/۲۰", physical_upload="25:99").status_code, 400)
        self.assertEqual(self.post_new(c, opening_time="سلام").status_code, 400)
        self.assertEqual(self.count_cases(), 0)
        self.post_new(c, send_deadline="۱۴۰۵/۱۲/۲۰", physical_upload="۹:05", opening_time="۱۴۰۵/۱۲/۲۹")
        row = self.case_row()
        self.assertEqual((row["physical_upload"], row["opening_time"]), ("۰۹:۰۵", "۱۴۰۵/۱۲/۲۹"))

    def test_old_free_text_values_stay_editable(self):
        c = self.login("entry1")
        self.post_new(c)
        self.db.execute("UPDATE cases SET send_deadline='۱۴۰۵/۰۸/۰۱', physical_upload='با پیک', opening_time='ظهر' WHERE id=1")
        t = self.token(c, "/cases/1")
        v = self.case_row()["version"]
        r = c.post("/cases/1", data={"csrf": t, "version": v, "send_deadline": "۱۴۰۵/۰۸/۰۱", "physical_upload": "با پیک",
                                      "opening_time": "ظهر", "notes": "n"})
        self.assertEqual(r.status_code, 302)

    def test_list_sorting_is_whitelisted_and_works(self):
        c = self.login("entry1")
        self.post_new(c, organization="شرکت ب", send_deadline="1405/09/01")
        self.post_new(c, organization="شرکت الف", send_deadline="1405/08/01")
        self.post_new(c, organization="")
        html = c.get("/cases?sort=deadline&dir=asc").get_data(as_text=True)
        self.assertLess(html.index("۱۴۰۵/۰۸/۰۱"), html.index("۱۴۰۵/۰۹/۰۱"))
        html = c.get("/cases?sort=deadline&dir=desc").get_data(as_text=True)
        self.assertLess(html.index("۱۴۰۵/۰۹/۰۱"), html.index("۱۴۰۵/۰۸/۰۱"))
        html = c.get("/cases?sort=org&dir=asc").get_data(as_text=True)
        self.assertLess(html.index("شرکت الف"), html.index("شرکت ب"))
        for bad in ("sort=1;DROP TABLE cases", "sort=c.id&dir=asc", "sort=&dir=zzz"):
            self.assertEqual(c.get("/cases?" + bad).status_code, 200)
        self.assertEqual(self.count_cases(), 3)
        for col in ("نوع پرونده", "شماره شناسنامه", "تاریخ دریافت", "مهلت ارسال", "وضعیت پرونده", "سازمان", "یادداشت", "ویرایش"):
            self.assertIn(col, html)


class PickerBugRegressionTests(FormBase):
    def test_picker_keeps_month_year_lists_usable_and_open(self):
        js = self.login("entry1").get("/static/jdatepicker.js").get_data(as_text=True)
        self.assertIn("SELECT|OPTION", js)     # لیست ماه/سال نباید با preventDefault قفل شود
        self.assertIn("jdpHandled", js)        # کلیک روی فلش‌ها نباید تقویم را ببندد


class FlexibleMatchTests(FormBase):
    def test_archived_variants_also_show_reason_field(self):
        options.add_labels(self.db, "decision", "عدم تایید و بايگانی شد")        # با «ي» عربی؛ فارسی‌سازی می‌شود
        self.assertIn("عدم تایید و بایگانی شد", options.active_labels(self.db, "decision"))
        c = self.login("entry1")
        t = self.token(c)
        self.assertEqual(c.post("/cases/new", data=self.new_data(t, decision="عدم تایید و بایگانی شد")).status_code, 400)
        r = c.post("/cases/new", data=self.new_data(t, decision="عدم تایید و بایگانی شد", archive_reason="علت"))
        self.assertEqual(r.status_code, 302)
        html = c.get("/cases/1").get_data(as_text=True)
        self.assertNotRegex(html, r'id="box-archive"[^>]*hidden')


class ResetDataTests(FormBase):
    def test_reset_empties_cases_keeps_users_and_options_and_backs_up(self):
        import reset_data, tempfile
        c = self.login("entry1")
        t = self.token(c)
        c.post("/cases/new", data=self.new_data(t, organization="شرکت الف"))
        self.assertEqual(self.count_cases(), 1)
        path = self.app.config["DATABASE"]
        folder = tempfile.mkdtemp()
        self.db.close()
        self.assertIsNotNone(reset_data.reset(path, folder, ask=lambda _: "YES"))
        db = sqlite3.connect(path)
        self.assertEqual(db.execute("SELECT COUNT(*) FROM cases").fetchone()[0], 0)
        self.assertEqual(db.execute("SELECT COUNT(*) FROM counters").fetchone()[0], 0)
        self.assertGreaterEqual(db.execute("SELECT COUNT(*) FROM users").fetchone()[0], 1)
        self.assertEqual(db.execute("SELECT COUNT(*) FROM options WHERE label='شرکت الف'").fetchone()[0], 1)
        db.close()
        backup = [f for f in os.listdir(folder)][0]
        b = sqlite3.connect(os.path.join(folder, backup))
        self.assertEqual(b.execute("SELECT COUNT(*) FROM cases").fetchone()[0], 1)    # بکاپ کامل
        b.close()
        # بدون تأیید هیچ اتفاقی نمی‌افتد
        self.assertIsNone(reset_data.reset(path, folder, ask=lambda _: "no"))

    def test_after_reset_numbering_restarts_at_one(self):
        import reset_data, tempfile
        c = self.login("entry1")
        t = self.token(c)
        c.post("/cases/new", data=self.new_data(t))
        c.post("/cases/new", data=self.new_data(t))
        self.db.close()
        reset_data.reset(self.app.config["DATABASE"], tempfile.mkdtemp(), ask=lambda _: "YES")
        c = self.login("entry1")
        t = self.token(c)
        c.post("/cases/new", data=self.new_data(t))
        db = sqlite3.connect(self.app.config["DATABASE"])
        self.assertEqual(db.execute("SELECT serial_no FROM cases").fetchone()[0], 1)
        db.close()


class InAppBackupTests(FormBase):
    def setUp(self):
        super().setUp()
        self.home = os.path.join(self.tmp.name, "home")
        os.makedirs(self.home)
        patcher = mock.patch.dict(os.environ, {"HOME": self.home, "USERPROFILE": self.home})
        patcher.start()
        self.addCleanup(patcher.stop)
        self.bdir = os.path.join(self.tmp.name, "bk")
        self.extra = os.path.join(self.tmp.name, "dropbox")
        os.makedirs(self.extra)
        self.app.config["BACKUP_DIR"] = self.bdir
        self.app.config["BACKUP_SETTINGS_FILE"] = os.path.join(self.tmp.name, "s.json")

    def admin_login(self):
        c = self.login("admin1")
        return c, self.token(c, "/admin/backup")

    def test_only_admin_sees_backup_page(self):
        self.assertEqual(self.login("entry1").get("/admin/backup").status_code, 403)
        self.assertEqual(self.login("viewer1").get("/admin/backup/download/cases-2026-01-01_00-00-00.sqlite").status_code, 403)
        self.assertEqual(self.login("admin1").get("/admin/backup").status_code, 200)

    def test_user_chooses_main_folder_and_extra_folders(self):
        c, t = self.admin_login()
        chosen = os.path.join(self.tmp.name, "my", "chosen")           # پوشهٔ دلخواه (ساخته می‌شود)
        os.makedirs(os.path.dirname(chosen))
        c.post("/admin/backup", data={"csrf": t, "action": "settings", "dir": chosen,
                                      "folders": self.extra + "\n/no/such/dir"})
        c.post("/admin/backup", data={"csrf": t, "action": "run"})
        self.assertEqual(len(os.listdir(chosen)), 1)                   # پوشهٔ اصلی انتخابی
        self.assertEqual(len(os.listdir(self.extra)), 1)               # نسخهٔ اضافه
        self.assertFalse(os.path.exists(self.bdir))                    # پوشهٔ پیش‌فرض استفاده نشد
        name = os.listdir(chosen)[0]
        self.assertIn(name, c.get("/admin/backup").get_data(as_text=True))
        d = c.get("/admin/backup/download/" + name)
        self.assertTrue(d.data.startswith(b"SQLite format 3"))
        d.close()
        self.assertEqual(c.get("/admin/backup/download/..%2Fetc%2Fpasswd").status_code, 404)
        self.assertEqual(c.get("/admin/backup/download/evil.sqlite").status_code, 404)

    def test_onedrive_and_dropbox_are_active_by_default(self):
        os.makedirs(os.path.join(self.home, "Dropbox"))
        os.makedirs(os.path.join(self.home, "Library", "CloudStorage", "OneDrive-Company"))
        c, t = self.admin_login()
        c.post("/admin/backup", data={"csrf": t, "action": "run"})
        for base in (os.path.join(self.home, "Dropbox"),
                     os.path.join(self.home, "Library", "CloudStorage", "OneDrive-Company")):
            files = os.listdir(os.path.join(base, "IranEnsheab-Backups"))
            self.assertEqual(len(files), 1, base)
        html = c.get("/admin/backup").get_data(as_text=True)
        self.assertIn("Dropbox", html)

    def test_restore_from_list_brings_old_data_back_and_keeps_safety_copy(self):
        c = self.login("admin1")
        t = self.token(c, "/admin/backup")
        c.post("/cases/new", data=self.new_data(t, organization="شرکت الف"))     # پرونده ۱
        c.post("/admin/backup", data={"csrf": t, "action": "run"})
        name = os.listdir(self.bdir)[0]
        c.post("/cases/new", data=self.new_data(t, organization="شرکت ب"))        # پرونده ۲، بعد از بکاپ
        self.assertEqual(self.count_cases(), 2)
        r = c.post("/admin/backup", data={"csrf": t, "action": "restore", "name": name, "confirm": "YES"})
        self.assertEqual(r.status_code, 302)
        self.assertEqual(self.count_cases(), 1)
        files = sorted(os.listdir(self.bdir))
        self.assertEqual(len(files), 2)                                         # بکاپ ایمنی ساخته شد
        counts = []
        for f in files:
            conn = sqlite3.connect(os.path.join(self.bdir, f))
            counts.append(conn.execute("SELECT COUNT(*) FROM cases").fetchone()[0])
            conn.close()
        self.assertEqual(sorted(counts), [1, 2])               # بکاپ قبلی (۱ پرونده) + نسخهٔ ایمنی (۲ پرونده)
        # برنامه بعد از بازگردانی سالم کار می‌کند و شماره‌گذاری ادامه می‌دهد
        c = self.login("admin1")
        t = self.token(c)
        c.post("/cases/new", data=self.new_data(t))
        self.assertEqual(self.db.execute("SELECT MAX(serial_no) FROM cases").fetchone()[0], 2)

    def test_restore_needs_yes_and_valid_name(self):
        c, t = self.admin_login()
        c.post("/admin/backup", data={"csrf": t, "action": "run"})
        name = os.listdir(self.bdir)[0]
        c.post("/cases/new", data=self.new_data(t))
        c.post("/admin/backup", data={"csrf": t, "action": "restore", "name": name, "confirm": "no"})
        self.assertEqual(self.count_cases(), 1)                                  # بدون YES تغییری نیست
        r = c.post("/admin/backup", data={"csrf": t, "action": "restore", "name": "../x.sqlite", "confirm": "YES"})
        self.assertEqual(r.status_code, 400)
        self.assertEqual(self.count_cases(), 1)

    def test_restore_from_uploaded_file_and_rejects_garbage(self):
        import io
        c, t = self.admin_login()
        c.post("/admin/backup", data={"csrf": t, "action": "run"})
        good = open(os.path.join(self.bdir, os.listdir(self.bdir)[0]), "rb").read()
        c.post("/cases/new", data=self.new_data(t))
        self.assertEqual(self.count_cases(), 1)
        # فایل خراب: اطلاعات فعلی دست‌نخورده می‌ماند
        c.post("/admin/backup", data={"csrf": t, "action": "restore", "confirm": "YES",
                                      "file": (io.BytesIO(b"this is not a database"), "x.sqlite")},
               content_type="multipart/form-data")
        self.assertEqual(self.count_cases(), 1)
        # فایل سالم
        c.post("/admin/backup", data={"csrf": t, "action": "restore", "confirm": "YES",
                                      "file": (io.BytesIO(good), "old.sqlite")},
               content_type="multipart/form-data")
        self.assertEqual(self.count_cases(), 0)
        self.assertEqual([f for f in os.listdir(self.bdir) if f.endswith(".sqlite") and not f.startswith("cases-")], [])

    def test_backup_when_app_opens_and_daily(self):
        folder = os.path.join(self.tmp.name, "auto")
        app = create_app({"TESTING": True, "SECRET_KEY": "x", "AUTO_BACKUP": True,
                          "DATABASE": self.app.config["DATABASE"], "BACKUP_DIR": folder,
                          "BACKUP_SETTINGS_FILE": os.path.join(self.tmp.name, "s2.json")})
        self.assertEqual(len(os.listdir(folder)), 1)               # هنگام باز شدن برنامه
        c = app.test_client()
        c.get("/login")
        c.get("/login")
        self.assertEqual(len(os.listdir(folder)), 1)               # همان روز دوباره نمی‌سازد


class SeedOptionsTests(FormBase):
    def test_organizations_from_access_are_loaded_once_without_duplicates(self):
        from app.seed_options import SEED_OPTIONS
        orgs = SEED_OPTIONS["organization"]
        self.assertEqual(len(orgs), 38)
        self.assertEqual(len(set(orgs)), 38)
        self.assertIn("شرکت آب و فاضلاب استان سمنان", options.active_labels(self.db, "organization"))
        n = self.db.execute("SELECT COUNT(*) FROM options WHERE grp='organization'").fetchone()[0]
        self.assertGreaterEqual(n, 38)
        # باز شدن دوباره برنامه چیزی را تکراری نمی‌کند و گزینهٔ غیرفعال‌شده را فعال نمی‌کند
        self.db.execute("UPDATE options SET active=0 WHERE label=?", (orgs[0],))
        init_db(self.app.config["DATABASE"])
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM options WHERE grp='organization'").fetchone()[0], n)
        self.assertNotIn(orgs[0], options.active_labels(self.db, "organization"))


class SearchableComboTests(FormBase):
    def test_form_loads_search_script_and_keeps_real_selects_for_submission(self):
        c = self.login("entry1")
        html = c.get("/cases/new").get_data(as_text=True)
        self.assertIn("searchable-select.js", html)
        js = c.get("/static/searchable-select.js")
        self.assertEqual(js.status_code, 200)
        text = js.get_data(as_text=True)
        js.close()
        self.assertIn("ي", text)                                # جستجو ی/ي عربی را یکی می‌گیرد
        self.assertIn('name="organization"', html)             # خود select برای ارسال فرم سر جایش است
        # فرم برای بیننده (فقط‌خواندنی) اسکریپت را نمی‌گیرد
        self.assertNotIn("searchable-select.js", self.login("viewer1").get("/cases/new").get_data(as_text=True))


class QuickAddOptionTests(FormBase):
    def post_add(self, c, t, grp, label):
        return c.post("/api/options/add", data={"csrf": t, "grp": grp, "label": label})

    def test_plus_button_adds_option_for_next_cases_without_duplicates(self):
        c = self.login("entry1")
        t = self.token(c)
        r = self.post_add(c, t, "size", "  ۲۲   اینچ ")
        self.assertEqual(r.get_json(), {"ok": True, "label": "۲۲ اینچ", "existed": False})
        self.assertTrue(self.post_add(c, t, "size", "۲۲ اینچ").get_json()["existed"])
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM options WHERE grp='size' AND label='۲۲ اینچ'").fetchone()[0], 1)
        # بلافاصله قابل ذخیره در پرونده است
        self.assertEqual(c.post("/cases/new", data=self.new_data(t, prod_uid=["new-1"], prod_size=["۲۲ اینچ"],
                         prod_product_type=[""], prod_quantity=["1"], prod_model=[""], prod_sample=[""])).status_code, 302)
        self.assertIn("۲۲ اینچ", c.get("/cases/new").get_data(as_text=True))

    def test_plus_button_rules(self):
        c = self.login("entry1")
        t = self.token(c)
        self.assertEqual(self.post_add(c, t, "size", "   ").status_code, 400)
        self.assertEqual(self.post_add(c, t, "nope", "x").status_code, 400)
        self.assertEqual(self.post_add(c, t, "archive_reason", "علت آزمایشی").status_code, 200)
        self.assertEqual(c.post("/api/options/add", data={"grp": "size", "label": "x"}).status_code, 400)   # بدون CSRF
        v = self.login("viewer1")
        self.assertEqual(v.post("/api/options/add", data={"csrf": "x", "grp": "size", "label": "x"}).status_code, 403)
        html = c.get("/cases/new").get_data(as_text=True)
        self.assertIn('data-grp="organization"', html)
        self.assertIn('data-add-url="/api/options/add"', html)

    def test_access_lists_are_preloaded(self):
        for grp, n, sample in (("product_type", 15, "سیم پلمپ"), ("size", 18, "۲-۱.۲"),
                               ("tender_type", 3, "ارزیابی کیفی")):
            labels = options.active_labels(self.db, grp)
            self.assertGreaterEqual(len(labels), n, grp)
            self.assertIn(sample, labels)
        self.assertEqual(config.OPTION_GROUPS["tender_type"], "نوع برگزاری")


class RenameOptionTests(FormBase):
    def post_rename(self, c, t, grp, old, new):
        return c.post("/api/options/rename", data={"csrf": t, "grp": grp, "old": old, "label": new})

    def make_case(self, c, t, **extra):
        return c.post("/cases/new", data=self.new_data(t, **extra))

    def test_rename_updates_option_and_every_case_and_product_row(self):
        c = self.login("entry1")
        t = self.token(c)
        self.make_case(c, t, organization="شرکت الف", prod_uid=["new-1"], prod_size=["۱ اینچ"],
                       prod_product_type=[""], prod_quantity=["1"], prod_model=[""], prod_sample=[""])
        self.make_case(c, t, organization="شرکت الف")
        self.make_case(c, t, organization="شرکت ب")
        r = self.post_rename(c, t, "organization", "شرکت الف", "شرکت آلفا")
        self.assertEqual(r.get_json(), {"ok": True, "label": "شرکت آلفا", "updated": 2, "active": None})
        orgs = [r["organization"] for r in self.db.execute("SELECT organization FROM cases ORDER BY id")]
        self.assertEqual(orgs, ["شرکت آلفا", "شرکت آلفا", "شرکت ب"])
        self.assertIn("شرکت آلفا", options.active_labels(self.db, "organization"))
        self.assertNotIn("شرکت الف", options.active_labels(self.db, "organization"))
        self.assertEqual(self.post_rename(c, t, "size", "۱ اینچ", "یک اینچ").get_json()["updated"], 1)
        self.assertEqual(self.db.execute("SELECT size FROM case_products").fetchone()[0], "یک اینچ")
        # پرونده بعد از تغییر نام هنوز قابل ویرایش و ذخیره است
        t = self.token(c, "/cases/1")
        v = self.case_row()["version"]
        self.assertEqual(c.post("/cases/1", data={"csrf": t, "version": v, "organization": "شرکت آلفا"}).status_code, 302)

    def test_rename_rules(self):
        c = self.login("entry1")
        t = self.token(c)
        self.assertEqual(self.post_rename(c, t, "organization", "شرکت الف", "شرکت ب").status_code, 400)   # تکراری
        self.assertEqual(self.post_rename(c, t, "organization", "نیست", "x").status_code, 400)
        self.assertEqual(self.post_rename(c, t, "organization", "شرکت الف", "  ").status_code, 400)
        self.assertEqual(self.post_rename(c, t, "archive_reason", "a", "b").status_code, 400)
        self.assertEqual(c.post("/api/options/rename", data={"grp": "size", "old": "a", "label": "b"}).status_code, 400)
        v = self.login("viewer1")
        self.assertEqual(v.post("/api/options/rename", data={"csrf": "x"}).status_code, 403)
        self.assertEqual(self.post_rename(c, t, "organization", "شرکت الف", "شرکت الف").get_json()["updated"], 0)
        self.assertIn("شرکت الف", options.active_labels(self.db, "organization"))

    def test_renamed_seed_option_is_not_resurrected_on_restart(self):
        c = self.login("entry1")
        t = self.token(c)
        self.assertTrue(self.post_rename(c, t, "tender_type", "یک مرحله ای", "یک‌مرحله‌ای").get_json()["ok"])
        init_db(self.app.config["DATABASE"])                      # مثل باز شدن دوبارهٔ برنامه
        labels = options.active_labels(self.db, "tender_type")
        self.assertIn("یک‌مرحله‌ای", labels)
        self.assertNotIn("یک مرحله ای", labels)
        self.assertEqual(len(labels), 3)

    def test_form_has_rename_endpoint_for_js(self):
        html = self.login("entry1").get("/cases/new").get_data(as_text=True)
        self.assertIn('data-rename-url="/api/options/rename"', html)


class ProfilePopupTests(FormBase):
    make_case = EditTests.make_case

    def test_profile_save_report_and_prices(self):
        c = self.login("entry1"); self.make_case(c)
        t = self.token(c)
        pid = self.db.execute("SELECT id FROM case_products").fetchone()[0]
        data = {"csrf": t, "pversion": "0", "subject": "موضوع آزمایشی", "issue_date": "۱۴۰۵/۰۷/۰۸",
                "warranty": "3 سال", f"price_{pid}": "۱,۲۰۰"}
        r = c.post("/cases/1/profile", data=data)
        self.assertEqual(r.get_json()["version"], 1)
        row = self.db.execute("SELECT subject, issue_date FROM case_profile").fetchone()
        self.assertEqual((row[0], row[1]), ("موضوع آزمایشی", "۱۴۰۵/۰۷/۰۸"))
        self.assertEqual(self.db.execute("SELECT price FROM case_products").fetchone()[0], 1200)
        html = c.get("/cases/1/report").get_data(as_text=True)
        self.assertIn("موضوع آزمایشی", html)
        self.assertIn("۱,۲۰۰", html)
        self.assertIn("شرکت الف", html)

    def test_profile_conflict_bad_date_and_bad_option(self):
        c = self.login("entry1"); self.make_case(c)
        t = self.token(c)
        self.assertEqual(c.post("/cases/1/profile", data={"csrf": t, "pversion": "0"}).status_code, 200)
        self.assertEqual(c.post("/cases/1/profile", data={"csrf": t, "pversion": "0"}).status_code, 409)
        self.assertEqual(c.post("/cases/1/profile", data={"csrf": t, "pversion": "1", "announce_date": "سلام"}).status_code, 400)
        self.assertEqual(c.post("/cases/1/profile", data={"csrf": t, "pversion": "1", "advance": "نامعتبر"}).status_code, 400)
        self.assertEqual(c.post("/cases/1/profile", data={"pversion": "1"}).status_code, 400)   # بدون CSRF

    def test_viewer_cannot_save_profile(self):
        self.make_case(self.login("entry1"))
        v = self.login("viewer1")
        self.assertEqual(v.post("/cases/1/profile", data={"pversion": "0"}).status_code, 403)
        self.assertEqual(v.get("/cases/1/report").status_code, 200)

    def test_size_fraction_text_and_today(self):
        from app.profile import size_text
        from app.jalali import today_jalali
        from datetime import date
        self.assertEqual([size_text(x) for x in ("1.2", "1-1.4", "2-1.2", "2")], ["1/2", "1-1/4", "2-1/2", "2"])
        self.assertEqual(today_jalali(date(2026, 9, 30)), "1405/07/08")

    def test_popup_not_on_new_form(self):
        html = self.login("entry1").get("/cases/new").get_data(as_text=True)
        self.assertNotIn('id="pf-modal"', html)

    def test_pdf_report_and_list_column(self):
        c = self.login("entry1"); self.make_case(c)
        self.assertNotIn("✓ دارد", c.get("/cases").get_data(as_text=True))
        c.post("/cases/1/profile", data={"csrf": self.token(c), "pversion": "0", "subject": "موضوع"})
        self.assertIn("✓ دارد", c.get("/cases").get_data(as_text=True))
        r = c.get("/cases/1/report.pdf")
        self.assertEqual(r.mimetype, "application/pdf")
        self.assertTrue(r.data.startswith(b"%PDF"))
        r = c.post("/cases/1/report/open", data={"csrf": self.token(c)})
        self.assertTrue(r.get_json()["ok"])
        self.assertEqual(c.post("/cases/1/report/open", data={}).status_code, 400)

    def test_shaper_joins_letters(self):
        from app import pdfreport
        self.assertNotEqual(pdfreport.shape("سلام"), "سلام")
        self.assertEqual(pdfreport.visual(pdfreport.shape("1405/07/19"))[:4], "۱۴۰۵")


class SeatsAndUsersTests(FormBase):
    def test_third_editor_is_view_only(self):
        a, b, c = self.login("entry1"), self.login("entry2"), self.login("admin1")
        self.assertEqual(a.get("/cases/new").status_code, 200)
        self.assertEqual(b.get("/cases/new").status_code, 200)
        r = c.get("/cases/new")                       # ظرفیت ۲ پر است
        self.assertEqual(r.status_code, 302)
        self.make_case_via(a)
        r = c.get("/cases/1")
        html = r.get_data(as_text=True)
        self.assertIn("حالت فقط‌مشاهده", html)
        self.assertNotIn('id="save-btn"', html)
        # ذخیره هم رد می‌شود و اطلاعات تغییر نمی‌کند
        data = {"csrf": self.token(c, "/cases/1"), "version": "1", "organization": "شرکت ب"}
        self.assertEqual(c.post("/cases/1", data=data).status_code, 423)
        self.assertNotEqual(self.case_row()["organization"], "شرکت ب")

    def make_case_via(self, client):
        client.post("/cases/new", data=self.new_data(self.token(client), organization="شرکت الف"))

    def test_seat_freed_on_logout_and_timeout_and_admin_free(self):
        from app import seats
        a, b, c = self.login("entry1"), self.login("entry2"), self.login("admin1")
        a.get("/cases/new"); b.get("/cases/new")
        self.assertEqual(c.get("/cases/new").status_code, 302)
        with a.session_transaction() as s:
            t = s["csrf"]
        a.post("/logout", data={"csrf": t})                    # خروج -> جا آزاد
        self.assertEqual(c.get("/cases/new").status_code, 200)
        # بی‌فعالیتی: ۱۱ دقیقه قبل
        self.db.execute("UPDATE edit_seats SET last_seen = last_seen - 700")
        self.assertEqual(seats.holders(self.db), [])
        # آزاد کردن توسط مدیر
        b.get("/cases/new")
        ct = self.token(c, "/admin/users")
        c.post("/admin/users", data={"csrf": ct, "action": "free_seat", "user_id": str(self.entry2)})
        self.assertFalse(seats.has_seat(self.db, self.entry2))

    def test_viewer_never_gets_seat_and_ping(self):
        v = self.login("viewer1")
        self.assertEqual(v.get("/cases/new").status_code, 403)
        with v.session_transaction() as s:
            pass
        v.get("/")
        with v.session_transaction() as s:
            t = s["csrf"]
        self.assertFalse(v.post("/api/seat/ping", data={"csrf": t}).get_json()["held"])
        e = self.login("entry1"); e.get("/")
        with e.session_transaction() as s:
            t = s["csrf"]
        self.assertTrue(e.post("/api/seat/ping", data={"csrf": t}).get_json()["held"])
        self.assertEqual(e.post("/api/seat/ping", data={}).status_code, 400)

    def test_option_and_profile_endpoints_need_seat(self):
        a, b, c = self.login("entry1"), self.login("entry2"), self.login("admin1")
        self.make_case_via(a); b.get("/cases/new")
        with c.session_transaction() as s:
            s["csrf"] = "tok"
        c.get("/")
        with c.session_transaction() as s:
            t = s["csrf"]
        r = c.post("/api/options/add", data={"csrf": t, "grp": "source", "label": "x"})
        self.assertEqual(r.status_code, 423)
        r = c.post("/cases/1/profile", data={"csrf": t, "pversion": "0"})
        self.assertEqual(r.status_code, 423)

    def test_admin_user_management_rules(self):
        c = self.login("admin1"); t = self.token(c, "/admin/users")
        def post(**kw):
            return c.post("/admin/users", data={"csrf": t, **kw}, follow_redirects=True).get_data(as_text=True)
        self.assertIn("ساخته شد", post(action="create", username="ali", password="abc123", role="entry", full_name="علی"))
        self.assertIn("قبلاً ساخته", post(action="create", username="ALI", password="abc123", role="entry"))
        self.assertIn("حداقل ۶", post(action="create", username="bob", password="123", role="entry"))
        self.assertIn("نقش خودتان", post(action="set_role", user_id=str(self.admin), role="viewer"))
        self.assertIn("خودتان را", post(action="disable", user_id=str(self.admin)))
        # کاربر غیرفعال نمی‌تواند وارد شود و حذفی در کار نیست
        post(action="disable", user_id=str(self.viewer))
        cl = self.app.test_client(); cl.get("/login")
        with cl.session_transaction() as s:
            tk = s["csrf"]
        r = cl.post("/login", data={"username": "viewer1", "password": "secret1", "csrf": tk}, follow_redirects=True)
        self.assertIn("غیرفعال", r.get_data(as_text=True))
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM users WHERE username='viewer1'").fetchone()[0], 1)
        # تغییر رمز
        post(action="reset_password", user_id=str(self.entry), password="newpass1")
        cl2 = self.app.test_client(); cl2.get("/login")
        with cl2.session_transaction() as s:
            tk = s["csrf"]
        self.assertEqual(cl2.post("/login", data={"username": "entry1", "password": "newpass1", "csrf": tk}).status_code, 302)

    def test_last_admin_protected_and_non_admin_forbidden(self):
        from app import users
        with self.assertRaises(users.UserError):
            users.set_active(self.db, self.entry, self.admin, False)
        with self.assertRaises(users.UserError):
            users.set_role(self.db, self.entry, self.admin, "entry")
        self.assertEqual(self.login("entry1").get("/admin/users").status_code, 403)

    def test_max_editors_setting(self):
        from app import seats
        c = self.login("admin1"); t = self.token(c, "/admin/users")
        c.post("/admin/users", data={"csrf": t, "action": "set_max", "max_editors": "3"})
        self.assertEqual(seats.get_max(self.db), 3)
        c.post("/admin/users", data={"csrf": t, "action": "set_max", "max_editors": "99"})
        self.assertEqual(seats.get_max(self.db), 3)


class DashboardTests(FormBase):
    def seed(self, c):
        for org, result, rd in (("شرکت الف", "برنده", "1405/05/10"), ("شرکت الف", "بازنده", "1405/06/11"),
                                ("شرکت ب", "", "1405/06/20")):
            data = self.new_data(self.token(c), organization=org, result=result, received_date=rd,
                                 send_deadline="1405/07/20", prod_uid=["new-1"], prod_product_type=["شیر"],
                                 prod_size=[""], prod_quantity=["10"], prod_model=[""], prod_sample=[""])
            if result == "بازنده":
                data.update(comp_uid=["new-1"], comp_name=["رقیب ۱"], comp_price=["500"], comp_note=[""])
            self.assertEqual(c.post("/cases/new", data=data).status_code, 302)

    def test_dashboard_numbers_and_filters(self):
        from app import dashboard
        c = self.login("entry1"); self.seed(c)
        d = dashboard.build(self.db, {})
        k = d["kpi"]
        self.assertEqual((k["total"], k["won"], k["lost"], k["open"]), (3, 1, 1, 1))
        self.assertEqual(k["win_rate"], 50.0)
        self.assertEqual(k["qty"], 30)
        self.assertEqual(d["orgs"][0]["label"], "شرکت الف")
        self.assertEqual(d["competitors"][0]["name"], "رقیب ۱")
        self.assertEqual(sum(sum(s["values"]) for s in d["trend"]["series"]), 3)
        self.assertEqual(dashboard.build(self.db, {"org": "شرکت ب"})["kpi"]["total"], 1)
        self.assertEqual(dashboard.build(self.db, {"result": "برنده"})["kpi"]["total"], 1)
        self.assertEqual(dashboard.build(self.db, {"ym": "1405/06"})["kpi"]["total"], 2)
        self.assertEqual(dashboard.build(self.db, {"year": "1404"})["kpi"]["total"], 0)
        self.assertEqual(dashboard.build(self.db, {"type": "bogus"})["kpi"]["total"], 3)   # فیلتر نامعتبر نادیده

    def test_dashboard_api_and_page(self):
        c = self.login("viewer1")
        self.assertEqual(c.get("/").status_code, 200)
        r = c.get("/api/dashboard?type=tender")
        self.assertEqual(r.status_code, 200)
        self.assertIn("kpi", r.get_json())
        self.assertEqual(self.app.test_client().get("/api/dashboard").status_code, 302)   # بدون ورود

    def test_jalali_to_gregorian(self):
        from app.jalali import jdate_to_date
        from datetime import date
        self.assertEqual(jdate_to_date("1405/07/19"), date(2026, 10, 11))
        self.assertIsNone(jdate_to_date("سلام"))


class AuditLogTests(EditTests):
    def rows(self):
        return [dict(r) for r in self.db.execute("SELECT * FROM audit_log ORDER BY id")]

    def test_login_create_edit_logout_are_logged_with_who_and_diff(self):
        c = self.make_case()                         # entry1: ورود + ثبت
        c.post("/cases/1", data=self.edit_data(c, status="ارسال شد", organization="شرکت ب"))
        acts = [(r["action"], r["username"]) for r in self.rows()]
        self.assertIn(("login", "entry1"), acts)
        self.assertIn(("case_create", "entry1"), acts)
        edit = [r for r in self.rows() if r["action"] == "case_edit"][0]
        self.assertIn("شرکت ب", edit["detail"])
        self.assertIn("وضعیت پرونده", edit["detail"])
        self.assertTrue(edit["at"].startswith("20"))
        c.post("/logout", data={"csrf": self.token(c, "/")})
        self.assertEqual(self.rows()[-1]["action"], "logout")

    def test_no_change_edit_not_logged_and_failed_login_logged(self):
        c = self.make_case()
        n = len([r for r in self.rows() if r["action"] == "case_edit"])
        c.post("/cases/1", data=self.edit_data(c))
        self.assertEqual(len([r for r in self.rows() if r["action"] == "case_edit"]), n)
        x = self.app.test_client(); x.get("/login")
        with x.session_transaction() as s: t = s["csrf"]
        x.post("/login", data={"username": "entry1", "password": "bad", "csrf": t})
        self.assertEqual(self.rows()[-1]["action"], "login_fail")

    def test_log_cannot_be_changed_or_deleted(self):
        self.login("entry1")
        import sqlite3
        with self.assertRaises(sqlite3.DatabaseError):
            self.db.execute("DELETE FROM audit_log")
        with self.assertRaises(sqlite3.DatabaseError):
            self.db.execute("UPDATE audit_log SET username='x'")

    def test_admin_page_filter_csv_and_access(self):
        a = self.make_case()
        ad = self.login("admin1")
        r = ad.get("/admin/logs")
        self.assertEqual(r.status_code, 200)
        self.assertIn("ثبت پرونده", r.get_data(as_text=True))
        self.assertIn("entry1", ad.get("/admin/logs?user=2&cat=پرونده").get_data(as_text=True))
        self.assertIn("ثبت پرونده", ad.get("/admin/logs.csv").get_data(as_text=True))
        self.assertEqual(a.get("/admin/logs").status_code, 403)
        self.assertEqual(self.login("viewer1").get("/admin/logs.csv").status_code, 403)

    def test_admin_actions_logged(self):
        ad = self.login("admin1")
        ad.post("/admin/users", data={"csrf": self.token(ad, "/admin/users"), "action": "set_max", "max_editors": "3"})
        ad.post("/admin/options", data={"csrf": self.token(ad, "/admin/options"), "action": "add",
                                        "grp": "source", "lines": "پیک"})
        acts = [r["action"] for r in self.rows()]
        self.assertIn("seats_max", acts)
        self.assertIn("option_add", acts)


class WelcomeVersionTests(EditTests):
    def test_welcome_popup_once_after_login_and_version_shown(self):
        from app import config
        c = self.login("entry1")
        html = c.get("/").get_data(as_text=True)
        self.assertIn('id="wl-modal"', html)
        self.assertIn("خوش آمدید", html)
        self.assertIn("ایران انشعاب", html)
        self.assertIn(config.APP_VERSION, html)
        self.assertNotIn('id="wl-modal"', c.get("/").get_data(as_text=True))     # فقط یک بار
        x = self.app.test_client()
        self.assertIn("v" + config.APP_VERSION, x.get("/login").get_data(as_text=True))

    def test_readme_mentions_current_version(self):
        from app import config
        txt = open(os.path.join(os.path.dirname(__file__), "..", "README.md"), encoding="utf-8").read()
        fa = config.APP_VERSION.translate(str.maketrans("0123456789", "۰۱۲۳۴۵۶۷۸۹"))
        self.assertIn("نسخه " + fa, txt)


class PersianDigitsAndOrderTests(EditTests):
    def test_ascii_and_arabic_digits_are_stored_persian(self):
        c = self.login("entry1")
        t = self.token(c)
        c.post("/cases/new", data=self.new_data(
            t, organization="شرکت الف", notes="تماس 021-123 و ٤٥٦", received_date="1405/7/5", send_deadline="1405/7/9", physical_upload="9:05",
            result="بازنده", prod_uid=["new-1"], prod_product_type=["شیر"], prod_size=["1 اینچ"], prod_quantity=["12"],
            prod_model=[""], prod_sample=[""], comp_uid=["new-1"], comp_name=["رقیب 2"], comp_price=["1,500"],
            comp_note=["نمونه 3"]))
        row = self.case_row()
        self.assertEqual(row["notes"], "تماس ۰۲۱-۱۲۳ و ۴۵۶")
        self.assertEqual((row["received_date"], row["physical_upload"]), ("۱۴۰۵/۰۷/۰۵", "۰۹:۰۵"))
        comp = self.db.execute("SELECT name, price, note FROM case_competitors").fetchone()
        self.assertEqual((comp["name"], comp["price"], comp["note"]), ("رقیب ۲", 1500, "نمونه ۳"))
        prod = self.db.execute("SELECT size, quantity FROM case_products").fetchone()
        self.assertEqual((prod["size"], prod["quantity"]), ("۱ اینچ", 12))      # گزینهٔ ثبت‌شده با ارقام فارسی
        html = c.get("/cases/1").get_data(as_text=True)
        self.assertIn('value="۱۲"', html)
        self.assertIn('value="۱,۵۰۰"', html)                         # جداکنندهٔ سه‌رقمی
        lst = c.get("/cases?q=021").get_data(as_text=True)          # جستجو با رقم انگلیسی هم پیدا می‌کند
        self.assertEqual(lst.count('class="case-table"'), 1)

    def test_product_rows_keep_their_order_and_middle_insert(self):
        c = self.login("entry1")
        t = self.token(c)
        base = dict(prod_product_type=["شیر", "لوله", "شیر"], prod_size=["", "", ""], prod_quantity=["1", "2", "3"],
                    prod_model=["", "", ""], prod_sample=["", "", ""])
        c.post("/cases/new", data=self.new_data(t, organization="شرکت الف", prod_uid=["new-1", "new-2", "new-3"], **base))
        qty = lambda: [p["quantity"] for p in case_data.load_case(self.db, 1)["products"]]
        self.assertEqual(qty(), [1, 2, 3])
        ids = [p["id"] for p in case_data.load_case(self.db, 1)["products"]]
        # ترتیب برعکس + یک ردیف جدید وسط
        order = [str(ids[2]), "new-9", str(ids[1]), str(ids[0])]
        data = self.edit_data(c, prod_uid=order, prod_product_type=["شیر", "شیر", "لوله", "شیر"], prod_size=["", "", "", ""],
                              prod_quantity=["3", "50", "2", "1"], prod_model=["", "", "", ""], prod_sample=["", "", "", ""])
        r = c.post("/cases/1", data=data)
        self.assertEqual(r.status_code, 302)
        self.assertEqual(qty(), [3, 50, 2, 1])

    def test_old_ascii_data_is_converted_once_and_seeds_are_not_duplicated(self):
        from app import db as dbm
        self.make_case()
        self.db.execute("UPDATE cases SET notes='رقم 123', received_date='1405/07/05' WHERE id=1")
        self.db.execute("UPDATE case_products SET size='1.2'")
        self.db.execute("INSERT INTO options (grp, label) VALUES ('model', 'M12')")
        self.db.execute("DELETE FROM settings WHERE key = 'digits_fa'")
        path = self.app.config["DATABASE"]
        dbm.init_db(path)
        n = self.db.execute("SELECT COUNT(*) FROM options").fetchone()[0]
        dbm.init_db(path)                                             # بار دوم: چیزی تکراری اضافه نمی‌شود
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM options").fetchone()[0], n)
        row = self.case_row()
        self.assertEqual((row["notes"], row["received_date"]), ("رقم ۱۲۳", "۱۴۰۵/۰۷/۰۵"))
        self.assertEqual(self.db.execute("SELECT size FROM case_products").fetchone()[0], "۱.۲")
        self.assertIn("M۱۲", options.active_labels(self.db, "model"))
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM options WHERE grp='size' AND label='1.2'").fetchone()[0], 0)

    def test_date_input_is_typable_and_calendar_selects_are_native(self):
        js = self.login("entry1").get("/static/jdatepicker.js").get_data(as_text=True)
        self.assertIn("readOnly = false", js)
        self.assertEqual(js.count("data-native"), 2)        # لیست ماه/سال تقویم نباید به کمبوی جستجودار تبدیل شود
        self.assertIn("maskValue", js)


class NumberFormatAndMessagesTests(EditTests):
    def test_fa_num_filter(self):
        from app.jalali import fa_num
        self.assertEqual(fa_num(1200000), "۱,۲۰۰,۰۰۰")
        self.assertEqual(fa_num("1,500"), "۱,۵۰۰")
        self.assertEqual(fa_num(0), "۰")
        self.assertEqual(fa_num(None), "")
        self.assertEqual(fa_num("abc 12"), "abc ۱۲")

    def test_thousands_input_is_accepted_and_font_and_messages_shipped(self):
        c = self.login("entry1")
        c.post("/cases/new", data=self.new_data(self.token(c), organization="شرکت الف", prod_uid=["new-1"],
               prod_product_type=["شیر"], prod_size=[""], prod_quantity=["۱,۲۰۰,۰۰۰"], prod_model=[""], prod_sample=[""]))
        self.assertEqual(self.db.execute("SELECT quantity FROM case_products").fetchone()[0], 1200000)
        self.assertIn('class="num"', c.get("/cases/1").get_data(as_text=True))
        self.assertEqual(c.get("/static/fonts/Vazirmatn-Regular.ttf").status_code, 200)
        js = c.get("/static/jdatepicker.js").get_data(as_text=True)
        self.assertIn("فقط", js)
        self.assertIn("function explain", js)


class V222Tests(FormBase):
    def post_new(self, c, **over):
        return c.post("/cases/new", data=self.new_data(self.token(c), **over))

    def test_five_types_have_separate_numbering(self):
        c = self.login("entry1")
        html = c.get("/cases/new").get_data(as_text=True)
        for label in ("مناقصه کنتورهای مکانیکی", "مناقصه کنتورهای هوشمند", "استعلام کنتورهای مکانیکی",
                      "استعلام کنتورهای هوشمند", "مزایده"):
            self.assertIn(label, html)
        self.assertNotIn('value="tender"', html)                 # نوع قدیمی قابل انتخاب نیست
        for t in ("tender_mech", "tender_smart", "inquiry_mech", "inquiry_smart", "auction"):
            self.assertEqual(self.post_new(c, case_type=t).status_code, 302)
        self.post_new(c, case_type="auction")
        rows = {r["case_type"]: r["serial_no"] for r in self.db.execute("SELECT case_type, MAX(serial_no) serial_no FROM cases GROUP BY case_type")}
        self.assertEqual(rows, {"tender_mech": 1, "tender_smart": 1, "inquiry_mech": 1, "inquiry_smart": 1, "auction": 2})
        self.assertEqual(c.get("/api/next-number?case_type=auction").get_json()["next"], 3) if False else None

    def test_clock_is_automatic_and_locked(self):
        c = self.login("entry1")
        html = c.get("/cases/new").get_data(as_text=True)
        self.assertRegex(html, r'id="physical_upload"[^>]*readonly')
        self.assertIn("ساعت مهلت ارسال اسناد", html)
        self.post_new(c, send_deadline="۱۴۰۵/۰۸/۰۱", physical_upload="")
        self.assertRegex(self.case_row()["physical_upload"], r"^[۰-۹]{2}:[۰-۹]{2}$")      # سرور هم پر می‌کند
        self.post_new(c, send_deadline="", physical_upload="۱۰:۳۰")
        self.assertEqual(self.db.execute("SELECT physical_upload FROM cases WHERE id=2").fetchone()[0], "")

    def test_sample_quantity_only_when_sample_is_yes(self):
        c = self.login("entry1")
        base = dict(prod_uid=["new-1", "new-2"], prod_product_type=["شیر", "لوله"], prod_size=["", ""],
                    prod_quantity=["۱۰", "۲۰"], prod_model=["", ""])
        self.post_new(c, prod_sample=["دارد", "ندارد"], prod_sample_qty=["۳,۰۰۰", "۷"], **base)
        qs = [r[0] for r in self.db.execute("SELECT sample_qty FROM case_products ORDER BY id")]
        self.assertEqual(qs, [3000, 0])                             # «ندارد» تعداد نمونه نمی‌گیرد
        html = c.get("/cases/1").get_data(as_text=True)
        self.assertIn("تعداد نمونه", html)
        self.assertIn('value="۳,۰۰۰"', html)
        self.assertEqual(self.post_new(c, prod_sample=["دارد", ""], prod_sample_qty=["abc", ""], **base).status_code, 400)

    def test_archive_decision_rules(self):
        c = self.login("entry1")
        self.post_new(c, decision="عدم تایید و بایگانی", archive_reason="مهلت گذشته", status="در حال بررسی",
                      opening_time="۱۴۰۵/۰۸/۱۰", result="برنده")
        row = self.case_row()
        self.assertEqual((row["status"], row["opening_time"], row["result"]), ("", "", ""))
        self.assertEqual(row["archive_reason"], "مهلت گذشته")
        html = c.get("/cases/1").get_data(as_text=True)
        self.assertRegex(html, r'<select name="archive_reason"')      # کمبو است نه متن آزاد
        self.assertIn("تایید", options.active_labels(self.db, "decision"))
        self.post_new(c, decision="تایید", archive_reason="x", result="برنده")
        self.assertEqual(self.db.execute("SELECT archive_reason, result FROM cases WHERE id=2").fetchone()[:], ("", "برنده"))

    def test_old_archive_option_is_migrated(self):
        from app import db as dbm
        self.db.execute("DELETE FROM settings WHERE key='archive_v222'") if False else None
        c = self.login("entry1")
        self.db.execute("DROP TRIGGER IF EXISTS options_no_delete")
        self.db.execute("UPDATE options SET label='بایگانی' WHERE grp='decision' AND label='عدم تایید و بایگانی'")
        self.post_new(c)
        self.db.execute("UPDATE cases SET decision='بایگانی', archive_reason='x' WHERE id=1")
        self.db.execute("DELETE FROM settings WHERE key='archive_v222'")
        dbm.init_db(self.app.config["DATABASE"])
        self.assertEqual(self.case_row()["decision"], "عدم تایید و بایگانی")
        self.assertIn("عدم تایید و بایگانی", options.active_labels(self.db, "decision"))
        self.assertNotIn("بایگانی", options.active_labels(self.db, "decision"))


class V223Tests(FormBase):
    def post_new(self, c, **over):
        return c.post("/cases/new", data=self.new_data(self.token(c), **over))

    def test_notes_and_opening_fields_removed_but_old_data_kept(self):
        c = self.login("entry1")
        html = c.get("/cases/new").get_data(as_text=True)
        self.assertNotIn('name="notes"', html)
        self.assertIn('name="opening_time"', html)
        self.post_new(c)
        self.db.execute("UPDATE cases SET notes='قدیمی', opening_time='۱۴۰۵/۰۸/۰۱' WHERE id=1")
        t = self.token(c, "/cases/1")
        v = self.case_row()["version"]
        self.assertEqual(c.post("/cases/1", data={"csrf": t, "version": v, "organization": ""}).status_code, 302)
        row = self.case_row()
        self.assertEqual(row["notes"], "قدیمی")

    def test_saved_popup_shown_once_for_create_and_edit(self):
        c = self.login("entry1")
        c.get("/")                                           # پاپ‌آپ خوش‌آمد مصرف شود
        r = self.post_new(c, case_type="auction")
        html = c.get(r.headers["Location"]).get_data(as_text=True)
        self.assertIn('id="sv-modal"', html)
        self.assertIn("پرونده مزایده با شماره ۱ ثبت شد.", html)
        self.assertNotIn('id="sv-modal"', c.get("/cases/1").get_data(as_text=True))      # فقط یک بار
        t = self.token(c, "/cases/1"); v = self.case_row()["version"]
        r = c.post("/cases/1", data={"csrf": t, "version": v})
        html = c.get(r.headers["Location"]).get_data(as_text=True)
        self.assertIn("تغییرات پرونده مزایده با شماره ۱ ذخیره شد.", html)
        self.assertIn("تغییرات ذخیره شد.", html)             # نوار سبز مثل قبل

    def test_inquiry_replaces_tender_type_with_source(self):
        c = self.login("entry1")
        options.add_labels(self.db, "tender_type", "عمومی")
        self.post_new(c, case_type="inquiry_mech", tender_type="عمومی", source="ایمیل")
        row = self.case_row()
        self.assertEqual((row["tender_type"], row["source"]), ("", "ایمیل"))
        html = c.get("/cases/1").get_data(as_text=True)
        self.assertRegex(html, r'data-grp-hide="inquiry" hidden')

    def test_profile_fields_per_type(self):
        from app import profile
        inq = {f[0] for f in profile.fields_for("inquiry_smart")}
        ten = {f[0] for f in profile.fields_for("tender_mech")}
        auc = {f[0] for f in profile.fields_for("auction")}
        self.assertIn("need_no", inq)
        for k in ("subject", "call_no", "tender_no", "contract_period", "advance", "clearance",
                  "bid_guarantee", "perf_guarantee"):
            self.assertNotIn(k, inq)
            self.assertIn(k, ten)
        self.assertNotIn("need_no", ten)
        self.assertNotIn("need_no", auc)
        self.assertNotIn("sent_date", inq | ten)

    def test_profile_popup_and_report_follow_type(self):
        c = self.login("entry1")
        self.post_new(c, case_type="inquiry_mech", source="ایمیل")
        html = c.get("/cases/1").get_data(as_text=True)
        self.assertIn('name="need_no"', html)
        self.assertNotIn('name="call_no"', html)
        self.assertNotIn('name="tender_no"', html)
        self.assertNotIn('name="sent_date"', html)
        rep = c.get("/cases/1/report").get_data(as_text=True)
        self.assertIn("شماره نیاز", rep)
        self.assertNotIn("شماره فراخوان", rep)
        self.assertNotIn("مبلغ ضمانت نامه", rep)
        self.assertIn("منبع دریافت", rep)
        self.post_new(c, case_type="tender_smart")
        html = c.get("/cases/2").get_data(as_text=True)
        self.assertIn('name="call_no"', html)
        self.assertNotIn('name="need_no"', html)
        self.assertNotIn("شماره نیاز", c.get("/cases/2/report").get_data(as_text=True))

    def test_glass_popups_css(self):
        css = self.login("entry1").get("/static/style.css").get_data(as_text=True)
        self.assertIn("backdrop-filter", css)



class V229Tests(FormBase):
    def post_new(self, c, **over):
        return c.post("/cases/new", data=self.new_data(self.token(c), **over))

    def test_result_sets_status_and_date(self):
        c = self.login("entry1")
        self.post_new(c, decision="تایید", status="ارسال شد", result="برنده", result_date="")
        row = self.case_row()
        self.assertEqual(row["status"], "نتیجه اعلام شد")
        self.assertNotEqual(row["result_date"], "")

    def test_no_result_clears_result_date_and_inquiry_has_no_opening(self):
        c = self.login("entry1")
        self.post_new(c, decision="تایید", status="ارسال شد", result="", result_date="۱۴۰۵/۰۱/۰۱")
        self.assertEqual(self.case_row()["result_date"], "")
        self.post_new(c, case_type="inquiry_mech", decision="تایید", opening_time="۱۴۰۵/۰۱/۰۱")
        self.assertEqual(self.case_row(2)["opening_time"], "")

    def test_org_pages(self):
        c = self.login("entry1")
        self.db.execute("INSERT INTO options (grp, label) VALUES ('organization', 'شرکت آزمون')")
        self.post_new(c, organization="شرکت آزمون")
        oid = self.db.execute("SELECT id FROM options WHERE grp='organization' AND label='شرکت آزمون'").fetchone()[0]
        self.assertEqual(c.get("/organizations").status_code, 200)
        self.assertEqual(c.get(f"/organizations/by-name?name=شرکت آزمون").status_code, 302)
        t = self.token(c, f"/organizations/{oid}")
        r = c.post(f"/organizations/{oid}", data={"csrf": t, "phone": "021-123", "address": "example-address"})
        self.assertEqual(r.status_code, 302)
        html = c.get(f"/organizations/{oid}").get_data(as_text=True)
        self.assertIn("example-address", html)
        v = self.login("viewer1")
        self.assertEqual(v.post(f"/organizations/{oid}", data={"csrf": "x", "phone": "1"}).status_code, 403)

    def test_update_progress_endpoints_admin_only(self):
        c = self.login("entry1")
        self.assertEqual(c.get("/admin/update/progress").status_code, 403)
        self.assertEqual(c.post("/admin/shutdown", data={}).status_code, 403)


class V230Tests(FormBase):
    def test_news_popup_until_checked(self):
        from app import config
        old = config.WHATS_NEW
        config.WHATS_NEW = {"version": "9.9", "items": ["مورد تازه"]}
        try:
            c = self.login("entry1")
            html = c.get("/").get_data(as_text=True)
            self.assertIn('id="nw-modal"', html)
            self.assertIn("مورد تازه", html)
            self.assertNotIn('id="nw-modal"', c.get("/").get_data(as_text=True))      # فقط بعد از ورود
            t = self.token(c)
            self.assertEqual(c.post("/api/news/seen", data={"csrf": t}).status_code, 200)
            c2 = self.login("entry1")
            self.assertNotIn('id="nw-modal"', c2.get("/").get_data(as_text=True))
        finally:
            config.WHATS_NEW = old

    def test_fetch_latest_falls_back_to_mirror(self):
        from app import updater
        import http.server, threading, json
        class H(http.server.BaseHTTPRequestHandler):
            def do_GET(self):
                b = json.dumps({"version": "9.0", "files": {}}).encode()
                self.send_response(200); self.end_headers(); self.wfile.write(b)
            def log_message(self, *a): pass
        srv = http.server.HTTPServer(("127.0.0.1", 0), H)
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        info = updater.fetch_latest(["http://127.0.0.1:1", f"http://127.0.0.1:{srv.server_address[1]}"])
        srv.shutdown()
        self.assertEqual(info["version"], "9.0")


class V240Tests(FormBase):
    def test_org_list_has_search(self):
        c = self.login("entry1")
        self.assertIn('id="org-q"', c.get("/organizations").get_data(as_text=True))
        import winapp
        self.assertNotIn("fullscreen", open(winapp.__file__, encoding="utf-8").read().split("def open_window")[1].split("def port_busy")[0])


class V243Tests(FormBase):
    def test_org_search_script_is_in_body(self):
        html = self.login("entry1").get("/organizations").get_data(as_text=True)
        self.assertLess(html.index('<main'), html.index("getElementById('org-q')"))


class V247Tests(FormBase):
    def test_zoom_controls_present(self):
        html = self.login("entry1").get("/").get_data(as_text=True)
        for i in ("zm-in", "zm-out", "zm-val"):
            self.assertIn(f'id="{i}"', html)


class V248Tests(FormBase):
    def test_org_api_and_ajax_save(self):
        c = self.login("entry1")
        self.db.execute("INSERT INTO options (grp, label) VALUES ('organization', 'شرکت پاپ‌آپ')")
        d = c.get("/api/org?name=شرکت پاپ‌آپ").get_json()
        self.assertTrue(d["ok"]); self.assertTrue(d["can_edit"])
        t = self.token(c)
        r = c.post(f"/organizations/{d['id']}", data={"csrf": t, "phone": "1", "website": "a.ir"}, headers={"X-Requested-With": "fetch"})
        self.assertEqual(r.get_json(), {"ok": True})
        self.assertEqual(c.get("/api/org?name=نیست").status_code, 404)
        self.assertFalse(self.login("viewer1").get("/api/org?name=شرکت پاپ‌آپ").get_json()["can_edit"])


class V249Tests(FormBase):
    def test_org_contacts_add_edit_no_delete(self):
        c = self.login("entry1")
        self.db.execute("INSERT INTO options (grp, label) VALUES ('organization', 'شرکت نفرات')")
        oid = self.db.execute("SELECT id FROM options WHERE label='شرکت نفرات'").fetchone()[0]
        t = self.token(c)
        data = {"csrf": t, "address": "تهران", "phone": "021",
                "contact_id": ["new", "new"], "contact_name": ["الف", ""], "contact_unit": ["فنی", ""],
                "contact_position": ["مدیر", ""], "contact_phone": ["0912", ""], "contact_ext": ["12", ""]}
        self.assertEqual(c.post(f"/organizations/{oid}", data=data).status_code, 302)
        rows = self.db.execute("SELECT * FROM org_contacts WHERE option_id=?", (oid,)).fetchall()
        self.assertEqual(len(rows), 1)                                   # ردیف کاملاً خالی ذخیره نمی‌شود
        cid = rows[0]["id"]
        t = self.token(c, f"/organizations/{oid}")
        data.update({"csrf": t, "contact_id": [str(cid)], "contact_name": ["الف ب"], "contact_unit": ["فنی"],
                     "contact_position": ["مدیر"], "contact_phone": ["0912"], "contact_ext": ["12"]})
        c.post(f"/organizations/{oid}", data=data)
        self.assertEqual(self.db.execute("SELECT name FROM org_contacts WHERE id=?", (cid,)).fetchone()[0], "الف ب")
        d = c.get(f"/api/org?name=شرکت نفرات").get_json()
        self.assertEqual(len(d["contacts"]), 1)
        self.assertEqual([x["key"] for x in d["fields"]], ["address", "phone"])
        html = c.get(f"/organizations/{oid}").get_data(as_text=True)
        self.assertIn("شماره داخلی در صورت تماس با ابفا", html)


class V251Tests(FormBase):
    def test_settings_and_company(self):
        c = self.login("admin1")
        self.assertIn("اطلاعات شرکت", c.get("/settings").get_data(as_text=True))
        t = self.token(c, "/settings/company")
        c.post("/settings/company", data={"csrf": t, "name": "شرکت آزمایشی", "phone": "021"})
        self.assertIn("شرکت آزمایشی", c.get("/").get_data(as_text=True))

    def test_non_admin_cannot_open_settings(self):
        c = self.login("entry1")
        self.assertEqual(c.get("/settings").status_code, 403)

    def test_dashboard_hidden_sections(self):
        c = self.login("admin1")
        t = self.token(c, "/admin/users")
        uid = self.db.execute("SELECT id FROM users WHERE username='entry1'").fetchone()["id"]
        c.post("/admin/users", data={"csrf": t, "action": "set_dash", "user_id": uid, "show": ["kpis", "c-trend"]})
        h = self.db.execute("SELECT dash_hidden FROM users WHERE id=?", (uid,)).fetchone()["dash_hidden"]
        self.assertIn("c-orgs", h)
        self.assertNotIn("kpis", h)
        e = self.login("entry1")
        self.assertIn("#c-orgs", e.get("/").get_data(as_text=True))

    def test_exit_page_and_footer(self):
        c = self.login("admin1")
        self.assertIn("پیشرو سیستم", c.get("/").get_data(as_text=True))
        t = self.token(c, "/")
        r = c.post("/logout", data={"csrf": t, "exit": "1"})
        self.assertIn("window.close", r.get_data(as_text=True))

    def test_option_active_toggle(self):
        c = self.login("admin1")
        t = self.token(c)
        c.application = self.app
        r = c.post("/api/options/rename", data={"csrf": t, "grp": "source", "old": "ایمیل", "label": "ایمیل", "active": "0"})
        self.assertTrue(r.get_json().get("ok"), r.get_data(as_text=True))
        self.assertEqual(self.db.execute("SELECT active FROM options WHERE grp='source' AND label='ایمیل'").fetchone()[0], 0)
        r = c.post("/api/options/rename", data={"csrf": t, "grp": "source", "old": "ایمیل", "label": "ایمیل", "active": "1"})
        self.assertEqual(self.db.execute("SELECT active FROM options WHERE grp='source' AND label='ایمیل'").fetchone()[0], 1)

    def test_periodic_backup_skips_when_unchanged(self):
        from app import backups
        src = self.app.config["DATABASE"]
        st = {"sig": backups.db_signature(src)}
        sf = os.path.join(os.path.dirname(src), "s.json"); d = os.path.join(os.path.dirname(src), "bk")
        self.assertFalse(backups.periodic_backup_once(src, sf, d, st))
        os.utime(src, (1, 1))
        self.assertTrue(backups.periodic_backup_once(src, sf, d, st))
        self.assertFalse(backups.periodic_backup_once(src, sf, d, st))

    def test_result_date_between_status_and_result(self):
        c = self.login("admin1")
        html = c.get("/cases/new").get_data(as_text=True)
        self.assertLess(html.index('id="box-status"'), html.index('id="box-resultdate"'))
        self.assertLess(html.index('id="box-resultdate"'), html.index('id="box-result"'))


class V252Tests(FormBase):
    def _post(self, c, subject="مشکل", body="متن"):
        t = self.token(c, "/tickets")
        return c.post("/tickets", data={"csrf": t, "subject": subject, "body": body, "contact": "0912"})

    def test_ticket_sent_and_reply_synced(self):
        from app import tickets
        calls = []

        def fake(app, method, path, payload=None):
            calls.append((method, path))
            if method == "POST" and path.endswith("/issues"):
                self.assertIn("شمارهٔ تیکت در برنامه", payload["body"])
                return {"number": 7}
            if path.endswith("/issues/7"):
                return {"state": "closed"}
            if path.endswith("/comments?per_page=100"):
                return [{"id": 1, "user": {"login": config.TICKET_SUPPORT_LOGIN}, "body": "جواب شما", "created_at": "2026-10-21T10:00:00Z"},
                        {"id": 2, "user": {"login": "other"}, "body": "x", "created_at": "2026-10-21T10:01:00Z"}]
            raise AssertionError(path)
        c = self.login("entry1")
        with mock.patch.object(tickets, "_call", fake):
            r = self._post(c)
            self.assertEqual(r.status_code, 302)
            html = c.get(r.headers["Location"]).get_data(as_text=True)
        self.assertIn("جواب شما", html)
        self.assertIn("بسته شد", html)
        self.assertEqual(self.db.execute("SELECT gh_number FROM tickets").fetchone()[0], 7)
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM ticket_comments").fetchone()[0], 1)

    def test_ticket_offline_stays_pending_then_retries(self):
        from app import tickets
        c = self.login("entry1")

        def down(app, method, path, payload=None):
            raise tickets.TicketError("x")
        with mock.patch.object(tickets, "_call", down):
            self._post(c)
        self.assertIsNone(self.db.execute("SELECT gh_number FROM tickets").fetchone()[0])
        with mock.patch.object(tickets, "_call", lambda *a, **k: {"number": 9}):
            c.get("/tickets")
        self.assertEqual(self.db.execute("SELECT gh_number FROM tickets").fetchone()[0], 9)

    def test_other_user_cannot_see_ticket(self):
        from app import tickets
        c = self.login("entry1")
        with mock.patch.object(tickets, "_call", lambda *a, **k: {"number": 1}):
            self._post(c)
        tid = self.db.execute("SELECT id FROM tickets").fetchone()[0]
        v = self.login("viewer1")
        self.assertEqual(v.get(f"/tickets/{tid}").status_code, 404)
        self.assertEqual(self.login("admin1").get(f"/tickets/{tid}").status_code, 200)

    def test_token_not_in_repo_files(self):
        import subprocess
        out = subprocess.run(["grep", "-rl", "--include=*.py", "--include=*.md", "github" + "_pat_1", "app", "tests", "README.md"], capture_output=True, text=True).stdout
        self.assertEqual(out.strip(), "")
