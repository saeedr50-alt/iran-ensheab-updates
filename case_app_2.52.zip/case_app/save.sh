#!/bin/bash
# ذخیره کامل با یک دستور:  bash save.sh
# ۱) بکاپ از اطلاعات (پوشه backups)  ۲) ذخیره نسخهٔ کد در Git
cd "$(dirname "$0")" || exit 1
python3 backup.py || true
git add . && git commit -m "ذخیره $(date '+%Y-%m-%d %H:%M')" || echo "(در کد تغییر تازه‌ای نبود)"
echo "تمام شد."
