import os

from app import create_app

app = create_app()

if __name__ == "__main__":
    # پورت 5001 است چون روی مک، پورت 5000 را AirPlay اشغال می‌کند.
    # host=0.0.0.0 یعنی از سایر کامپیوترهای شبکه هم قابل دسترسی است.
    port = int(os.environ.get("PORT", "5001"))
    app.run(host="0.0.0.0", port=port, debug=False)
