@echo off
rem اجرای برنامه با یک دستور (ویندوز): دوبار کلیک روی start.bat
cd /d "%~dp0"
python -c "import flask" 2>nul || python -m pip install flask
python -c "import reportlab" 2>nul || python -m pip install reportlab
python -c "import certifi" 2>nul || python -m pip install certifi
if not exist instance\cases.sqlite (
  echo اولین اجرا: یک کاربر مدیر بسازید
  python create_user.py
) else (
  python backup.py
)
echo http://localhost:5001
python run.py
pause
