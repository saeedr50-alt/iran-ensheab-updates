"""ساخت کاربر جدید از خط فرمان:

    python3 create_user.py                # تعاملی
    python3 create_user.py ali entry      # نام کاربری و نقش؛ رمز پرسیده می‌شود

نقش‌ها: admin (مدیر) / entry (ثبت‌کننده) / viewer (بیننده)
"""
import getpass
import sqlite3
import sys

from app import auth, config, create_app
from app.db import connect


def main():
    args = sys.argv[1:]
    username = args[0] if len(args) > 0 else input("نام کاربری: ").strip()
    role = args[1] if len(args) > 1 else input(f"نقش {list(config.ROLES)}: ").strip()
    password = getpass.getpass("رمز عبور (حداقل ۶ کاراکتر): ")
    if password != getpass.getpass("تکرار رمز عبور: "):
        sys.exit("رمزها یکسان نیستند.")

    app = create_app()
    conn = connect(app.config["DATABASE"])
    try:
        auth.create_user(conn, username, password, role)
    except (ValueError, sqlite3.IntegrityError) as e:
        sys.exit(f"خطا: {e}")
    finally:
        conn.close()
    print(f"کاربر «{username}» با نقش «{config.ROLES[role]}» ساخته شد.")


if __name__ == "__main__":
    main()
