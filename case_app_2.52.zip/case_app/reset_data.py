"""پاک‌سازی اطلاعات آزمایشی (پرونده‌ها و شماره‌ها) با یک دستور:

    python3 reset_data.py

- ابتدا از کل دیتابیس بکاپ کامل در پوشه backups ساخته می‌شود (چیزی واقعاً از بین نمی‌رود).
- کاربران و گزینه‌های «مدیریت گزینه‌ها» می‌مانند.
- پرونده‌ها، ردیف محصولات و رقبا و شمارنده‌ها خالی می‌شوند؛ شماره‌گذاری دوباره از ۱ شروع می‌شود.
- قبل از اجرا، برنامه (run.py) را با Control+C متوقف کنید.
"""
import os
import sqlite3
import sys

from backup import SOURCE, HERE, make_backup


def reset(source: str = SOURCE, folder: str | None = None, ask=input) -> str | None:
    if not os.path.exists(source):
        raise FileNotFoundError(f"دیتابیس پیدا نشد: {source}")
    if ask("همهٔ پرونده‌ها خالی شود؟ (کاربران و گزینه‌ها می‌مانند) برای تأیید بنویسید YES: ").strip() != "YES":
        print("لغو شد؛ هیچ چیز تغییر نکرد.")
        return None
    backup_path = make_backup(source, folder)
    print("بکاپ کامل ساخته شد:", backup_path)

    # دیتابیس تازه با همان ساختار، فقط با کاربران و گزینه‌های قبلی
    from app.db import connect, init_db
    fresh = source + ".new"
    for ext in ("", "-wal", "-shm"):
        if os.path.exists(fresh + ext):
            os.remove(fresh + ext)
    init_db(fresh)
    old = sqlite3.connect(source)
    new = connect(fresh)
    try:
        new.execute("BEGIN")
        for r in old.execute("SELECT id, username, password_hash, role, created_at FROM users"):
            new.execute("INSERT OR REPLACE INTO users (id, username, password_hash, role, created_at) "
                        "VALUES (?, ?, ?, ?, ?)", r)
        for r in old.execute("SELECT grp, label, active FROM options ORDER BY id"):
            new.execute("INSERT INTO options (grp, label, active) VALUES (?, ?, ?) "
                        "ON CONFLICT(grp, label) DO UPDATE SET active = excluded.active", r)
        new.execute("COMMIT")
    finally:
        old.close()
        new.close()
    for ext in ("-wal", "-shm"):             # فایل‌های جانبی دیتابیس قدیمی
        if os.path.exists(source + ext):
            os.remove(source + ext)
    os.replace(fresh, source)
    for ext in ("-wal", "-shm"):
        if os.path.exists(fresh + ext):
            os.remove(fresh + ext)
    print("تمام شد. پرونده‌ها خالی شدند؛ شمارهٔ بعدی دوباره ۱ است.")
    return backup_path


if __name__ == "__main__":
    try:
        reset()
    except FileNotFoundError as e:
        sys.exit(str(e))
