"""نقطهٔ شروع نسخهٔ ویندوز (exe). بدون نیاز به نصب پایتون؛ همه‌چیز کنار همین فایل می‌ماند.

پوشه‌های کنار exe:  instance (دیتابیس)،  backups (بکاپ‌ها)،  reports (PDFها)
"""
import os
import sys
import threading
import time
import webbrowser

from app import create_app, config


def base_dir() -> str:
    return os.path.dirname(sys.executable) if getattr(sys, "frozen", False) else os.path.dirname(os.path.abspath(__file__))


def find_browser() -> str:
    """Edge یا Chrome نصب‌شده روی ویندوز (Edge همیشه هست)."""
    roots = [os.environ.get(k, "") for k in ("ProgramFiles(x86)", "ProgramFiles", "LocalAppData")]
    rels = [r"Microsoft\Edge\Application\msedge.exe", r"Google\Chrome\Application\chrome.exe"]
    for rel in rels:
        for root in roots:
            p = os.path.join(root, rel) if root else ""
            if p and os.path.isfile(p):
                return p
    return ""


def open_window(url: str, base: str) -> None:
    """برنامه را در پنجرهٔ بزرگ‌شده (maximize، با نوار وظیفه؛ نه تمام‌صفحه) و جدا (بدون نوار آدرس) باز می‌کند. مرورگرهای دیگر بسته نمی‌شوند
    (ممکن است کار ذخیره‌نشده داشته باشند)."""
    exe = find_browser()
    if exe:
        try:
            import subprocess
            # پروفایل معمولی خود مرورگر (پروفایل تازه صفحه‌های خوش‌آمدگویی/همگام‌سازی باز می‌کرد)
            subprocess.Popen([exe, f"--app={url}", "--start-maximized", "--disable-features=Translate,TranslateUI"])
            return
        except Exception:
            pass
    webbrowser.open(url)


def port_busy(port: int) -> bool:
    import socket
    with socket.socket() as s:
        s.settimeout(0.5)
        return s.connect_ex(("127.0.0.1", port)) == 0


def main() -> None:
    base = base_dir()
    port = int(os.environ.get("PORT", "5001"))
    if getattr(sys, "frozen", False):               # بدون پنجرهٔ کنسول: خروجی در فایل لاگ
        os.makedirs(os.path.join(base, "instance"), exist_ok=True)
        sys.stdout = sys.stderr = open(os.path.join(base, "instance", "app.log"), "a", buffering=1, encoding="utf-8")
    if port_busy(port):                              # برنامه از قبل باز است: فقط پنجره را باز کن
        if not os.environ.get("NO_BROWSER"):
            open_window(f"http://localhost:{port}", base)
        return
    app = create_app({"BACKUP_DIR": os.path.join(base, "backups")}, instance_path=os.path.join(base, "instance"))
    url = f"http://localhost:{port}"
    print("=" * 60)
    print(f" Iran Ensheab  v{config.APP_VERSION}")
    print(f" Address : {url}")
    print(" (Windows may ask about the firewall: click 'Allow access')")
    print(" To stop the program use the in-app exit button.")
    print("=" * 60)
    if not os.environ.get("NO_BROWSER"):
        threading.Thread(target=lambda: (time.sleep(1.5), open_window(url, base)), daemon=True).start()
    app.run(host="0.0.0.0", port=port, debug=False, threaded=True)


if __name__ == "__main__":
    main()
