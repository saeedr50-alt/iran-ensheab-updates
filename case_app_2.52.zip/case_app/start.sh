#!/bin/bash
# اجرای برنامه با یک دستور (مک/لینوکس):  bash start.sh
cd "$(dirname "$0")" || exit 1
PY=python3
command -v python3 >/dev/null 2>&1 || PY=python
$PY -c "import flask" 2>/dev/null || $PY -m pip install flask
$PY -c "import reportlab" 2>/dev/null || $PY -m pip install reportlab   # برای گزارش PDF شناسنامه
$PY -c "import certifi" 2>/dev/null || $PY -m pip install certifi
if [ ! -f instance/cases.sqlite ]; then
  echo "اولین اجرا: یک کاربر مدیر بسازید"
  $PY create_user.py
else
  $PY backup.py || true      # قبل از هر اجرا یک بکاپ از اطلاعات
fi
echo "برنامه روی  http://localhost:5001  اجرا می‌شود (برای توقف: Control+C)"
$PY run.py
