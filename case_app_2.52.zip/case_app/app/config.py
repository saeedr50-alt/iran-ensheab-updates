"""تنظیمات برنامه. مقادیر مهم اینجا جمع شده‌اند تا تغییرشان ساده باشد."""

# انواع پرونده: کد داخلی -> عنوان نمایشی
CASE_TYPES = {
    "tender_mech": "مناقصه کنتورهای مکانیکی",
    "tender_smart": "مناقصه کنتورهای هوشمند",
    "inquiry_mech": "استعلام کنتورهای مکانیکی",
    "inquiry_smart": "استعلام کنتورهای هوشمند",
    "auction": "مزایده",
    # نوع‌های قدیمی (نسخه‌های قبل از ۲.۲۲): فقط برای نمایش پرونده‌های موجود؛ برای پرونده جدید انتخاب نمی‌شوند
    "tender": "مناقصه",
    "inquiry": "استعلام",
}
LEGACY_TYPES = ("tender", "inquiry")
SELECTABLE_TYPES = {k: v for k, v in CASE_TYPES.items() if k not in LEGACY_TYPES}
# گروه هر نوع (برای عنوان‌های گزارش و شمارش در داشبورد)
CASE_GROUPS = {"tender_mech": "مناقصه", "tender_smart": "مناقصه", "tender": "مناقصه",
               "inquiry_mech": "استعلام", "inquiry_smart": "استعلام", "inquiry": "استعلام",
               "auction": "مزایده"}

# اگر True باشد، شماره‌گذاری هر سال شمسی از ۱ شروع می‌شود.
# اگر شرکت بخواهد شماره‌ها همیشه ادامه‌دار باشند، فقط این را False کنید.
RESET_NUMBERING_YEARLY = True

# نقش‌ها:
#   admin  -> همه کارها + مدیریت گزینه‌های کمبوباکس‌ها
#   entry  -> ثبت و ویرایش پرونده + دیدن لیست
#   viewer -> فقط دیدن
ROLES = {
    "admin": "مدیر",
    "entry": "ثبت‌کننده",
    "viewer": "بیننده",
}
ROLES_CAN_CREATE = ("admin", "entry")      # نقش‌هایی که می‌توانند «جای ویرایش» بگیرند

# ویرایش همزمان: حداکثر چند نفر هم‌زمان می‌توانند پرونده ثبت/ویرایش کنند (مدیر می‌تواند تغییرش دهد)
DEFAULT_MAX_EDITORS = 2
MAX_EDITORS_LIMIT = 10
SEAT_TIMEOUT_SECONDS = 10 * 60             # اگر این‌قدر بدون فعالیت بماند، جایش آزاد می‌شود

# جدول سطح دسترسی (فقط برای نمایش در صفحهٔ کاربران): (عنوان، {نقش: بله/خیر})
ROLE_CAPS = [
    ("دیدن پرونده‌ها و گزارش شناسنامه", {"admin": True, "entry": True, "viewer": True}),
    ("ثبت و ویرایش پرونده و اطلاعات شناسنامه", {"admin": True, "entry": True, "viewer": False}),
    ("افزودن/ویرایش گزینه‌ها با دکمه‌های + و مداد", {"admin": True, "entry": True, "viewer": False}),
    ("مدیریت گزینه‌ها (فعال/غیرفعال)", {"admin": True, "entry": False, "viewer": False}),
    ("بکاپ و بازگردانی", {"admin": True, "entry": False, "viewer": False}),
    ("مدیریت کاربران و ظرفیت ویرایش", {"admin": True, "entry": False, "viewer": False}),
]

# گروه‌های گزینه‌ها (محتوای کمبوباکس‌ها). مدیر از صفحه «مدیریت گزینه‌ها» پرشان می‌کند.
OPTION_GROUPS = {
    "source": "منبع دریافت",
    "organization": "سازمان / شرکت",
    "product_type": "نام محصول",
    "size": "سایز",
    "model": "مدل",
    "sample": "نمونه",
    "tender_type": "نوع برگزاری",
    "status": "وضعیت پرونده",
    "decision": "تصمیم مدیریتی",
    "result": "نتیجه",
    "archive_reason": "علت بایگانی",
    # گزینه‌های فرم شناسنامه (پاپ‌آپ)
    "send_method": "نحوه ارسال اسناد",
    "payment_method": "نحوه پرداخت",
    "advance": "پیش پرداخت",
    "inspection": "بازرسی",
    "shipping": "حمل",
    "unloading": "تخلیه",
    "clearance": "مفاصا حساب",
}

# ستون‌هایی که مقدار هر گروه گزینه را نگه می‌دارند (برای اصلاح نام گزینه در همهٔ پرونده‌ها)
OPTION_COLUMNS = {
    "source": [("cases", "source")], "organization": [("cases", "organization")],
    "tender_type": [("cases", "tender_type")], "status": [("cases", "status")],
    "decision": [("cases", "decision")], "result": [("cases", "result")], "archive_reason": [("cases", "archive_reason")],
    "product_type": [("case_products", "product_type")], "size": [("case_products", "size")],
    "model": [("case_products", "model")], "sample": [("case_products", "sample")],
    "send_method": [("case_profile", "send_method")], "payment_method": [("case_profile", "payment_method")],
    "advance": [("case_profile", "advance")], "inspection": [("case_profile", "inspection")],
    "shipping": [("case_profile", "shipping")], "unloading": [("case_profile", "unloading")],
    "clearance": [("case_profile", "clearance")],
}

# کد فرم چاپی شناسنامه (پایین گزارش)
REPORT_FORM_CODE = "Sel/FO/115.02"

# مقدارهایی که منطق فرم به آن‌ها وابسته است
ARCHIVE_VALUE = "عدم تایید و بایگانی"   # تصمیم مدیریتی = این  ->  «علت بایگانی» (کمبو) ظاهر می‌شود و وضعیت/بازگشایی/نتیجه قفل می‌شوند
OLD_ARCHIVE_VALUE = "بایگانی"           # نام قدیمی (نسخه‌های قبل از ۲.۲۲)
# فیلدهای صفحهٔ هر شرکت؛ برای افزودن فیلد فقط یک خط به این فهرست اضافه کنید (بدون تغییر دیتابیس)
ORG_FIELDS = [("address", "آدرس"), ("phone", "شماره تلفن")]
# «نفرات مربوطه» (چند نفر برای هر سازمان): کلید و عنوان ستون‌ها
ORG_CONTACT_FIELDS = [("name", "اسم و فامیل"), ("unit", "واحد"), ("position", "سمت"), ("phone", "شماره تلفن"),
                      ("ext", "شماره داخلی در صورت تماس با ابفا")]
DEVELOPER_NAME = "پیشرو سیستم"           # طراح و توسعه‌دهندهٔ برنامه (پایین منو و صفحهٔ ورود)
BACKUP_INTERVAL_SECONDS = 15 * 60        # بکاپ خودکار هر ۱۵ دقیقه (فقط اگر اطلاعات عوض شده باشد)
# بخش‌های داشبورد که مدیر برای هر کاربر می‌تواند نشان بدهد/پنهان کند: (شناسه، عنوان)
DASH_SECTIONS = [("kpis", "شاخص‌های کلیدی (کارت‌های بالا)"), ("c-trend", "روند ثبت پرونده‌ها"), ("c-result", "نتیجهٔ پرونده‌ها"),
                 ("c-orgs", "سازمان‌ها"), ("c-status", "وضعیت پرونده‌ها"), ("c-products", "محصولات"),
                 ("c-deadlines", "مهلت‌های ارسال پیش رو"), ("c-competitors", "رقبا"), ("c-tender", "نوع برگزاری و نرخ برد"),
                 ("c-source", "منبع دریافت"), ("c-reasons", "علت‌های بایگانی"), ("c-sizes", "سایزها"),
                 ("c-recent", "آخرین پرونده‌ها")]
# اطلاعات شرکتی که برنامه را استفاده می‌کند (تنظیمات ← اطلاعات شرکت)
COMPANY_FIELDS = [("name", "نام شرکت"), ("address", "آدرس"), ("phone", "شماره تلفن"), ("email", "ایمیل"), ("website", "وب‌سایت")]
TICKET_REPO = "saeedr50-alt/iran-ensheab-tickets"      # مخزن خصوصی تیکت‌ها در گیت‌هاب
TICKET_SUPPORT_LOGIN = "saeedr50-alt"                  # پاسخ‌های این حساب «پاسخ پشتیبان» حساب می‌شوند
APPROVE_VALUE = "تایید"                  # تصمیم مدیریتی = تایید  ->  «وضعیت پرونده» نشان داده می‌شود
STATUS_SENT = "ارسال شد"                 # وضعیت = ارسال شد  ->  «نتیجه» نشان داده می‌شود
STATUS_RESULT = "نتیجه اعلام شد"         # با انتخاب نتیجه، وضعیت خودکار این می‌شود و «تاریخ اعلام نتایج» ظاهر می‌شود
SAMPLE_YES = "دارد"                      # نمونه = دارد  ->  فیلد «تعداد نمونه» فعال می‌شود
LOSER_VALUE = "بازنده"      # نتیجه = بازنده           ->  بخش «رقبا» ظاهر می‌شود


def same(a: str, b: str) -> bool:
    """برابری دقیق متن (ی/ي و ک/ك و فاصله‌های اضافه نادیده گرفته می‌شود)."""
    fix = lambda s: " ".join((s or "").replace("ي", "ی").replace("ك", "ک").split())
    return fix(a) == fix(b)


def sample_is_yes(value: str) -> bool:
    """دقیقاً «دارد» (نه «ندارد» که آن هم شامل کلمهٔ دارد است)."""
    fix = lambda s: " ".join((s or "").replace("ي", "ی").replace("ك", "ک").split())
    return fix(value) == fix(SAMPLE_YES)


def matches(value: str, keyword: str) -> bool:
    """آیا «value» شامل کلمهٔ «keyword» است؟ (مثلاً «بایگانی شد» هم بایگانی حساب می‌شود.)
    تفاوت ی/ي و ک/ك عربی و فارسی نادیده گرفته می‌شود."""
    fix = lambda s: (s or "").replace("ي", "ی").replace("ك", "ک")
    return fix(keyword) in fix(value)


# این گزینه‌ها همیشه باید در لیست باشند (اگر نبودند خودکار اضافه می‌شوند)
REQUIRED_OPTIONS = {
    "decision": [APPROVE_VALUE, ARCHIVE_VALUE],
    "status": [STATUS_SENT, STATUS_RESULT],
    "result": [LOSER_VALUE],
    "sample": [SAMPLE_YES, "ندارد"],
}

# گزینه‌های اولیه (فقط اولین بار که دیتابیس ساخته می‌شود)
DEFAULT_OPTIONS = {
    "result": ["برنده", "بازنده"],
    "decision": ["تایید", ARCHIVE_VALUE],
}


# نسخهٔ برنامه: با هر تغییر این عدد را بالا ببرید (در صفحهٔ ورود، منو و پاپ‌آپ خوش‌آمد نمایش داده می‌شود)
APP_VERSION = "2.52"
# مخزن عمومی فایل‌های به‌روزرسانی (فقط فایل نسخه‌ها؛ هیچ اطلاعاتی از شرکت آنجا نمی‌رود)
# «چه چیزهایی تازه است» بعد از ورود نشان داده می‌شود تا کاربر تیک «دیگر نمایش نده» را بزند.
# برای نسخهٔ جدید: version را عوض کنید و items را بنویسید (خالی = پاپ‌آپ نیست).
WHATS_NEW = {"version": "2.52", "items": [
    "ثبت تیکت پشتیبانی اضافه شد: سؤال یا مشکل را بنویسید تا برای پشتیبان ارسال شود و پاسخ را همان‌جا ببینید.",
    "لینک «ثبت تیکت پشتیبانی» پایین منو و در تنظیمات هست."]}
UPDATE_URL = "https://raw.githubusercontent.com/saeedr50-alt/iran-ensheab-updates/main"
# آدرس‌های جایگزین؛ اگر اولی (مثلاً به‌خاطر فیلتر/DNS) باز نشد، به ترتیب این‌ها امتحان می‌شوند
UPDATE_MIRRORS = [
    "https://cdn.jsdelivr.net/gh/saeedr50-alt/iran-ensheab-updates@main",
    "https://github.com/saeedr50-alt/iran-ensheab-updates/raw/main",
]
COMPANY_NAME = "ایران انشعاب"
APP_TITLE = "سامانه مناقصات و استعلامات"
