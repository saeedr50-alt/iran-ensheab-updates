/* کمبوباکس قابل جستجو: هر <select> داخل فرم را با یک لیست کشویی دارای کادر جستجو جایگزین می‌کند.
 * خود <select> (پنهان) می‌ماند، پس ارسال فرم و اعتبارسنجی سمت سرور هیچ تغییری نمی‌کند.
 * جستجو: چند کلمه به هر ترتیب؛ تفاوت ی/ي و ک/ك و نیم‌فاصله و ارقام فارسی نادیده گرفته می‌شود.
 */
(function () {
  'use strict';

  function norm(s) {
    return String(s || '')
      .replace(/ي/g, 'ی').replace(/ك/g, 'ک')
      .replace(/[۰-۹]/g, function (c) { return c.charCodeAt(0) - 1776; })
      .replace(/[٠-٩]/g, function (c) { return c.charCodeAt(0) - 1632; })
      .replace(/‌/g, ' ').replace(/\s+/g, ' ').trim().toLowerCase();
  }
  function matches(text, query) {
    var t = norm(text), words = norm(query).split(' ');
    for (var i = 0; i < words.length; i++) { if (words[i] && t.indexOf(words[i]) === -1) return false; }
    return true;
  }
  if (typeof module !== 'undefined' && module.exports) { module.exports = { norm: norm, matches: matches }; }
  if (typeof document === 'undefined') { return; }

  var pop = null, list = null, q = null, active = null, items = [], cursor = -1, controls = [];

  function buildPop() {
    pop = document.createElement('div');
    pop.className = 'ss-pop';
    pop.hidden = true;
    pop.dir = 'rtl';
    q = document.createElement('input');
    q.type = 'text'; q.className = 'ss-q'; q.placeholder = 'جستجو…'; q.autocomplete = 'off';
    q.setAttribute('aria-label', 'جستجو در گزینه‌ها');
    list = document.createElement('ul');
    list.className = 'ss-list'; list.setAttribute('role', 'listbox');
    pop.appendChild(q); pop.appendChild(list);
    document.body.appendChild(pop);

    q.addEventListener('input', function () { fill(q.value); });
    q.addEventListener('keydown', function (e) {
      if (e.key === 'ArrowDown') { e.preventDefault(); move(1); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); move(-1); }
      else if (e.key === 'Enter') { e.preventDefault(); if (cursor >= 0 && items[cursor]) choose(items[cursor].value); }
      else if (e.key === 'Escape') { e.preventDefault(); close(true); }
      else if (e.key === 'Tab') { close(false); }
    });
    list.addEventListener('mousedown', function (e) { e.preventDefault(); });
    list.addEventListener('click', function (e) {
      var li = e.target.closest('li[data-i]');
      if (li) choose(items[+li.getAttribute('data-i')].value);
    });
  }

  function fill(query) {
    var opts = active.select.options, html = '', n = 0;
    items = [];
    for (var i = 0; i < opts.length; i++) {
      var o = opts[i];
      if (o.disabled && o.value === '') continue;              // «انتخاب کنید…» غیرقابل‌انتخاب
      var label = o.value === '' ? '— بدون انتخاب —' : o.text;
      if (o.value !== '' && query && !matches(o.text, query)) continue;
      if (o.value === '' && query) continue;
      items.push({ value: o.value, label: label });
    }
    items.forEach(function (it, idx) {
      var cur = it.value === active.select.value;
      html += '<li role="option" data-i="' + idx + '" class="' + (cur ? 'cur' : '') + (it.value === '' ? ' none' : '') + '"></li>';
    });
    list.innerHTML = html || '<li class="empty">نتیجه‌ای پیدا نشد</li>';
    var lis = list.querySelectorAll('li[data-i]');
    for (var k = 0; k < lis.length; k++) { lis[k].textContent = items[k].label; }
    cursor = items.length ? (query ? 0 : Math.max(0, items.findIndex(function (x) { return x.value === active.select.value; }))) : -1;
    paintCursor(true);
  }

  function paintCursor(scroll) {
    var lis = list.querySelectorAll('li[data-i]');
    for (var i = 0; i < lis.length; i++) { lis[i].classList.toggle('hot', i === cursor); }
    if (scroll && cursor >= 0 && lis[cursor]) {
      var el = lis[cursor];
      if (el.offsetTop < list.scrollTop) list.scrollTop = el.offsetTop;
      else if (el.offsetTop + el.offsetHeight > list.scrollTop + list.clientHeight) list.scrollTop = el.offsetTop + el.offsetHeight - list.clientHeight;
    }
  }
  function move(d) {
    if (!items.length) return;
    cursor = (cursor + d + items.length) % items.length;
    paintCursor(true);
  }

  function place() {
    var r = active.btn.getBoundingClientRect();
    var w = Math.max(r.width, 240), h = pop.offsetHeight;
    var left = Math.min(Math.max(8, r.right - w), document.documentElement.clientWidth - w - 8);
    var top = r.bottom + 4;
    if (top + h > window.innerHeight - 8 && r.top > h + 8) top = r.top - h - 4;
    pop.style.width = w + 'px'; pop.style.left = left + 'px'; pop.style.top = top + 'px';
  }

  function open(ctl) {
    if (!pop) buildPop();
    if (active && active !== ctl) close(false);
    active = ctl;
    pop.hidden = false;
    ctl.btn.setAttribute('aria-expanded', 'true');
    q.value = '';
    fill('');
    place();
    q.focus();
  }
  function close(refocus) {
    if (!pop || pop.hidden) return;
    pop.hidden = true;
    if (active) { active.btn.setAttribute('aria-expanded', 'false'); if (refocus) active.btn.focus(); }
    active = null;
  }
  function choose(value) {
    var ctl = active;
    close(true);
    if (!ctl) return;
    if (ctl.select.value !== value) {
      ctl.select.value = value;
      ctl.select.dispatchEvent(new Event('input', { bubbles: true }));
      ctl.select.dispatchEvent(new Event('change', { bubbles: true }));
    }
    refresh(ctl);
    if (value !== '' && window.svFocusNext) {       // بعد از انتخاب، مستقیم به فیلد بعدی برو
      setTimeout(function () { window.svFocusNext(ctl.btn); }, 60);
    }
  }

  function refresh(ctl) {
    var o = ctl.select.options[ctl.select.selectedIndex];
    var text = o && o.value !== '' ? o.text : '';
    ctl.label.textContent = text || 'انتخاب کنید…';
    ctl.btn.classList.toggle('empty', !text);
    ctl.btn.disabled = ctl.select.disabled;
    if (ctl.plus) ctl.plus.disabled = ctl.select.disabled;
    if (ctl.edit) ctl.edit.disabled = ctl.select.disabled || !text;
  }

  // ---- پنجرهٔ کوچک «افزودن گزینه»
  var modal = null, modalCtl = null;
  function buildModal() {
    modal = document.createElement('div');
    modal.className = 'ss-modal'; modal.hidden = true; modal.dir = 'rtl';
    modal.innerHTML = '<div class="ss-box" role="dialog" aria-modal="true"><h3></h3>' +
      '<input type="text" maxlength="200" autocomplete="off" aria-label="متن گزینه">' +
      '<p class="ss-note"></p>' +
      '<label class="ss-act" hidden><input type="checkbox" checked> این گزینه فعال باشد (در لیست نمایش داده شود)</label>' +
      '<p class="ss-err" role="alert"></p>' +
      '<div class="ss-acts"><button type="button" class="btn primary small" data-do="save">ذخیره</button>' +
      '<button type="button" class="btn small" data-do="cancel">انصراف</button></div></div>';
    document.body.appendChild(modal);
    modal.addEventListener('mousedown', function (e) { if (e.target === modal) closeModal(); });
    modal.addEventListener('click', function (e) {
      var b = e.target.closest('button[data-do]');
      if (!b) return;
      if (b.getAttribute('data-do') === 'cancel') closeModal(); else saveOption();
    });
    modal.querySelector('input').addEventListener('keydown', function (e) {
      if (e.key === 'Enter') { e.preventDefault(); saveOption(); }
      else if (e.key === 'Escape') { e.preventDefault(); closeModal(); }
    });
  }
  var modalEdit = false, modalOld = '', modalWasActive = true;
  function openAdd(ctl, editing) {
    if (!modal) buildModal();
    close(false);
    modalCtl = ctl; modalEdit = !!editing;
    var title = ctl.select.getAttribute('data-title') || '';
    var inp = modal.querySelector('input');
    var actLbl = modal.querySelector('.ss-act'), actBox = actLbl.querySelector('input');
    modalOld = modalEdit ? ctl.select.value : '';
    if (modalEdit) {
      modal.querySelector('h3').textContent = 'ویرایش گزینه' + (title ? ' در «' + title + '»' : '');
      modal.querySelector('.ss-note').textContent = 'نام جدید در همهٔ پرونده‌هایی که این گزینه را دارند هم اصلاح می‌شود.';
      inp.value = modalOld;
      var so = ctl.select.options[ctl.select.selectedIndex];
      modalWasActive = !(so && so.getAttribute('data-off'));
      actBox.checked = modalWasActive; actLbl.hidden = false;
    } else {
      actLbl.hidden = true;
      modal.querySelector('h3').textContent = 'افزودن گزینهٔ تازه' + (title ? ' به «' + title + '»' : '');
      modal.querySelector('.ss-note').textContent = '';
      inp.value = '';
    }
    modal.querySelector('.ss-err').textContent = '';
    modal.hidden = false;
    inp.focus(); inp.select();
  }
  function closeModal() {
    if (!modal || modal.hidden) return;
    modal.hidden = true;
    if (modalCtl) (modalEdit && modalCtl.edit ? modalCtl.edit : modalCtl.plus).focus();
    modalCtl = null;
  }
  function addOptionEverywhere(grp, label) {
    function put(root) {
      var sels = root.querySelectorAll('select[data-grp="' + grp + '"]');
      for (var i = 0; i < sels.length; i++) {
        var has = false;
        for (var j = 0; j < sels[i].options.length; j++) { if (sels[i].options[j].value === label) has = true; }
        if (!has) sels[i].appendChild(new Option(label, label));
      }
    }
    put(document);
    document.querySelectorAll('template').forEach(function (t) { put(t.content); });   // ردیف‌های جدید بعدی هم گزینه را دارند
  }
  function renameEverywhere(grp, oldLabel, newLabel) {
    function ren(root) {
      var sels = root.querySelectorAll('select[data-grp="' + grp + '"]');
      for (var i = 0; i < sels.length; i++) {
        for (var j = 0; j < sels[i].options.length; j++) {
          if (sels[i].options[j].value === oldLabel) { sels[i].options[j].value = newLabel; sels[i].options[j].text = newLabel; }
        }
      }
    }
    ren(document);
    document.querySelectorAll('template').forEach(function (t) { ren(t.content); });
    controls.forEach(refresh);
  }
  function setActiveEverywhere(grp, label, on) {
    if (on === null || on === undefined) return;
    if (on) { addOptionEverywhere(grp, label); }
    function mark(root) {
      var sels = root.querySelectorAll('select[data-grp="' + grp + '"]');
      for (var i = 0; i < sels.length; i++) {
        for (var j = sels[i].options.length - 1; j >= 0; j--) {
          var o = sels[i].options[j];
          if (o.value !== label) continue;
          if (on) o.removeAttribute('data-off');
          else if (o.selected) o.setAttribute('data-off', '1');   // مقدار فعلی همین فرم می‌ماند
          else sels[i].remove(j);
        }
      }
    }
    mark(document);
    document.querySelectorAll('template').forEach(function (t) { mark(t.content); });
    controls.forEach(refresh);
  }
  function saveOption() {
    var ctl = modalCtl, inp = modal.querySelector('input'), err = modal.querySelector('.ss-err');
    var text = inp.value.replace(/\s+/g, ' ').trim();
    if (!text) { err.textContent = 'متن گزینه را بنویسید.'; inp.focus(); return; }
    var body = new URLSearchParams();
    body.set('csrf', ctl.form.querySelector('input[name=csrf]').value);
    body.set('grp', ctl.grp); body.set('label', text);
    var url = ctl.form.getAttribute('data-add-url');
    if (modalEdit) {
      var want = modal.querySelector('.ss-act input').checked;
      if (text === modalOld && want === modalWasActive) { closeModal(); return; }
      body.set('old', modalOld); body.set('active', want ? '1' : '0');
      url = ctl.form.getAttribute('data-rename-url');
    }
    var save = modal.querySelector('[data-do=save]'); save.disabled = true;
    fetch(url, { method: 'POST', body: body, credentials: 'same-origin' })
      .then(function (r) { return r.json().then(function (d) { return { ok: r.ok, d: d }; }); })
      .then(function (res) {
        save.disabled = false;
        if (!res.ok || !res.d.ok) { err.textContent = (res.d && res.d.error) || 'ذخیره نشد. دوباره تلاش کنید.'; return; }
        if (modalEdit) { var oldv = modalOld; closeModal(); renameEverywhere(ctl.grp, oldv, res.d.label); setActiveEverywhere(ctl.grp, res.d.label, res.d.active); return; }
        addOptionEverywhere(ctl.grp, res.d.label);
        var target = ctl;
        closeModal();
        target.select.value = res.d.label;
        target.select.dispatchEvent(new Event('input', { bubbles: true }));
        target.select.dispatchEvent(new Event('change', { bubbles: true }));
        refresh(target);
      })
      .catch(function () { save.disabled = false; err.textContent = 'ارتباط با سرور برقرار نشد.'; });
  }

  function enhance(select) {
    if (select.getAttribute('data-ss') || select.hasAttribute('data-native')) return;
    select.setAttribute('data-ss', '1');
    var wrap = document.createElement('div');
    wrap.className = 'ss';
    var btn = document.createElement('button');
    btn.type = 'button'; btn.className = 'ss-btn';
    btn.setAttribute('aria-haspopup', 'listbox'); btn.setAttribute('aria-expanded', 'false');
    var label = document.createElement('span');
    btn.appendChild(label);
    wrap.appendChild(btn);
    var form = select.closest('form[data-add-url]'), grp = select.getAttribute('data-grp');
    var plus = null, edit = null;
    if (form && grp) {                       // دکمهٔ «+» برای افزودن گزینهٔ تازه به همین کمبوباکس
      plus = document.createElement('button');
      plus.type = 'button'; plus.className = 'ss-add'; plus.textContent = '+';
      plus.title = 'افزودن گزینهٔ تازه'; plus.setAttribute('aria-label', 'افزودن گزینهٔ تازه');
      wrap.appendChild(plus);
      edit = document.createElement('button');
      edit.type = 'button'; edit.className = 'ss-edit';
      edit.title = 'ویرایش گزینهٔ انتخاب‌شده'; edit.setAttribute('aria-label', 'ویرایش گزینهٔ انتخاب‌شده');
      edit.innerHTML = '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 20h4L19 9l-4-4L4 16v4Z"/><path d="m13.5 6.5 4 4"/></svg>';
      wrap.appendChild(edit);
    }
    select.parentNode.insertBefore(wrap, select);
    select.style.display = 'none';
    select.tabIndex = -1;
    var ctl = { select: select, btn: btn, label: label, plus: plus, edit: edit, form: form, grp: grp };
    controls.push(ctl);
    if (plus) plus.addEventListener('click', function () { openAdd(ctl, false); });
    if (edit) edit.addEventListener('click', function () { openAdd(ctl, true); });
    btn.addEventListener('click', function () { if (active === ctl) close(true); else open(ctl); });
    btn.addEventListener('keydown', function (e) {
      if (e.key === 'ArrowDown' || e.key === 'Enter' || e.key === ' ') { e.preventDefault(); open(ctl); }
    });
    select.addEventListener('change', function () { refresh(ctl); });
    new MutationObserver(function () { refresh(ctl); }).observe(select, { attributes: true, attributeFilter: ['disabled'] });
    refresh(ctl);
  }

  function enhanceAll(root) {
    var sels = (root || document).querySelectorAll('select');
    for (var i = 0; i < sels.length; i++) { enhance(sels[i]); }
  }

  document.addEventListener('mousedown', function (e) {
    if (pop && !pop.hidden && !pop.contains(e.target) && !(active && active.btn.contains(e.target))) close(false);
  });
  window.addEventListener('resize', function () { if (pop && !pop.hidden) place(); });
  window.addEventListener('scroll', function (e) {
    if (pop && !pop.hidden && !pop.contains(e.target)) close(false);
  }, true);

  // ردیف‌هایی که بعداً اضافه می‌شوند (محصولات) هم خودکار قابل جستجو می‌شوند
  function start() {
    enhanceAll(document);
    new MutationObserver(function (muts) {
      muts.forEach(function (m) {
        m.addedNodes.forEach(function (n) {
          if (n.nodeType === 1) { if (n.tagName === 'SELECT') enhance(n); else enhanceAll(n); }
        });
      });
    }).observe(document.body, { childList: true, subtree: true });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
})();
