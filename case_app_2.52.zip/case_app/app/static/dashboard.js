/* داشبورد مدیریتی: نمودارها با SVG/HTML ساده (بدون هیچ کتابخانهٔ بیرونی، پس بدون اینترنت هم کار می‌کند).
 * کلیک روی هر نمودار = فیلتر متقابل مثل Power BI. هر ۶۰ ثانیه خودکار بروز می‌شود. */
(function () {
  'use strict';
  var root = document.getElementById('dash');
  if (!root) return;
  var URL = root.dataset.url, CASE_URL = root.dataset.caseUrl, LIST_URL = root.dataset.list;
  var filters = {}, data = null, timer = null;
  var PAL = ['#2563eb', '#14b8a6', '#f59e0b', '#8b5cf6', '#0ea5e9', '#ec4899', '#84cc16', '#f97316', '#64748b', '#06b6d4'];
  var RES_COLOR = { 'برنده': '#16a34a', 'بازنده': '#dc2626', 'نامشخص': '#94a3b8' };
  var DIM_LABEL = { type: 'نوع', year: 'سال', month: 'ماه', ym: 'ماه', org: 'سازمان', status: 'وضعیت', result: 'نتیجه',
                    product: 'محصول', source: 'منبع', tender: 'نوع برگزاری' };
  var tip = document.getElementById('d-tip');

  function $(s, r) { return (r || document).querySelector(s); }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function fmt(n) { return Number(n || 0).toLocaleString('en-US'); }
  function short(n) {
    n = Number(n || 0);
    if (n >= 1e12) return (n / 1e12).toFixed(1).replace(/\.0$/, '') + ' هزار میلیارد';
    if (n >= 1e9) return (n / 1e9).toFixed(1).replace(/\.0$/, '') + ' میلیارد';
    if (n >= 1e6) return (n / 1e6).toFixed(1).replace(/\.0$/, '') + ' میلیون';
    if (n >= 1e3) return (n / 1e3).toFixed(1).replace(/\.0$/, '') + ' هزار';
    return fmt(n);
  }
  function pct(a, b) { return b ? Math.round(1000 * a / b) / 10 : 0; }
  function empty(msg) { return '<div class="d-empty">' + esc(msg || 'داده‌ای برای نمایش نیست') + '</div>'; }

  // ---------- tooltip
  function showTip(e, html) {
    tip.innerHTML = html; tip.hidden = false;
    var w = tip.offsetWidth, h = tip.offsetHeight, x = e.clientX - w / 2, y = e.clientY - h - 14;
    x = Math.max(8, Math.min(window.innerWidth - w - 8, x)); if (y < 8) y = e.clientY + 18;
    tip.style.left = x + 'px'; tip.style.top = y + 'px';
  }
  function hideTip() { tip.hidden = true; }
  document.addEventListener('mouseover', function (e) {
    var t = e.target.closest('[data-tip]');
    if (t) showTip(e, t.getAttribute('data-tip'));
  });
  document.addEventListener('mousemove', function (e) { if (!tip.hidden && e.target.closest('[data-tip]')) showTip(e, e.target.closest('[data-tip]').getAttribute('data-tip')); });
  document.addEventListener('mouseout', function (e) { if (e.target.closest('[data-tip]')) hideTip(); });

  // ---------- فیلتر متقابل
  function toggle(dim, val) {
    if (filters[dim] === val) delete filters[dim]; else filters[dim] = val;
    if (dim === 'ym') { delete filters.month; }
    load();
  }
  root.addEventListener('click', function (e) {
    var el = e.target.closest('[data-dim]');
    if (el && el.dataset.val !== undefined) { toggle(el.dataset.dim, el.dataset.val); return; }
    var row = e.target.closest('[data-case]');
    if (row) { location.href = CASE_URL.replace(/0$/, row.dataset.case); }
  });
  function sel(dim, val) { return filters[dim] === val ? ' sel' : (filters[dim] ? ' dim' : ''); }

  // ---------- KPI
  function spark(vals, color) {
    if (!vals || vals.length < 2) return '';
    var w = 90, h = 28, mx = Math.max.apply(null, vals) || 1, st = w / (vals.length - 1);
    var pts = vals.map(function (v, i) { return (i * st).toFixed(1) + ',' + (h - 3 - (v / mx) * (h - 8)).toFixed(1); });
    return '<svg class="spark" viewBox="0 0 ' + w + ' ' + h + '" aria-hidden="true"><polyline points="' + pts.join(' ') +
      '" fill="none" stroke="' + color + '" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>' +
      '<circle cx="' + ((vals.length - 1) * st) + '" cy="' + pts[pts.length - 1].split(',')[1] + '" r="2.6" fill="' + color + '"/></svg>';
  }
  function gauge(p) {
    var r = 30, c = Math.PI * r, v = Math.max(0, Math.min(100, p || 0)) / 100;
    return '<svg class="gauge" viewBox="0 0 80 46" aria-hidden="true"><path d="M10 40 A30 30 0 0 1 70 40" fill="none" stroke="#e5eaf3" stroke-width="8" stroke-linecap="round"/>' +
      '<path d="M10 40 A30 30 0 0 1 70 40" fill="none" stroke="' + (p >= 50 ? '#16a34a' : p >= 30 ? '#f59e0b' : '#dc2626') + '" stroke-width="8" stroke-linecap="round" stroke-dasharray="' + (c * v) + ' ' + c + '"/></svg>';
  }
  function kpiCard(o) {
    return '<div class="kpi ' + (o.cls || '') + '"' + (o.dim ? ' data-dim="' + o.dim + '" data-val="' + esc(o.val) + '"' : '') + '>' +
      '<div class="k-top"><span class="k-ico" style="background:' + o.color + '1a;color:' + o.color + '">' + o.icon + '</span><span class="k-label">' + o.label + '</span></div>' +
      '<div class="k-val" data-n="' + (o.num == null ? '' : o.num) + '">' + o.value + '</div>' +
      '<div class="k-sub">' + (o.sub || '') + '</div>' + (o.viz || '') + '</div>';
  }
  var IC = {
    doc: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M7 3h7l4 4v14H7z"/><path d="M14 3v4h4M9 12h6M9 16h6"/></svg>',
    run: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>',
    win: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8 21h8M12 17v4M7 4h10v5a5 5 0 0 1-10 0z"/><path d="M7 6H4v2a3 3 0 0 0 3 3M17 6h3v2a3 3 0 0 1-3 3"/></svg>',
    lose: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="m9 9 6 6M15 9l-6 6"/></svg>',
    rate: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19V5M4 19h16M8 15l3-4 3 2 4-6"/></svg>',
    money: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="6" width="18" height="12" rx="2"/><circle cx="12" cy="12" r="2.5"/></svg>',
    cal: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="5" width="16" height="15" rx="2"/><path d="M4 10h16M9 3v4M15 3v4"/></svg>',
    box: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 8l9-5 9 5v8l-9 5-9-5z"/><path d="M3 8l9 5 9-5M12 13v8"/></svg>',
    arch: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="5" rx="1"/><path d="M5 9v10h14V9M10 13h4"/></svg>',
    id: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="9" cy="11" r="2"/><path d="M6 16c.5-1.5 1.7-2 3-2s2.5.5 3 2M14 10h4M14 14h4"/></svg>'
  };
  function renderKpis() {
    var k = data.kpi, vals = data.trend.series.length ? data.trend.keys.map(function (_, i) {
      return data.trend.series.reduce(function (a, s) { return a + s.values[i]; }, 0); }) : [];
    var rate = k.win_rate;
    $('#kpis').innerHTML =
      kpiCard({ label: 'کل پرونده‌ها', value: fmt(k.total), num: k.total, color: '#2563eb', icon: IC.doc,
                sub: 'مناقصه ' + fmt(k.tender) + ' · استعلام ' + fmt(k.inquiry) + ' · مزایده ' + fmt(k.auction), viz: spark(vals, '#2563eb') }) +
      kpiCard({ label: 'در جریان', value: fmt(k.open), num: k.open, color: '#0ea5e9', icon: IC.run,
                sub: 'بدون نتیجه و بایگانی‌نشده', dim: 'result', val: 'نامشخص' }) +
      kpiCard({ label: 'برنده', value: fmt(k.won), num: k.won, color: '#16a34a', icon: IC.win,
                sub: k.won_value ? 'ارزش ' + short(k.won_value) : '', dim: 'result', val: 'برنده' }) +
      kpiCard({ label: 'بازنده', value: fmt(k.lost), num: k.lost, color: '#dc2626', icon: IC.lose,
                sub: pct(k.lost, k.won + k.lost) ? pct(k.lost, k.won + k.lost) + '٪ از نتیجه‌دارها' : '', dim: 'result', val: 'بازنده' }) +
      kpiCard({ label: 'نرخ برد', value: rate == null ? '—' : rate + '٪', color: '#8b5cf6', icon: IC.rate,
                sub: 'برنده ÷ (برنده + بازنده)', viz: gauge(rate || 0), cls: 'has-gauge' }) +
      kpiCard({ label: 'ارزش کل پیشنهادها', value: short(k.value), color: '#14b8a6', icon: IC.money,
                sub: 'جمع تعداد × قیمت محصولات' }) +
      kpiCard({ label: 'مهلت تا ۷ روز آینده', value: fmt(k.due7), num: k.due7, color: k.due7 ? '#f59e0b' : '#16a34a', icon: IC.cal,
                sub: k.overdue ? '<b class="bad">' + fmt(k.overdue) + ' مهلت گذشته</b>' : 'مهلت گذشته ندارد', cls: k.due7 ? 'warn' : '' }) +
      kpiCard({ label: 'تعداد کل محصولات', value: fmt(k.qty), num: k.qty, color: '#f97316', icon: IC.box, sub: 'جمع تعداد ردیف‌های محصول' }) +
      kpiCard({ label: 'بایگانی‌شده', value: fmt(k.archived), num: k.archived, color: '#64748b', icon: IC.arch, sub: '' }) +
      kpiCard({ label: 'بدون شناسنامه', value: fmt(k.no_profile), num: k.no_profile, color: k.no_profile ? '#ec4899' : '#16a34a', icon: IC.id,
                sub: k.no_profile ? 'اطلاعات شناسنامه ثبت نشده' : 'همه شناسنامه دارند' });
    countUp();
  }
  function countUp() {
    document.querySelectorAll('.k-val[data-n]').forEach(function (el) {
      var n = el.getAttribute('data-n'); if (n === '') return; n = +n;
      if (n < 2 || n > 1e6) return;
      var t0 = null, dur = 600;
      function step(ts) { if (!t0) t0 = ts; var p = Math.min(1, (ts - t0) / dur); el.textContent = fmt(Math.round(n * (1 - Math.pow(1 - p, 3)))); if (p < 1) requestAnimationFrame(step); }
      requestAnimationFrame(step);
    });
  }

  // ---------- نمودار ستونیِ انباشته (روند)
  function renderTrend() {
    var t = data.trend, box = $('#c-trend .dbody');
    if (!t.keys.length) { box.innerHTML = empty('هنوز پروندهٔ دارای تاریخ دریافت نیست'); return; }
    var W = 760, H = 250, L = 34, R = 10, T = 16, B = 34, n = t.keys.length;
    var totals = t.keys.map(function (_, i) { return t.series.reduce(function (a, s) { return a + s.values[i]; }, 0); });
    var mx = Math.max.apply(null, totals) || 1, step = Math.max(1, Math.ceil(mx / 4)), top = step * Math.ceil(mx / step);
    var cw = (W - L - R) / n, bw = Math.min(46, cw * 0.62), colors = ['#2563eb', '#14b8a6', '#f59e0b', '#8b5cf6', '#ec4899', '#64748b', '#f97316'];
    var s = '<svg viewBox="0 0 ' + W + ' ' + H + '" class="chart" role="img" aria-label="روند ماهانه">';
    for (var g = 0; g <= top; g += step) {
      var y = T + (H - T - B) * (1 - g / top);
      s += '<line x1="' + L + '" x2="' + (W - R) + '" y1="' + y + '" y2="' + y + '" class="grid"/><text x="' + (L - 6) + '" y="' + (y + 4) + '" class="ax" text-anchor="end">' + g + '</text>';
    }
    t.keys.forEach(function (k, i) {
      var x = L + i * cw + (cw - bw) / 2, acc = 0, cls = sel('ym', k);
      var tipHtml = '<b>' + esc(t.labels[i]) + '</b><br>' + t.series.map(function (sr, j) { return '<span style="color:' + colors[j] + '">●</span> ' + esc(sr.name) + ': ' + sr.values[i]; }).join('<br>') + '<br>جمع: ' + totals[i];
      s += '<g class="bar-g' + cls + '" data-dim="ym" data-val="' + k + '" data-tip="' + esc(tipHtml) + '"><rect x="' + (L + i * cw) + '" y="' + T + '" width="' + cw + '" height="' + (H - T - B) + '" fill="transparent"/>';
      t.series.forEach(function (sr, j) {
        var h = (H - T - B) * sr.values[i] / top, yy = T + (H - T - B) - acc - h; acc += h;
        if (sr.values[i]) s += '<rect x="' + x + '" y="' + yy + '" width="' + bw + '" height="' + h + '" rx="' + (j === t.series.length - 1 ? 5 : 0) + '" fill="' + colors[j] + '" class="bar-r"/>';
      });
      if (totals[i]) s += '<text x="' + (x + bw / 2) + '" y="' + (T + (H - T - B) - acc - 6) + '" class="val" text-anchor="middle">' + totals[i] + '</text>';
      s += '<text x="' + (x + bw / 2) + '" y="' + (H - 12) + '" class="ax" text-anchor="middle">' + esc(t.labels[i]) + '</text></g>';
    });
    s += '</svg><div class="lg">' + t.series.map(function (sr, j) { return '<span><i style="background:' + colors[j] + '"></i>' + esc(sr.name) + '</span>'; }).join('') + '</div>';
    if (data.no_date) s += '<div class="foot-note">' + fmt(data.no_date) + ' پرونده تاریخ دریافت ندارد و در این نمودار نیست.</div>';
    box.innerHTML = s;
  }

  // ---------- دونات
  function donut(rows, dim, colorOf, centerTop, centerSub) {
    var tot = rows.reduce(function (a, r) { return a + r.value; }, 0);
    if (!tot) return empty();
    var R = 62, r = 40, cx = 80, cy = 80, a0 = -Math.PI / 2, s = '<div class="donut-wrap"><svg viewBox="0 0 160 160" class="donut">';
    if (rows.length === 1) {
      s += '<circle cx="80" cy="80" r="' + ((R + r) / 2) + '" fill="none" stroke="' + colorOf(rows[0], 0) + '" stroke-width="' + (R - r) + '"/>';
    } else rows.forEach(function (row, i) {
      var a1 = a0 + 2 * Math.PI * row.value / tot, large = a1 - a0 > Math.PI ? 1 : 0, gap = 0.02;
      var p = function (rad, a) { return (cx + rad * Math.cos(a)).toFixed(2) + ' ' + (cy + rad * Math.sin(a)).toFixed(2); };
      var d = 'M' + p(R, a0 + gap) + ' A' + R + ' ' + R + ' 0 ' + large + ' 1 ' + p(R, a1 - gap) + ' L' + p(r, a1 - gap) + ' A' + r + ' ' + r + ' 0 ' + large + ' 0 ' + p(r, a0 + gap) + 'Z';
      s += '<path d="' + d + '" fill="' + colorOf(row, i) + '" class="slice' + (dim ? sel(dim, row.label) : '') + '" ' + (dim ? 'data-dim="' + dim + '" data-val="' + esc(row.label) + '"' : '') +
        ' data-tip="' + esc('<b>' + row.label + '</b><br>' + fmt(row.value) + ' (' + pct(row.value, tot) + '٪)') + '"/>';
      a0 = a1;
    });
    s += '<text x="80" y="78" text-anchor="middle" class="d-big">' + centerTop + '</text><text x="80" y="95" text-anchor="middle" class="d-sm">' + centerSub + '</text></svg><ul class="dlegend">';
    rows.forEach(function (row, i) {
      s += '<li class="' + (dim ? sel(dim, row.label).trim() : '') + '" ' + (dim ? 'data-dim="' + dim + '" data-val="' + esc(row.label) + '"' : '') + '><i style="background:' + colorOf(row, i) + '"></i><span>' + esc(row.label) +
        '</span><b>' + fmt(row.value) + '</b><small>' + pct(row.value, tot) + '٪</small></li>';
    });
    return s + '</ul></div>';
  }
  function renderResult() {
    var k = data.kpi;
    $('#c-result .dbody').innerHTML = donut(data.results, 'result', function (r) { return RES_COLOR[r.label] || '#8b5cf6'; },
      k.win_rate == null ? '—' : k.win_rate + '٪', 'نرخ برد');
  }
  function renderStatus() {
    $('#c-status .dbody').innerHTML = donut(data.status, 'status', function (r, i) { return r.label === 'نامشخص' ? '#cbd5e1' : PAL[i % PAL.length]; }, fmt(data.kpi.total), 'پرونده');
  }
  function renderSource() {
    $('#c-source .dbody').innerHTML = donut(data.source, 'source', function (r, i) { return r.label === 'نامشخص' ? '#cbd5e1' : PAL[(i + 3) % PAL.length]; }, fmt(data.kpi.total), 'پرونده');
  }

  // ---------- میله‌های افقی
  function shortLabel(t) { return String(t).replace(/^شرکت آب و فاضلاب /, '').replace(/^آب و فاضلاب /, ''); }
  function hbars(rows, opt) {
    if (!rows.length) return empty();
    var mx = Math.max.apply(null, rows.map(function (r) { return r.value; })) || 1;
    return '<ul class="hbars">' + rows.map(function (r, i) {
      var w = Math.max(2, 100 * r.value / mx), color = (opt.color && opt.color(r, i)) || PAL[0];
      var inner = '<span class="fill" style="width:' + w + '%;background:' + color + '"></span>';
      if (opt.stack) {                                 // برنده/بازنده/بقیه داخل میله
        var other = r.value - r.won - r.lost, W = w;
        inner = '<span class="fill stack" style="width:' + w + '%">' +
          (r.won ? '<i style="flex:' + r.won + ';background:#16a34a"></i>' : '') + (r.lost ? '<i style="flex:' + r.lost + ';background:#dc2626"></i>' : '') +
          (other > 0 ? '<i style="flex:' + other + ';background:#93c5fd"></i>' : '') + '</span>';
      }
      var tipH = '<b>' + r.label + '</b><br>' + (opt.unit || 'تعداد') + ': ' + fmt(r.value) + (r.won != null && opt.stack ? '<br>برنده: ' + r.won + ' · بازنده: ' + r.lost : '') + (r.amount ? '<br>ارزش: ' + short(r.amount) : '') + (r.rate != null && r.rate !== undefined && opt.rate ? '<br>نرخ برد: ' + r.rate + '٪' : '');
      return '<li class="' + (opt.dim ? sel(opt.dim, r.label).trim() : '') + '" ' + (opt.dim ? 'data-dim="' + opt.dim + '" data-val="' + esc(r.label) + '"' : '') + ' data-tip="' + esc(tipH) + '">' +
        '<span class="hl" title="' + esc(r.label) + '">' + esc(opt.short ? shortLabel(r.label) : r.label) + '</span><span class="track">' + inner + '</span><b class="hv">' + fmt(r.value) +
        (opt.rate && r.rate != null ? ' <small class="rate ' + (r.rate >= 50 ? 'good' : 'low') + '">' + r.rate + '٪</small>' : '') + '</b></li>';
    }).join('') + '</ul>' + (opt.legend || '');
  }
  function renderOrgs() {
    $('#c-orgs .dbody').innerHTML = hbars(data.orgs, { dim: 'org', stack: true, short: true,
      legend: '<div class="lg"><span><i style="background:#16a34a"></i>برنده</span><span><i style="background:#dc2626"></i>بازنده</span><span><i style="background:#93c5fd"></i>در جریان / سایر</span></div>' });
  }
  function renderProducts() {
    $('#c-products .dbody').innerHTML = hbars(data.products, { dim: 'product', unit: 'تعداد', color: function (r, i) { return PAL[i % PAL.length]; } });
  }
  function renderSizes() { $('#c-sizes .dbody').innerHTML = hbars(data.sizes, { unit: 'تعداد', color: function () { return '#0ea5e9'; } }); }
  function renderReasons() { $('#c-reasons .dbody').innerHTML = hbars(data.reasons, { unit: 'پرونده', color: function () { return '#f59e0b'; } }); }
  function renderTender() {
    $('#c-tender .dbody').innerHTML = hbars(data.tender, { dim: 'tender', stack: true, rate: true, unit: 'پرونده' });
  }

  // ---------- جدول‌ها
  function chip(days) {
    var cls = days < 0 ? 'late' : days <= 3 ? 'hot' : days <= 7 ? 'warm' : 'ok';
    var txt = days < 0 ? Math.abs(days) + ' روز گذشته' : days === 0 ? 'امروز' : days + ' روز مانده';
    return '<span class="dchip ' + cls + '">' + txt + '</span>';
  }
  function renderDeadlines() {
    var rows = data.deadlines;
    $('#c-deadlines .dbody').innerHTML = !rows.length ? empty('مهلت بازِ پیش‌رویی ثبت نشده 🎉') :
      '<table class="dtable"><thead><tr><th>پرونده</th><th>سازمان</th><th>وضعیت</th><th>مهلت ارسال</th><th>زمان باقی‌مانده</th></tr></thead><tbody>' +
      rows.map(function (r) {
        return '<tr data-case="' + r.id + '" class="clk"><td><b>' + esc(r.type) + ' ' + r.serial + '</b></td><td class="org" title="' + esc(r.org) + '">' + esc(r.org) +
          '</td><td>' + (esc(r.status) || '—') + '</td><td dir="ltr" class="ltr">' + esc(r.deadline) + '</td><td>' + chip(r.days) + '</td></tr>';
      }).join('') + '</tbody></table>';
  }
  function renderCompetitors() {
    var rows = data.competitors;
    if (!rows.length) { $('#c-competitors .dbody').innerHTML = empty('رقیبی ثبت نشده (فقط وقتی نتیجه «بازنده» است ثبت می‌شود)'); return; }
    var mx = Math.max.apply(null, rows.map(function (r) { return r.count; })) || 1;
    $('#c-competitors .dbody').innerHTML = '<table class="dtable comp"><thead><tr><th>رقیب</th><th>حضور</th><th>برد</th><th>میانگین قیمت</th></tr></thead><tbody>' +
      rows.map(function (r) {
        return '<tr data-tip="' + esc('<b>' + r.name + '</b><br>حضور: ' + r.count + ' · برد: ' + r.won + (r.min ? '<br>کمترین قیمت: ' + fmt(r.min) : '')) + '"><td class="org" title="' + esc(r.name) + '">' + esc(r.name) +
          '</td><td><span class="mini"><i style="width:' + (100 * r.count / mx) + '%"></i></span> ' + r.count + '</td><td>' + (r.won ? '<b class="bad">' + r.won + '</b>' : '0') + '</td><td>' + (r.avg ? short(r.avg) : '—') + '</td></tr>';
      }).join('') + '</tbody></table>';
  }
  function renderRecent() {
    var rows = data.recent;
    $('#c-recent .dbody').innerHTML = !rows.length ? empty() :
      '<table class="dtable"><thead><tr><th>پرونده</th><th>تاریخ دریافت</th><th>سازمان</th><th>وضعیت</th><th>نتیجه</th></tr></thead><tbody>' +
      rows.map(function (r) {
        return '<tr data-case="' + r.id + '" class="clk"><td><b>' + esc(r.type) + ' ' + r.serial + '</b></td><td dir="ltr" class="ltr">' + esc(r.date || '—') + '</td><td class="org" title="' + esc(r.org) + '">' + esc(r.org) +
          '</td><td>' + (esc(r.status) || '—') + '</td><td><span class="rchip" style="--c:' + (RES_COLOR[r.result] || '#8b5cf6') + '">' + esc(r.result) + '</span></td></tr>';
      }).join('') + '</tbody></table>';
  }

  // ---------- نوار فیلتر
  function renderFilters() {
    var yearSel = $('#f-year'), monthSel = $('#f-month');
    if (yearSel.options.length - 1 !== data.years.length) {
      yearSel.innerHTML = '<option value="">همهٔ سال‌ها</option>' + data.years.map(function (y) { return '<option>' + y + '</option>'; }).join('');
    }
    if (monthSel.options.length === 1) {
      monthSel.innerHTML = '<option value="">همهٔ ماه‌ها</option>' + data.months.map(function (m, i) { return '<option value="' + (i + 1) + '">' + m + '</option>'; }).join('');
    }
    yearSel.value = filters.year || ''; monthSel.value = filters.month || '';
    document.querySelectorAll('#f-type button').forEach(function (b) { b.classList.toggle('on', (filters.type || '') === b.dataset.v); });
    var chips = [], cross = ['org', 'status', 'result', 'product', 'source', 'tender', 'ym'];
    cross.forEach(function (k) {
      if (filters[k]) chips.push('<button type="button" class="fchip" data-k="' + k + '">' + DIM_LABEL[k] + ': <b>' + esc(k === 'ym' ? filters[k] : filters[k]) + '</b> ✕</button>');
    });
    $('#f-chips').innerHTML = chips.join('');
    $('#f-reset').hidden = !Object.keys(filters).length;
  }
  $('#f-type').addEventListener('click', function (e) { var b = e.target.closest('button'); if (!b) return; if (b.dataset.v) filters.type = b.dataset.v; else delete filters.type; load(); });
  $('#f-year').addEventListener('change', function () { if (this.value) filters.year = this.value; else delete filters.year; delete filters.ym; load(); });
  $('#f-month').addEventListener('change', function () { if (this.value) filters.month = this.value; else delete filters.month; delete filters.ym; load(); });
  $('#f-chips').addEventListener('click', function (e) { var b = e.target.closest('.fchip'); if (b) { delete filters[b.dataset.k]; load(); } });
  $('#f-reset').addEventListener('click', function () { filters = {}; load(); });
  $('#d-refresh').addEventListener('click', function () { load(); });

  function renderAll() {
    renderFilters(); renderKpis(); renderTrend(); renderResult(); renderOrgs(); renderStatus(); renderProducts();
    renderDeadlines(); renderCompetitors(); renderTender(); renderSource(); renderReasons(); renderSizes(); renderRecent();
    var n = new Date(), p = function (x) { return ('0' + x).slice(-2); };
    $('#d-updated').textContent = 'امروز ' + data.today + ' · بروزرسانی ' + p(n.getHours()) + ':' + p(n.getMinutes()) + ':' + p(n.getSeconds());
    root.classList.toggle('is-empty', data.empty);
  }
  function load() {
    var qs = Object.keys(filters).map(function (k) { return encodeURIComponent(k) + '=' + encodeURIComponent(filters[k]); }).join('&');
    root.classList.add('loading');
    fetch(URL + (qs ? '?' + qs : ''), { credentials: 'same-origin', cache: 'no-store' })
      .then(function (r) { if (!r.ok) throw new Error(r.status); return r.json(); })
      .then(function (d) { data = d; filters = d.filters; renderAll(); })
      .catch(function () { $('#d-updated').textContent = 'دریافت اطلاعات ممکن نشد؛ دوباره تلاش می‌شود…'; })
      .then(function () { root.classList.remove('loading'); });
  }
  load();
  setInterval(function () { if (!document.hidden) load(); }, 60000);
})();
