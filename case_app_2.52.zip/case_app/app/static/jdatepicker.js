/* تقویم شمسی ساده بدون وابستگی خارجی.
 * هر <input class="jdate"> با کلیک، یک تقویم باز می‌کند و تاریخ را به شکل 1405/07/16 در فیلد می‌نویسد.
 * قانون کبیسه: سال‌های با باقی‌مانده 1، 5، 9، 13، 17، 22، 26، 30 بر 33 (همان قاعده سمت سرور).
 */
(function () {
  'use strict';

  var MONTHS = ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
                'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'];
  var WEEK = ['ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج'];            // هفته از شنبه شروع می‌شود
  var MIN_Y = 1300, MAX_Y = 1500;
  var ANCHOR_Y = 1405;                                         // 1405/01/01 = 2026-03-21
  var ANCHOR_UTC = Date.UTC(2026, 2, 21);
  var DAY_MS = 86400000;

  // ------------------------------------------------------------ محاسبات تاریخ
  function isLeap(y) { return [1, 5, 9, 13, 17, 22, 26, 30].indexOf(y % 33) !== -1; }
  function yearLen(y) { return isLeap(y) ? 366 : 365; }
  function monthLen(y, m) { return m <= 6 ? 31 : (m <= 11 ? 30 : (isLeap(y) ? 30 : 29)); }

  function toUTC(y, m, d) {
    var days = 0, i;
    if (y >= ANCHOR_Y) { for (i = ANCHOR_Y; i < y; i++) days += yearLen(i); }
    else { for (i = y; i < ANCHOR_Y; i++) days -= yearLen(i); }
    for (i = 1; i < m; i++) days += monthLen(y, i);
    return ANCHOR_UTC + (days + d - 1) * DAY_MS;
  }

  function fromUTC(ms) {
    var diff = Math.round((ms - ANCHOR_UTC) / DAY_MS), y = ANCHOR_Y, m = 1;
    while (diff < 0) { y--; diff += yearLen(y); }
    while (diff >= yearLen(y)) { diff -= yearLen(y); y++; }
    while (diff >= monthLen(y, m)) { diff -= monthLen(y, m); m++; }
    return { y: y, m: m, d: diff + 1 };
  }

  function weekdayIndex(y, m, d) {                              // شنبه = 0 ... جمعه = 6
    return (new Date(toUTC(y, m, d)).getUTCDay() + 1) % 7;
  }

  function today() {
    var n = new Date();
    return fromUTC(Date.UTC(n.getFullYear(), n.getMonth(), n.getDate()));
  }

  function pad2(n) { return (n < 10 ? '0' : '') + n; }
  function format(y, m, d) { return y + '/' + pad2(m) + '/' + pad2(d); }          // اسکریپت‌های دیگر/تست: ارقام 0-9

  function toAscii(s) {
    return String(s || '').replace(/[۰-۹]/g, function (c) { return c.charCodeAt(0) - 1776; })
                          .replace(/[٠-٩]/g, function (c) { return c.charCodeAt(0) - 1632; });
  }
  function toFa(n) { return String(n).replace(/\d/g, function (c) { return '۰۱۲۳۴۵۶۷۸۹'.charAt(+c); }); }

  function parse(text) {
    var m = /^(\d{4})\/(\d{1,2})\/(\d{1,2})$/.exec(toAscii(text).trim());
    if (!m) return null;
    var y = +m[1], mo = +m[2], d = +m[3];
    if (y < MIN_Y || y > MAX_Y || mo < 1 || mo > 12 || d < 1 || d > monthLen(y, mo)) return null;
    return { y: y, m: mo, d: d };
  }

  var api = { isLeap: isLeap, monthLen: monthLen, toUTC: toUTC, fromUTC: fromUTC,
              weekdayIndex: weekdayIndex, format: format, parse: parse };
  if (typeof module !== 'undefined' && module.exports) { module.exports = api; }
  if (typeof document === 'undefined') { return; }

  // ------------------------------------------------------------ رابط کاربری
  var pop = null, current = null, view = { y: 0, m: 1 }, selected = null, lastTouch = 0;

  function stamp() { lastTouch = Date.now(); }

  // متنی که کاربر تایپ می‌کند را مرتب می‌کند: ارقام فارسی، جداکنندهٔ «/»، حداکثر 4/2/2 رقم
  function maskValue(v, grow) {
    var s = toAscii(v).replace(/[-.\/\\،]/g, '/').replace(/[^0-9\/]/g, '');
    var parts = [''], limits = [4, 2, 2], i, ch, k;
    for (i = 0; i < s.length; i++) {
      ch = s.charAt(i);
      if (ch === '/') { if (parts.length < 3 && parts[parts.length - 1] !== '') parts.push(''); continue; }
      k = parts.length - 1;
      if (parts[k].length >= limits[k]) { if (k < 2) parts.push(ch); continue; }
      parts[k] += ch;
    }
    k = parts.length - 1;
    if (grow && k < 2 && parts[k].length >= limits[k]) parts.push('');   // بعد از سال/ماهِ کامل، «/» خودکار
    return toFa(parts.join('/'));
  }

  // «1405/7/5» یا «۱۴۰۵/۰۷/۰۵» -> تاریخ معتبر یا null
  function parseLoose(text) {
    var m = /^(\d{4})\/(\d{1,2})\/(\d{1,2})$/.exec(toAscii(text).trim());
    if (!m) return null;
    return parse(m[1] + '/' + m[2] + '/' + m[3]);
  }

  // علت اشتباه بودن تاریخ را به فارسی می‌گوید (null = درست است)
  function explain(text, final) {
    var s = toAscii(text).trim(), parts = s.split('/'), y, m, d;
    if (!s) return null;
    y = parts[0]; m = parts[1]; d = parts[2];
    if (final && !/^\d{4}\/\d{1,2}\/\d{1,2}$/.test(s)) return 'تاریخ ناقص یا اشتباه است؛ آن را مثل ' + toFa('1405/07/19') + ' بنویسید.';
    if (y.length === 4 && (+y < MIN_Y || +y > MAX_Y)) return 'سال باید بین ' + toFa(MIN_Y) + ' تا ' + toFa(MAX_Y) + ' باشد.';
    if (m && (m.length === 2 || final) && (+m < 1 || +m > 12)) return 'ماه باید عددی بین ' + toFa(1) + ' تا ' + toFa(12) + ' باشد.';
    if (d && y.length === 4 && m && +m >= 1 && +m <= 12 && (d.length === 2 || final)) {
      var len = monthLen(+y, +m);
      if (+d < 1) return 'روز باید ' + toFa(1) + ' یا بیشتر باشد.';
      if (+d > len) return 'ماه «' + MONTHS[+m - 1] + '» در سال ' + toFa(y) + ' فقط ' + toFa(len) + ' روز دارد.';
    }
    return null;
  }

  function flag(el, msg) {
    if (msg) { el.classList.add('jdate-bad'); el.setAttribute('aria-invalid', 'true'); }
    else { el.classList.remove('jdate-bad'); el.removeAttribute('aria-invalid'); }
    if (window.faFieldMsg) window.faFieldMsg(el, msg || '');
  }

  function build() {
    pop = document.createElement('div');
    pop.className = 'jdp';
    pop.dir = 'rtl';
    pop.setAttribute('role', 'dialog');
    pop.setAttribute('aria-label', 'انتخاب تاریخ');
    pop.hidden = true;
    document.body.appendChild(pop);

    // فوکوس فیلد نپرد؛ اما روی لیست ماه/سال نباید جلوی باز شدن گرفته شود
    pop.addEventListener('mousedown', function (e) {
      stamp();
      if (!/^(SELECT|OPTION)$/.test(e.target.tagName)) e.preventDefault();
    });
    pop.addEventListener('touchstart', stamp, { passive: true });
    pop.addEventListener('click', onPopClick);
    pop.addEventListener('change', function (e) {
      // لیست ماه/سال را دوباره نمی‌سازیم (ساختن دوباره‌اش باعث بسته‌شدن تقویم در بعضی مرورگرها می‌شد)؛ فقط روزها
      stamp();
      var t = e.target;
      if (t.getAttribute('data-sel') === 'month') view.m = +t.value;
      if (t.getAttribute('data-sel') === 'year') view.y = +t.value;
      renderDays();
    });
  }

  function renderDays() {
    var t = today(), html = '', i, d;
    var lead = weekdayIndex(view.y, view.m, 1), len = monthLen(view.y, view.m);
    for (i = 0; i < 7; i++) html += '<span class="jdp-wd' + (i === 6 ? ' jdp-fri' : '') + '">' + WEEK[i] + '</span>';
    for (i = 0; i < lead; i++) html += '<span></span>';
    for (d = 1; d <= len; d++) {
      var cls = 'jdp-day';
      if ((lead + d - 1) % 7 === 6) cls += ' jdp-fri';
      if (t.y === view.y && t.m === view.m && t.d === d) cls += ' jdp-today';
      if (selected && selected.y === view.y && selected.m === view.m && selected.d === d) cls += ' jdp-sel';
      html += '<button type="button" class="' + cls + '" data-d="' + d + '">' + toFa(d) + '</button>';
    }
    pop.querySelector('.jdp-grid').innerHTML = html;
    var ms = pop.querySelector('[data-sel="month"]'), ys = pop.querySelector('[data-sel="year"]');
    if (ms) ms.value = view.m;
    if (ys) {
      if (!ys.querySelector('option[value="' + view.y + '"]')) { render(); return; }
      ys.value = view.y;
    }
  }

  function render() {
    var i, html = '';
    var y0 = Math.max(MIN_Y, view.y - 12), y1 = Math.min(MAX_Y, view.y + 12);
    html += '<div class="jdp-head">';
    html += '<button type="button" class="jdp-nav" data-act="prev" aria-label="ماه قبل">›</button>';
    html += '<select data-sel="month" data-native aria-label="ماه">';
    for (i = 1; i <= 12; i++) html += '<option value="' + i + '"' + (i === view.m ? ' selected' : '') + '>' + MONTHS[i - 1] + '</option>';
    html += '</select><select data-sel="year" data-native aria-label="سال">';
    for (i = y0; i <= y1; i++) html += '<option value="' + i + '"' + (i === view.y ? ' selected' : '') + '>' + toFa(i) + '</option>';
    html += '</select>';
    html += '<button type="button" class="jdp-nav" data-act="next" aria-label="ماه بعد">‹</button></div>';
    html += '<div class="jdp-grid"></div>';
    html += '<div class="jdp-foot"><button type="button" data-act="today">امروز</button>' +
            '<button type="button" data-act="clear">پاک کردن</button></div>';
    pop.innerHTML = html;
    renderDays();
  }

  function place() {
    var r = current.getBoundingClientRect(), w = pop.offsetWidth, h = pop.offsetHeight;
    var left = r.right + window.pageXOffset - w;
    var maxLeft = window.pageXOffset + document.documentElement.clientWidth - w - 8;
    left = Math.max(window.pageXOffset + 8, Math.min(left, maxLeft));
    var top = r.bottom + window.pageYOffset + 4;
    if (r.bottom + h + 8 > window.innerHeight && r.top > h + 8) top = r.top + window.pageYOffset - h - 4;
    pop.style.left = left + 'px';
    pop.style.top = top + 'px';
  }

  function open(input) {
    if (!pop) build();
    current = input;
    selected = parseLoose(input.value);
    var base = selected || today();
    view = { y: base.y, m: base.m };
    render();
    pop.hidden = false;
    place();
  }

  function close() { if (pop) pop.hidden = true; current = null; }

  function setValue(text) {
    current.value = text;
    flag(current, null);
    current.dispatchEvent(new Event('input', { bubbles: true }));
    current.dispatchEvent(new Event('change', { bubbles: true }));
  }

  function onPopClick(e) {
    stamp();
    var btn = e.target.closest('button');
    e.jdpHandled = true;   // بعد از render دکمه از صفحه جدا می‌شود؛ نباید به‌اشتباه «کلیک بیرون» حساب شود
    if (!btn || !current) return;
    var act = btn.getAttribute('data-act'), day = btn.getAttribute('data-d');
    if (day) { setValue(toFa(format(view.y, view.m, +day))); close(); return; }
    if (act === 'prev') { view.m--; if (view.m < 1) { view.m = 12; view.y--; } }
    else if (act === 'next') { view.m++; if (view.m > 12) { view.m = 1; view.y++; } }
    else if (act === 'today') { var t = today(); setValue(toFa(format(t.y, t.m, t.d))); close(); return; }
    else if (act === 'clear') { setValue(''); close(); return; }
    view.y = Math.max(MIN_Y, Math.min(MAX_Y, view.y));
    render();
  }

  function isDate(el) { return el && el.classList && el.classList.contains('jdate'); }

  function prepare(root) {
    var inputs = (root || document).querySelectorAll('input.jdate');
    for (var i = 0; i < inputs.length; i++) {
      inputs[i].readOnly = false;                 // هم از تقویم انتخاب می‌شود و هم می‌شود تایپ کرد
      inputs[i].setAttribute('autocomplete', 'off');
      inputs[i].setAttribute('inputmode', 'numeric');
      inputs[i].setAttribute('maxlength', '10');
      inputs[i].setAttribute('placeholder', '۱۴۰۵/۰۷/۱۹');
      inputs[i].setAttribute('title', 'تاریخ را تایپ کنید (مثل ۱۴۰۵/۰۷/۱۹) یا برای باز شدن تقویم کلیک کنید');
    }
  }

  // ---- تایپ دستی
  document.addEventListener('input', function (e) {
    var el = e.target;
    if (!isDate(el) || el.disabled) return;
    var grow = !(e.inputType && e.inputType.indexOf('delete') === 0);
    var v = maskValue(el.value, grow);
    if (v !== el.value) el.value = v;
    flag(el, explain(el.value, false));          // اشتباهِ واضح را همان لحظه می‌گوید
    var d = parseLoose(el.value);
    if (d && pop && !pop.hidden && current === el) { selected = d; view = { y: d.y, m: d.m }; render(); }
  }, true);

  document.addEventListener('focusout', function (e) {
    var el = e.target;
    if (isDate(el) && !el.disabled) {
      var raw = el.value.trim();
      if (raw) {
        var d = parseLoose(raw);
        if (d) {
          var good = toFa(format(d.y, d.m, d.d));
          if (good !== el.value) { el.value = good; el.dispatchEvent(new Event('change', { bubbles: true })); }
          flag(el, null);
        } else {
          flag(el, explain(raw, true) || 'تاریخ اشتباه است.');
        }
      } else { flag(el, null); }
    }
    // با Tab از فیلد بیرون رفتیم و فوکوس به خود تقویم نرفته: تقویم بسته شود
    setTimeout(function () {
      if (pop && !pop.hidden && !pop.contains(document.activeElement) && document.activeElement !== current) close();
    }, 0);
  });

  document.addEventListener('click', function (e) {
    var el = e.target;
    if (isDate(el) && !el.disabled) { open(el); return; }
    if (e.jdpHandled) return;
    if (Date.now() - lastTouch < 400) return;       // تازه داخل تقویم کار کرده‌ایم (مثلاً انتخاب ماه از لیست)
    if (pop && !pop.hidden && !pop.contains(el)) close();
  });
  document.addEventListener('keydown', function (e) {
    var el = e.target;
    if (e.key === 'Escape') { close(); return; }
    if (isDate(el) && !el.disabled) {
      if (e.key === 'ArrowDown' || e.key === 'F4') { e.preventDefault(); open(el); }
      else if (e.key === 'Enter' && pop && !pop.hidden && current === el) { e.preventDefault(); close(); }
    }
  });
  window.addEventListener('resize', function () { if (pop && !pop.hidden && current) place(); });

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { prepare(); });
  else prepare();
})();
