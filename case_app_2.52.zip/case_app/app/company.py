"""اطلاعات شرکتی که برنامه را استفاده می‌کند (در جدول settings با کلید company_*)."""
from . import config


def get(db) -> dict:
    out = {k: "" for k, _ in config.COMPANY_FIELDS}
    for r in db.execute("SELECT key, value FROM settings WHERE key LIKE 'company_%'"):
        k = r["key"][len("company_"):]
        if k in out:
            out[k] = r["value"]
    if not out["name"]:
        out["name"] = config.COMPANY_NAME
    return out


def save(db, form) -> list:
    old = get(db)
    changes = []
    for k, title in config.COMPANY_FIELDS:
        v = " ".join((form.get(k) or "").split())[:200]
        if k == "name" and not v:
            v = config.COMPANY_NAME
        if v != old[k]:
            changes.append([title, old[k], v])
        db.execute("INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value",
                   (f"company_{k}", v))
    return changes
