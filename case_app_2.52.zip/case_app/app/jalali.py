"""تاریخ شمسی (بدون نیاز به کتابخانه خارجی)."""
import re
from datetime import date

_DIGITS = str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789")


_FA = str.maketrans("0123456789٠١٢٣٤٥٦٧٨٩", "۰۱۲۳۴۵۶۷۸۹۰۱۲۳۴۵۶۷۸۹")


def to_fa_digits(text) -> str:
    """همهٔ ارقام (انگلیسی و عربی) را به ارقام فارسی ۰-۹ تبدیل می‌کند. None -> ''."""
    return "" if text is None else str(text).translate(_FA)


def fa_num(value) -> str:
    """عدد با جداکنندهٔ سه‌رقمی و ارقام فارسی: 1200000 -> ۱,۲۰۰,۰۰۰ . ورودی غیرعددی دست‌نخورده فارسی می‌شود."""
    if value is None or value == "":
        return ""
    s = to_ascii_digits(str(value))
    plain = s.replace(",", "").replace("،", "").replace("٬", "").replace(" ", "")
    if plain.isdigit():
        return to_fa_digits("{:,}".format(int(plain)))
    return to_fa_digits(s)


def to_ascii_digits(text: str) -> str:
    """ارقام فارسی و عربی را به 0-9 تبدیل می‌کند."""
    return (text or "").translate(_DIGITS)


def gregorian_to_jalali_year(g_year: int, g_month: int, g_day: int) -> int:
    g_days_in_month = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334]
    gy2 = g_year + 1 if g_month > 2 else g_year
    days = (
        355666
        + (365 * g_year)
        + ((gy2 + 3) // 4)
        - ((gy2 + 99) // 100)
        + ((gy2 + 399) // 400)
        + g_day
        + g_days_in_month[g_month - 1]
    )
    jy = -1595 + (33 * (days // 12053))
    days %= 12053
    jy += 4 * (days // 1461)
    days %= 1461
    if days > 365:
        jy += (days - 1) // 365
    return jy


def current_jalali_year(today: date | None = None) -> int:
    today = today or date.today()
    return gregorian_to_jalali_year(today.year, today.month, today.day)


def is_jalali_leap(jy: int) -> bool:
    return (jy % 33) in (1, 5, 9, 13, 17, 22, 26, 30)


def days_in_jalali_month(jy: int, jm: int) -> int:
    if jm <= 6:
        return 31
    if jm <= 11:
        return 30
    return 30 if is_jalali_leap(jy) else 29


def normalize_jdate(text: str) -> str | None:
    """'۱۴۰۵/۷/۱۶' -> '1405/07/16'. اگر تاریخ معتبر نباشد None برمی‌گرداند."""
    s = to_ascii_digits((text or "").strip()).replace("-", "/").replace(".", "/")
    m = re.fullmatch(r"(\d{4})/(\d{1,2})/(\d{1,2})", s)
    if not m:
        return None
    y, mo, d = (int(x) for x in m.groups())
    if not (1300 <= y <= 1500) or not (1 <= mo <= 12):
        return None
    if not (1 <= d <= days_in_jalali_month(y, mo)):
        return None
    return f"{y:04d}/{mo:02d}/{d:02d}"


def gregorian_to_jalali(g_year: int, g_month: int, g_day: int) -> tuple[int, int, int]:
    g_days_in_month = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334]
    gy2 = g_year + 1 if g_month > 2 else g_year
    days = (355666 + 365 * g_year + (gy2 + 3) // 4 - (gy2 + 99) // 100 + (gy2 + 399) // 400
            + g_day + g_days_in_month[g_month - 1])
    jy = -1595 + 33 * (days // 12053)
    days %= 12053
    jy += 4 * (days // 1461)
    days %= 1461
    if days > 365:
        jy += (days - 1) // 365
        days = (days - 1) % 365
    if days < 186:
        jm, jd = 1 + days // 31, 1 + days % 31
    else:
        jm, jd = 7 + (days - 186) // 30, 1 + (days - 186) % 30
    return jy, jm, jd


def today_jalali(today: date | None = None) -> str:
    """تاریخ امروز به شکل 1405/07/19"""
    today = today or date.today()
    return "%04d/%02d/%02d" % gregorian_to_jalali(today.year, today.month, today.day)


def jalali_to_gregorian(jy: int, jm: int, jd: int) -> tuple[int, int, int]:
    jy += 1595
    days = (-355668 + 365 * jy + (jy // 33) * 8 + ((jy % 33) + 3) // 4 + jd
            + ((jm - 1) * 31 if jm < 7 else (jm - 7) * 30 + 186))
    gy = 400 * (days // 146097)
    days %= 146097
    if days > 36524:
        days -= 1
        gy += 100 * (days // 36524)
        days %= 36524
        if days >= 365:
            days += 1
    gy += 4 * (days // 1461)
    days %= 1461
    if days > 365:
        gy += (days - 1) // 365
        days = (days - 1) % 365
    gd = days + 1
    leap = (gy % 4 == 0 and gy % 100 != 0) or gy % 400 == 0
    months = [0, 31, 29 if leap else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    gm = 0
    while gm < 13 and gd > months[gm]:
        gd -= months[gm]
        gm += 1
    return gy, gm, gd


def jdate_to_date(text: str) -> date | None:
    """'1405/07/19' -> date یا None"""
    n = normalize_jdate(text or "")
    if not n:
        return None
    y, m, d = (int(x) for x in n.split("/"))
    try:
        return date(*jalali_to_gregorian(y, m, d))
    except ValueError:
        return None
