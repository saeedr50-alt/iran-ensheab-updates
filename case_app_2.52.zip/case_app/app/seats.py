"""جای ویرایش همزمان: حداکثر N نفر (پیش‌فرض ۲) هم‌زمان می‌توانند ثبت/ویرایش کنند؛ بقیه فقط می‌بینند.

- جای ویرایش وقتی گرفته می‌شود که کاربر فرم ثبت/ویرایش را باز می‌کند (یا ذخیره می‌کند).
- صفحهٔ باز با ضربان (هر یک دقیقه) جا را نگه می‌دارد. با خروج از برنامه یا ۱۰ دقیقه بی‌فعالیتی آزاد می‌شود.
- مدیر می‌تواند جای هر کس را آزاد کند و حداکثر را تغییر دهد.
"""
import sqlite3
import time

from . import config


def get_max(db: sqlite3.Connection) -> int:
    row = db.execute("SELECT value FROM settings WHERE key = 'max_editors'").fetchone()
    try:
        n = int(row["value"]) if row else config.DEFAULT_MAX_EDITORS
    except ValueError:
        n = config.DEFAULT_MAX_EDITORS
    return max(1, min(config.MAX_EDITORS_LIMIT, n))


def set_max(db: sqlite3.Connection, n: int) -> None:
    if not 1 <= n <= config.MAX_EDITORS_LIMIT:
        raise ValueError(f"عدد باید بین ۱ و {config.MAX_EDITORS_LIMIT} باشد.")
    db.execute("INSERT INTO settings (key, value) VALUES ('max_editors', ?) "
               "ON CONFLICT(key) DO UPDATE SET value = excluded.value", (str(n),))


def _purge(db: sqlite3.Connection, now: float) -> None:
    db.execute("DELETE FROM edit_seats WHERE last_seen < ?", (now - config.SEAT_TIMEOUT_SECONDS,))


def holders(db: sqlite3.Connection) -> list[dict]:
    now = time.time()
    rows = db.execute(
        "SELECT s.user_id, s.last_seen, u.username, u.full_name, u.role FROM edit_seats s "
        "JOIN users u ON u.id = s.user_id WHERE s.last_seen >= ? ORDER BY s.taken_at, s.user_id",
        (now - config.SEAT_TIMEOUT_SECONDS,)).fetchall()
    return [dict(r, name=r["full_name"] or r["username"], idle=int(now - r["last_seen"])) for r in rows]


def has_seat(db: sqlite3.Connection, user_id: int) -> bool:
    return any(h["user_id"] == user_id for h in holders(db))


def acquire(db: sqlite3.Connection, user_id: int) -> bool:
    """جای ویرایش را برای این کاربر می‌گیرد/تمدید می‌کند. اگر ظرفیت پر باشد False."""
    now = time.time()
    db.execute("BEGIN IMMEDIATE")
    try:
        _purge(db, now)
        if db.execute("UPDATE edit_seats SET last_seen = ? WHERE user_id = ?", (now, user_id)).rowcount:
            ok = True
        else:
            used = db.execute("SELECT COUNT(*) FROM edit_seats").fetchone()[0]
            ok = used < get_max(db)
            if ok:
                db.execute("INSERT INTO edit_seats (user_id, last_seen) VALUES (?, ?)", (user_id, now))
        db.execute("COMMIT")
        return ok
    except BaseException:
        db.execute("ROLLBACK")
        raise


def release(db: sqlite3.Connection, user_id: int) -> None:
    db.execute("DELETE FROM edit_seats WHERE user_id = ?", (user_id,))


def full_message(db: sqlite3.Connection) -> str:
    names = "، ".join(h["name"] for h in holders(db))
    return (f"ظرفیت ویرایش همزمان پر است ({names} در حال ویرایش‌اند). "
            "فعلاً فقط می‌توانید ببینید؛ کمی بعد دوباره امتحان کنید.")
