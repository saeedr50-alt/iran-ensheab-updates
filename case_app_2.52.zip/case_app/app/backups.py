"""بکاپ از دیتابیس: ساخت بکاپ، کپی در پوشه‌های اضافه (مثلاً OneDrive / Dropbox)، بکاپ روزانهٔ خودکار."""
import os
import re
import shutil
import sqlite3
from datetime import date, datetime

NAME_RE = re.compile(r"^cases-\d{4}-\d{2}-\d{2}_\d{2}-\d{2}-\d{2}(-\d+)?\.sqlite$")


def make_backup(source: str, folder: str) -> str:
    """یک نسخهٔ سازگار از دیتابیس می‌سازد (حتی وقتی برنامه در حال کار است)."""
    if not os.path.exists(source):
        raise FileNotFoundError(f"دیتابیس پیدا نشد: {source}")
    os.makedirs(folder, exist_ok=True)
    stamp = datetime.now().strftime("cases-%Y-%m-%d_%H-%M-%S")
    target, n = os.path.join(folder, stamp + ".sqlite"), 1
    while os.path.exists(target):               # دو بکاپ در یک ثانیه، یکدیگر را رونویسی نکنند
        target = os.path.join(folder, f"{stamp}-{n}.sqlite")
        n += 1
    src, dst = sqlite3.connect(source), sqlite3.connect(target)
    try:
        src.backup(dst)
        dst.execute("PRAGMA journal_mode = DELETE")     # فایل بکاپ یکپارچه باشد (بدون فایل‌های جانبی)
    finally:
        dst.close()
        src.close()
    return target


def list_backups(folder: str) -> list[dict]:
    if not os.path.isdir(folder):
        return []
    items = []
    for name in os.listdir(folder):
        if NAME_RE.match(name):
            st = os.stat(os.path.join(folder, name))
            items.append({"name": name, "mtime": st.st_mtime_ns, "size_kb": max(1, st.st_size // 1024),
                          "time": datetime.fromtimestamp(st.st_mtime).strftime("%Y-%m-%d %H:%M")})
    return sorted(items, key=lambda x: (x["mtime"], x["name"]), reverse=True)


# ---- تنظیمات بکاپ (فایل JSON کنار دیتابیس): پوشهٔ اصلی + پوشه‌های اضافه
CLOUD_SUBFOLDER = "IranEnsheab-Backups"


def detect_cloud_folders() -> list[tuple[str, str]]:
    """OneDrive / Dropbox / iCloud نصب‌شده روی همین کامپیوتر را پیدا می‌کند. خروجی: [(نام، مسیر)]"""
    home = os.path.expanduser("~")
    found: list[tuple[str, str]] = []
    patterns = [
        ("Dropbox", [os.path.join(home, "Dropbox")], "Dropbox"),
        ("OneDrive", [os.path.join(home, "OneDrive")], "OneDrive"),
        ("iCloud Drive", [os.path.join(home, "Library", "Mobile Documents", "com~apple~CloudDocs")], ""),
    ]
    for name, paths, _ in patterns:
        for pth in paths:
            if os.path.isdir(pth):
                found.append((name, pth))
    cs = os.path.join(home, "Library", "CloudStorage")          # مک: برنامه‌های جدید اینجا هستند
    if os.path.isdir(cs):
        for entry in sorted(os.listdir(cs)):
            full = os.path.join(cs, entry)
            if os.path.isdir(full) and entry.lower().startswith(("dropbox", "onedrive")):
                found.append(("Dropbox" if entry.lower().startswith("dropbox") else "OneDrive", full))
    for entry in sorted(os.listdir(home)) if os.path.isdir(home) else []:   # ویندوز: OneDrive - نام شرکت
        if entry.lower().startswith("onedrive") and os.path.isdir(os.path.join(home, entry)):
            item = ("OneDrive", os.path.join(home, entry))
            if item not in found:
                found.append(item)
    return found


def default_extras() -> list[str]:
    return [os.path.join(p, CLOUD_SUBFOLDER) for _, p in detect_cloud_folders()]


def read_settings(path: str, default_dir: str) -> dict:
    """{'dir': پوشهٔ اصلی، 'extras': [پوشه‌های اضافه]}. اگر هنوز تنظیمی ذخیره نشده، OneDrive/Dropbox
    پیدا‌شده روی کامپیوتر به‌صورت پیش‌فرض فعال‌اند."""
    import json
    if os.path.exists(path):
        try:
            with open(path, encoding="utf-8") as f:
                data = json.load(f)
            return {"dir": data.get("dir") or default_dir, "extras": list(data.get("extras", []))}
        except (OSError, ValueError):
            pass
    return {"dir": default_dir, "extras": default_extras()}


def write_settings(path: str, folder: str, extras: list[str]) -> None:
    import json
    with open(path, "w", encoding="utf-8") as f:
        json.dump({"dir": folder, "extras": extras}, f, ensure_ascii=False, indent=2)


def check_folder(raw: str) -> tuple[str | None, str]:
    """مسیر را بررسی می‌کند. خروجی: (مسیر کامل یا None، پیام خطا)."""
    p = os.path.abspath(os.path.expanduser(raw.strip().strip('"').strip("'")))
    if not os.path.isdir(p):
        if os.path.isdir(os.path.dirname(p)):           # پوشهٔ تازه در مسیری که وجود دارد: ساخته می‌شود
            try:
                os.makedirs(p)
            except OSError:
                return None, "ساخت پوشه ممکن نیست"
        else:
            return None, "این پوشه وجود ندارد"
    probe = os.path.join(p, ".write-test")
    try:
        with open(probe, "w") as f:
            f.write("ok")
        os.remove(probe)
    except OSError:
        return None, "نوشتن در این پوشه ممکن نیست"
    return p, ""


def copy_to_extras(backup_path: str, folders: list[str]) -> list[tuple[str, bool, str]]:
    results = []
    for raw in folders:
        p, err = check_folder(raw)
        if p is None:
            results.append((raw, False, err))
            continue
        try:
            shutil.copy2(backup_path, os.path.join(p, os.path.basename(backup_path)))
            results.append((raw, True, ""))
        except OSError as e:
            results.append((raw, False, str(e)))
    return results


def run_backup(source: str, settings_file: str, default_dir: str):
    """بکاپ در پوشهٔ اصلی + کپی در پوشه‌های اضافه. خروجی: (مسیر، نتیجهٔ کپی‌ها)"""
    st = read_settings(settings_file, default_dir)
    folder = check_folder(st["dir"])[0] or default_dir
    path = make_backup(source, folder)
    return path, copy_to_extras(path, st["extras"])


def has_backup_today(folder: str) -> bool:
    prefix = date.today().strftime("cases-%Y-%m-%d_")
    return os.path.isdir(folder) and any(n.startswith(prefix) and NAME_RE.match(n) for n in os.listdir(folder))


# ---- بازگردانی
class RestoreError(Exception):
    pass


def validate_backup_file(path: str) -> None:
    """مطمئن می‌شود فایل یک بکاپ سالم این برنامه است."""
    try:
        conn = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
    except sqlite3.Error as e:
        raise RestoreError("فایل قابل خواندن نیست") from e
    try:
        try:
            ok = conn.execute("PRAGMA integrity_check").fetchone()[0]
            tables = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        except sqlite3.DatabaseError as e:
            raise RestoreError("این فایل دیتابیس نیست یا خراب است") from e
        if ok != "ok":
            raise RestoreError("فایل بکاپ خراب است")
        missing = {"users", "cases", "options", "counters"} - tables
        if missing:
            raise RestoreError("این فایل بکاپ این برنامه نیست")
    finally:
        conn.close()


def restore_backup(backup_path: str, live_db: str, safety_folder: str) -> str:
    """بکاپ را به‌جای اطلاعات فعلی می‌گذارد. قبل از آن از اطلاعات فعلی یک بکاپ ایمنی می‌گیرد
    (برای برگشت دوباره). خروجی: مسیر بکاپ ایمنی."""
    validate_backup_file(backup_path)
    safety = make_backup(live_db, safety_folder)
    src = sqlite3.connect(f"file:{backup_path}?mode=ro", uri=True)
    dst = sqlite3.connect(live_db, timeout=30)
    try:
        src.backup(dst)
    finally:
        dst.close()
        src.close()
    from .db import init_db            # بکاپ قدیمی‌تر هم به ساختار جدید ارتقا پیدا می‌کند
    init_db(live_db)
    return safety


# ---- بکاپ دوره‌ای (هر ۱۵ دقیقه، فقط اگر اطلاعات از بکاپ قبلی تغییر کرده باشد)
def db_signature(source: str):
    """اثر انگشت ساده از وضعیت دیتابیس (اندازه و زمان تغییر فایل اصلی و فایل WAL)."""
    sig = []
    for suffix in ("", "-wal"):
        try:
            st = os.stat(source + suffix)
            sig.append((st.st_mtime_ns, st.st_size))
        except OSError:
            sig.append(None)
    return tuple(sig)


def periodic_backup_once(source: str, settings_file: str, default_dir: str, state: dict) -> bool:
    """یک نوبت بکاپ دوره‌ای؛ اگر چیزی عوض نشده باشد بکاپ نمی‌گیرد. خروجی: آیا بکاپ گرفته شد."""
    sig = db_signature(source)
    if sig == state.get("sig"):
        return False
    run_backup(source, settings_file, default_dir)
    state["sig"] = db_signature(source)
    return True


def start_periodic(source: str, settings_file: str, default_dir: str, interval: int, logger=None) -> "threading.Thread":
    import threading
    import time
    state = {"sig": db_signature(source)}        # بکاپ زمان باز شدن برنامه همین الان گرفته شده

    def loop():
        while True:
            time.sleep(interval)
            try:
                periodic_backup_once(source, settings_file, default_dir, state)
            except Exception:                    # noqa: BLE001 — خطای بکاپ هرگز برنامه را متوقف نمی‌کند
                if logger:
                    logger.exception("بکاپ دوره‌ای انجام نشد")
    t = threading.Thread(target=loop, name="periodic-backup", daemon=True)
    t.start()
    return t
