"""مدیریت کاربران (فقط مدیر). هیچ کاربری حذف نمی‌شود؛ فقط غیرفعال می‌شود."""
import re
import sqlite3

from werkzeug.security import generate_password_hash

from . import config, seats


class UserError(Exception):
    pass


_NAME_RE = re.compile(r"^[\w.\-@]{2,40}$")


def list_users(db: sqlite3.Connection) -> list[sqlite3.Row]:
    return db.execute("SELECT id, username, full_name, role, active, created_at, last_login, dash_hidden "
                      "FROM users ORDER BY id").fetchall()


def _active_admins(db, excluding: int | None = None) -> int:
    q = "SELECT COUNT(*) FROM users WHERE role = 'admin' AND active = 1"
    if excluding is not None:
        return db.execute(q + " AND id != ?", (excluding,)).fetchone()[0]
    return db.execute(q).fetchone()[0]


def _get(db, user_id: int) -> sqlite3.Row:
    row = db.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
    if row is None:
        raise UserError("کاربر پیدا نشد.")
    return row


def _check_password(pw: str) -> None:
    if len(pw or "") < 6:
        raise UserError("رمز عبور باید حداقل ۶ کاراکتر باشد.")


def create(db, username: str, password: str, role: str, full_name: str = "") -> int:
    username = (username or "").strip()
    if not _NAME_RE.match(username):
        raise UserError("نام کاربری ۲ تا ۴۰ حرف/عدد باشد و فاصله نداشته باشد.")
    if role not in config.ROLES:
        raise UserError("نقش نامعتبر است.")
    _check_password(password)
    if db.execute("SELECT 1 FROM users WHERE username = ? COLLATE NOCASE", (username,)).fetchone():
        raise UserError("این نام کاربری قبلاً ساخته شده است.")
    return db.execute("INSERT INTO users (username, password_hash, role, full_name) VALUES (?, ?, ?, ?)",
                      (username, generate_password_hash(password), role, " ".join((full_name or "").split())[:60])
                      ).lastrowid


def set_role(db, actor_id: int, user_id: int, role: str) -> None:
    if role not in config.ROLES:
        raise UserError("نقش نامعتبر است.")
    u = _get(db, user_id)
    if u["role"] == "admin" and role != "admin":
        if user_id == actor_id:
            raise UserError("نقش خودتان را نمی‌توانید پایین بیاورید.")
        if u["active"] and _active_admins(db, excluding=user_id) == 0:
            raise UserError("حداقل یک مدیر فعال باید بماند.")
    db.execute("UPDATE users SET role = ? WHERE id = ?", (role, user_id))
    if role not in config.ROLES_CAN_CREATE:
        seats.release(db, user_id)


def set_active(db, actor_id: int, user_id: int, active: bool) -> None:
    u = _get(db, user_id)
    if not active:
        if user_id == actor_id:
            raise UserError("خودتان را نمی‌توانید غیرفعال کنید.")
        if u["role"] == "admin" and _active_admins(db, excluding=user_id) == 0:
            raise UserError("حداقل یک مدیر فعال باید بماند.")
    db.execute("UPDATE users SET active = ? WHERE id = ?", (1 if active else 0, user_id))
    if not active:
        seats.release(db, user_id)


def reset_password(db, user_id: int, password: str) -> None:
    _get(db, user_id)
    _check_password(password)
    db.execute("UPDATE users SET password_hash = ? WHERE id = ?", (generate_password_hash(password), user_id))


def set_full_name(db, user_id: int, name: str) -> None:
    _get(db, user_id)
    db.execute("UPDATE users SET full_name = ? WHERE id = ?", (" ".join((name or "").split())[:60], user_id))


def set_dash_hidden(db: sqlite3.Connection, user_id: int, hidden: list) -> list:
    """بخش‌های داشبورد که این کاربر نباید ببیند (فقط شناسه‌های معتبر)."""
    from . import config
    valid = {k for k, _ in config.DASH_SECTIONS}
    clean = [k for k in hidden if k in valid]
    db.execute("UPDATE users SET dash_hidden = ? WHERE id = ?", (",".join(clean), user_id))
    return clean
