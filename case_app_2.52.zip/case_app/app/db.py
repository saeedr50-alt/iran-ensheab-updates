import sqlite3

from flask import current_app, g

from . import config

# ---------------------------------------------------------------------------
# ساختار پایه. هر جدول/ستون جدید در نسخه‌های بعدی با init_db به دیتابیس موجود
# اضافه می‌شود (بدون پاک شدن اطلاعات قبلی).
# ---------------------------------------------------------------------------
SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    username      TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    role          TEXT NOT NULL CHECK (role IN ('admin', 'entry', 'viewer')),
    created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

-- آخرین شماره صادرشده برای هر (نوع پرونده، سال)
CREATE TABLE IF NOT EXISTS counters (
    case_type TEXT    NOT NULL,
    year      INTEGER NOT NULL,
    last_no   INTEGER NOT NULL,
    PRIMARY KEY (case_type, year)
);

CREATE TABLE IF NOT EXISTS cases (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    case_type  TEXT    NOT NULL,
    year       INTEGER NOT NULL,
    serial_no  INTEGER NOT NULL,
    created_by INTEGER NOT NULL REFERENCES users(id),
    created_at TEXT    NOT NULL DEFAULT (datetime('now')),
    UNIQUE (case_type, year, serial_no)   -- تضمین نهایی: شماره تکراری ممکن نیست
);

-- محصولات هر پرونده (ردیف‌های زیرفرم محصولات)
CREATE TABLE IF NOT EXISTS case_products (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    case_id      INTEGER NOT NULL REFERENCES cases(id),
    product_type TEXT    NOT NULL DEFAULT '',
    size         TEXT    NOT NULL DEFAULT '',
    quantity     INTEGER NOT NULL DEFAULT 0,
    model        TEXT    NOT NULL DEFAULT '',
    sample       TEXT    NOT NULL DEFAULT ''
);

-- رقبای هر پرونده (ردیف‌های زیرفرم رقبا)
CREATE TABLE IF NOT EXISTS case_competitors (
    id      INTEGER PRIMARY KEY AUTOINCREMENT,
    case_id INTEGER NOT NULL REFERENCES cases(id),
    name    TEXT    NOT NULL DEFAULT '',
    price   INTEGER NOT NULL DEFAULT 0,
    won     INTEGER NOT NULL DEFAULT 0,
    note    TEXT    NOT NULL DEFAULT ''
);

-- گزینه‌های کمبوباکس‌ها. گزینه حذف نمی‌شود، فقط غیرفعال می‌شود.
CREATE TABLE IF NOT EXISTS options (
    id     INTEGER PRIMARY KEY AUTOINCREMENT,
    grp    TEXT    NOT NULL,
    label  TEXT    NOT NULL,
    active INTEGER NOT NULL DEFAULT 1,
    UNIQUE (grp, label)
);

-- تاریخچهٔ تغییر نام گزینه‌ها: گزینه‌های اولیه (seed) بعد از تغییر نام دوباره با نام قدیمی اضافه نمی‌شوند
-- صفحهٔ هر سازمان/شرکت: کلید = شناسهٔ گزینه (با تغییر نام گزینه هم پابرجاست)
CREATE TABLE IF NOT EXISTS org_fields (
    option_id INTEGER NOT NULL,
    key       TEXT    NOT NULL,
    value     TEXT    NOT NULL DEFAULT '',
    PRIMARY KEY (option_id, key)
);

CREATE TABLE IF NOT EXISTS org_contacts (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    option_id INTEGER NOT NULL,
    name      TEXT NOT NULL DEFAULT '',
    unit      TEXT NOT NULL DEFAULT '',
    position  TEXT NOT NULL DEFAULT '',
    phone     TEXT NOT NULL DEFAULT '',
    ext       TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS option_renames (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    grp       TEXT NOT NULL,
    old_label TEXT NOT NULL,
    new_label TEXT NOT NULL,
    renamed_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- جای‌های ویرایش همزمان: هر کاربرِ در حال ویرایش یک ردیف دارد (با زمان آخرین فعالیت)
CREATE TABLE IF NOT EXISTS edit_seats (
    user_id   INTEGER PRIMARY KEY REFERENCES users(id),
    last_seen REAL NOT NULL,
    taken_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS tickets (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL,
    username   TEXT NOT NULL DEFAULT '',
    subject    TEXT NOT NULL,
    body       TEXT NOT NULL,
    contact    TEXT NOT NULL DEFAULT '',
    gh_number  INTEGER,                         -- شمارهٔ Issue در گیت‌هاب (خالی = هنوز ارسال نشده)
    gh_state   TEXT NOT NULL DEFAULT 'open',
    created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
    last_sync  REAL NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS ticket_comments (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    ticket_id  INTEGER NOT NULL,
    gh_id      INTEGER,
    author     TEXT NOT NULL DEFAULT '',       -- support = پاسخ پشتیبان، user = پیام کاربر
    body       TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT '',
    UNIQUE (ticket_id, gh_id)
);

CREATE TABLE IF NOT EXISTS settings (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

-- اطلاعات «فرم شناسنامه» هر پرونده (ستون‌های فیلدها در init_db از app/profile.py ساخته می‌شود)
CREATE TABLE IF NOT EXISTS case_profile (
    case_id    INTEGER PRIMARY KEY REFERENCES cases(id),
    version    INTEGER NOT NULL DEFAULT 1,
    updated_at TEXT,
    updated_by INTEGER
);

CREATE TABLE IF NOT EXISTS audit_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    at TEXT NOT NULL,
    user_id INTEGER,
    username TEXT NOT NULL DEFAULT '',
    ip TEXT NOT NULL DEFAULT '',
    action TEXT NOT NULL,
    case_id INTEGER,
    case_label TEXT NOT NULL DEFAULT '',
    summary TEXT NOT NULL DEFAULT '',
    detail TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_audit_at ON audit_log(at);
CREATE INDEX IF NOT EXISTS idx_audit_user ON audit_log(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_case ON audit_log(case_id);
CREATE TRIGGER IF NOT EXISTS audit_no_delete BEFORE DELETE ON audit_log
BEGIN SELECT RAISE(ABORT, 'لاگ قابل حذف نیست'); END;
CREATE TRIGGER IF NOT EXISTS audit_no_update BEFORE UPDATE ON audit_log
BEGIN SELECT RAISE(ABORT, 'لاگ قابل ویرایش نیست'); END;

CREATE TRIGGER IF NOT EXISTS profile_no_delete
BEFORE DELETE ON case_profile
BEGIN
    SELECT RAISE(ABORT, 'حذف اطلاعات شناسنامه مجاز نیست');
END;

-- هیچ پرونده یا ردیفی حذف نمی‌شود؛ شماره و نوع پرونده هم تغییر نمی‌کند.
CREATE TRIGGER IF NOT EXISTS cases_no_delete
BEFORE DELETE ON cases
BEGIN
    SELECT RAISE(ABORT, 'حذف پرونده مجاز نیست');
END;

CREATE TRIGGER IF NOT EXISTS cases_no_renumber
BEFORE UPDATE OF case_type, year, serial_no ON cases
BEGIN
    SELECT RAISE(ABORT, 'تغییر شماره یا نوع پرونده مجاز نیست');
END;

CREATE TRIGGER IF NOT EXISTS products_no_delete
BEFORE DELETE ON case_products
BEGIN
    SELECT RAISE(ABORT, 'حذف ردیف محصول مجاز نیست');
END;

CREATE TRIGGER IF NOT EXISTS competitors_no_delete
BEFORE DELETE ON case_competitors
BEGIN
    SELECT RAISE(ABORT, 'حذف ردیف رقیب مجاز نیست');
END;

CREATE TRIGGER IF NOT EXISTS options_no_delete
BEFORE DELETE ON options
BEGIN
    SELECT RAISE(ABORT, 'حذف گزینه مجاز نیست؛ فقط غیرفعال کنید');
END;
"""

# ستون‌هایی که بعد از نسخه ۱ به جدول cases اضافه شدند
CASES_EXTRA_COLUMNS = {
    "received_date": "TEXT NOT NULL DEFAULT ''",
    "source": "TEXT NOT NULL DEFAULT ''",
    "organization": "TEXT NOT NULL DEFAULT ''",
    "tender_type": "TEXT NOT NULL DEFAULT ''",
    "status": "TEXT NOT NULL DEFAULT ''",
    "send_deadline": "TEXT NOT NULL DEFAULT ''",
    "physical_upload": "TEXT NOT NULL DEFAULT ''",
    "opening_time": "TEXT NOT NULL DEFAULT ''",
    "result_date": "TEXT NOT NULL DEFAULT ''",       # تاریخ اعلام نتایج
    "decision": "TEXT NOT NULL DEFAULT ''",
    "result": "TEXT NOT NULL DEFAULT ''",
    "notes": "TEXT NOT NULL DEFAULT ''",
    "archive_reason": "TEXT NOT NULL DEFAULT ''",
    "version": "INTEGER NOT NULL DEFAULT 1",   # برای جلوگیری از تداخل دو کاربر
    "updated_at": "TEXT",
    "updated_by": "INTEGER",
}


def connect(path: str) -> sqlite3.Connection:
    # isolation_level=None یعنی تراکنش‌ها را خودمان صریح کنترل می‌کنیم
    conn = sqlite3.connect(path, timeout=30, isolation_level=None)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    return conn


def get_db() -> sqlite3.Connection:
    if "db" not in g:
        g.db = connect(current_app.config["DATABASE"])
    return g.db


def close_db(_exc=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def _ensure_option(conn, grp: str, label: str) -> None:
    """گزینه را اگر نیست اضافه می‌کند؛ مگر اینکه قبلاً از این نام به نام دیگری تغییر کرده باشد."""
    from .jalali import to_fa_digits
    label = to_fa_digits(label)                  # ارقام همه‌جا فارسی
    renamed = conn.execute("SELECT 1 FROM option_renames WHERE grp = ? AND old_label = ?", (grp, label)).fetchone()
    if not renamed:
        conn.execute("INSERT OR IGNORE INTO options (grp, label) VALUES (?, ?)", (grp, label))


def _persianize_digits(conn) -> None:
    """یک‌بار: ارقام انگلیسی/عربیِ اطلاعات قبلی (متن، تاریخ، گزینه‌ها) به فارسی تبدیل می‌شود.
    عددهای تعداد و قیمت عدد می‌مانند (برای جمع و محاسبه) و فقط فارسی نمایش داده می‌شوند."""
    from . import profile
    from .jalali import to_fa_digits
    if conn.execute("SELECT 1 FROM settings WHERE key = 'digits_fa'").fetchone():
        return
    targets = [("cases", ["received_date", "send_deadline", "physical_upload", "opening_time", "result_date", "source", "organization",
                          "tender_type", "status", "decision", "archive_reason", "result", "notes"]),
               ("case_products", ["product_type", "size", "model", "sample"]),
               ("case_competitors", ["name", "note"]),
               ("case_profile", list(profile.KEYS)),
               ("option_renames", ["old_label", "new_label"])]
    conn.execute("BEGIN IMMEDIATE")
    try:
        for table, cols in targets:
            have = {r["name"] for r in conn.execute(f"PRAGMA table_info({table})")}
            for col in cols:
                if col not in have:
                    continue
                for row in conn.execute(f"SELECT rowid AS rid, {col} AS v FROM {table}").fetchall():
                    new = to_fa_digits(row["v"])
                    if new != row["v"]:
                        conn.execute(f"UPDATE {table} SET {col} = ? WHERE rowid = ?", (new, row["rid"]))
        for row in conn.execute("SELECT id, grp, label FROM options").fetchall():
            new = to_fa_digits(row["label"])
            if new != row["label"] and not conn.execute(
                    "SELECT 1 FROM options WHERE grp = ? AND label = ?", (row["grp"], new)).fetchone():
                conn.execute("UPDATE options SET label = ? WHERE id = ?", (new, row["id"]))
        conn.execute("INSERT INTO settings (key, value) VALUES ('digits_fa', '1')")
        conn.execute("COMMIT")
    except BaseException:
        conn.execute("ROLLBACK")
        raise


def _rename_archive_option(conn) -> None:
    """یک‌بار: تصمیم مدیریتی «بایگانی» به «عدم تایید و بایگانی» تبدیل می‌شود (در گزینه‌ها و پرونده‌های قبلی)."""
    if conn.execute("SELECT 1 FROM settings WHERE key = 'archive_v222'").fetchone():
        return
    new, old = config.ARCHIVE_VALUE, config.OLD_ARCHIVE_VALUE
    conn.execute("BEGIN IMMEDIATE")
    try:
        has_old = conn.execute("SELECT 1 FROM options WHERE grp='decision' AND label=?", (old,)).fetchone()
        has_new = conn.execute("SELECT 1 FROM options WHERE grp='decision' AND label=?", (new,)).fetchone()
        if has_old and not has_new:
            conn.execute("UPDATE options SET label=? WHERE grp='decision' AND label=?", (new, old))
            conn.execute("INSERT INTO option_renames (grp, old_label, new_label) VALUES ('decision', ?, ?)", (old, new))
        elif has_old and has_new:
            conn.execute("UPDATE options SET active=0 WHERE grp='decision' AND label=?", (old,))
        conn.execute("UPDATE cases SET decision=? WHERE decision LIKE '%بایگانی%' AND decision != ?", (new, new))
        conn.execute("INSERT OR REPLACE INTO settings (key, value) VALUES ('archive_v222', '1')")
        conn.execute("COMMIT")
    except BaseException:
        conn.execute("ROLLBACK")
        raise


def init_db(path: str) -> None:
    """دیتابیس را می‌سازد یا به نسخه جدید ارتقا می‌دهد (اطلاعات قبلی حفظ می‌شود)."""
    conn = connect(path)
    try:
        conn.executescript(SCHEMA)

        existing = {r["name"] for r in conn.execute("PRAGMA table_info(cases)")}
        for column, ddl in CASES_EXTRA_COLUMNS.items():
            if column not in existing:
                conn.execute(f"ALTER TABLE cases ADD COLUMN {column} {ddl}")

        users_cols = {r["name"] for r in conn.execute("PRAGMA table_info(users)")}
        for col, ddl in (("active", "INTEGER NOT NULL DEFAULT 1"), ("last_login", "TEXT"),
                         ("full_name", "TEXT NOT NULL DEFAULT ''"), ("dash_hidden", "TEXT NOT NULL DEFAULT ''")):
            if col not in users_cols:
                conn.execute(f"ALTER TABLE users ADD COLUMN {col} {ddl}")
        from . import profile
        profile.ensure_columns(conn)
        if "price" not in {r["name"] for r in conn.execute("PRAGMA table_info(case_products)")}:
            conn.execute("ALTER TABLE case_products ADD COLUMN price INTEGER NOT NULL DEFAULT 0")
        pcols = {r["name"] for r in conn.execute("PRAGMA table_info(case_products)")}
        if "pos" not in pcols:                    # ترتیب ردیف‌های محصول (برای جابه‌جایی ردیف‌ها)
            conn.execute("ALTER TABLE case_products ADD COLUMN pos INTEGER NOT NULL DEFAULT 0")
            conn.execute("UPDATE case_products SET pos = id")
        if "sample_qty" not in pcols:             # تعداد نمونه (فقط وقتی نمونه = دارد)
            conn.execute("ALTER TABLE case_products ADD COLUMN sample_qty INTEGER NOT NULL DEFAULT 0")
        _persianize_digits(conn)
        _rename_archive_option(conn)

        # گزینه‌های پیش‌فرض، فقط برای گروه‌هایی که هنوز هیچ گزینه‌ای ندارند
        for grp, labels in config.DEFAULT_OPTIONS.items():
            has_any = conn.execute("SELECT 1 FROM options WHERE grp = ? LIMIT 1", (grp,)).fetchone()
            if not has_any:
                for label in labels:
                    _ensure_option(conn, grp, label)
        # گزینه‌هایی که منطق فرم لازم دارد؛ فقط اگر اصلاً وجود نداشته باشند اضافه می‌شوند
        # (اگر مدیر عمداً غیرفعالشان کرده باشد، دست نمی‌زنیم)
        for grp, labels in config.REQUIRED_OPTIONS.items():
            for label in labels:
                _ensure_option(conn, grp, label)
        # گزینه‌های اولیه از اکسس (INSERT OR IGNORE: تکراری اضافه نمی‌شود، غیرفعال‌شده‌ها دست نمی‌خورند)
        from .seed_options import SEED_OPTIONS
        for grp, labels in SEED_OPTIONS.items():
            for label in labels:
                _ensure_option(conn, grp, label)
    finally:
        conn.close()
