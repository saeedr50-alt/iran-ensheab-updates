"""ساخت گزارش شناسنامه به‌صورت فایل PDF واقعی (با reportlab).

شکل‌دهی حروف فارسی (چسباندن حروف) و چینش راست‌به‌چپ را خودمان انجام می‌دهیم تا فقط به reportlab
نیاز باشد (pip install reportlab). فونت وزیرمتن (مجوز OFL) داخل پوشهٔ app/fonts است.
"""
import io
import os
import unicodedata

HERE = os.path.dirname(os.path.abspath(__file__))
FONT_DIR = os.path.join(HERE, "fonts")
LOGO = os.path.join(HERE, "static", "logo.png")

# ------------------------------------------------------------- شکل‌دهی حروف
_FORMS: dict[str, dict[str, str]] = {}
_LIGS: dict[str, dict[str, str]] = {}      # لا، لآ، ... : {"isolated": ..., "final": ...}


def _build_tables():
    for lo, hi in ((0xFB50, 0xFDFF), (0xFE70, 0xFEFF)):
        for cp in range(lo, hi + 1):
            dec = unicodedata.decomposition(chr(cp))
            if not dec.startswith("<") or ">" not in dec:
                continue
            tag, rest = dec[1:].split(">", 1)
            if tag not in ("initial", "medial", "final", "isolated"):
                continue
            base = "".join(chr(int(x, 16)) for x in rest.split())
            if len(base) == 1:
                _FORMS.setdefault(base, {})[tag] = chr(cp)
            elif base.startswith("ل") and len(base) == 2:
                _LIGS.setdefault(base, {})[tag] = chr(cp)


_build_tables()
_FIX = {"ي": "ی", "ك": "ک", "ى": "ی"}
_ZWNJ = "‌"


def _is_mark(ch: str) -> bool:
    return unicodedata.category(ch) == "Mn"


def _dual(ch: str) -> bool:           # به حرف بعدی می‌چسبد
    return "initial" in _FORMS.get(ch, {})


def _joinable(ch: str) -> bool:       # به حرف قبلی می‌تواند بچسبد
    return "final" in _FORMS.get(ch, {})


def shape(text: str) -> str:
    from .jalali import to_fa_digits
    text = "".join(_FIX.get(c, c) for c in to_fa_digits(text))        # همهٔ ارقام فارسی
    chars = [c for c in text]
    # ligature لا
    out: list[str] = []
    i = 0
    while i < len(chars):
        out.append(chars[i]); i += 1
    # حذف علامت‌ها از دید چسبندگی ولی نگه‌داشتن آن‌ها
    base_idx = [k for k, c in enumerate(out) if not _is_mark(c)]
    res = list(out)
    skip = set()
    for pos, k in enumerate(base_idx):
        if k in skip:
            continue
        c = out[k]
        prev = out[base_idx[pos - 1]] if pos > 0 else ""
        nxt_k = base_idx[pos + 1] if pos + 1 < len(base_idx) else None
        nxt = out[nxt_k] if nxt_k is not None else ""
        if c not in _FORMS:
            continue
        prev_conn = bool(prev) and _dual(prev) and (base_idx[pos - 1] not in skip or True)
        # لام + الف
        if c == "ل" and nxt in ("ا", "آ", "أ", "إ"):
            lig = _LIGS.get(c + nxt)
            if lig:
                form = lig.get("final") if prev_conn and "final" in lig else lig.get("isolated")
                res[k] = form or c
                res[nxt_k] = ""
                skip.add(nxt_k)
                continue
        next_conn = bool(nxt) and _joinable(nxt) and _dual(c)
        f = _FORMS[c]
        if prev_conn and next_conn and "medial" in f:
            res[k] = f["medial"]
        elif prev_conn and "final" in f:
            res[k] = f["final"]
        elif next_conn and "initial" in f:
            res[k] = f["initial"]
        else:
            res[k] = f.get("isolated", c)
    return "".join(res).replace(_ZWNJ, "")


# ------------------------------------------------------------- چینش راست‌به‌چپ (ساده)
_MIRROR = {"(": ")", ")": "(", "[": "]", "]": "[", "«": "»", "»": "«"}
_LTR_JOIN = set("/.,:-%٪+")


def _cls(ch: str) -> str:
    o = ord(ch)
    if ch.isascii() and ch.isalnum():
        return "L"
    if 0x0600 <= o <= 0x06FF or 0xFB50 <= o <= 0xFDFF or 0xFE70 <= o <= 0xFEFF or 0x0750 <= o <= 0x077F:
        return "L" if ch in "۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩" else "R"
    if ch == "‏":
        return "R"
    return "N"


def visual(shaped: str) -> str:
    """متنِ منطقی (شکل‌داده‌شده) -> ترتیب نمایش از چپ به راست برای صفحهٔ راست‌به‌چپ."""
    cl = [_cls(c) for c in shaped]
    n = len(shaped)
    # اتصال علامت‌های میان عددها/حروف لاتین (مثل 1405/07/19 یا Sel/FO/115.02) و فاصلهٔ بین دو کلمهٔ لاتین
    for i in range(1, n - 1):
        if cl[i] == "N" and cl[i - 1] == "L" and cl[i + 1] == "L" and (shaped[i] in _LTR_JOIN or shaped[i] == " "):
            cl[i] = "L"
    # بقیهٔ خنثی‌ها در متن راست‌به‌چپ = R
    cl = ["R" if c == "N" else c for c in cl]
    runs: list[tuple[str, str]] = []
    for ch, c in zip(shaped, cl):
        if runs and runs[-1][0] == c:
            runs[-1] = (c, runs[-1][1] + ch)
        else:
            runs.append((c, ch))
    parts = []
    for c, s in reversed(runs):
        if c == "R":
            s = "".join(_MIRROR.get(x, x) for x in reversed(s))
        parts.append(s)
    return "".join(parts)


# ------------------------------------------------------------- رسم PDF
def build_pdf(case: dict, ctx: dict, title: str, form_code: str) -> bytes:
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    from reportlab.pdfgen import canvas

    for name, fn in (("Vz", "Vazirmatn-Regular.ttf"), ("VzB", "Vazirmatn-Bold.ttf")):
        if name not in pdfmetrics.getRegisteredFontNames():
            pdfmetrics.registerFont(TTFont(name, os.path.join(FONT_DIR, fn)))

    W, H = A4
    M = 22
    X0, X1 = M, W - M                 # لبهٔ چپ و راست کادر
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=A4)
    c.setTitle(title)
    c.setLineWidth(0.8)
    SZ = 9.5

    def sw(text, font="Vz", size=SZ):
        return pdfmetrics.stringWidth(visual(shape(text)), font, size)

    def put_right(x, y, text, font="Vz", size=SZ):
        c.setFont(font, size)
        c.drawRightString(x, y, visual(shape(text)))

    def put_center(x, y, text, font="VzB", size=SZ):
        c.setFont(font, size)
        c.drawCentredString(x, y, visual(shape(text)))

    def wrap(text, width, font="Vz", size=SZ, first_width=None):
        lines, cur = [], ""
        w = first_width if first_width is not None else width
        for para in str(text or "").split("\n"):
            cur = ""
            for word in para.split():
                trial = (cur + " " + word).strip()
                if cur and sw(trial, font, size) > w:
                    lines.append(cur); cur = word; w = width
                else:
                    cur = trial
            lines.append(cur); w = width
        return lines or [""]

    LH = 13.5
    top = H - M

    # ---------- سربرگ
    head_h = 58
    c.rect(X0, top - head_h, X1 - X0, head_h)
    logo_w = (X1 - X0) * 0.35
    c.line(X1 - logo_w, top, X1 - logo_w, top - head_h)
    if os.path.exists(LOGO):
        from reportlab.lib.utils import ImageReader
        img = ImageReader(LOGO)
        iw, ih = img.getSize()
        h = 40; w = h * iw / ih
        c.drawImage(img, X1 - 14 - w, top - head_h / 2 - h / 2, w, h, mask="auto")
    put_center((X0 + X1 - logo_w) / 2, top - head_h / 2 - 5, title, "VzB", 14)
    y = top - head_h

    # ---------- اطلاعات دو ستونی
    colw = (X1 - X0) / 2
    xr, xl = X1, X1 - colw            # ستون راست و چپ

    def row_height(label, value, cw):
        lw = sw(label + ":") + 6
        lines = wrap(value, cw - 12, "VzB", SZ, first_width=cw - 12 - lw)
        return max(17, len(lines) * LH + 4), lines, lw

    def col_rows(rows, right_x, cw, ystart):
        yy = ystart
        for label, value in rows:
            h, lines, lw = row_height(label, value, cw)
            base = yy - 12.5
            put_right(right_x - 6, base, label + ":")
            for i, ln in enumerate(lines):
                if i == 0:
                    put_right(right_x - 6 - lw, base, ln, "VzB")
                else:
                    put_right(right_x - 6, base - i * LH, ln, "VzB")
            yy -= h
            c.setStrokeGray(0.7); c.line(right_x - cw, yy, right_x, yy); c.setStrokeGray(0)
        return yy

    from . import config
    p, tt = ctx["prof"], config.CASE_GROUPS.get(case["case_type"], title.replace("شناسنامه ", ""))
    hide = ctx["hide"]
    inquiry = "subject" in hide
    kind_row = ("منبع دریافت", case["source"]) if inquiry else ("نوع برگزاری " + tt, case["tender_type"])
    right_all = [
        (None, "شماره شناسنامه", str(case["serial_no"])), (None, "تاریخ صدور شناسنامه", p["issue_date"]),
        (None, "نام خریدار", case["organization"]), ("subject", "موضوع " + tt, p["subject"]),
        (None, *kind_row), ("call_no", "شماره فراخوان", p["call_no"]),
        ("need_no", "شماره نیاز", p["need_no"]), ("tender_no", "شماره " + tt, p["tender_no"] or "-"),
        (None, "تاریخ اعلان آگهی", p["announce_date"]), (None, "تاریخ دریافت اسناد", case["received_date"]),
        (None, "مهلت ارسال اسناد", case["send_deadline"]), (None, "ساعت مهلت ارسال", case["physical_upload"]),
        (None, "نحوه ارسال اسناد", p["send_method"]),
        (None, "محل تحویل کالا", p["delivery_place"]),
    ]
    left_all = [
        ("contract_period", "مدت قرارداد", p["contract_period"]), (None, "نحوه پرداخت", p["payment_method"]),
        ("advance", "پیش پرداخت", p["advance"]), ("clearance", "مفاصا حساب", p["clearance"]),
        (None, "بازرسی", p["inspection"]),
        (None, "نمونه", ctx["samples"]), ("bid_guarantee", "مبلغ ضمانت نامه شرکت در مناقصه", p["bid_guarantee"]),
        ("perf_guarantee", "مبلغ ضمانت نامه حسن انجام تعهدات", p["perf_guarantee"]), (None, "مدت گارانتی", p["warranty"]),
        (None, "مدت خدمات پس از فروش", p["after_sales"]), (None, "حمل", p["shipping"]), (None, "تخلیه", p["unloading"]),
    ]
    right_rows = [(l, v) for k, l, v in right_all if k not in hide]
    left_rows = [(l, v) for k, l, v in left_all if k not in hide]
    yr = col_rows(right_rows, xr, colw, y)
    yl = col_rows(left_rows, xl, colw, y)
    y_end = min(yr, yl)
    c.line(xl, y, xl, y_end)
    c.line(X0, y_end, X1, y_end)
    c.rect(X0, y_end, X1 - X0, y - y_end)
    y = y_end

    # ---------- جعبه‌های متنی
    n_prod = max(1, len(ctx["products"]))
    fixed_after = 22 + n_prod * 21 + 20          # جدول + پانویس
    def box(label, text, min_h, width=None, x_right=None, draw_bottom=True):
        nonlocal y
        width = width or (X1 - X0)
        x_right = x_right or X1
        lines = wrap(text, width - 14, "Vz", SZ)
        h = max(min_h, 20 + len(lines) * LH)
        put_right(x_right - 6, y - 13, label, "VzB")
        for i, ln in enumerate(lines if text else []):
            put_right(x_right - 6, y - 13 - LH * (i + 1), ln)
        y -= h
        c.line(X0, y, X1, y)
        return h

    box("توضیحات:", p["doc_notes"], 56)
    box("توضیحات واحد بازرگانی:", p["commercial_notes"], 42)
    # امضاها
    sign_h = 46
    c.setFont("VzB", SZ)
    put_right(X1 - 6, y - 13, "امضا کارشناس:", "VzB")
    if p["expert_sign"]:
        put_right(X1 - 6, y - 13 - LH, p["expert_sign"])
    put_right(X1 - colw - 6, y - 13, "امضا مدیر بازرگانی یا مدیر فروش:", "VzB")
    if p["manager_sign"]:
        put_right(X1 - colw - 6, y - 13 - LH, p["manager_sign"])
    c.line(xl, y, xl, y - sign_h)
    y -= sign_h
    c.line(X0, y, X1, y)
    box("دستور مدیریت:", case["decision"], 52)

    # ---------- جدول محصولات
    cols = [(X1 - 26, "n", 26), (None, "name", 0), (None, "model", 105), (None, "qty", 70), (None, "price", 95)]
    name_w = (X1 - X0) - 26 - 105 - 70 - 95
    widths = [26, name_w, 105, 70, 95]
    xs = []
    xcur = X1
    for wd in widths:
        xs.append((xcur - wd, xcur)); xcur -= wd
    hdr = ["", "نوع محصول", "مدل", "تعداد", "قیمت"]
    row_h = 21
    for i, (xa, xb) in enumerate(xs):
        put_center((xa + xb) / 2, y - 14, hdr[i], "Vz")
    y -= 21
    c.line(X0, y, X1, y)
    prods = ctx["products"] + [None] * (n_prod - len(ctx["products"]))
    for i, pr in enumerate(prods):
        put_center((xs[0][0] + xs[0][1]) / 2, y - 14, str(i + 1), "Vz")
        if pr:
            put_right(xs[1][1] - 6, y - 14, pr["name"], "Vz", SZ if sw(pr["name"]) < name_w - 12 else 8)
            put_center((xs[2][0] + xs[2][1]) / 2, y - 14, pr["model"], "Vz")
            put_center((xs[3][0] + xs[3][1]) / 2, y - 14, "{:,}".format(pr["quantity"]) if pr["quantity"] else "", "Vz")
            put_center((xs[4][0] + xs[4][1]) / 2, y - 14, "{:,}".format(pr["price"]) if pr["price"] else "", "Vz")
        y -= row_h
        c.line(X0, y, X1, y)
    for xa, xb in xs[:-1]:
        c.line(xa, y + row_h * n_prod + 21, xa, y)

    # ---------- مدیرعامل (باقی صفحه) + پانویس
    foot_h = 20
    bottom = M
    rest = y - (bottom + foot_h)
    lines = wrap(p["ceo_notes"], (X1 - X0) - 14, "Vz", SZ)
    put_right(X1 - 6, y - 13, "توضیحات و امضا مدیرعامل:", "VzB")
    for i, ln in enumerate(lines if p["ceo_notes"] else []):
        put_right(X1 - 6, y - 13 - LH * (i + 1), ln)
    y = min(y - 10, bottom + foot_h) if rest < 10 else bottom + foot_h
    c.line(X0, y, X1, y)
    c.setFont("Vz", 9)
    c.drawString(X0 + 8, bottom + 6, form_code)
    # کادر بیرونی
    c.rect(X0, bottom, X1 - X0, top - bottom)
    c.showPage()
    c.save()
    return buf.getvalue()
