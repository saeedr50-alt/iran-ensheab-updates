"""گزینه‌های کمبوباکس‌ها (منبع دریافت، سازمان، وضعیت و...)."""
import sqlite3

from .jalali import to_fa_digits
from . import config

MAX_LABEL_LEN = 200


def clean_label(text: str) -> str:
    """فاصله‌های اضافه حذف و ي/ك عربی به ی/ک فارسی تبدیل می‌شود (تا جستجو و تکراری‌یابی درست کار کند)."""
    return to_fa_digits(" ".join((text or "").replace("ي", "ی").replace("ك", "ک").split())[:MAX_LABEL_LEN])


def active_labels(db: sqlite3.Connection, grp: str) -> list[str]:
    rows = db.execute(
        "SELECT label FROM options WHERE grp = ? AND active = 1 ORDER BY id", (grp,)
    ).fetchall()
    return [r["label"] for r in rows]


def all_options(db: sqlite3.Connection, grp: str) -> list[sqlite3.Row]:
    return db.execute(
        "SELECT id, label, active FROM options WHERE grp = ? ORDER BY id", (grp,)
    ).fetchall()


def options_for_form(db: sqlite3.Connection) -> dict[str, list[str]]:
    return {grp: active_labels(db, grp) for grp in config.OPTION_GROUPS}


def add_labels(db: sqlite3.Connection, grp: str, text: str) -> int:
    """هر خط یک گزینه. گزینه تکراری اضافه نمی‌شود (اگر غیرفعال بود دوباره فعال می‌شود)."""
    if grp not in config.OPTION_GROUPS:
        raise ValueError("گروه نامعتبر")
    changed = 0
    seen = set()
    for line in (text or "").splitlines():
        label = clean_label(line)
        if not label or label in seen:
            continue
        seen.add(label)
        row = db.execute("SELECT id, active FROM options WHERE grp = ? AND label = ?", (grp, label)).fetchone()
        if row is None:
            db.execute("INSERT INTO options (grp, label) VALUES (?, ?)", (grp, label))
            changed += 1
        elif not row["active"]:
            db.execute("UPDATE options SET active = 1 WHERE id = ?", (row["id"],))
            changed += 1
    return changed


def set_active(db: sqlite3.Connection, option_id: int, active: bool) -> None:
    db.execute("UPDATE options SET active = ? WHERE id = ?", (1 if active else 0, option_id))


def remember_label(db: sqlite3.Connection, grp: str, label: str) -> None:
    """یک گزینه را (اگر نبود) به لیست اضافه می‌کند یا (اگر غیرفعال بود) فعال می‌کند."""
    add_labels(db, grp, label)


class RenameError(Exception):
    pass


def rename_label(db: sqlite3.Connection, grp: str, old: str, new: str) -> int:
    """نام یک گزینه را عوض می‌کند و همان نام را در همهٔ پرونده‌هایی که از آن استفاده کرده‌اند هم اصلاح می‌کند
    (همه یا هیچ). خروجی: تعداد ردیف‌های اصلاح‌شده در پرونده‌ها."""
    if grp not in config.OPTION_COLUMNS:
        raise RenameError("این کمبوباکس قابل ویرایش نیست.")
    old, new = clean_label(old), clean_label(new)
    if not new:
        raise RenameError("متن گزینه را بنویسید.")
    if db.execute("SELECT 1 FROM options WHERE grp = ? AND label = ?", (grp, old)).fetchone() is None:
        raise RenameError("این گزینه پیدا نشد.")
    if new == old:
        return 0
    if db.execute("SELECT 1 FROM options WHERE grp = ? AND label = ?", (grp, new)).fetchone():
        raise RenameError("گزینه‌ای با این نام از قبل هست.")
    changed = 0
    db.execute("BEGIN IMMEDIATE")
    try:
        db.execute("UPDATE options SET label = ? WHERE grp = ? AND label = ?", (new, grp, old))
        db.execute("INSERT INTO option_renames (grp, old_label, new_label) VALUES (?, ?, ?)", (grp, old, new))
        for table, column in config.OPTION_COLUMNS[grp]:
            changed += db.execute(f"UPDATE {table} SET {column} = ? WHERE {column} = ?", (new, old)).rowcount
        db.execute("COMMIT")
    except BaseException:
        db.execute("ROLLBACK")
        raise
    return changed
