"""تیکت پشتیبانی: هر تیکت یک Issue در مخزن خصوصی گیت‌هاب است؛ پاسخ پشتیبان از همان Issue خوانده می‌شود.
کلید (توکن) هرگز در Git نمی‌رود؛ از فایل ticket_token.txt کنار برنامه خوانده می‌شود."""
import json
import os
import sys
import time
import urllib.error
import urllib.request

from . import config, updater

API = "https://api.github.com"
SYNC_EVERY = 60          # ثانیه: حداقل فاصلهٔ دو بار همگام‌سازی یک تیکت


class TicketError(Exception):
    pass


def token(app=None) -> str:
    t = os.environ.get("IE_TICKET_TOKEN", "").strip()
    if t:
        return t
    dirs = []
    if app is not None:
        dirs.append(os.path.dirname(app.config["DATABASE"]))
    dirs += [updater.app_root(app), os.path.dirname(updater.app_root(app)), os.path.dirname(os.path.abspath(sys.executable))]
    for d in dirs:
        try:
            with open(os.path.join(d, "ticket_token.txt"), encoding="utf-8") as f:
                t = f.read().strip()
            if t:
                return t
        except OSError:
            continue
    return ""


def _call(app, method: str, path: str, payload=None):
    tk = token(app)
    if not tk:
        raise TicketError("کلید ارسال تیکت روی این سیستم نیست.")
    data = json.dumps(payload).encode("utf-8") if payload is not None else None
    req = urllib.request.Request(API + path, data=data, method=method, headers={
        "Authorization": f"Bearer {tk}", "Accept": "application/vnd.github+json",
        "User-Agent": "IranEnsheab-Tickets", "X-GitHub-Api-Version": "2022-11-28",
        "Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=15, context=updater._ssl_context()) as r:
            return json.loads(r.read().decode("utf-8") or "null")
    except urllib.error.HTTPError as e:
        raise TicketError(f"گیت‌هاب خطا داد ({e.code}).") from e
    except Exception as e:                       # noqa: BLE001 — اینترنت، DNS، SSL
        raise TicketError("اتصال به اینترنت برقرار نشد.") from e


def _issue_body(t, company_name: str) -> str:
    return (f"{t['body']}\n\n---\nشرکت: {company_name}\nکاربر: {t['username']}\n"
            f"تماس: {t['contact'] or '—'}\nنسخهٔ برنامه: {config.APP_VERSION}\nشمارهٔ تیکت در برنامه: {t['id']}")


def send(app, db, tid: int, company_name: str) -> bool:
    """ارسال یک تیکت هنوز-ارسال‌نشده؛ خروجی True اگر رفت. خطا هرگز استثنا نمی‌دهد."""
    t = db.execute("SELECT * FROM tickets WHERE id = ?", (tid,)).fetchone()
    if t is None or t["gh_number"]:
        return bool(t and t["gh_number"])
    try:
        r = _call(app, "POST", f"/repos/{config.TICKET_REPO}/issues",
                  {"title": f"[{company_name}] {t['subject']}", "body": _issue_body(t, company_name)})
    except TicketError:
        return False
    db.execute("UPDATE tickets SET gh_number = ? WHERE id = ?", (int(r["number"]), tid))
    db.commit()
    return True


def post_reply(app, db, tid: int, user_name: str, text: str) -> bool:
    t = db.execute("SELECT * FROM tickets WHERE id = ?", (tid,)).fetchone()
    if t is None or not t["gh_number"]:
        return False
    try:
        r = _call(app, "POST", f"/repos/{config.TICKET_REPO}/issues/{t['gh_number']}/comments",
                  {"body": f"**{user_name}:**\n{text}"})
    except TicketError:
        return False
    db.execute("INSERT OR IGNORE INTO ticket_comments (ticket_id, gh_id, author, body, created_at) VALUES (?,?,?,?,?)",
               (tid, r["id"], "user", text, (r.get("created_at") or "")[:16].replace("T", " ")))
    db.execute("UPDATE tickets SET gh_state = 'open' WHERE id = ?", (tid,))
    db.commit()
    return True


def sync(app, db, tid: int, force: bool = False) -> None:
    """وضعیت و پاسخ‌های پشتیبان را از گیت‌هاب می‌گیرد (بی‌صدا؛ اگر اینترنت نبود همان قبلی می‌ماند)."""
    t = db.execute("SELECT * FROM tickets WHERE id = ?", (tid,)).fetchone()
    if t is None or not t["gh_number"] or (not force and time.time() - t["last_sync"] < SYNC_EVERY):
        return
    try:
        issue = _call(app, "GET", f"/repos/{config.TICKET_REPO}/issues/{t['gh_number']}")
        comments = _call(app, "GET", f"/repos/{config.TICKET_REPO}/issues/{t['gh_number']}/comments?per_page=100")
    except TicketError:
        return
    for c in comments or []:
        who = (c.get("user") or {}).get("login", "")
        if who.lower() != config.TICKET_SUPPORT_LOGIN.lower():
            continue                              # پیام‌های خود کاربر قبلاً از داخل برنامه ثبت شده‌اند
        db.execute("INSERT OR IGNORE INTO ticket_comments (ticket_id, gh_id, author, body, created_at) VALUES (?,?,?,?,?)",
                   (tid, c["id"], "support", c.get("body") or "", (c.get("created_at") or "")[:16].replace("T", " ")))
    db.execute("UPDATE tickets SET gh_state = ?, last_sync = ? WHERE id = ?",
               (issue.get("state", "open"), time.time(), tid))
    db.commit()
