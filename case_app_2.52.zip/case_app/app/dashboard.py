"""داده‌های داشبورد مدیریتی: همهٔ عددها و نمودارها از پرونده‌های واقعی برنامه محاسبه می‌شوند.

فیلتر (مثل Power BI): نوع پرونده، سال/ماه (تاریخ دریافت)، و فیلتر متقابل روی سازمان، وضعیت، نتیجه،
محصول، منبع، نوع برگزاری، ماه. همه با پارامترهای آدرس و بدون هیچ دستکاری در دیتابیس.
"""
import sqlite3
from collections import defaultdict
from datetime import date

from . import config
from .jalali import jdate_to_date, to_ascii_digits, today_jalali

MONTHS = ["فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
          "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"]
WIN = "برنده"
UNKNOWN = "نامشخص"
FILTER_KEYS = ("type", "year", "month", "ym", "org", "status", "result", "product", "source", "tender")
TIME_KEYS = ("year", "month", "ym")


def _clean(v) -> str:
    return " ".join(str(v or "").split())


def _result_of(c: dict) -> str:
    r = _clean(c["result"])
    if not r:
        return UNKNOWN
    if config.matches(r, config.LOSER_VALUE):
        return config.LOSER_VALUE
    if config.matches(r, WIN):
        return WIN
    return r


def _month_key(d: str) -> str:
    return d[:7] if len(d) >= 7 else ""


def _load(db: sqlite3.Connection) -> list[dict]:
    cases = {r["id"]: dict(r, products=[], competitors=[], has_profile=False) for r in db.execute(
        "SELECT id, case_type, year, serial_no, received_date, source, organization, tender_type, status, "
        "send_deadline, opening_time, decision, result, archive_reason, created_at FROM cases")}
    for r in db.execute("SELECT case_id, product_type, size, model, quantity, price FROM case_products"):
        if r["case_id"] in cases:
            cases[r["case_id"]]["products"].append(dict(r))
    for r in db.execute("SELECT case_id, name, price, won FROM case_competitors"):
        if r["case_id"] in cases:
            cases[r["case_id"]]["competitors"].append(dict(r))
    for r in db.execute("SELECT case_id FROM case_profile"):
        if r["case_id"] in cases:
            cases[r["case_id"]]["has_profile"] = True
    for c in cases.values():                  # تاریخ‌ها در دیتابیس فارسی‌اند؛ برای محاسبه داخل داشبورد 0-9 می‌شوند
        for k in ("received_date", "send_deadline", "opening_time", "created_at"):
            c[k] = to_ascii_digits(c[k] or "")
    return list(cases.values())


def _match(c: dict, f: dict, skip_time=False) -> bool:
    if f.get("type") and c["case_type"] != f["type"]:
        return False
    rd = c["received_date"] or ""
    if not skip_time:
        if f.get("year") and rd[:4] != f["year"]:
            return False
        if f.get("month") and rd[5:7] != f["month"].zfill(2):
            return False
        if f.get("ym") and _month_key(rd) != f["ym"]:
            return False
    if f.get("org") and _clean(c["organization"]) != f["org"]:
        return False
    if f.get("status") and (_clean(c["status"]) or UNKNOWN) != f["status"]:
        return False
    if f.get("result") and _result_of(c) != f["result"]:
        return False
    if f.get("source") and (_clean(c["source"]) or UNKNOWN) != f["source"]:
        return False
    if f.get("tender") and (_clean(c["tender_type"]) or UNKNOWN) != f["tender"]:
        return False
    if f.get("product") and not any(_clean(p["product_type"]) == f["product"] for p in c["products"]):
        return False
    return True


def _count(items, top=None, other=False):
    d: dict[str, int] = defaultdict(int)
    for k in items:
        d[k] += 1
    rows = sorted(d.items(), key=lambda x: (-x[1], x[0]))
    out = [dict(label=k, value=v) for k, v in rows]
    return out[:top] if top else out


def build(db: sqlite3.Connection, raw_filters: dict) -> dict:
    f = {k: _clean(raw_filters.get(k)) for k in FILTER_KEYS if _clean(raw_filters.get(k))}
    if f.get("type") not in config.CASE_TYPES:
        f.pop("type", None)
    allc = _load(db)
    today = date.today()
    rows = [c for c in allc if _match(c, f)]

    years = sorted({c["received_date"][:4] for c in allc if len(c["received_date"] or "") >= 4}, reverse=True)

    # ---------- شاخص‌ها
    total = len(rows)
    res = [_result_of(c) for c in rows]
    won, lost = res.count(WIN), res.count(config.LOSER_VALUE)
    archived = sum(1 for c in rows if config.matches(c["decision"], config.ARCHIVE_VALUE))
    open_cases = [c for c, r in zip(rows, res)
                  if r == UNKNOWN and not config.matches(c["decision"], config.ARCHIVE_VALUE)]
    qty = sum(p["quantity"] or 0 for c in rows for p in c["products"])
    value = sum((p["quantity"] or 0) * (p["price"] or 0) for c in rows for p in c["products"])
    won_value = sum((p["quantity"] or 0) * (p["price"] or 0)
                    for c, r in zip(rows, res) if r == WIN for p in c["products"])
    no_profile = sum(1 for c in rows if not c["has_profile"])
    grp = [config.CASE_GROUPS.get(c["case_type"]) for c in rows]
    kpi = dict(total=total, tender=grp.count("مناقصه"), inquiry=grp.count("استعلام"), auction=grp.count("مزایده"),
               open=len(open_cases), won=won, lost=lost, archived=archived,
               win_rate=round(100 * won / (won + lost), 1) if (won + lost) else None,
               qty=qty, value=value, won_value=won_value, no_profile=no_profile)

    # ---------- روند ماهانه (بر اساس تاریخ دریافت)، برای ۱۲ ماه اخیر یا همهٔ ماه‌های دارای داده
    months = sorted({_month_key(c["received_date"]) for c in rows if len(c["received_date"] or "") >= 7})
    if not f.get("year") and not f.get("ym") and len(months) > 12:
        months = months[-12:]
    ser: dict[str, dict] = defaultdict(lambda: defaultdict(int))
    for c in rows:
        mk = _month_key(c["received_date"])
        if mk in months:
            ser[c["case_type"]][mk] += 1
    shown = [t for t in config.CASE_TYPES if t in ser]
    trend = dict(keys=months,
                 labels=[MONTHS[int(m[5:7]) - 1] + (" " + m[2:4] if not f.get("year") else "") for m in months],
                 series=[dict(name=config.CASE_TYPES[t], key=t, values=[ser[t][m] for m in months])
                         for t in shown])
    no_date = sum(1 for c in rows if len(c["received_date"] or "") < 7)

    # ---------- گروه‌بندی‌ها
    order = {WIN: 0, config.LOSER_VALUE: 1, UNKNOWN: 9}
    results = sorted(_count(res), key=lambda x: order.get(x["label"], 5))
    orgs_all = defaultdict(lambda: dict(total=0, won=0, lost=0))
    for c, r in zip(rows, res):
        o = orgs_all[_clean(c["organization"]) or UNKNOWN]
        o["total"] += 1
        o["won"] += r == WIN
        o["lost"] += r == config.LOSER_VALUE
    orgs = sorted(([k, v] for k, v in orgs_all.items()), key=lambda x: (-x[1]["total"], x[0]))[:10]
    orgs = [dict(label=k, value=v["total"], won=v["won"], lost=v["lost"]) for k, v in orgs]
    status = _count([_clean(c["status"]) or UNKNOWN for c in rows])
    source = _count([_clean(c["source"]) or UNKNOWN for c in rows])
    tender_acc = defaultdict(lambda: dict(total=0, won=0, lost=0))
    for c, r in zip(rows, res):
        t = tender_acc[_clean(c["tender_type"]) or UNKNOWN]
        t["total"] += 1; t["won"] += r == WIN; t["lost"] += r == config.LOSER_VALUE
    tender = [dict(label=k, value=v["total"], won=v["won"], lost=v["lost"],
                   rate=round(100 * v["won"] / (v["won"] + v["lost"]), 1) if v["won"] + v["lost"] else None)
              for k, v in sorted(tender_acc.items(), key=lambda x: -x[1]["total"])]
    reasons = _count([_clean(c["archive_reason"]) for c in rows
                      if config.matches(c["decision"], config.ARCHIVE_VALUE) and _clean(c["archive_reason"])], top=8)

    pa: dict[str, dict] = defaultdict(lambda: dict(qty=0, value=0, cases=set()))
    sizes: dict[str, int] = defaultdict(int)
    for c in rows:
        for p in c["products"]:
            name = _clean(p["product_type"]) or UNKNOWN
            a = pa[name]
            a["qty"] += p["quantity"] or 0
            a["value"] += (p["quantity"] or 0) * (p["price"] or 0)
            a["cases"].add(c["id"])
            if _clean(p["size"]):
                sizes[_clean(p["size"])] += p["quantity"] or 0
    products = sorted((dict(label=k, value=v["qty"], amount=v["value"], cases=len(v["cases"]))
                       for k, v in pa.items()), key=lambda x: -x["value"])[:10]
    size_rows = sorted((dict(label=k.replace(".", "/") if k.count(".") == 1 and k.replace(".", "").replace("-", "").isdigit() else k,
                             raw=k, value=v) for k, v in sizes.items()), key=lambda x: -x["value"])[:10]

    # ---------- رقبا
    comp: dict[str, dict] = defaultdict(lambda: dict(count=0, won=0, prices=[]))
    for c in rows:
        for r in c["competitors"]:
            name = _clean(r["name"])
            if not name:
                continue
            a = comp[name]
            a["count"] += 1
            a["won"] += 1 if r["won"] else 0
            if r["price"]:
                a["prices"].append(r["price"])
    competitors = sorted((dict(name=k, count=v["count"], won=v["won"],
                               avg=round(sum(v["prices"]) / len(v["prices"])) if v["prices"] else 0,
                               min=min(v["prices"]) if v["prices"] else 0)
                          for k, v in comp.items()), key=lambda x: (-x["count"], -x["won"]))[:8]

    # ---------- مهلت‌ها (مستقل از فیلتر زمان)
    deadlines = []
    for c in allc:
        if not _match(c, f, skip_time=True):
            continue
        if _result_of(c) != UNKNOWN or config.matches(c["decision"], config.ARCHIVE_VALUE):
            continue
        d = jdate_to_date(c["send_deadline"])
        if d is None:
            continue
        days = (d - today).days
        if -14 <= days <= 30:
            deadlines.append(dict(id=c["id"], type=config.CASE_TYPES.get(c["case_type"], ""), serial=c["serial_no"],
                                  org=_clean(c["organization"]) or "—", deadline=c["send_deadline"], days=days,
                                  status=_clean(c["status"])))
    deadlines.sort(key=lambda x: x["days"])
    due7 = sum(1 for d in deadlines if 0 <= d["days"] <= 7)
    overdue = sum(1 for d in deadlines if d["days"] < 0)
    kpi.update(due7=due7, overdue=overdue)

    recent = sorted(rows, key=lambda c: -c["id"])[:8]
    recent = [dict(id=c["id"], type=config.CASE_TYPES.get(c["case_type"], ""), serial=c["serial_no"],
                   org=_clean(c["organization"]) or "—", status=_clean(c["status"]), result=_result_of(c),
                   date=c["received_date"]) for c in recent]

    return dict(filters=f, years=years, months=MONTHS, today=today_jalali(), kpi=kpi, trend=trend, no_date=no_date,
                results=results, orgs=orgs, status=status, source=source, tender=tender, reasons=reasons,
                products=products, sizes=size_rows, competitors=competitors, deadlines=deadlines[:12],
                recent=recent, empty=(len(allc) == 0))
