"""به‌روزرسانی برنامه از داخل خود برنامه (فقط مدیر).

جریان: بررسی فایل `latest.json` در مخزن عمومی به‌روزرسانی ← بکاپ از اطلاعات ← دانلود و تأیید SHA-256
← نگه‌داشتن نسخهٔ قبلی در `updates/previous` ← جایگزینی فایل‌های برنامه ← اجرای دوباره.
پوشه‌های `instance` (اطلاعات)، `backups`، `reports` و `updates` هرگز دست نمی‌خورند.
"""
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time
import http.client
import socket
import ssl
import urllib.error
import urllib.parse
import urllib.request
import zipfile

from . import config

KEEP = {"instance", "backups", "reports", "updates", ".git"}      # فقط در ریشهٔ برنامه
MAX_ZIP = 400 * 1024 * 1024
CACHE_SECONDS = 6 * 3600
_cache = {"at": 0.0, "info": None, "error": ""}


class UpdateError(Exception):
    pass


def is_frozen() -> bool:
    return bool(getattr(sys, "frozen", False))


def app_root(app=None) -> str:
    if app is not None and app.config.get("APP_ROOT"):
        return app.config["APP_ROOT"]
    if is_frozen():
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def updates_dir(app=None) -> str:
    d = os.path.join(app_root(app), "updates")
    os.makedirs(d, exist_ok=True)
    return d


def platform_key() -> str:
    return "windows" if (is_frozen() and os.name == "nt") else "source"


def version_tuple(v: str) -> tuple:
    return tuple(int(x) for x in re.findall(r"\d+", str(v or "")))


def is_newer(latest: str, current: str) -> bool:
    return version_tuple(latest) > version_tuple(current)


def _ssl_context():
    """گواهی‌های certifi (اگر نصب باشد)؛ روی مک پایتون گاهی گواهی سیستم را ندارد."""
    try:
        import certifi
        return ssl.create_default_context(cafile=certifi.where())
    except Exception:
        import os as _os
        if _os.path.isfile("/etc/ssl/cert.pem"):          # گواهی‌های سیستم مک
            return ssl.create_default_context(cafile="/etc/ssl/cert.pem")
        return ssl.create_default_context()


def bases(app) -> list:
    """آدرس اصلی + جایگزین‌ها (جایگزین‌ها فقط وقتی آدرس اصلی همان پیش‌فرض است)؛ آدرسِ آخرین موفق اول."""
    main = (app.config.get("UPDATE_URL", config.UPDATE_URL) or "").rstrip("/")
    out = [main] + ([m.rstrip("/") for m in config.UPDATE_MIRRORS] if main == config.UPDATE_URL.rstrip("/") else [])
    good = _cache.get("base")
    if good in out:
        out.remove(good); out.insert(0, good)
    return out


DOH_SERVERS = ["https://1.1.1.1/dns-query", "https://8.8.8.8/resolve", "https://9.9.9.9:5053/dns-query"]


def _doh_resolve(host: str) -> list:
    """اگر DNS سیستم جواب نداد (مثلاً در ویندوز/ماشین مجازی)، آدرس IP را از DNS-over-HTTPS می‌گیرد."""
    for server in DOH_SERVERS:
        try:
            req = urllib.request.Request(f"{server}?name={host}&type=A", headers={"Accept": "application/dns-json"})
            with urllib.request.urlopen(req, timeout=8, context=_ssl_context()) as r:
                data = json.loads(r.read(100_000).decode("utf-8"))
            ips = [a["data"] for a in data.get("Answer", []) if a.get("type") == 1]
            if ips:
                return ips
        except Exception:
            continue
    raise socket.gaierror("DNS lookup failed (system DNS and DNS-over-HTTPS)")


def _open_via_ip(url: str, timeout: int, ips: list):
    u = urllib.parse.urlsplit(url)
    last = None
    for ip in ips:
        try:
            sock = socket.create_connection((ip, u.port or 443), timeout=timeout)
            sock = _ssl_context().wrap_socket(sock, server_hostname=u.hostname)       # SNI و گواهی برای نام اصلی
            conn = http.client.HTTPSConnection(u.hostname, u.port or 443, timeout=timeout)
            conn.sock = sock
            conn.request("GET", (u.path or "/") + (f"?{u.query}" if u.query else ""),
                         headers={"Host": u.hostname, "User-Agent": "IranEnsheab-Updater", "Connection": "close"})
            resp = conn.getresponse()
            if resp.status in (301, 302, 303, 307, 308) and resp.getheader("Location"):
                loc = urllib.parse.urljoin(url, resp.getheader("Location"))
                resp.close()
                return _open(loc, timeout)
            if resp.status != 200:
                raise urllib.error.HTTPError(url, resp.status, resp.reason, resp.msg, None)
            return resp
        except Exception as e:                                  # noqa: BLE001
            last = e
    raise last or OSError("connection failed")


def _open(url: str, timeout: int):
    req = urllib.request.Request(url, headers={"User-Agent": "IranEnsheab-Updater", "Cache-Control": "no-cache"})
    try:
        return urllib.request.urlopen(req, timeout=timeout, context=_ssl_context())
    except urllib.error.URLError as e:
        if url.startswith("https://") and isinstance(getattr(e, "reason", None), socket.gaierror):
            return _open_via_ip(url, timeout, _doh_resolve(urllib.parse.urlsplit(url).hostname))
        raise


def fetch_latest(base_urls) -> dict:
    """latest.json را از اولین آدرسی که جواب بدهد می‌خواند. خطا -> UpdateError با پیام فارسی."""
    if isinstance(base_urls, str):
        base_urls = [base_urls]
    base_urls = [b for b in base_urls if b]
    if not base_urls:
        raise UpdateError("آدرس به‌روزرسانی تنظیم نشده است.")
    info, errs = None, []
    for b in base_urls:
        try:
            with _open(b.rstrip("/") + "/latest.json", 12) as r:
                info = json.loads(r.read(200_000).decode("utf-8"))
            _cache["base"] = b.rstrip("/")
            break
        except Exception as e:                      # شبکه، SSL، DNS، JSON خراب، ...
            reason = getattr(e, "reason", None)
            errs.append(f"{type(e).__name__}" + (f": {reason}" if reason else ""))
    if info is None:
        raise UpdateError("اتصال به سرور به‌روزرسانی ممکن نشد. اینترنت (یا فیلترشکن) را بررسی کنید. جزئیات فنی: "
                          + " | ".join(errs)[:300])
    if not isinstance(info, dict) or not info.get("version") or not isinstance(info.get("files"), dict):
        raise UpdateError("فایل اطلاعات نسخهٔ جدید معتبر نیست.")
    return info


def status(app, force: bool = False) -> dict:
    """وضعیت نسخه (با کش ۶ ساعته تا هر صفحه‌ای اینترنت نخواهد)."""
    now = time.time()
    if force or _cache["info"] is None and not _cache["error"] or now - _cache["at"] > CACHE_SECONDS:
        try:
            _cache.update(info=fetch_latest(bases(app)), error="", at=now)
        except UpdateError as e:
            _cache.update(info=None, error=str(e), at=now)
    info = _cache["info"]
    out = dict(current=config.APP_VERSION, error=_cache["error"], latest="", newer=False, notes="", file=None)
    if info:
        out.update(latest=str(info["version"]), notes=str(info.get("notes", "")),
                   newer=is_newer(info["version"], config.APP_VERSION),
                   file=info["files"].get(platform_key()))
        if out["newer"] and not out["file"]:
            out.update(newer=False, error="برای این سیستم فایل به‌روزرسانی در سرور نیست.")
    return out


def download(app, entry: dict, progress=None) -> str:
    """zip را دانلود و با SHA-256 و ساختار zip می‌سنجد. خروجی: مسیر فایل."""
    name = str(entry.get("url", ""))
    if not name or "/" in name or "\\" in name or ".." in name:
        raise UpdateError("نام فایل به‌روزرسانی معتبر نیست.")
    target = os.path.join(updates_dir(app), "package.zip")
    sha, total = hashlib.sha256(), 0
    try:
        r0 = None
        for b in bases(app):
            try:
                r0 = _open(f"{b}/{name}", 60)
                break
            except Exception:
                continue
        if r0 is None:
            raise UpdateError("دانلود انجام نشد (اتصال برقرار نشد).")
        with r0 as r, open(target + ".part", "wb") as f:
            try:
                size = float(r.headers.get("Content-Length") or 0)
            except (TypeError, ValueError):
                size = 0.0
            while True:
                chunk = r.read(1 << 20)
                if not chunk:
                    break
                total += len(chunk)
                if progress and size:
                    progress(min(1.0, total / size))
                if total > MAX_ZIP:
                    raise UpdateError("فایل به‌روزرسانی بیش از حد بزرگ است.")
                sha.update(chunk)
                f.write(chunk)
    except UpdateError:
        raise
    except Exception as e:
        raise UpdateError(f"دانلود انجام نشد ({type(e).__name__}).")
    if entry.get("sha256") and sha.hexdigest().lower() != str(entry["sha256"]).lower():
        os.remove(target + ".part")
        raise UpdateError("فایل دانلودشده سالم نیست (SHA-256 نمی‌خواند). چیزی تغییر نکرد.")
    os.replace(target + ".part", target)
    if not zipfile.is_zipfile(target):
        raise UpdateError("فایل دانلودشده zip معتبر نیست.")
    return target


# ---------------------------------------------------------------- جایگزینی (مک / لینوکس / اجرای مستقیم پایتون)
def _snapshot(root: str, dest: str) -> None:
    shutil.rmtree(dest, ignore_errors=True)
    for name in os.listdir(root):
        if name in KEEP or name == "__pycache__":
            continue
        src = os.path.join(root, name)
        if os.path.isdir(src):
            shutil.copytree(src, os.path.join(dest, name), ignore=shutil.ignore_patterns("__pycache__"))
        else:
            os.makedirs(dest, exist_ok=True)
            shutil.copy2(src, os.path.join(dest, name))


def apply_source(root: str, zip_path: str, previous_dir: str) -> int:
    """فایل‌های zip را روی برنامه می‌نویسد (پوشهٔ اولِ zip حذف می‌شود). خروجی: تعداد فایل."""
    with zipfile.ZipFile(zip_path) as z:
        names = [n for n in z.namelist() if not n.endswith("/")]
        tops = {n.split("/", 1)[0] for n in names}
        strip = len(tops) == 1 and all("/" in n for n in names)
        plan = []
        for n in names:
            rel = n.split("/", 1)[1] if strip else n
            parts = [p for p in rel.replace("\\", "/").split("/") if p]
            if not parts or parts[0] in KEEP or ".." in parts or os.path.isabs(rel):
                continue
            plan.append((n, os.path.join(root, *parts)))
        if not plan:
            raise UpdateError("در فایل به‌روزرسانی چیزی برای نصب نبود.")
        _snapshot(root, previous_dir)                      # برای برگشت دستی
        for n, dest in plan:
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            with z.open(n) as src, open(dest, "wb") as out:
                shutil.copyfileobj(src, out)
    return len(plan)


def restart_source() -> None:
    # سوکت گوش‌دهندهٔ سرور بعد از execv باز می‌ماند و پورت ۵۰۰۱ اشغال می‌شود («Address already in use»)؛ پس همهٔ fdها بسته می‌شوند.
    # (بستن همهٔ fdها روی مک برنامه را می‌کشد؛ فقط سوکت‌ها «بسته‌شدن هنگام execv» می‌شوند.)
    try:
        import fcntl, stat
        for fd in range(3, 1024):
            try:
                if stat.S_ISSOCK(os.fstat(fd).st_mode):
                    os.set_inheritable(fd, False)
            except OSError:
                pass
    except Exception:
        pass
    os.execv(sys.executable, [sys.executable] + sys.argv)


# ---------------------------------------------------------------- ویندوز (exe)
BAT = r"""@echo off
setlocal EnableDelayedExpansion
title Iran Ensheab - updating
echo.
echo  Updating Iran Ensheab ... please do not close this window.
echo  (this window closes by itself)
echo.
rem pushd (not cd) so it also works when the app folder is on a network share (UNC path)
pushd "%~dp0.."
echo [%date% %time%] update started >> updates\update.log
set N=0
:wait
tasklist /FI "IMAGENAME eq IranEnsheab.exe" 2>nul | find /I "IranEnsheab.exe" >nul
if not errorlevel 1 (
  set /a N+=1
  if !N! GEQ 60 goto start
  timeout /t 1 /nobreak >nul
  goto wait
)
rd /s /q updates\previous 2>nul
rd /s /q updates\new 2>nul
powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force -LiteralPath 'updates\package.zip' -DestinationPath 'updates\new'" >> updates\update.log 2>&1
if errorlevel 1 goto start
if not exist "updates\new\IranEnsheab\IranEnsheab.exe" goto start
robocopy . updates\previous /E /XD instance backups reports updates /MT:16 /R:2 /W:1 /NFL /NDL /NJH /NJS /NP >> updates\update.log
robocopy updates\new\IranEnsheab . /E /XD instance backups reports updates /MT:16 /R:2 /W:1 /NFL /NDL /NJH /NJS /NP >> updates\update.log
if errorlevel 8 (
  echo copy failed, restoring previous version >> updates\update.log
  robocopy updates\previous . /E /XD instance backups reports updates /MT:16 /R:2 /W:1 /NFL /NDL /NJH /NJS /NP >> updates\update.log
)
:start
set NO_BROWSER=1
for %%I in ("%~dp0..") do set "APPDIR=%%~fI"
start "" /D "%SystemRoot%" "%APPDIR%\IranEnsheab.exe"
echo [%date% %time%] update finished >> updates\update.log
popd
"""


def write_windows_script(app) -> str:
    script = os.path.join(updates_dir(app), "apply_update.bat")
    with open(script, "w", encoding="utf-8", newline="\r\n") as f:
        f.write(BAT)
    return script


def _log_launch(app, text: str) -> None:
    try:
        with open(os.path.join(updates_dir(app), "launch.log"), "a", encoding="utf-8") as f:
            f.write(time.strftime("%Y-%m-%d %H:%M:%S ") + text + "\n")
    except Exception:
        pass


def launch_windows_update(app) -> None:
    """اسکریپت را مثل دوبار کلیک کاربر (ShellExecute، همان روشِ تست‌شده) اجرا می‌کند، ولی از طریق یک فایل VBS کوچک
    تا پنجرهٔ سیاه دیده نشود. اگر VBS شروع نشد، خود bat با پنجرهٔ دیدنی اجرا می‌شود. هر مرحله در updates/launch.log."""
    script = write_windows_script(app)
    vbs = os.path.join(updates_dir(app), "apply_update.vbs")
    try:
        with open(vbs, "w", encoding="utf-16") as f:
            f.write('Set sh = CreateObject("WScript.Shell")\r\n'
                    'sh.Run "cmd /c ""' + script.replace('"', '') + '""", 0, False\r\n')
        _log_launch(app, "launching hidden via vbs")
        os.startfile(vbs)                         # فقط ویندوز
        return
    except Exception as e:
        _log_launch(app, f"vbs launch failed, falling back to visible bat: {type(e).__name__}: {e}")
    try:
        os.startfile(script)
    except Exception as e:
        _log_launch(app, f"{type(e).__name__}: {e}")
        raise
