"""بکاپ امن از دیتابیس (حتی وقتی برنامه در حال اجراست):

    python3 backup.py

فایل بکاپ با تاریخ و ساعت در پوشه backups/ ساخته می‌شود. این پوشه را گاهی روی فلش یا
فضای دیگری کپی کنید. (Git فقط کد را نگه می‌دارد، نه اطلاعات ثبت‌شده را.)
"""
import os
import sqlite3
import sys
from datetime import datetime

HERE = os.path.dirname(os.path.abspath(__file__))
SOURCE = os.path.join(HERE, "instance", "cases.sqlite")


from app.backups import make_backup as _make  # noqa: E402


def make_backup(source: str = SOURCE, folder: str | None = None) -> str:
    return _make(source, folder or os.path.join(HERE, "backups"))


if __name__ == "__main__":
    try:
        from app.backups import run_backup
        path, results = run_backup(SOURCE, os.path.join(HERE, "instance", "backup_settings.json"),
                                   os.path.join(HERE, "backups"))
        print("بکاپ ساخته شد:", path)
        for raw, ok, err in results:
            print(" کپی در", raw, "->", "انجام شد" if ok else f"انجام نشد ({err})")
    except FileNotFoundError as e:
        sys.exit(str(e))
