"""تست دودی برنامهٔ در حال اجرا (برای نسخهٔ exe): راه‌اندازی، ورود، ثبت پرونده، داشبورد و PDF."""
import http.cookiejar
import re
import sys
import urllib.parse
import urllib.request

B = sys.argv[1]
jar = http.cookiejar.CookieJar()
op = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))


def get(path):
    r = op.open(B + path, timeout=30)
    return r.status, r.read()


def post(path, data):
    r = op.open(B + path, urllib.parse.urlencode(data, doseq=True).encode(), timeout=60)
    return r.status, r.read()


def csrf(html):
    return re.search(r'name="csrf" value="([^"]+)"', html.decode()).group(1)


st, html = get("/login")                       # برنامهٔ خام باید به /setup برود
assert b"setup" in html or "راه‌اندازی".encode() in html, "setup page not shown"
post("/setup", {"csrf": csrf(html), "username": "boss", "full_name": "T", "password": "abcdef", "password2": "abcdef"})
st, html = get("/login")
post("/login", {"csrf": csrf(html), "username": "boss", "password": "abcdef"})
st, html = get("/cases/new")
t = csrf(html)
post("/cases/new", {"csrf": t, "case_type": "tender", "organization": "", "prod_uid": ["new-1"],
                    "prod_product_type": [""], "prod_size": [""], "prod_quantity": ["3"], "prod_model": [""],
                    "prod_sample": [""]})
st, data = get("/cases/1/report.pdf")
assert data[:4] == b"%PDF" and len(data) > 5000, "pdf failed"
assert get("/api/dashboard")[0] == 200
assert get("/admin/logs")[0] == 200
assert get("/admin/update")[0] == 200          # صفحهٔ به‌روزرسانی (حتی بدون اینترنت باز می‌شود)
print("SMOKE OK, pdf bytes:", len(data))
