"""پاک‌سازی همهٔ کارتابل‌ها و سابقهٔ گردش (برای آزمایش) با یک دستور:

    python3 reset_workflow.py

- ابتدا بکاپ کامل دیتابیس ساخته می‌شود (چیزی واقعاً از بین نمی‌رود).
- پرونده‌ها، کاربران، تنظیمات و «مراحل گردش کار» می‌مانند.
- فقط «وضعیت پرونده‌ها در گردش» و «سابقهٔ ارجاع‌ها» پاک می‌شود؛ همهٔ پرونده‌ها «خارج از گردش» می‌شوند.
- قبل از اجرا، برنامه (run.py) را با Control+C متوقف کنید.
"""
import os
import sqlite3
import sys

from backup import SOURCE, make_backup


def reset(source: str = SOURCE, folder: str | None = None, ask=input) -> str | None:
    if not os.path.exists(source):
        raise FileNotFoundError(f"دیتابیس پیدا نشد: {source}")
    if ask("همهٔ کارتابل‌ها و سابقهٔ ارجاع‌ها پاک شود؟ (پرونده‌ها می‌مانند) برای تأیید بنویسید YES: ").strip() != "YES":
        print("لغو شد؛ هیچ چیز تغییر نکرد.")
        return None
    backup_path = make_backup(source, folder)
    print("بکاپ کامل ساخته شد:", backup_path)
    conn = sqlite3.connect(source)
    try:
        conn.executescript("""
            DROP TRIGGER IF EXISTS wf_cases_no_delete;
            DROP TRIGGER IF EXISTS wf_log_no_delete;
            DELETE FROM wf_cases;
            DELETE FROM wf_log;
        """)
        conn.commit()
    finally:
        conn.close()
    from app.db import init_db          # محافظ‌های ضد حذف دوباره ساخته می‌شوند
    init_db(source)
    print("تمام شد. همهٔ کارتابل‌ها خالی شدند و پرونده‌ها سر جایشان هستند.")
    return backup_path


if __name__ == "__main__":
    try:
        reset()
    except FileNotFoundError as e:
        sys.exit(str(e))
