"""صفحه‌های کارتابل و تنظیمات گردش کار (به routes.bp اضافه می‌شوند)."""
from flask import abort, flash, g, redirect, render_template, request, url_for

from . import audit, case_data, config, perms, workflow
from .auth import check_csrf, login_required, roles_required
from .db import get_db
from .routes import bp


def _case_or_404(case_id):
    case = case_data.load_case(get_db(), case_id)
    if case is None:
        abort(404)
    return case


def _back(case_id):
    return redirect(url_for("main.case_edit", case_id=case_id))


@bp.before_request
def _wf_switch_guard():
    """وقتی کارتابل خاموش است، صفحه‌ها و عمل‌های آن وجود ندارند."""
    if request.endpoint in ("main.cartable", "main.wf_action", "main.wf_save") and not workflow.enabled(get_db()):
        abort(404)


@bp.route("/cartable")
@login_required
def cartable():
    db = get_db()
    tab = request.args.get("tab", "inbox")
    return render_template("cartable.html", tab=tab, inbox=workflow.inbox(db, g.user["id"]),
                           sent=workflow.sent(db, g.user["id"]), done=workflow.done(db, g.user["id"]),
                           col_titles=workflow.COL_TITLES, sent_cols=workflow.SENT_COLS,
                           can_work=g.user["role"] in config.ROLES_CAN_CREATE)


@bp.route("/cases/<int:case_id>/wf/<action>", methods=["POST"])
@roles_required(*config.ROLES_CAN_CREATE)
def wf_action(case_id: int, action: str):
    db = get_db()
    check_csrf()
    case = _case_or_404(case_id)
    note = (request.form.get("note") or "").strip()[:300]
    try:
        if action == "send":
            try:
                to = int(request.form.get("to", ""))
            except ValueError:
                raise workflow.WfError("گیرنده را انتخاب کنید.")
            r = workflow.send(db, g.user, case, to, note)
            db.commit()
            flash(f"پرونده برای «{r['to']}» (مرحلهٔ {r['stage']}) ارسال شد.", "success")
            return redirect(url_for("main.cartable", tab="sent"))
        if action == "back":
            r = workflow.send_back(db, g.user, case, note)
            db.commit()
            flash(f"پرونده به «{r['to']}» برگشت داده شد.", "success")
            return redirect(url_for("main.cartable", tab="sent"))
        if action == "reopen":
            workflow.reopen(db, g.user, case)
            db.commit()
            flash("پرونده دوباره باز شد و در «کارتابل من» است.", "success")
            return redirect(url_for("main.cartable"))
        if action == "recall":
            workflow.recall(db, g.user, case)
            db.commit()
            flash("پرونده را پس گرفتید؛ دوباره در «کارتابل من» است و می‌توانید ویرایش و ارسال کنید.", "success")
            return redirect(url_for("main.cartable"))
        if action == "done":
            workflow.complete(db, g.user, case)
            db.commit()
            flash("گردش پرونده تکمیل شد.", "success")
            return redirect(url_for("main.cartable", tab="done"))
        if action == "reassign":
            if g.user["role"] != "admin":
                abort(403)
            try:
                to, sid = int(request.form.get("to", "")), int(request.form.get("stage", ""))
            except ValueError:
                raise workflow.WfError("مرحله و کاربر را انتخاب کنید.")
            workflow.reassign(db, g.user, case, to, sid)
            db.commit()
            flash("پرونده جابه‌جا شد.", "success")
            return _back(case_id)
    except workflow.WfError as e:
        flash(str(e), "error")
        return redirect(url_for("main.cartable", tab="sent")) if action in ("recall", "reopen") else _back(case_id)
    abort(404)


# ------------------------------------------------------------------ تنظیمات مدیر
@bp.route("/settings/workflow", methods=["GET", "POST"])
@roles_required("admin")
def settings_workflow():
    db = get_db()
    grp = request.args.get("grp", "استعلام")
    if grp not in ("مناقصه", "استعلام", "مزایده"):
        grp = "استعلام"
    if request.method == "POST" and request.form.get("switch") in ("on", "off"):
        check_csrf()
        on = request.form.get("switch") == "on"
        workflow.set_enabled(db, on)
        audit.log(db, "wf_config", "کارتابل " + ("روشن شد" if on else "خاموش شد"))
        db.commit()
        flash("کارتابل " + ("روشن شد." if on else "خاموش شد؛ برنامه مثل قبل از کارتابل کار می‌کند."), "success")
        return redirect(url_for("main.settings_workflow", grp=grp))
    if not workflow.enabled(db):
        return render_template("settings_workflow.html", off=True, grp=grp, stages=[], kinds=(), columns=(), field_groups=(), titles=(), flow=[], to_fa=lambda x: x)
    if request.method == "POST":
        check_csrf()
        n = _save_stages(db, grp)
        audit.log(db, "wf_config", f"مراحل گردش «{grp}» ذخیره شد ({n} مرحله)")
        db.commit()
        flash("مراحل گردش کار ذخیره شد.", "success")
        return redirect(url_for("main.settings_workflow", grp=grp))
    sts = workflow.stages(db, grp, only_active=False)
    for s in sts:
        s["edit_set"] = set(workflow._csv(s["edit_keys"]))
        s["req_set"] = set(workflow._csv(s["required_keys"]))
        s["col_list"] = workflow._csv(s["columns"])
    titles = sorted({r["job_title"] for r in db.execute("SELECT DISTINCT job_title FROM users WHERE job_title != ''")}
                    | {r["job_title"] for r in db.execute("SELECT DISTINCT job_title FROM wf_stages WHERE job_title != ''")})
    flow = [dict(r) for r in db.execute(
        "SELECT c.id, c.case_type, c.year, c.serial_no, c.organization, s.name AS stage_name, w.status, "
        "COALESCE(NULLIF(h.full_name,''), h.username) AS holder FROM wf_cases w JOIN cases c ON c.id = w.case_id "
        "LEFT JOIN wf_stages s ON s.id = w.stage_id LEFT JOIN users h ON h.id = w.holder_id ORDER BY w.updated_at DESC LIMIT 200")]
    return render_template("settings_workflow.html", off=False, grp=grp, stages=sts, kinds=workflow.KINDS, columns=workflow.COLUMNS,
                           field_groups=[(t, [(k, l) for k, l in items if k in workflow.field_universe()])
                                         for t, items in perms.groups() if t.startswith(("فرم", "جدول", "اطلاعات"))],
                           titles=titles, flow=flow, to_fa=__import__("app.jalali", fromlist=["x"]).to_fa_digits)


def _save_stages(db, grp: str) -> int:
    uni = workflow.field_universe()
    ids = request.form.getlist("sid")
    n = 0
    for i, sid in enumerate(ids):
        name = (request.form.get(f"name_{sid}") or "").strip()[:60]
        if not name and sid.startswith("new"):
            continue
        name = name or "مرحله"
        kind = request.form.get(f"kind_{sid}", "work")
        if kind not in dict(workflow.KINDS):
            kind = "work"
        edit = ",".join(k for k in request.form.getlist(f"edit_{sid}") if k in uni)
        req = ",".join(k for k in request.form.getlist(f"req_{sid}") if k in uni)
        cols = ",".join(k for k in request.form.getlist(f"col_{sid}") if k in workflow.COL_TITLES)
        job = (request.form.get(f"job_{sid}") or "").strip()[:60]
        try:
            pos = int(request.form.get(f"pos_{sid}", i + 1))
        except ValueError:
            pos = i + 1
        active = 1 if request.form.get(f"active_{sid}") else 0
        free = 1 if request.form.get(f"free_{sid}") else 0
        if sid.startswith("new"):
            db.execute("INSERT INTO wf_stages (grp,pos,name,job_title,kind,edit_keys,required_keys,columns,active,free_send) VALUES (?,?,?,?,?,?,?,?,?,?)",
                       (grp, pos, name, job, kind, edit, req, cols, 1, free))
        else:
            db.execute("UPDATE wf_stages SET pos=?, name=?, job_title=?, kind=?, edit_keys=?, required_keys=?, columns=?, active=?, free_send=? WHERE id=? AND grp=?",
                       (pos, name, job, kind, edit, req, cols, active, free, int(sid), grp))
        n += 1
    return n


# ------------------------------------------------------------------ کاربر «فقط کارتابل»
CARTABLE_ONLY_OK = {
    "main.cartable", "main.wf_action", "main.wf_save", "main.case_edit", "main.profile_save", "main.case_report", "main.case_report_pdf",
    "main.case_report_open", "main.option_add", "main.option_rename", "main.org_api", "main.account", "main.help_page",
    "main.tickets_page", "main.ticket_view", "main.ticket_file", "main.news_seen", "main.seat_ping", "main.update_notice",
    "main.manifest", "main.apple_touch_icon", "main.service_worker", "main.next_number",
}


@bp.before_request
def _cartable_only_guard():
    """کاربری که «فقط کارتابل» دارد، به هیچ صفحهٔ دیگری راه ندارد (سمت سرور؛ پنهان کردن منو کافی نیست)."""
    u = g.get("user")
    if u is None or not u["cartable_only"] or u["role"] == "admin":
        return None
    if request.endpoint in CARTABLE_ONLY_OK or request.endpoint is None:
        return None
    return redirect(url_for("main.cartable"))


# ------------------------------------------------------------------ صفحهٔ واحد کارتابل
from . import case_data, options, profile, seats  # noqa: E402
from .jalali import to_fa_digits  # noqa: E402


def _main_kind(key: str) -> str:
    if key in case_data.DATE_FIELDS:
        return "date"
    if key == "notes":
        return "long"
    if key in case_data.OPTION_FIELDS or key == "archive_reason":
        return "combo"
    return "text"


def _edit_fields(db, case, prof, editable, required, override=None):
    """فیلدهای قابل‌ویرایش این مرحله برای بالای صفحه: [{name,label,kind,value,options,required}]"""
    opts = options.options_for_form(db)
    hide = profile.hidden_keys(case["case_type"])
    out = []
    for key in sorted(editable, key=lambda k: (k.startswith("p_"), list(case_data.TEXT_FIELDS).index(k) if k in case_data.TEXT_FIELDS else 99)):
        if key.startswith("p_"):
            name = key[2:]
            meta = next((f for f in profile.PROFILE_FIELDS if f[0] == name), None)
            if not meta or name in hide or name == "announce_date":
                continue
            kind, label, val = meta[2], meta[1], prof.get(name, "")
        elif key in case_data.TEXT_FIELDS:
            name, kind, label, val = key, _main_kind(key), case_data.FIELD_LABELS[key], case.get(key, "")
        else:
            continue
        if override is not None and name in override:
            val = override.get(name, "")
        cur = [val] if val else []
        out.append(dict(name=name, label=label, kind=kind, value=val, required=key in required,
                        options=(opts.get(name, []) + [v for v in cur if v not in opts.get(name, [])]) if kind == "combo" else []))
    return out


def _read_rows(case, prof):
    main = [(case_data.FIELD_LABELS[k], to_fa_digits(case.get(k) or "")) for k in case_data.TEXT_FIELDS if case.get(k)]
    hide = profile.hidden_keys(case["case_type"])
    pr = [(l, to_fa_digits(str(prof.get(k) or ""))) for k, l, _ in profile.PROFILE_FIELDS if k not in hide and prof.get(k)]
    return main, pr


def render_cart(db, case, errors=None, override=None, status=200):
    from .routes import _wf_context
    st = workflow.state(db, case["id"])
    s = workflow.stage(db, st["stage_id"])
    editable = set(workflow._csv(s["edit_keys"])) if st["status"] == "active" else set()
    required = set(workflow._csv(s["required_keys"]))
    prof = profile.load(db, case["id"])
    main_rows, prof_rows = _read_rows(case, prof)
    return render_template("case_cart.html", c=case, wf=_wf_context(case), stage=s, st=st, errors=errors or [],
                           fields=_edit_fields(db, case, prof, editable, required, override), pversion=prof["version"],
                           main_rows=main_rows, prof_rows=prof_rows, CASE_TYPES=config.CASE_TYPES,
                           ARCHIVE_WORD="بایگانی", decision_now=(override.get("decision") if override is not None and "decision" in override else case.get("decision", ""))), status


@bp.route("/cases/<int:case_id>/wf/save", methods=["POST"])
@roles_required(*config.ROLES_CAN_CREATE)
def wf_save(case_id: int):
    """ذخیره (و در صورت درخواست ارسال) از صفحهٔ واحد کارتابل: فقط فیلدهای همین مرحله تغییر می‌کند."""
    db = get_db()
    check_csrf()
    case = _case_or_404(case_id)
    if not workflow.cart_view_ok(db, g.user, case_id):
        abort(403)
    if not seats.acquire(db, g.user["id"]):
        flash(seats.full_message(db), "error")
        return _back(case_id)
    locked = workflow.locks(db, g.user, case_id)
    st = workflow.state(db, case_id)
    if st["status"] != "active":
        abort(403)
    errors = []
    form, denied = perms.apply_locks(request.form, case, locked)
    data, errors = case_data.parse_form(form, db, existing=case)
    denied += perms.restore_tables(data, case, locked, request.form)
    old = profile.load(db, case_id)
    vals, prices, perr = profile.parse(request.form, db, case, old, locked=locked)
    errors = list(errors) + list(perr)
    try:
        expected = int(request.form.get("version", ""))
        pexpected = int(request.form.get("pversion", ""))
    except ValueError:
        abort(400)
    if denied:
        audit.log(db, "perm_denied", "تلاش برای تغییر فیلد قفل‌شده: " + "، ".join(denied), case=case)
    if errors:
        return render_cart(db, case, errors, request.form, 400)
    try:
        changes = audit.case_changes(case, data)
        case_data.save_changes(db, case_id, data, g.user["id"], expected)
        if changes:
            audit.log(db, "case_edit", f"{len(changes)} تغییر", case=case, changes=changes)
        pchanges = audit.profile_changes(old, vals, case["products"], prices)
        profile.save(db, case_id, vals, prices, g.user["id"], pexpected)
        if pchanges:
            audit.log(db, "profile_edit", f"{len(pchanges)} تغییر در شناسنامه", case=case, changes=pchanges)
    except (case_data.ConflictError, profile.Conflict):
        return render_cart(db, case, ["این پرونده در همین فاصله توسط کاربر دیگری تغییر کرد؛ صفحه را دوباره باز کنید."], request.form, 409)
    db.commit()
    if request.form.get("go") == "send":
        try:
            to = int(request.form.get("to", ""))
        except ValueError:
            flash("ذخیره شد؛ برای ارسال گیرنده را انتخاب کنید.", "error")
            return _back(case_id)
        case = _case_or_404(case_id)
        try:
            r = workflow.send(db, g.user, case, to, (request.form.get("note") or "").strip()[:300])
        except workflow.WfError as e:
            flash("ذخیره شد، ولی ارسال نشد: " + str(e), "error")
            return _back(case_id)
        db.commit()
        flash(f"ذخیره و برای «{r['to']}» (مرحلهٔ {r['stage']}) ارسال شد.", "success")
        return redirect(url_for("main.cartable", tab="sent"))
    flash("تغییرات ذخیره شد.", "success")
    return _back(case_id)
