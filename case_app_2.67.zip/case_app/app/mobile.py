"""نمای موبایل مدیریتی: فقط مشاهدهٔ خلاصه و گزارش‌ها (ورود اطلاعات ندارد). همهٔ عددها از همان منبع داشبورد می‌آیند."""
import sqlite3
from collections import Counter

from . import config, dashboard as dash

NONE = "بدون تصمیم"


def decision_of(value: str) -> str:
    if config.matches(value or "", config.ARCHIVE_VALUE):      # «عدم تایید و بایگانی» شامل کلمهٔ «تایید» هم هست؛ اول بایگانی را بسنج
        return "archive"
    if config.matches(value or "", config.APPROVE_VALUE):
        return "approve"
    return "none"


def days_label(days: int) -> str:
    return "گذشته" if days < 0 else ("امروز" if days == 0 else f"{days} روز")


def days_tone(days: int) -> str:
    return "t1" if days <= 3 else ("t2" if days <= 10 else "t3")


def home(db: sqlite3.Connection) -> dict:
    d = dash.build(db, {})
    cnt = Counter()
    status_of_approved = Counter()
    for r in db.execute("SELECT decision, status FROM cases"):
        k = decision_of(r["decision"])
        cnt[k] += 1
        if k == "approve":
            status_of_approved[dash._clean(r["status"]) or dash.UNKNOWN] += 1
    total_approved = cnt["approve"] or 1
    statuses = [dict(label=k, value=v, pct=round(100 * v / total_approved))
                for k, v in sorted(status_of_approved.items(), key=lambda x: -x[1])]
    dl = [dict(x, label=days_label(x["days"]), tone=days_tone(x["days"])) for x in d["deadlines"] if x["days"] >= -7][:6]
    return dict(kpi=d["kpi"], decisions=dict(approve=cnt["approve"], archive=cnt["archive"], none=cnt["none"]),
                statuses=statuses, deadlines=dl, empty=d["empty"])


def reports(db: sqlite3.Connection) -> dict:
    d = dash.build(db, {})
    t = d["trend"]
    totals = [sum(s["values"][i] for s in t["series"]) for i in range(len(t["keys"]))]
    peak = max(totals) if totals and max(totals) else 1
    months = [dict(label=l, value=v, h=max(4, round(100 * v / peak)) if v else 2) for l, v in zip(t["labels"], totals)]
    res_total = sum(r["value"] for r in d["results"]) or 1
    results = [dict(r, pct=round(100 * r["value"] / res_total)) for r in d["results"]]
    return dict(kpi=d["kpi"], months=months, results=results, orgs=d["orgs"][:8], tender=d["tender"], empty=d["empty"])
