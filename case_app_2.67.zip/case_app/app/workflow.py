"""گردش کار (کارتابل): هر پرونده می‌تواند مرحله‌به‌مرحله بین کاربران دست‌به‌دست شود.

- مراحل هر «گروه پرونده» (مناقصه / استعلام / مزایده) در جدول wf_stages است و مدیر در تنظیمات عوضشان می‌کند.
- هر مرحله: نام، سمتِ مسئول، فیلدهایی که صاحب مرحله می‌تواند ویرایش کند، فیلدهای الزامی برای ارجاع، ستون‌های کارتابل.
- پرونده‌ای که wf_cases ندارد «خارج از گردش» است و مثل قبل رفتار می‌کند (هیچ پرونده‌ای گم یا پنهان نمی‌شود).
- پروندهٔ در گردش فقط پیش یک نفر (holder) است. «ثبت‌کننده»‌های دیگر آن را نمی‌بینند؛ مدیر و «بیننده» فقط‌خواندنی می‌بینند.
- قفل فیلدها از همان سامانهٔ perms (قفل هر کاربر) ساخته می‌شود: فیلدهای خارج از edit_keys مرحله قفل‌اند.
"""
import sqlite3

from . import audit, case_data, config, perms, profile
from .jalali import gregorian_to_jalali, to_fa_digits

KINDS = (("start", "ثبت (شروع)"), ("work", "کار"), ("final", "اطلاع و پایان"))
COLUMNS = [("serial", "شمارهٔ شناسنامه"), ("type", "نوع"), ("org", "سازمان"), ("received", "تاریخ دریافت"),
           ("deadline", "مهلت ارسال"), ("status", "وضعیت پرونده"), ("decision", "تصمیم مدیریتی"), ("stage", "مرحله"),
           ("sender", "از طرف"), ("holder", "الان پیش"), ("arrived", "رسیده در"), ("last", "آخرین اقدام")]
COL_TITLES = dict(COLUMNS)
DEFAULT_COLS = "serial,type,org,received,deadline,sender,arrived"
SENT_COLS = ("serial", "type", "org", "holder", "stage", "last")
ACTION_TITLES = {"recall": "پس‌گرفتن", "send": "ارجاع", "return": "برگشت", "done": "تکمیل", "reassign": "تغییر توسط مدیر"}
_NOT_FIELD = ("type_", "ui_")


def enabled(db) -> bool:
    """کلید کلی کارتابل (تنظیمات ← گردش کار). پیش‌فرض خاموش است؛ خاموش = برنامه دقیقاً مثل قبل از کارتابل."""
    r = db.execute("SELECT value FROM settings WHERE key = 'workflow_enabled'").fetchone()
    return bool(r and r["value"] == "1")


def set_enabled(db, on: bool) -> None:
    db.execute("INSERT OR REPLACE INTO settings (key, value) VALUES ('workflow_enabled', ?)", ("1" if on else "0"))


def now() -> str:
    return audit.now_text()


def jdt(text: str) -> str:
    """'2026-11-16 10:30:00' ← '۱۴۰۵/۰۸/۲۵ ۱۰:۳۰' (برای نمایش)."""
    try:
        d, t = (text or "").split(" ")
        y, m, dd = (int(x) for x in d.split("-"))
        return to_fa_digits("%04d/%02d/%02d %s" % (*gregorian_to_jalali(y, m, dd), t[:5]))
    except (ValueError, TypeError):
        return text or ""


def field_universe() -> set:
    """همهٔ کلیدهایی که می‌توان برای یک مرحله «قابل ویرایش» کرد (بدون کلیدهای نوع پرونده و دکمه‌ها)."""
    return {k for k in perms.all_keys() if not k.startswith(_NOT_FIELD)}


def _csv(text) -> list:
    return [x for x in (text or "").split(",") if x]


# ------------------------------------------------------------------ مراحل پیش‌فرض
def seed_defaults(conn) -> None:
    """فقط یک بار (اگر جدول مراحل خالی است): مراحل نمونهٔ «استعلام» طبق جلسهٔ شرکت. مدیر می‌تواند همه را عوض کند."""
    if conn.execute("SELECT 1 FROM wf_stages LIMIT 1").fetchone():
        return
    after_decision = {"decision", "archive_reason", "result", "result_date", "p_manager_sign", "p_ceo_notes"}
    start_edit = ",".join(sorted(field_universe() - after_decision))
    rows = [
        ("استعلام", 1, "ثبت", "کارشناس بازرگانی", "start", start_edit, "", ""),
        ("استعلام", 2, "امضای بازرگانی", "مدیر بازرگانی", "work", "p_manager_sign", "p_manager_sign", "serial,type,org,received,deadline,sender,arrived"),
        ("استعلام", 3, "تصمیم مدیرعامل", "مدیرعامل", "work", "decision,archive_reason", "decision", "serial,org,deadline,sender,arrived"),
        ("استعلام", 4, "اطلاع از نتیجه", "مدیر بازرگانی", "final", "", "", "serial,org,decision,sender,arrived"),
    ]
    for r in rows:
        conn.execute("INSERT INTO wf_stages (grp, pos, name, job_title, kind, edit_keys, required_keys, columns) VALUES (?,?,?,?,?,?,?,?)", r)


# ------------------------------------------------------------------ خواندن
def group_of(case_type: str) -> str:
    return config.CASE_GROUPS.get(case_type, "")


def stages(db, grp: str, only_active=True) -> list:
    q = "SELECT * FROM wf_stages WHERE grp = ?" + (" AND active = 1" if only_active else "") + " ORDER BY pos, id"
    return [dict(r) for r in db.execute(q, (grp,))]


def stage(db, sid):
    r = db.execute("SELECT * FROM wf_stages WHERE id = ?", (sid,)).fetchone()
    return dict(r) if r else None


def configured(db, grp: str) -> bool:
    return len(stages(db, grp)) >= 2


def state(db, case_id: int):
    """وضعیت پرونده در گردش یا None (خارج از گردش)."""
    r = db.execute(
        "SELECT w.*, s.name AS stage_name, s.pos AS stage_pos, s.kind AS stage_kind, s.job_title AS stage_title, "
        "COALESCE(NULLIF(h.full_name, ''), h.username) AS holder_name, COALESCE(NULLIF(sn.full_name, ''), sn.username) AS sender_name "
        "FROM wf_cases w LEFT JOIN wf_stages s ON s.id = w.stage_id LEFT JOIN users h ON h.id = w.holder_id "
        "LEFT JOIN users sn ON sn.id = w.sender_id WHERE w.case_id = ?", (case_id,)).fetchone()
    return dict(r) if r else None


def is_hidden_for(db, user, case_id: int) -> bool:
    """پروندهٔ در گردش را فقط صاحب فعلی و مدیر و «بیننده» می‌بینند (ثبت‌کنندهٔ دیگر نمی‌بیند)."""
    if user is None or user["role"] == "admin" or not enabled(db):
        return False
    st = db.execute("SELECT holder_id, status FROM wf_cases WHERE case_id = ?", (case_id,)).fetchone()
    if user["cartable_only"]:                    # «فقط کارتابل»: فقط پرونده‌هایی که الان پیش خودش است
        return not (st and st["holder_id"] == user["id"])
    if user["role"] != "entry":
        return False
    return bool(st and st["status"] == "active" and st["holder_id"] != user["id"])


def hidden_ids(db, user) -> set:
    if user is None or user["role"] != "entry" or user["cartable_only"] or not enabled(db):
        return set()
    # پروندهٔ در گردشِ دیگران پنهان است، مگر خودش آن را فرستاده باشد (تا مرحله‌اش را در لیست ببیند)
    return {r["case_id"] for r in db.execute(
        "SELECT w.case_id FROM wf_cases w WHERE w.status = 'active' AND w.holder_id != ? AND NOT EXISTS "
        "(SELECT 1 FROM wf_log l WHERE l.case_id = w.case_id AND l.from_user = ?)", (user["id"], user["id"]))}


def locks(db, user, case_id) -> frozenset:
    """قفل‌های این کاربر روی این پرونده: قفل‌های شخصی + (اگر پرونده پیش اوست) همهٔ فیلدهای خارج از مرحله."""
    base = perms.locked_for(user)
    if not case_id or user is None or user["role"] == "admin" or not enabled(db):
        return base
    st = state(db, case_id)
    if st and st["status"] == "done" and st["holder_id"] == user["id"]:
        return frozenset(base | field_universe())            # گردش تمام شده: فقط‌خواندنی
    if not st or st["status"] != "active" or st["holder_id"] != user["id"]:
        return base
    s = stage(db, st["stage_id"])
    editable = set(_csv(s["edit_keys"])) if s else set()
    return frozenset(base | (field_universe() - editable))


CART_UNSUPPORTED = {"case_type", "products", "competitors", "p_prices"}


def cart_view_ok(db, user, case_id: int) -> bool:
    """آیا این کاربر باید «صفحهٔ واحد کارتابل» را ببیند؟ (صاحب فعلیِ پروندهٔ در گردش، در مرحلهٔ غیر از «ثبت»؛ مدیر و ثبت‌کننده همان فرم کامل را می‌بینند)."""
    if user is None or user["role"] == "admin" or not enabled(db):
        return False
    st = state(db, case_id)
    if not st or st["holder_id"] != user["id"]:
        return False
    if st["status"] == "done":
        return True
    s = stage(db, st["stage_id"])
    if not s or s["kind"] == "start":
        return False
    return not (set(_csv(s["edit_keys"])) & CART_UNSUPPORTED)


def candidates(db, stage_row: dict) -> tuple:
    """(همهٔ کاربران فعال با نقش ثبت‌کننده/مدیر، اول کسانی که سمتِ این مرحله را دارند؛ آیا کسی با آن سمت پیدا شد؟)."""
    users = [dict(r) for r in db.execute(
        "SELECT id, username, COALESCE(NULLIF(full_name, ''), username) AS name, job_title, role FROM users "
        "WHERE active = 1 AND role IN ('entry', 'admin') ORDER BY id")]
    title = (stage_row.get("job_title") or "").strip()
    hit = [u for u in users if title and u["job_title"].strip() == title]
    rest = [u for u in users if u not in hit]
    return hit + rest, bool(hit)             # همهٔ کاربران (مدیر هم)؛ دارندگان سمتِ مرحله اول لیست‌اند


def _names(db) -> dict:
    return {r["id"]: r["name"] for r in db.execute("SELECT id, COALESCE(NULLIF(full_name, ''), username) AS name FROM users")}


def history(db, case_id: int) -> list:
    names = _names(db)
    stg = {r["id"]: r["name"] for r in db.execute("SELECT id, name FROM wf_stages")}
    out = []
    for r in db.execute("SELECT * FROM wf_log WHERE case_id = ? ORDER BY id", (case_id,)):
        out.append(dict(r, from_name=names.get(r["from_user"], ""), to_name=names.get(r["to_user"], ""),
                        from_stage_name=stg.get(r["from_stage"], ""), to_stage_name=stg.get(r["to_stage"], ""),
                        title=ACTION_TITLES.get(r["action"], r["action"]), when=jdt(r["at"])))
    return out


def suggest_user(db, case_id: int, cands: list):
    """نفرِ پیشنهادی: آخرین کسی که پرونده پیش او بوده (اگر در لیست مجازها باشد)."""
    ids = [c["id"] for c in cands]
    for r in db.execute("SELECT to_user FROM wf_log WHERE case_id = ? AND to_user IS NOT NULL ORDER BY id DESC", (case_id,)):
        if r["to_user"] in ids:
            return r["to_user"]
    return ids[0] if len(ids) == 1 else None


# ------------------------------------------------------------------ اقدام‌ها
class WfError(Exception):
    pass


def _value(db, case: dict, key: str) -> str:
    if key.startswith("p_"):
        return str(profile.load(db, case["id"]).get(key[2:], "") or "").strip()
    v = case.get(key, "")
    return str(v or "").strip()


def _missing(db, case: dict, st_row: dict) -> list:
    out = []
    for k in _csv(st_row["required_keys"]):
        if not _value(db, case, k):
            out.append(perms.label_of(k))
    return out


def _current_stage(db, case: dict):
    """(مرحلهٔ فعلی، حالت). پروندهٔ خارج از گردش در مرحلهٔ شروع حساب می‌شود."""
    grp = group_of(case["case_type"])
    sts = stages(db, grp)
    if len(sts) < 2:
        raise WfError("برای این نوع پرونده گردش کار تنظیم نشده است (مدیر: تنظیمات ← گردش کار).")
    st = state(db, case["id"])
    if st is None:
        return sts[0], None, sts
    if st["status"] != "active":
        raise WfError("گردش این پرونده تکمیل شده است.")
    cur = stage(db, st["stage_id"])
    return cur, st, sts


def can_act(db, user, case: dict) -> bool:
    """آیا این کاربر الان می‌تواند پرونده را ارجاع بدهد/برگرداند؟ (صاحب فعلی؛ یا هر ثبت‌کننده برای پروندهٔ خارج از گردش)."""
    if user["role"] not in config.ROLES_CAN_CREATE:
        return False
    st = state(db, case["id"])
    if st is None:
        return configured(db, group_of(case["case_type"]))
    return st["status"] == "active" and st["holder_id"] == user["id"]


def _set(db, case_id, stage_id, holder, sender, status="active"):
    t = now()
    if db.execute("SELECT 1 FROM wf_cases WHERE case_id = ?", (case_id,)).fetchone():
        db.execute("UPDATE wf_cases SET stage_id=?, holder_id=?, sender_id=?, status=?, updated_at=? WHERE case_id=?",
                   (stage_id, holder, sender, status, t, case_id))
    else:
        db.execute("INSERT INTO wf_cases (case_id, stage_id, holder_id, sender_id, status, entered_at, updated_at) VALUES (?,?,?,?,?,?,?)",
                   (case_id, stage_id, holder, sender, status, t, t))


def _who(db, uid) -> str:
    return _names(db).get(uid, "") if uid else ""


def _note(note: str) -> str:
    return f" — یادداشت: «{note}»" if note else ""


def _log(db, case_id, action, frm, to, fs, ts, note=""):
    db.execute("INSERT INTO wf_log (case_id, at, action, from_user, to_user, from_stage, to_stage, note) VALUES (?,?,?,?,?,?,?,?)",
               (case_id, now(), action, frm, to, fs, ts, note))


def _resolve_stage(db, sts, cur, to_user):
    """مرحلهٔ مقصد از روی «سمت» گیرنده: مرحله‌ای که سمتش با سمت او یکی است (اول رو به جلو)؛ وگرنه مرحلهٔ بعد."""
    row = db.execute("SELECT job_title FROM users WHERE id = ?", (to_user,)).fetchone()
    title = (row["job_title"] if row else "").strip()
    others = [s for s in sts if s["id"] != cur["id"]]
    key = lambda s: (s["pos"], s["id"])
    hits = [s for s in others if title and (s["job_title"] or "").strip() == title]
    fwd = [s for s in hits if key(s) > key(cur)]
    if fwd:
        return min(fwd, key=key)
    if hits:
        return max(hits, key=key)
    nxt = [s for s in others if key(s) > key(cur)]
    return min(nxt, key=key) if nxt else None


def send_free(db, user, case: dict, to_user: int, note: str = "") -> dict:
    """ارسال به هر نفر (فقط اگر مدیر برای مرحلهٔ فعلی «ارسال آزاد» را فعال کرده): مرحله از روی سمت گیرنده تعیین می‌شود."""
    if not can_act(db, user, case):
        raise WfError("این پرونده الان پیش شما نیست.")
    cur, st, sts = _current_stage(db, case)
    if not cur.get("free_send"):
        raise WfError("در این مرحله ارسال آزاد فعال نیست.")
    users_ok, _ = candidates(db, {"job_title": ""})
    if to_user not in [c["id"] for c in users_ok]:
        raise WfError("گیرندهٔ انتخاب‌شده مجاز نیست.")
    tgt = _resolve_stage(db, sts, cur, to_user)
    if tgt is None:
        raise WfError("مرحلهٔ مناسبی برای این گیرنده پیدا نشد؛ سمت او را در «کاربران» بنویسید یا مدیر پرونده را جابه‌جا کند.")
    if (tgt["pos"], tgt["id"]) > (cur["pos"], cur["id"]):          # رو به جلو: فیلدهای الزامی لازم است
        miss = _missing(db, case, cur)
        if miss:
            raise WfError("اول این فیلد را پر و ذخیره کنید: «" + "، ".join(miss) + "»")
    _set(db, case["id"], tgt["id"], to_user, user["id"])
    _log(db, case["id"], "send", user["id"], to_user, cur["id"], tgt["id"], note)
    names = _names(db)
    audit.log(db, "wf_send", f"{names.get(user['id'], '')} ← {names.get(to_user, '')}: از مرحلهٔ «{cur['name']}» به «{tgt['name']}»" + _note(note), case=case)
    return {"to": names.get(to_user, ""), "stage": tgt["name"]}


def send(db, user, case: dict, to_user: int, note: str = "") -> dict:
    """ارجاع به مرحلهٔ بعد، برای نفر انتخاب‌شده. خروجی: {'to': نام، 'stage': نام مرحله}"""
    if not can_act(db, user, case):
        raise WfError("این پرونده الان پیش شما نیست.")
    cur, st, sts = _current_stage(db, case)
    if cur.get("free_send"):
        return send_free(db, user, case, to_user, note)
    miss = _missing(db, case, cur)
    if miss:
        raise WfError("اول این فیلد را پر و ذخیره کنید: «" + "، ".join(miss) + "»")
    nxt = next((s for s in sts if (s["pos"], s["id"]) > (cur["pos"], cur["id"])), None)
    if cur["kind"] == "final" or nxt is None:
        raise WfError("این آخرین مرحله است؛ از دکمهٔ «تکمیل و بستن» استفاده کنید.")
    cands, _ = candidates(db, nxt)
    if to_user not in [c["id"] for c in cands]:
        raise WfError("گیرندهٔ انتخاب‌شده برای مرحلهٔ «" + nxt["name"] + "» مجاز نیست.")
    _set(db, case["id"], nxt["id"], to_user, user["id"])
    _log(db, case["id"], "send", user["id"], to_user, cur["id"], nxt["id"], note)
    names = _names(db)
    audit.log(db, "wf_send", f"{names.get(user['id'], '')} ← {names.get(to_user, '')}: از مرحلهٔ «{cur['name']}» به «{nxt['name']}»" + _note(note), case=case)
    return {"to": names.get(to_user, ""), "stage": nxt["name"]}


def send_back(db, user, case: dict, note: str = "") -> dict:
    """برگرداندن به نفر و مرحلهٔ قبلی (همان که پرونده را فرستاده بود)."""
    st = state(db, case["id"])
    if st is None or st["status"] != "active" or st["holder_id"] != user["id"]:
        raise WfError("این پرونده الان پیش شما نیست.")
    last = db.execute("SELECT * FROM wf_log WHERE case_id = ? AND to_user = ? AND action IN ('send','return','reassign') "
                      "ORDER BY id DESC LIMIT 1", (case["id"], user["id"])).fetchone()
    if not last or not last["from_user"] or not last["from_stage"]:
        raise WfError("فرستندهٔ قبلی پیدا نشد؛ از مدیر بخواهید پرونده را جابه‌جا کند.")
    _set(db, case["id"], last["from_stage"], last["from_user"], user["id"])
    _log(db, case["id"], "return", user["id"], last["from_user"], st["stage_id"], last["from_stage"], note)
    names = _names(db)
    audit.log(db, "wf_return", f"{names.get(user['id'], '')} پرونده را به {names.get(last['from_user'], '')} برگرداند (مرحلهٔ «{stage(db, last['from_stage'])['name']}»)" + _note(note), case=case)
    return {"to": names.get(last["from_user"], "")}


def _recallable_log(db, case_id: int, user_id: int):
    """اگر آخرین اقدام روی پرونده، ارسال/برگشتِ همین کاربر بوده و پرونده هنوز پیش گیرنده است، آن ردیف را برمی‌گرداند."""
    st = db.execute("SELECT holder_id, status FROM wf_cases WHERE case_id = ?", (case_id,)).fetchone()
    if not st or st["status"] != "active" or st["holder_id"] == user_id:
        return None
    last = db.execute("SELECT * FROM wf_log WHERE case_id = ? ORDER BY id DESC LIMIT 1", (case_id,)).fetchone()
    if last and last["from_user"] == user_id and last["action"] in ("send", "return") and last["from_stage"]:
        return last
    return None


def recall(db, user, case: dict) -> None:
    """فرستنده پرونده را پس می‌گیرد (تا وقتی گیرنده کاری نکرده و جلو نفرستاده)."""
    last = _recallable_log(db, case["id"], user["id"])
    if not last:
        raise WfError("این پرونده را دیگر نمی‌شود پس گرفت (گیرنده آن را جلو برده یا پیش شما نبوده).")
    old = state(db, case["id"])
    _set(db, case["id"], last["from_stage"], user["id"], last["to_user"])
    _log(db, case["id"], "recall", user["id"], user["id"], old["stage_id"], last["from_stage"])
    audit.log(db, "wf_recall", f"{_who(db, user['id'])} پرونده را از {_who(db, last['to_user'])} پس گرفت (مرحلهٔ «{stage(db, last['from_stage'])['name']}»)", case=case)


def _reopenable(db, case_id: int, user_id: int) -> bool:
    st = db.execute("SELECT holder_id, status FROM wf_cases WHERE case_id = ?", (case_id,)).fetchone()
    last = db.execute("SELECT action, from_user FROM wf_log WHERE case_id = ? ORDER BY id DESC LIMIT 1", (case_id,)).fetchone()
    return bool(st and st["status"] == "done" and st["holder_id"] == user_id and last and last["action"] == "done" and last["from_user"] == user_id)


def reopen(db, user, case: dict) -> None:
    """اگر «تکمیل و بستن» اشتباه زده شد، همان کسی که بست می‌تواند دوباره بازش کند."""
    if not _reopenable(db, case["id"], user["id"]):
        raise WfError("این پرونده را دیگر نمی‌شود دوباره باز کرد.")
    st = state(db, case["id"])
    _set(db, case["id"], st["stage_id"], user["id"], st["sender_id"])
    _log(db, case["id"], "recall", user["id"], user["id"], st["stage_id"], st["stage_id"], "بازکردن دوباره")
    audit.log(db, "wf_reopen", f"{_who(db, user['id'])} گردش بسته‌شده را دوباره باز کرد", case=case)


def complete(db, user, case: dict) -> None:
    st = state(db, case["id"])
    if st is None or st["status"] != "active" or st["holder_id"] != user["id"]:
        raise WfError("این پرونده الان پیش شما نیست.")
    if st["stage_kind"] != "final":
        raise WfError("این مرحله آخرین مرحله نیست؛ پرونده را ارجاع بدهید.")
    _set(db, case["id"], st["stage_id"], user["id"], st["sender_id"], status="done")
    _log(db, case["id"], "done", user["id"], None, st["stage_id"], None)
    audit.log(db, "wf_done", f"{_who(db, user['id'])} گردش پرونده را تکمیل و بست (مرحلهٔ «{st['stage_name']}»)", case=case)


def reassign(db, admin, case: dict, to_user: int, stage_id: int) -> None:
    """فقط مدیر: پرونده را در هر مرحله‌ای به هر نفری بدهد (حتی پروندهٔ خارج از گردش یا تمام‌شده را دوباره وارد گردش کند)."""
    s = stage(db, stage_id)
    if not s or s["grp"] != group_of(case["case_type"]):
        raise WfError("مرحلهٔ انتخاب‌شده برای این نوع پرونده نیست.")
    u = db.execute("SELECT id, role, active FROM users WHERE id = ?", (to_user,)).fetchone()
    if not u or not u["active"] or u["role"] not in config.ROLES_CAN_CREATE:
        raise WfError("کاربر انتخاب‌شده نمی‌تواند پرونده را بگیرد.")
    old = state(db, case["id"])
    _set(db, case["id"], stage_id, to_user, admin["id"])
    _log(db, case["id"], "reassign", admin["id"], to_user, old["stage_id"] if old else None, stage_id)
    audit.log(db, "wf_reassign", f"مدیر ({_who(db, admin['id'])}) پرونده را به {_who(db, to_user)} داد (مرحلهٔ «{s['name']}»)", case=case)


# ------------------------------------------------------------------ لیست‌های کارتابل
_BASE = ("SELECT c.id, c.case_type, c.year, c.serial_no, c.organization, c.received_date, c.send_deadline, c.status, c.decision, "
         "w.stage_id, w.holder_id, w.sender_id, w.status AS wf_status, w.updated_at, w.entered_at, "
         "s.name AS stage_name, s.columns AS stage_columns, s.pos AS stage_pos, "
         "COALESCE(NULLIF(h.full_name, ''), h.username) AS holder_name, COALESCE(NULLIF(sn.full_name, ''), sn.username) AS sender_name "
         "FROM wf_cases w JOIN cases c ON c.id = w.case_id LEFT JOIN wf_stages s ON s.id = w.stage_id "
         "LEFT JOIN users h ON h.id = w.holder_id LEFT JOIN users sn ON sn.id = w.sender_id ")


def _last_action(db, case_id: int) -> str:
    r = db.execute("SELECT action, at FROM wf_log WHERE case_id = ? ORDER BY id DESC LIMIT 1", (case_id,)).fetchone()
    return f"{ACTION_TITLES.get(r['action'], r['action'])} · {jdt(r['at'])}" if r else ""


def cell(db, row: dict, key: str) -> str:
    if key == "serial":
        return to_fa_digits(f"{row['year']}-{row['serial_no']}")
    if key == "type":
        return config.CASE_TYPES.get(row["case_type"], row["case_type"])
    m = {"org": "organization", "received": "received_date", "deadline": "send_deadline", "status": "status", "decision": "decision",
         "stage": "stage_name", "sender": "sender_name", "holder": "holder_name"}
    if key in m:
        return to_fa_digits(row[m[key]] or "—")
    if key == "arrived":
        return jdt(row["updated_at"])
    if key == "last":
        return _last_action(db, row["id"])
    return ""


def inbox(db, user_id: int) -> list:
    """[(مرحله، ستون‌ها، [سطرها])] برای پرونده‌هایی که الان پیش این کاربر است؛ هر مرحله با ستون‌های خودش."""
    rows = [dict(r) for r in db.execute(_BASE + "WHERE w.holder_id = ? AND w.status = 'active' ORDER BY w.stage_pos, w.updated_at DESC".replace("w.stage_pos", "s.pos"), (user_id,))]
    groups, order = {}, []
    for r in rows:
        if r["stage_id"] not in groups:
            groups[r["stage_id"]] = (r["stage_name"], [k for k in _csv(r["stage_columns"] or DEFAULT_COLS) if k in COL_TITLES] or _csv(DEFAULT_COLS), [])
            order.append(r["stage_id"])
        groups[r["stage_id"]][2].append({"id": r["id"], "cells": None, "_r": r})
    out = []
    for sid in order:
        name, cols, lst = groups[sid]
        for it in lst:
            it["cells"] = [cell(db, it["_r"], k) for k in cols]
            it["stage"] = it["_r"]["stage_name"]
        out.append((name, cols, lst))
    return out


def sent(db, user_id: int) -> list:
    """هر پرونده‌ای که این کاربر یک بار ارسال کرده (حتی اگر الان برگشته یا تمام شده)؛ به‌عنوان سابقه."""
    rows = [dict(r) for r in db.execute(
        _BASE + "WHERE EXISTS (SELECT 1 FROM wf_log l WHERE l.case_id = c.id AND l.from_user = ? AND l.action IN ('send', 'return')) "
        "ORDER BY w.updated_at DESC", (user_id,))]
    out = []
    for r in rows:
        mine = r["holder_id"] == user_id
        if r["wf_status"] == "done":
            note = "تمام‌شده"
        elif mine:
            note = "برگشته به شما"
        else:
            note = ""
        cells = [cell(db, r, k) for k in SENT_COLS]
        if mine:
            cells[SENT_COLS.index("holder")] = "شما"
        out.append({"id": r["id"], "cells": cells, "stage": r["stage_name"], "note": note,
                    "recall": _recallable_log(db, r["id"], user_id) is not None})
    return out


def done(db, user_id: int) -> list:
    rows = [dict(r) for r in db.execute(
        _BASE + "WHERE w.status = 'done' AND EXISTS (SELECT 1 FROM wf_log l WHERE l.case_id = c.id AND (l.from_user = ? OR l.to_user = ?)) "
        "ORDER BY w.updated_at DESC", (user_id, user_id))]
    return [{"id": r["id"], "cells": [cell(db, r, k) for k in SENT_COLS], "stage": r["stage_name"],
             "reopen": _reopenable(db, r["id"], user_id)} for r in rows]


def list_info(db, ids, user) -> dict:
    """برای لیست پرونده‌ها: {شناسهٔ پرونده: {stage, holder, status, mine, steps, hist}} فقط برای پرونده‌های وارد گردش‌شده."""
    ids = [int(i) for i in ids]
    if not ids or not enabled(db):
        return {}
    q = ",".join(str(i) for i in ids)
    stg = {}
    for r in db.execute("SELECT id, grp, pos, name FROM wf_stages WHERE active = 1 ORDER BY pos, id"):
        stg.setdefault(r["grp"], []).append(dict(r))
    out = {}
    for r in db.execute(
            "SELECT w.case_id, w.stage_id, w.holder_id, w.status, w.updated_at, c.case_type, s.name AS sname, s.pos AS spos, "
            "COALESCE(NULLIF(h.full_name,''), h.username) AS holder FROM wf_cases w JOIN cases c ON c.id = w.case_id "
            "LEFT JOIN wf_stages s ON s.id = w.stage_id LEFT JOIN users h ON h.id = w.holder_id WHERE w.case_id IN (" + q + ")"):
        sts = stg.get(group_of(r["case_type"]), [])
        done = r["status"] == "done"
        steps = [{"name": s["name"], "state": "past" if done or s["pos"] < r["spos"] else ("cur" if s["id"] == r["stage_id"] else "")} for s in sts]
        out[r["case_id"]] = dict(stage=r["sname"], holder=r["holder"], status=r["status"], mine=r["holder_id"] == user["id"],
                                 steps=steps, when=jdt(r["updated_at"]), hist=[])
    for h in db.execute("SELECT case_id, at, action, from_user, to_user FROM wf_log WHERE case_id IN (" + q + ") ORDER BY id DESC"):
        d = out.get(h["case_id"])
        if d is not None and len(d["hist"]) < 3:
            d["hist"].append(f"{jdt(h['at'])} — {ACTION_TITLES.get(h['action'], h['action'])}")
    return out


def count_inbox(db, user_id: int) -> int:
    return db.execute("SELECT COUNT(*) FROM wf_cases WHERE holder_id = ? AND status = 'active'", (user_id,)).fetchone()[0]
