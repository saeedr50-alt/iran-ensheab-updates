"""قلب برنامه: صدور شماره شناسنامه برای پرونده جدید.

قانون: برای هر «نوع پرونده» (و هر سال، اگر شماره‌گذاری سالانه باشد)
شماره‌ها جدا از ۱ شروع می‌شوند و بدون جا افتادن و بدون تکرار بالا می‌روند.
"""
import sqlite3

from . import case_data, config
from .jalali import current_jalali_year


class InvalidCaseType(ValueError):
    pass


def period_year(year: int | None = None) -> int:
    """سالی که شمارنده با آن کلید می‌خورد (۰ یعنی شماره‌گذاری ادامه‌دار)."""
    if not config.RESET_NUMBERING_YEARLY:
        return 0
    return year if year is not None else current_jalali_year()


def last_used(db: sqlite3.Connection, case_type: str, year: int) -> int:
    """بزرگ‌ترین شمارهٔ واقعاً موجود برای این نوع و سال. شمارنده هرگز از آن جلوتر نمی‌ماند؛
    پس اگر شمارنده (مثلاً با تغییر نوعِ قدیمی) یک عدد جلو افتاده باشد، خودش اصلاح می‌شود."""
    r = db.execute("SELECT MAX(serial_no) FROM cases WHERE case_type = ? AND year = ?", (case_type, year)).fetchone()
    return r[0] or 0


def peek_next_number(db: sqlite3.Connection, case_type: str, year: int | None = None) -> int:
    """فقط برای نمایش پیش‌نمایش؛ شماره قطعی هنگام ذخیره صادر می‌شود."""
    if case_type not in config.CASE_TYPES:
        raise InvalidCaseType(case_type)
    row = db.execute(
        "SELECT last_no FROM counters WHERE case_type = ? AND year = ?",
        (case_type, period_year(year)),
    ).fetchone()
    return last_used(db, case_type, period_year(year)) + 1


def create_case(db: sqlite3.Connection, case_type: str, user_id: int,
                year: int | None = None, data: dict | None = None) -> dict:
    """پرونده جدید می‌سازد و شماره بعدی را (اتمیک) به آن می‌دهد.

    BEGIN IMMEDIATE باعث می‌شود اگر دو نفر همزمان ذخیره بزنند،
    یکی منتظر بماند تا دیگری تمام شود؛ پس شماره‌ها هرگز تکراری نمی‌شوند.
    اگر data (اطلاعات فرم) داده شود، در همان تراکنش ذخیره می‌شود؛ پس یا
    «شماره + همه اطلاعات» ثبت می‌شود یا هیچ‌کدام (شماره هم مصرف نمی‌شود).
    """
    if case_type not in config.CASE_TYPES:
        raise InvalidCaseType(case_type)
    y = period_year(year)

    db.execute("BEGIN IMMEDIATE")
    try:
        row = db.execute(
            "SELECT last_no FROM counters WHERE case_type = ? AND year = ?",
            (case_type, y),
        ).fetchone()
        number = last_used(db, case_type, y) + 1
        if row is None:
            db.execute(
                "INSERT INTO counters (case_type, year, last_no) VALUES (?, ?, ?)",
                (case_type, y, number),
            )
        else:
            db.execute(
                "UPDATE counters SET last_no = ? WHERE case_type = ? AND year = ?",
                (number, case_type, y),
            )
        cur = db.execute(
            "INSERT INTO cases (case_type, year, serial_no, created_by) VALUES (?, ?, ?, ?)",
            (case_type, y, number, user_id),
        )
        if data is not None:
            case_data.apply_details(db, cur.lastrowid, data, user_id, bump_version=False)
        db.execute("COMMIT")
    except BaseException:
        db.execute("ROLLBACK")
        raise
    return {"id": cur.lastrowid, "case_type": case_type, "year": y, "serial_no": number}
