"""اطلاعات شرکتی که برنامه را استفاده می‌کند (در جدول settings با کلید company_*)."""
import re

from . import config
from .jalali import to_fa_digits

_TO_ASCII = str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789")
BANK_KEYS = [k for k, _ in config.COMPANY_BANK_FIELDS]
NUMERIC_BANK = {"account", "sheba", "card"}         # شماره‌ها با رقم انگلیسی ذخیره می‌شوند (برای کپی در اپ بانک)


def phones(db, only_active=False) -> list:
    q = "SELECT id, label, number, active FROM company_phones" + (" WHERE active = 1" if only_active else "") + " ORDER BY id"
    return [dict(r) for r in db.execute(q)]


def banks(db, only_active=False) -> list:
    q = f"SELECT id, {', '.join(BANK_KEYS)}, active FROM company_banks" + (" WHERE active = 1" if only_active else "") + " ORDER BY id"
    return [dict(r) for r in db.execute(q)]


def _clean(v, n=200):
    return " ".join((v or "").split())[:n]


def get(db) -> dict:
    out = {k: "" for k, _ in config.COMPANY_FIELDS}
    for r in db.execute("SELECT key, value FROM settings WHERE key LIKE 'company_%'"):
        k = r["key"][len("company_"):]
        if k in out:
            out[k] = r["value"]
    if not out["name"]:
        out["name"] = config.COMPANY_NAME
    return out


def _save_phones(db, form, changes):
    old = {r["id"]: r for r in phones(db)}
    ids, labels, nums, acts = (form.getlist("phone_id"), form.getlist("phone_label"),
                               form.getlist("phone_number"), form.getlist("phone_active"))
    for i, pid in enumerate(ids):
        label = _clean(labels[i] if i < len(labels) else "", 60)
        num = to_fa_digits(_clean(nums[i] if i < len(nums) else "", 40))
        act = 0 if (acts[i] if i < len(acts) else "1") == "0" else 1
        if pid.isdigit() and int(pid) in old:
            o = old[int(pid)]
            if (o["label"], o["number"], o["active"]) != (label, num, act):
                db.execute("UPDATE company_phones SET label = ?, number = ?, active = ? WHERE id = ?", (label, num, act, o["id"]))
                changes.append([f"تلفن «{o['label'] or o['number']}»",
                                f"{o['label']} {o['number']}" + ("" if o["active"] else " (غیرفعال)"),
                                f"{label} {num}" + ("" if act else " (غیرفعال)")])
        elif label or num:
            db.execute("INSERT INTO company_phones (label, number, active) VALUES (?, ?, ?)", (label, num, act))
            changes.append(["تلفن جدید", "", f"{label} {num}".strip()])


def _bank_vals(form, i):
    out = {}
    for k in BANK_KEYS:
        lst = form.getlist("bank_" + k)
        v = _clean(lst[i] if i < len(lst) else "", 80)
        if k in NUMERIC_BANK:
            v = v.translate(_TO_ASCII).upper()
        out[k] = v
    return out


def _save_banks(db, form, changes):
    old = {r["id"]: r for r in banks(db)}
    ids, acts = form.getlist("bank_id"), form.getlist("bank_active")
    titles = dict(config.COMPANY_BANK_FIELDS)
    for i, bid in enumerate(ids):
        vals = _bank_vals(form, i)
        act = 0 if (acts[i] if i < len(acts) else "1") == "0" else 1
        if bid.isdigit() and int(bid) in old:
            o = old[int(bid)]
            name = o["bank"] or vals["bank"] or o["account"]
            for k in BANK_KEYS:
                if o[k] != vals[k]:
                    changes.append([f"حساب «{name}» — {titles[k]}", o[k], vals[k]])
            if o["active"] != act:
                changes.append([f"حساب «{name}» — وضعیت", "فعال" if o["active"] else "غیرفعال", "فعال" if act else "غیرفعال"])
            db.execute("UPDATE company_banks SET " + ", ".join(f"{k} = ?" for k in BANK_KEYS) + ", active = ? WHERE id = ?",
                       [vals[k] for k in BANK_KEYS] + [act, o["id"]])
        elif any(vals.values()):
            db.execute("INSERT INTO company_banks (" + ", ".join(BANK_KEYS) + ", active) VALUES (" + ", ".join("?" for _ in BANK_KEYS) + ", ?)",
                       [vals[k] for k in BANK_KEYS] + [act])
            changes.append([f"حساب بانکی جدید «{vals['bank']}»", "", " | ".join(v for v in vals.values() if v)])


def save(db, form) -> list:
    old = get(db)
    changes = []
    _save_phones(db, form, changes)
    _save_banks(db, form, changes)
    for k, title in config.COMPANY_FIELDS:
        v = " ".join((form.get(k) or "").split())[:200]
        if k == "name" and not v:
            v = config.COMPANY_NAME
        if v != old[k]:
            changes.append([title, old[k], v])
        db.execute("INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value",
                   (f"company_{k}", v))
    return changes
