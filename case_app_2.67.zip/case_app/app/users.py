"""مدیریت کاربران (فقط مدیر). هیچ کاربری حذف نمی‌شود؛ فقط غیرفعال می‌شود."""
import re
import sqlite3

from werkzeug.security import generate_password_hash

from . import config, seats


class UserError(Exception):
    pass


_NAME_RE = re.compile(r"^[\w.\-@]{2,40}$")


def list_users(db: sqlite3.Connection) -> list[sqlite3.Row]:
    return db.execute("SELECT id, username, full_name, job_title, role, active, created_at, last_login, dash_hidden, field_locked, cartable_only "
                      "FROM users ORDER BY id").fetchall()


def _active_admins(db, excluding: int | None = None) -> int:
    q = "SELECT COUNT(*) FROM users WHERE role = 'admin' AND active = 1"
    if excluding is not None:
        return db.execute(q + " AND id != ?", (excluding,)).fetchone()[0]
    return db.execute(q).fetchone()[0]


def _get(db, user_id: int) -> sqlite3.Row:
    row = db.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
    if row is None:
        raise UserError("کاربر پیدا نشد.")
    return row


PASSWORD_RULE = "حداقل ۸ کاراکتر، شامل حرف کوچک و بزرگ انگلیسی و عدد (علامت مثل @ و # اختیاری است)"


def _check_password(pw: str) -> None:
    """قانون رمز: حداقل ۸ کاراکتر + حرف کوچک + حرف بزرگ + عدد. علامت‌ها مجازند ولی اجباری نیستند."""
    pw = pw or ""
    if (len(pw) < 8 or not any("a" <= c <= "z" for c in pw)
            or not any("A" <= c <= "Z" for c in pw) or not any("0" <= c <= "9" for c in pw)):
        raise UserError("رمز عبور باید " + PASSWORD_RULE + " باشد.")


def create(db, username: str, password: str, role: str, full_name: str = "", job_title: str = "") -> int:
    username = (username or "").strip()
    if not _NAME_RE.match(username):
        raise UserError("نام کاربری ۲ تا ۴۰ حرف/عدد باشد و فاصله نداشته باشد.")
    if role not in config.ROLES:
        raise UserError("نقش نامعتبر است.")
    _check_password(password)
    if db.execute("SELECT 1 FROM users WHERE username = ? COLLATE NOCASE", (username,)).fetchone():
        raise UserError("این نام کاربری قبلاً ساخته شده است.")
    return db.execute("INSERT INTO users (username, password_hash, role, full_name, job_title) VALUES (?, ?, ?, ?, ?)",
                      (username, generate_password_hash(password), role, " ".join((full_name or "").split())[:60],
                       " ".join((job_title or "").split())[:40])
                      ).lastrowid


def set_role(db, actor_id: int, user_id: int, role: str) -> None:
    if role not in config.ROLES:
        raise UserError("نقش نامعتبر است.")
    u = _get(db, user_id)
    if u["role"] == "admin" and role != "admin":
        if user_id == actor_id:
            raise UserError("نقش خودتان را نمی‌توانید پایین بیاورید.")
        if u["active"] and _active_admins(db, excluding=user_id) == 0:
            raise UserError("حداقل یک مدیر فعال باید بماند.")
    db.execute("UPDATE users SET role = ? WHERE id = ?", (role, user_id))
    if role not in config.ROLES_CAN_CREATE:
        seats.release(db, user_id)


def set_active(db, actor_id: int, user_id: int, active: bool) -> None:
    u = _get(db, user_id)
    if not active:
        if user_id == actor_id:
            raise UserError("خودتان را نمی‌توانید غیرفعال کنید.")
        if u["role"] == "admin" and _active_admins(db, excluding=user_id) == 0:
            raise UserError("حداقل یک مدیر فعال باید بماند.")
    db.execute("UPDATE users SET active = ? WHERE id = ?", (1 if active else 0, user_id))
    if not active:
        seats.release(db, user_id)


def reset_password(db, user_id: int, password: str) -> None:
    _get(db, user_id)
    _check_password(password)
    db.execute("UPDATE users SET password_hash = ? WHERE id = ?", (generate_password_hash(password), user_id))


def set_username(db, user_id: int, new_name: str) -> tuple:
    """تغییر نام کاربری (فقط مدیر). یکتا بودن بدون توجه به بزرگی و کوچکی حروف. (قدیم، جدید) را برمی‌گرداند."""
    u = _get(db, user_id)
    new_name = (new_name or "").strip()
    if not _NAME_RE.match(new_name):
        raise UserError("نام کاربری ۲ تا ۴۰ حرف/عدد باشد و فاصله نداشته باشد.")
    if db.execute("SELECT 1 FROM users WHERE username = ? COLLATE NOCASE AND id != ?", (new_name, user_id)).fetchone():
        raise UserError("این نام کاربری قبلاً برای شخص دیگری ثبت شده است.")
    db.execute("UPDATE users SET username = ? WHERE id = ?", (new_name, user_id))
    return u["username"], new_name


def change_own_password(db, user_id: int, current: str, new: str, new2: str) -> None:
    """تغییر رمز توسط خود کاربر؛ رمز فعلی را باید بداند."""
    from werkzeug.security import check_password_hash
    u = _get(db, user_id)
    if not check_password_hash(u["password_hash"], current or ""):
        raise UserError("رمز فعلی درست نیست.")
    if new != new2:
        raise UserError("رمز جدید و تکرارش یکی نیست.")
    if new == current:
        raise UserError("رمز جدید باید با رمز فعلی فرق داشته باشد.")
    reset_password(db, user_id, new)


def set_job_title(db, user_id: int, title: str) -> None:
    _get(db, user_id)
    db.execute("UPDATE users SET job_title = ? WHERE id = ?", (" ".join((title or "").split())[:40], user_id))


def set_cartable_only(db, user_id: int, on: bool) -> None:
    """کاربرِ «فقط کارتابل»: جز کارتابل خودش و پرونده‌های داخل آن چیزی نمی‌بیند (مدیر همیشه مستثناست)."""
    row = _get(db, user_id)
    if row["role"] == "admin":
        raise UserError("برای مدیر نمی‌شود «فقط کارتابل» گذاشت.")
    db.execute("UPDATE users SET cartable_only = ? WHERE id = ?", (1 if on else 0, user_id))


def set_full_name(db, user_id: int, name: str) -> None:
    _get(db, user_id)
    db.execute("UPDATE users SET full_name = ? WHERE id = ?", (" ".join((name or "").split())[:60], user_id))


def set_dash_hidden(db: sqlite3.Connection, user_id: int, hidden: list) -> list:
    """بخش‌های داشبورد که این کاربر نباید ببیند (فقط شناسه‌های معتبر)."""
    from . import config
    valid = {k for k, _ in config.DASH_SECTIONS}
    clean = [k for k in hidden if k in valid]
    db.execute("UPDATE users SET dash_hidden = ? WHERE id = ?", (",".join(clean), user_id))
    return clean
