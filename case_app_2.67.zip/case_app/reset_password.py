"""بازیابی رمز یک کاربر (مثلاً مدیر) وقتی رمز یادتان رفته:

    python3 reset_password.py saeedr50

- رمز جدید دوبار پرسیده می‌شود (هنگام تایپ دیده نمی‌شود) و باید قانون رمز را رعایت کند.
- فقط رمز همان کاربر عوض می‌شود؛ پرونده‌ها و بقیه چیز دست نمی‌خورد. در گزارش فعالیت هم ثبت می‌شود.
- اگر کاربر غیرفعال باشد، فعالش می‌کند (تا بتواند وارد شود).
"""
import getpass
import sys

from app import audit, create_app, users
from app.db import connect


def main():
    name = (sys.argv[1] if len(sys.argv) > 1 else input("نام کاربری: ")).strip()
    app = create_app()
    conn = connect(app.config["DATABASE"])
    try:
        row = conn.execute("SELECT id, username, active FROM users WHERE username = ? COLLATE NOCASE", (name,)).fetchone()
        if row is None:
            names = ", ".join(r["username"] for r in conn.execute("SELECT username FROM users ORDER BY id"))
            sys.exit(f"کاربری با این نام نیست. کاربران موجود: {names}")
        pw = getpass.getpass("رمز جدید: ")
        if pw != getpass.getpass("تکرار رمز جدید: "):
            sys.exit("رمزها یکسان نیستند؛ چیزی تغییر نکرد.")
        try:
            users.reset_password(conn, row["id"], pw)
        except users.UserError as e:
            sys.exit(f"خطا: {e}")
        if not row["active"]:
            conn.execute("UPDATE users SET active = 1 WHERE id = ?", (row["id"],))
        audit.log(conn, "user_password", f"بازیابی رمز «{row['username']}» از خط فرمان", user=None)
        conn.commit()
    finally:
        conn.close()
    print(f"رمز «{row['username']}» عوض شد. برنامه را یک بار ببندید و دوباره باز کنید، بعد با رمز جدید وارد شوید.")


if __name__ == "__main__":
    main()
