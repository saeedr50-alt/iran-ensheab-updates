from app import users, workflow
from tests.test_form import FormBase


class WorkflowBase(FormBase):
    def setUp(self):
        super().setUp()
        workflow.set_enabled(self.db, True)
        users.set_job_title(self.db, self.uid("entry1"), "کارشناس بازرگانی")
        users.set_job_title(self.db, self.uid("entry2"), "مدیر بازرگانی")
        from app import auth
        auth.create_user(self.db, "ceo1", "secret1", "entry")
        users.set_job_title(self.db, self.uid("ceo1"), "مدیرعامل")
        self.db.commit()

    def uid(self, name):
        return self.db.execute("SELECT id FROM users WHERE username = ?", (name,)).fetchone()["id"]

    def inquiry(self, c=None):
        c = c or self.login("entry1")
        t = self.token(c)
        c.post("/cases/new", data=self.new_data(t, case_type="inquiry", organization="شرکت الف"))
        return c, self.db.execute("SELECT id FROM cases ORDER BY id DESC").fetchone()["id"]

    def post(self, c, cid, action, **data):
        t = self.token(c, "/cartable")
        return c.post(f"/cases/{cid}/wf/{action}", data=dict(csrf=t, **data))



class WorkflowTests(WorkflowBase):
    def test_defaults_seeded_and_free_case_untouched(self):
        sts = workflow.stages(self.db, "استعلام")
        self.assertEqual([s["name"] for s in sts], ["ثبت", "امضای بازرگانی", "تصمیم مدیرعامل", "اطلاع از نتیجه"])
        c, cid = self.inquiry()
        self.assertIsNone(workflow.state(self.db, cid))
        self.assertEqual(self.login("entry2").get(f"/cases/{cid}").status_code, 200)    # خارج از گردش = مثل قبل

    def test_full_flow_locks_visibility_and_history(self):
        a, cid = self.inquiry()
        b, ceo = self.login("entry2"), self.login("ceo1")
        # ارسال از الف به ب (سمت مدیر بازرگانی)
        r = self.post(a, cid, "send", to=self.uid("entry2"))
        self.assertEqual(r.status_code, 302)
        st = workflow.state(self.db, cid)
        self.assertEqual((st["stage_name"], st["holder_id"]), ("امضای بازرگانی", self.uid("entry2")))
        # الف دیگر پرونده را نمی‌بیند
        self.assertEqual(a.get(f"/cases/{cid}").status_code, 302)
        lst = a.get("/cases").get_data(as_text=True)                       # فرستنده در لیست خودش مرحله را می‌بیند
        self.assertIn("امضای بازرگانی", lst)
        self.assertIn("در کارتابل دیگری", lst)
        self.assertNotIn("امضای بازرگانی", self.login("ceo1").get("/cases").get_data(as_text=True))   # دیگران نمی‌بینند
        # ب بدون امضا نمی‌تواند بفرستد
        self.post(b, cid, "send", to=self.uid("ceo1"))
        self.assertEqual(workflow.state(self.db, cid)["stage_name"], "امضای بازرگانی")
        # قفل: فیلد سازمان برای ب قفل است، امضا آزاد
        locks = workflow.locks(self.db, self.db.execute("SELECT * FROM users WHERE username='entry2'").fetchone(), cid)
        self.assertIn("organization", locks)
        self.assertNotIn("p_manager_sign", locks)
        # ثبت امضا و ارسال به مدیرعامل
        self.db.execute("INSERT INTO case_profile (case_id, manager_sign) VALUES (?, 'تایید می‌شود')", (cid,))
        self.db.commit()
        self.post(b, cid, "send", to=self.uid("ceo1"))
        self.assertEqual(workflow.state(self.db, cid)["stage_name"], "تصمیم مدیرعامل")
        # مدیرعامل بدون تصمیم نمی‌فرستد؛ برگشت به ب ممکن است
        self.post(ceo, cid, "send", to=self.uid("entry2"))
        self.assertEqual(workflow.state(self.db, cid)["stage_name"], "تصمیم مدیرعامل")
        self.db.execute("UPDATE cases SET decision = 'تایید' WHERE id = ?", (cid,))
        self.db.commit()
        self.post(ceo, cid, "send", to=self.uid("entry2"))
        st = workflow.state(self.db, cid)
        self.assertEqual((st["stage_name"], st["holder_id"]), ("اطلاع از نتیجه", self.uid("entry2")))
        self.post(b, cid, "done")
        self.assertEqual(workflow.state(self.db, cid)["status"], "done")
        self.assertEqual(len(workflow.history(self.db, cid)), 4)
        self.assertEqual(len(workflow.done(self.db, self.uid("entry2"))), 1)

    def test_return_and_admin_reassign_and_cartable(self):
        a, cid = self.inquiry()
        b = self.login("entry2")
        self.post(a, cid, "send", to=self.uid("entry2"))
        self.assertIn("شرکت الف", b.get("/cartable").get_data(as_text=True))
        self.post(b, cid, "back")
        st = workflow.state(self.db, cid)
        self.assertEqual((st["stage_name"], st["holder_id"]), ("ثبت", self.uid("entry1")))
        ad = self.login("admin1")
        self.assertEqual(ad.get(f"/cases/{cid}").status_code, 200)
        self.post(ad, cid, "reassign", to=self.uid("ceo1"), stage=workflow.stages(self.db, "استعلام")[2]["id"])
        self.assertEqual(workflow.state(self.db, cid)["holder_id"], self.uid("ceo1"))
        self.assertEqual(ad.get("/settings/workflow").status_code, 200)

    def test_sender_can_recall_until_receiver_acts(self):
        a, cid = self.inquiry()
        b = self.login("entry2")
        self.post(a, cid, "send", to=self.uid("entry2"))
        self.assertIn("پس‌گرفتن", a.get("/cartable?tab=sent").get_data(as_text=True))
        self.post(a, cid, "recall")
        st = workflow.state(self.db, cid)
        self.assertEqual((st["stage_name"], st["holder_id"]), ("ثبت", self.uid("entry1")))
        self.assertEqual(a.get(f"/cases/{cid}").status_code, 200)
        self.post(a, cid, "send", to=self.uid("entry2"))
        self.db.execute("INSERT INTO case_profile (case_id, manager_sign) VALUES (?, 'x')", (cid,))
        self.db.commit()
        self.post(b, cid, "send", to=self.uid("ceo1"))
        self.post(a, cid, "recall")                              # گیرنده جلو برده؛ دیگر پس‌گرفتنی نیست
        self.assertEqual(workflow.state(self.db, cid)["stage_name"], "تصمیم مدیرعامل")

    def test_cartable_only_user_sees_nothing_else(self):
        a, cid = self.inquiry()
        users.set_cartable_only(self.db, self.uid("entry2"), True)
        self.db.commit()
        b = self.login("entry2")
        for path in ("/", "/cases", "/cases/new", "/organizations", "/m", f"/cases/{cid}"):
            r = b.get(path)
            self.assertEqual((r.status_code, r.headers["Location"].endswith("/cartable")), (302, True), path)
        html = b.get("/cartable").get_data(as_text=True)
        self.assertNotIn('id="tn"', html)
        self.assertNotIn('class="sidebar"', html)
        self.post(a, cid, "send", to=self.uid("entry2"))
        self.assertEqual(b.get(f"/cases/{cid}").status_code, 200)       # پرونده‌ای که پیش اوست باز می‌شود
        self.assertEqual(b.get("/cartable").status_code, 200)
        self.assertEqual(b.get("/help").status_code, 200)
        self.assertEqual(self.login("admin1").get("/cases").status_code, 200)

    def test_reopen_after_complete(self):
        a, cid = self.inquiry()
        b = self.login("entry2")
        self.db.execute("INSERT INTO case_profile (case_id, manager_sign) VALUES (?, 'x')", (cid,))
        self.db.commit()
        ad = self.login("admin1")
        self.post(ad, cid, "reassign", to=self.uid("entry2"), stage=workflow.stages(self.db, "استعلام")[3]["id"])
        self.post(b, cid, "done")
        self.assertEqual(workflow.state(self.db, cid)["status"], "done")
        self.assertIn("باز کردن دوباره", b.get("/cartable?tab=done").get_data(as_text=True))
        self.post(b, cid, "reopen")
        self.assertEqual(workflow.state(self.db, cid)["status"], "active")

    def test_free_send_when_enabled(self):
        a, cid = self.inquiry()
        sts = workflow.stages(self.db, "استعلام")
        ceo = self.login("ceo1")
        ad = self.login("admin1")
        self.post(ad, cid, "reassign", to=self.uid("ceo1"), stage=sts[2]["id"])
        self.post(ceo, cid, "send", to=self.uid("entry1"))           # هنوز غیرفعال: فقط مرحلهٔ بعد/کاربران مجاز
        self.assertEqual(workflow.state(self.db, cid)["holder_id"], self.uid("ceo1"))
        self.db.execute("UPDATE wf_stages SET free_send = 1 WHERE id = ?", (sts[2]["id"],))
        self.db.commit()
        self.assertIn("مرحله از روی سمت گیرنده", ceo.get(f"/cases/{cid}").get_data(as_text=True))
        self.post(ceo, cid, "send", to=self.uid("entry1"))
        st = workflow.state(self.db, cid)
        self.assertEqual((st["stage_name"], st["holder_id"]), ("ثبت", self.uid("entry1")))

    def test_sent_tab_keeps_history_after_case_returns(self):
        a, cid = self.inquiry()
        b = self.login("entry2")
        self.post(a, cid, "send", to=self.uid("entry2"))
        self.post(b, cid, "back")                                       # برگشت به فرستنده
        html = a.get("/cartable?tab=sent").get_data(as_text=True)
        self.assertIn("شرکت الف", html)
        self.assertIn("برگشته به شما", html)

    def test_settings_save_adds_stage(self):
        ad = self.login("admin1")
        t = self.token(ad, "/settings/workflow")
        sid = workflow.stages(self.db, "استعلام")[0]["id"]
        r = ad.post("/settings/workflow?grp=استعلام", data={"csrf": t, "sid": [str(sid), "new1"], f"name_{sid}": "ثبت", f"pos_{sid}": "1",
                    f"active_{sid}": "on", f"kind_{sid}": "start", "name_new1": "کنترل", "pos_new1": "9", "kind_new1": "work", "col_new1": "serial"})
        self.assertEqual(r.status_code, 302)
        self.assertEqual(len(workflow.stages(self.db, "استعلام", only_active=False)), 5)


class CartPageTests(WorkflowBase):
    def test_single_page_for_holder_and_save_and_send(self):
        a, cid = self.inquiry()
        sts = workflow.stages(self.db, "استعلام")
        self.post(a, cid, "send", to=self.uid("entry2"))
        b = self.login("entry2")
        html = b.get(f"/cases/{cid}").get_data(as_text=True)
        self.assertIn("کار شما در این مرحله", html)
        self.assertIn('name="manager_sign"', html)
        self.assertNotIn('id="case-form"', html)                       # فرم کامل نیست
        t = self.token(b, f"/cases/{cid}")
        # بدون امضا ذخیره‌وارسال: ذخیره می‌شود ولی ارسال نه
        c = self.db.execute("SELECT version FROM cases WHERE id = ?", (cid,)).fetchone()["version"]
        r = b.post(f"/cases/{cid}/wf/save", data={"csrf": t, "version": c, "pversion": 0, "manager_sign": "", "go": "send", "to": self.uid("ceo1")})
        self.assertEqual(workflow.state(self.db, cid)["stage_name"], "امضای بازرگانی")
        c = self.db.execute("SELECT version FROM cases WHERE id = ?", (cid,)).fetchone()["version"]
        pv = self.db.execute("SELECT COALESCE(MAX(version),0) v FROM case_profile WHERE case_id = ?", (cid,)).fetchone()["v"]
        r = b.post(f"/cases/{cid}/wf/save", data={"csrf": t, "version": c, "pversion": pv, "manager_sign": "تایید می‌شود", "go": "send", "to": self.uid("ceo1"),
                                                  "organization": "هک"})
        self.assertEqual(r.status_code, 302)
        self.assertEqual(workflow.state(self.db, cid)["stage_name"], "تصمیم مدیرعامل")
        self.assertEqual(self.db.execute("SELECT organization FROM cases WHERE id = ?", (cid,)).fetchone()[0], "شرکت الف")   # فیلد قفل عوض نشد
        self.assertEqual(self.db.execute("SELECT manager_sign FROM case_profile WHERE case_id = ?", (cid,)).fetchone()[0], "تایید می‌شود")
        # کارشناس ثبت (مرحلهٔ شروع) هنوز فرم کامل را می‌بیند؛ مدیر هم
        self.assertIn('id="case-form"', self.login("admin1").get(f"/cases/{cid}").get_data(as_text=True))

    def test_archive_reason_only_when_archive_decision(self):
        a, cid = self.inquiry()
        ad = self.login("admin1")
        self.post(ad, cid, "reassign", to=self.uid("ceo1"), stage=workflow.stages(self.db, "استعلام")[2]["id"])
        html = self.login("ceo1").get(f"/cases/{cid}").get_data(as_text=True)
        self.assertRegex(html, r'id="cf-wrap-archive"[^>]*\bhidden\b')
        self.db.execute("UPDATE cases SET decision = 'عدم تایید و بایگانی' WHERE id = ?", (cid,))
        self.db.commit()
        html = self.login("ceo1").get(f"/cases/{cid}").get_data(as_text=True)
        self.assertNotRegex(html, r'id="cf-wrap-archive"[^>]*\bhidden\b')


class ResetWorkflowTests(WorkflowBase):
    def test_reset_clears_inbox_keeps_cases(self):
        import os, tempfile
        import reset_workflow
        a, cid = self.inquiry()
        self.post(a, cid, "send", to=self.uid("entry2"))
        self.assertIsNotNone(workflow.state(self.db, cid))
        path = self.app.config["DATABASE"]
        with tempfile.TemporaryDirectory() as folder:
            self.assertIsNotNone(reset_workflow.reset(path, folder, ask=lambda _: "YES"))
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM wf_cases").fetchone()[0], 0)
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM wf_log").fetchone()[0], 0)
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM cases").fetchone()[0], 1)
        with self.assertRaises(Exception):                       # محافظ دوباره فعال است
            self.db.execute("INSERT INTO wf_cases (case_id, stage_id) VALUES (99, 1)")
            self.db.execute("DELETE FROM wf_cases")


class MobileManifestTests(WorkflowBase):
    def test_mobile_manifest_starts_at_m(self):
        c = self.login("entry1")
        import json
        self.assertEqual(json.loads(c.get("/m/manifest.webmanifest").get_data(as_text=True))["start_url"], "/m")
        self.assertEqual(json.loads(c.get("/manifest.webmanifest").get_data(as_text=True))["start_url"], "/")
        self.assertIn("/m/manifest.webmanifest", c.get("/m").get_data(as_text=True))


class SwitchTests(WorkflowBase):
    def test_off_hides_everything_and_on_restores(self):
        a, cid = self.inquiry()
        self.post(a, cid, "send", to=self.uid("entry2"))
        workflow.set_enabled(self.db, False)
        self.db.commit()
        b = self.login("entry2")
        self.assertEqual(b.get("/cartable").status_code, 404)
        html = b.get("/cases").get_data(as_text=True)
        self.assertNotIn("cart-btn", html)
        self.assertNotIn("امضای بازرگانی", self.login("entry1").get("/cases").get_data(as_text=True))
        self.assertEqual(self.login("entry1").get(f"/cases/{cid}").status_code, 200)        # دوباره مثل قبل باز می‌شود
        ad = self.login("admin1")
        self.assertIn("کارتابل خاموش است", ad.get("/settings/workflow").get_data(as_text=True))
        t = self.token(ad, "/settings/workflow")
        ad.post("/settings/workflow", data={"csrf": t, "switch": "on"})
        self.assertTrue(workflow.enabled(self.db))
        self.assertEqual(self.login("entry2").get("/cartable").status_code, 200)


class AuditTests(WorkflowBase):
    def test_every_workflow_action_is_logged_with_names(self):
        a, cid = self.inquiry()
        b = self.login("entry2")
        self.post(a, cid, "send", to=self.uid("entry2"), note="لطفا بررسی")
        self.post(a, cid, "recall")
        self.post(a, cid, "send", to=self.uid("entry2"))
        self.post(b, cid, "back")
        acts = [r["action"] for r in self.db.execute("SELECT action FROM audit_log WHERE action LIKE 'wf_%' ORDER BY id")]
        self.assertEqual(acts, ["wf_send", "wf_recall", "wf_send", "wf_return"])
        first = self.db.execute("SELECT summary FROM audit_log WHERE action = 'wf_send' ORDER BY id").fetchone()[0]
        self.assertIn("entry1 ← entry2", first)
        self.assertIn("لطفا بررسی", first)
