import json
import os
import unittest
from unittest import mock

from app import mailer
from tests.test_app import BaseCase


class MailerTests(BaseCase):
    def cfg(self):
        p = os.path.join(os.path.dirname(self.app.config["DATABASE"]), "mail.json")
        with open(p, "w", encoding="utf-8") as f:
            json.dump({"user": "a@gmail.com", "password": "abcd efgh ijkl mnop", "to": "me@x.com"}, f)

    def test_no_config_is_silent(self):
        self.assertIsNone(mailer.settings(self.app))
        self.assertEqual(mailer.send_now(self.app, "s", "b"), (False, "no-config"))

    def test_sends_with_attachment_and_strips_password_spaces(self):
        self.cfg()
        self.assertEqual(mailer.settings(self.app)["password"], "abcdefghijklmnop")
        with mock.patch("app.mailer.smtplib.SMTP_SSL") as smtp:
            ok, err = mailer.send_now(self.app, "موضوع", "متن", ("a.png", b"xx"))
        self.assertTrue(ok, err)
        inst = smtp.return_value.__enter__.return_value
        inst.login.assert_called_once_with("a@gmail.com", "abcdefghijklmnop")
        msg = inst.send_message.call_args[0][0]
        self.assertEqual(msg["To"], "me@x.com")
        self.assertEqual(len(list(msg.iter_attachments())), 1)

    def test_failure_is_logged_not_raised(self):
        self.cfg()
        with mock.patch("app.mailer.smtplib.SMTP_SSL", side_effect=OSError("down")):
            ok, _ = mailer.send_now(self.app, "s", "b")
        self.assertFalse(ok)
        log = os.path.join(os.path.dirname(self.app.config["DATABASE"]), "mail.log")
        self.assertIn("down", open(log, encoding="utf-8").read())
        self.assertNotIn("abcd", open(log, encoding="utf-8").read())


if __name__ == "__main__":
    unittest.main()


class TicketUnreadTests(BaseCase):
    def login(self, name):
        c = self.app.test_client()
        c.get("/login")
        with c.session_transaction() as s:
            t = s["csrf"]
        c.post("/login", data={"username": name, "password": "secret1", "csrf": t})
        return c

    def mk(self, uid):
        cur = self.db.execute("INSERT INTO tickets (user_id, username, subject, body, gh_number) VALUES (?,?,?,?,5)", (uid, "u", "موضوع تست", "متن"))
        self.db.commit()
        return cur.lastrowid

    def reply(self, tid, who="support"):
        self.db.execute("INSERT INTO ticket_comments (ticket_id, gh_id, author, body, created_at) VALUES (?,?,?,?,?)",
                        (tid, self.db.execute("SELECT COALESCE(MAX(gh_id),0)+1 FROM ticket_comments").fetchone()[0], who, "پاسخ", "2026-11-15 10:00"))
        self.db.commit()

    def test_unread_flow(self):
        from app import tickets as tk
        tid = self.mk(self.entry)
        c = self.login("entry1")
        self.assertEqual(c.get("/update-notice").get_json()["tickets"], 0)
        self.reply(tid, "user")                                   # پیام خود کاربر «جدید» حساب نمی‌شود
        self.assertEqual(tk.unread_ids(self.db, self.entry), [])
        self.reply(tid)
        self.assertEqual(tk.unread_ids(self.db, self.entry), [tid])
        self.assertEqual(c.get("/update-notice").get_json()["tickets"], 1)
        page = c.get("/tickets").get_data(as_text=True)
        self.assertIn("پاسخ جدید", page)
        self.assertIn("tk-unread", page)
        self.assertIn("پاسخ جدید", c.get("/").get_data(as_text=True))       # نشان در منو
        c.get(f"/tickets/{tid}")                                  # باز کردن تیکت = دیده شد
        self.assertEqual(tk.unread_ids(self.db, self.entry), [])
        self.assertNotIn("tk-unread", c.get("/tickets").get_data(as_text=True))
        self.reply(tid)                                           # پاسخ دوم دوباره نشان می‌دهد
        self.assertEqual(tk.unread_ids(self.db, self.entry), [tid])

    def test_admin_opening_others_ticket_does_not_mark_seen(self):
        from app import tickets as tk
        tid = self.mk(self.entry)
        self.reply(tid)
        a = self.login("admin1")
        a.get(f"/tickets/{tid}")
        self.assertEqual(tk.unread_ids(self.db, self.entry), [tid])


class MobileViewTests(BaseCase):
    def login(self, name, ua=""):
        c = self.app.test_client()
        c.get("/login")
        with c.session_transaction() as s:
            t = s["csrf"]
        r = c.post("/login", data={"username": name, "password": "secret1", "csrf": t}, headers={"User-Agent": ua} if ua else {})
        return c, r

    def add_case(self, n, decision, status="", org="سازمان"):
        self.db.execute("INSERT INTO cases (case_type, year, serial_no, organization, decision, status, received_date, created_by) "
                        "VALUES ('tender_smart', 1405, ?, ?, ?, ?, '۱۴۰۵/۰۸/۱۰', ?)", (n, org, decision, status, self.admin))
        self.db.commit()

    def test_requires_login(self):
        for u in ("/m", "/m/cases", "/m/reports", "/m/me"):
            self.assertEqual(self.app.test_client().get(u).status_code, 302)

    def test_pages_render_and_decision_counts(self):
        from app import mobile
        self.assertEqual(mobile.decision_of("تایید"), "approve")
        self.assertEqual(mobile.decision_of("عدم تایید و بایگانی"), "archive")     # شامل کلمهٔ «تایید» هم هست
        self.assertEqual(mobile.decision_of(""), "none")
        self.add_case(1, "تایید", "در حال بررسی")
        self.add_case(2, "تایید", "ارسال شد")
        self.add_case(3, "عدم تایید و بایگانی")
        self.add_case(4, "", org="بدون تصمیم‌گیری")
        c, _ = self.login("viewer1")
        h = mobile.home(self.db)
        self.assertEqual(h["decisions"], dict(approve=2, archive=1, none=1))
        self.assertEqual({s["label"] for s in h["statuses"]}, {"در حال بررسی", "ارسال شد"})
        for u in ("/m", "/m/cases", "/m/reports", "/m/me"):
            self.assertEqual(c.get(u).status_code, 200, u)
        page = c.get("/m/cases?d=archive").get_data(as_text=True)
        self.assertIn("عدم تایید", page)
        self.assertNotIn("بدون تصمیم‌گیری", page)
        self.assertIn("بدون تصمیم‌گیری", c.get("/m/cases?d=none").get_data(as_text=True))
        self.assertEqual(len(mobile.reports(self.db)["months"]), 1)

    def test_empty_database_renders(self):
        c, _ = self.login("viewer1")
        self.assertIn("هنوز پرونده‌ای ثبت نشده", c.get("/m").get_data(as_text=True))
        self.assertEqual(c.get("/m/reports").status_code, 200)

    def test_viewer_on_phone_lands_in_mobile_view(self):
        _, r = self.login("viewer1", "Mozilla/5.0 (iPhone) Mobile Safari")
        self.assertEqual(r.headers["Location"], "/m")
        _, r = self.login("viewer1", "Mozilla/5.0 (Macintosh)")
        self.assertEqual(r.headers["Location"], "/")
        _, r = self.login("admin1", "Mozilla/5.0 (iPhone) Mobile Safari")
        self.assertEqual(r.headers["Location"], "/")


class JobTitleTests(BaseCase):
    def login(self, name):
        c = self.app.test_client()
        c.get("/login")
        with c.session_transaction() as s:
            t = s["csrf"]
        c.post("/login", data={"username": name, "password": "secret1", "csrf": t})
        return c

    def test_create_set_and_show_under_name(self):
        from app import users
        uid = users.create(self.db, "karshenas", "Abcdef12", "entry", "علی احمدی", "  کارشناس   بازرگانی ")
        self.db.commit()
        self.assertEqual(self.db.execute("SELECT job_title FROM users WHERE id=?", (uid,)).fetchone()[0], "کارشناس بازرگانی")
        users.set_job_title(self.db, uid, "مدیر فنی")
        self.db.commit()
        c = self.app.test_client()
        c.get("/login")
        with c.session_transaction() as s:
            t = s["csrf"]
        c.post("/login", data={"username": "karshenas", "password": "Abcdef12", "csrf": t})
        html = c.get("/").get_data(as_text=True)
        self.assertIn("علی احمدی<small>مدیر فنی</small>", html)

    def test_role_shown_when_no_title(self):
        c = self.login("entry1")
        self.assertIn("<small>ثبت‌کننده</small>", c.get("/").get_data(as_text=True))

    def test_admin_form_saves_title(self):
        a = self.login("admin1")
        a.get("/admin/users")
        with a.session_transaction() as s:
            t = s["csrf"]
        r = a.post("/admin/users", data={"csrf": t, "action": "set_name", "user_id": str(self.entry), "full_name": "نام", "job_title": "سرپرست انبار"})
        self.assertEqual(self.db.execute("SELECT job_title FROM users WHERE id=?", (self.entry,)).fetchone()[0], "سرپرست انبار")
        r = a.post("/admin/users", data={"csrf": t, "action": "create", "username": "neo", "password": "Abcdef12", "role": "entry", "full_name": "نئو", "job_title": "حسابدار"})
        self.assertEqual(self.db.execute("SELECT job_title FROM users WHERE username='neo'").fetchone()[0], "حسابدار")


class ReportFlagTests(unittest.TestCase):
    def test_flag_hidden_when_unticked(self):
        from app import config
        self.assertIsNone(config.report_flag("tender"))
        self.assertIsNone(config.report_flag("inquiry"))
        self.assertIsNone(config.report_flag("auction"))
        self.assertEqual(config.report_flag("quality_call"), ("فراخوان ارزیابی کیفی", True))
        self.assertEqual(config.report_flag("price_estimate"), ("برآورد قیمت", True))


class WelcomeAndSaveButtonTests(BaseCase):
    def test_existing_user_row_has_save_button(self):
        import re
        c = self.app.test_client()
        c.get("/login")
        with c.session_transaction() as s:
            t = s["csrf"]
        c.post("/login", data={"username": "admin1", "password": "secret1", "csrf": t})
        html = c.get("/admin/users").get_data(as_text=True)
        form = re.search(r'<form method="post" class="us-name">.*?</form>', html, re.S).group(0)
        self.assertIn('name="job_title"', form)
        self.assertIn('type="submit"', form)            # بدون دکمه، با دو کادر Enter فرم را ارسال نمی‌کند

    def test_welcome_text_uses_new_name(self):
        c = self.app.test_client()
        c.get("/login")
        with c.session_transaction() as s:
            t = s["csrf"]
        c.post("/login", data={"username": "entry1", "password": "secret1", "csrf": t})
        html = c.get("/").get_data(as_text=True)
        import re
        wl = re.search(r'<p class="wl-text">(.*?)</p>', html, re.S).group(1)
        self.assertIn("پیشرو سیستم", wl)
        self.assertNotIn("مناقصات", wl)
