// منوی کناری: دکمهٔ همبرگری آن را به نوار آیکون جمع می‌کند؛ حالت در مرورگر یادآوری می‌شود.
(function () {
  var KEY = "ensheab-side-collapsed";
  function get() { try { return localStorage.getItem(KEY) === "1"; } catch (e) { return false; } }
  function put(v) { try { localStorage.setItem(KEY, v ? "1" : "0"); } catch (e) {} }
  function apply(v) {
    document.body.classList.toggle("side-collapsed", v);
    var b = document.getElementById("side-toggle");
    if (b) b.setAttribute("aria-expanded", v ? "false" : "true");
  }
  apply(get());
  document.addEventListener("DOMContentLoaded", function () {
    apply(get());
    var b = document.getElementById("side-toggle");
    if (b) b.addEventListener("click", function () { var v = !document.body.classList.contains("side-collapsed"); put(v); apply(v); });
  });
})();
