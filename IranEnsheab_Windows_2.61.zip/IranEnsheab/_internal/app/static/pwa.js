// ثبت سرویس‌ورکر ساده برای «نصب به‌صورت اپ»
if ("serviceWorker" in navigator) { navigator.serviceWorker.register("/sw.js").catch(function () {}); }
