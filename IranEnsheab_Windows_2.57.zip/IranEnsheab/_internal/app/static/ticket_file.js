/* پیوست تیکت: نشان می‌دهد فایل انتخاب و آماده است؛ نوع و حجم را همان‌جا بررسی می‌کند */
(function () {
  var MAX = 10 * 1024 * 1024, OK = /\.(png|jpe?g|gif|webp|pdf|txt|log|csv|xlsx?|docx?|zip)$/i;
  document.querySelectorAll('input[type=file]').forEach(function (inp) {
    var form = inp.closest('form'), box = form.querySelector('[data-file-status]');
    function show(msg, cls) { box.hidden = false; box.textContent = msg; box.className = 'file-status ' + cls; }
    inp.addEventListener('change', function () {
      var f = inp.files && inp.files[0];
      if (!f) { box.hidden = true; return; }
      if (!OK.test(f.name)) { show('✖ نوع این فایل مجاز نیست.', 'bad'); inp.value = ''; return; }
      if (f.size > MAX) { show('✖ حجم فایل بیشتر از ۱۰ مگابایت است.', 'bad'); inp.value = ''; return; }
      show('✔ فایل «' + f.name + '» (' + Math.max(1, Math.round(f.size / 1024)).toLocaleString('fa') + ' کیلوبایت) آماده است؛ حالا می‌توانید ارسال کنید.', 'ok');
    });
    form.addEventListener('submit', function () {
      var b = form.querySelector('button[type=submit]');
      if (inp.files && inp.files[0] && b) { b.disabled = true; b.textContent = 'در حال ارسال فایل…'; }
    });
  });
})();
