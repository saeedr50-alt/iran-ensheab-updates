"""کار همزمان چند کاربر روی یک برنامه (نخ‌های جدا، مثل چند مرورگر): نباید خطای قفل دیتابیس،
شمارهٔ تکراری یا ذخیرهٔ از دست‌رفته داشته باشیم."""
import threading
import unittest

from app import auth, options, seats
from tests.test_app import BaseCase

N_USERS = 8
CASES_EACH = 5


class MultiUserTests(BaseCase):
    def setUp(self):
        super().setUp()
        options.add_labels(self.db, "organization", "شرکت الف")
        seats.set_max(self.db, N_USERS)
        for i in range(N_USERS):
            auth.create_user(self.db, f"u{i}", "secret1", "entry")

    def _login(self, name):
        c = self.app.test_client()
        c.get("/login")
        with c.session_transaction() as s:
            t = s["csrf"]
        self.assertEqual(c.post("/login", data={"username": name, "password": "secret1", "csrf": t}).status_code, 302)
        return c

    def _token(self, c, path="/cases/new"):
        c.get(path)
        with c.session_transaction() as s:
            return s["csrf"]

    def test_many_users_create_cases_at_the_same_time(self):
        results, errors = [], []
        start = threading.Barrier(N_USERS)

        def work(i):
            try:
                c = self._login(f"u{i}")
                start.wait()
                for _ in range(CASES_EACH):
                    t = self._token(c)
                    r = c.post("/cases/new", data={"csrf": t, "case_type": "tender", "organization": "شرکت الف"})
                    results.append(r.status_code)
            except Exception as e:      # noqa: BLE001
                errors.append(repr(e))

        threads = [threading.Thread(target=work, args=(i,)) for i in range(N_USERS)]
        [t.start() for t in threads]
        [t.join(120) for t in threads]
        self.assertEqual(errors, [])
        self.assertEqual(results.count(302), N_USERS * CASES_EACH, sorted(set(results)))
        rows = self.db.execute("SELECT serial_no FROM cases WHERE case_type='tender' ORDER BY serial_no").fetchall()
        self.assertEqual([r[0] for r in rows], list(range(1, N_USERS * CASES_EACH + 1)))   # بدون شماره تکراری و حفره

    def test_simultaneous_edit_of_one_case_never_loses_silently(self):
        c0 = self._login("u0")
        t = self._token(c0)
        c0.post("/cases/new", data={"csrf": t, "case_type": "tender", "organization": "شرکت الف"})
        ver = self.db.execute("SELECT version FROM cases WHERE id=1").fetchone()[0]
        codes = []
        start = threading.Barrier(N_USERS)

        def work(i):
            c = self._login(f"u{i}")
            t = self._token(c, "/cases/1")
            start.wait()
            r = c.post("/cases/1", data={"csrf": t, "case_type": "tender", "organization": "شرکت الف",
                                         "version": str(ver), "notes": f"یادداشت {i}"})
            codes.append(r.status_code)

        threads = [threading.Thread(target=work, args=(i,)) for i in range(N_USERS)]
        [t.start() for t in threads]
        [t.join(120) for t in threads]
        # دقیقاً یک نفر برنده است؛ بقیه پیام «تغییر کرده» (۴۰۹) می‌گیرند، نه خطای سرور
        self.assertEqual(codes.count(302), 1, codes)
        self.assertEqual(codes.count(409), N_USERS - 1, codes)
        self.assertEqual(self.db.execute("SELECT version FROM cases WHERE id=1").fetchone()[0], ver + 1)


if __name__ == "__main__":
    unittest.main()
