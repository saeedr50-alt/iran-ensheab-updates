"""تست دکمهٔ به‌روزرسانی: با سرور آزمایشی محلی؛ اینترنت لازم نیست."""
import unittest
import hashlib
import http.server
import json
import os
import threading
import zipfile
from functools import partial

from app import config, updater
from tests.test_app import BaseCase


class UpdateTests(BaseCase):
    def setUp(self):
        super().setUp()
        self.srv_dir = os.path.join(self.tmp.name, "srv")
        self.root = os.path.join(self.tmp.name, "root")
        os.makedirs(self.srv_dir)
        for d in ("instance", "backups", "app"):
            os.makedirs(os.path.join(self.root, d))
        for rel, text in (("instance/cases.sqlite", "REAL-DATA"), ("backups/b1.sqlite", "BK"), ("app/old.py", "old"),
                          ("run.py", "v-old")):
            with open(os.path.join(self.root, rel), "w") as f:
                f.write(text)
        handler = partial(http.server.SimpleHTTPRequestHandler, directory=self.srv_dir)
        handler.log_message = lambda *a, **k: None
        self.httpd = http.server.ThreadingHTTPServer(("127.0.0.1", 0), handler)
        threading.Thread(target=self.httpd.serve_forever, daemon=True).start()
        self.app.config.update(UPDATE_URL=f"http://127.0.0.1:{self.httpd.server_address[1]}", APP_ROOT=self.root,
                               UPDATE_NO_RESTART=True)
        updater._cache.update(at=0.0, info=None, error="")

    def tearDown(self):
        self.httpd.shutdown()
        super().tearDown()

    def publish(self, version="9.0", sha_ok=True, evil=False):
        z = os.path.join(self.srv_dir, "case_app_9.zip")
        with zipfile.ZipFile(z, "w") as zf:
            zf.writestr("case_app/run.py", "v-new")
            zf.writestr("case_app/app/new.py", "new")
            zf.writestr("case_app/instance/cases.sqlite", "HACK")          # هرگز نباید بنویسد
            zf.writestr("case_app/backups/b1.sqlite", "HACK")
            if evil:
                zf.writestr("case_app/../evil.txt", "x")
        sha = hashlib.sha256(open(z, "rb").read()).hexdigest()
        info = {"version": version, "notes": "تست", "files": {"source": {"url": "case_app_9.zip", "sha256": sha if sha_ok else "0" * 64},
                                                              "windows": {"url": "case_app_9.zip", "sha256": sha}}}
        with open(os.path.join(self.srv_dir, "latest.json"), "w") as f:
            json.dump(info, f)

    def login_admin(self):
        c = self.app.test_client()
        c.get("/login")
        with c.session_transaction() as s:
            t = s["csrf"]
        c.post("/login", data={"username": "admin1", "password": "secret1", "csrf": t})
        return c

    def token(self, c, path="/admin/update"):
        self.assertEqual(c.get(path).status_code, 200)
        with c.session_transaction() as s:
            return s["csrf"]

    def test_version_compare(self):
        self.assertTrue(updater.is_newer("2.10", "2.9"))
        self.assertTrue(updater.is_newer("3.0", "2.99"))
        self.assertFalse(updater.is_newer("2.25", "2.25"))
        self.assertFalse(updater.is_newer("2.24", "2.25"))

    def test_only_admin(self):
        c = self.app.test_client()
        self.assertIn(c.get("/admin/update").status_code, (302, 401, 403))
        c.get("/login")
        with c.session_transaction() as s:
            t = s["csrf"]
        c.post("/login", data={"username": "entry1", "password": "secret1", "csrf": t})
        self.assertEqual(c.get("/admin/update").status_code, 403)
        self.assertEqual(c.get("/admin/update/status").status_code, 403)

    def test_shows_new_version_and_menu_link(self):
        self.publish("9.0")
        c = self.login_admin()
        html = c.get("/admin/update").get_data(as_text=True)
        self.assertIn("نسخهٔ جدید آماده است", html)
        self.assertIn("9.0", html)
        self.assertTrue(c.get("/admin/update/status").get_json()["newer"])
        self.assertIn("upd-banner", c.get("/").get_data(as_text=True))
        self.assertIn("به‌روزرسانی برنامه", c.get("/settings").get_data(as_text=True))

    def test_up_to_date_and_offline(self):
        self.publish(config.APP_VERSION)
        c = self.login_admin()
        self.assertIn("آخرین نسخه را دارید", c.get("/admin/update").get_data(as_text=True))
        os.remove(os.path.join(self.srv_dir, "latest.json"))
        t = self.token(c)
        c.post("/admin/update", data={"csrf": t, "action": "check"})
        self.assertIn("اتصال به سرور", c.get("/admin/update").get_data(as_text=True))

    def test_apply_replaces_app_but_keeps_data(self):
        self.publish("9.0")
        c = self.login_admin()
        t = self.token(c)
        r = c.post("/admin/update", data={"csrf": t, "action": "apply"})
        self.assertEqual(r.status_code, 200)
        self.assertIn("در حال به‌روزرسانی", r.get_data(as_text=True))
        read = lambda rel: open(os.path.join(self.root, rel)).read()
        self.assertEqual(read("run.py"), "v-new")
        self.assertEqual(read("app/new.py"), "new")
        self.assertEqual(read("instance/cases.sqlite"), "REAL-DATA")     # اطلاعات دست‌نخورده
        self.assertEqual(read("backups/b1.sqlite"), "BK")
        self.assertEqual(read("updates/previous/run.py"), "v-old")        # نسخهٔ قبلی برای برگشت
        self.assertFalse(os.path.exists(os.path.join(self.tmp.name, "evil.txt")))
        acts = [r[0] for r in self.db.execute("SELECT action FROM audit_log")]
        self.assertIn("app_update", acts)

    def test_bad_checksum_changes_nothing(self):
        self.publish("9.0", sha_ok=False)
        c = self.login_admin()
        t = self.token(c)
        r = c.post("/admin/update", data={"csrf": t, "action": "apply"}, follow_redirects=True)
        self.assertIn("سالم نیست", r.get_data(as_text=True))
        self.assertEqual(open(os.path.join(self.root, "run.py")).read(), "v-old")

    def test_zip_slip_is_ignored(self):
        self.publish("9.0", evil=True)
        c = self.login_admin()
        t = self.token(c)
        c.post("/admin/update", data={"csrf": t, "action": "apply"})
        self.assertFalse(os.path.exists(os.path.join(self.root, "..", "evil.txt")))
        self.assertFalse(os.path.exists(os.path.join(self.tmp.name, "evil.txt")))

    def test_csrf_required(self):
        self.publish("9.0")
        c = self.login_admin()
        self.assertEqual(c.post("/admin/update", data={"action": "apply"}).status_code, 400)
        self.assertEqual(open(os.path.join(self.root, "run.py")).read(), "v-old")

    def test_windows_script_protects_data(self):
        bat = updater.BAT
        self.assertIn("/XD instance backups reports updates", bat)
        self.assertIn("pushd", bat)                     # پوشهٔ شبکه (UNC) هم کار کند
        self.assertIn("updates\\previous", bat)
        self.assertIn('IranEnsheab.exe"', bat.split(':start')[1])
        self.assertNotIn("rd /s /q instance", bat)
        self.assertNotIn("del ", bat.replace("update", ""))

    def test_windows_launch_uses_shell_execute(self):
        from unittest import mock
        with mock.patch.object(os, "startfile", create=True) as sf:
            updater.launch_windows_update(self.app)
        path = sf.call_args[0][0]
        self.assertTrue(path.endswith("apply_update.vbs"))
        self.assertIn("apply_update.bat", open(path, encoding="utf-16").read())
        bat = os.path.join(os.path.dirname(path), "apply_update.bat")
        self.assertIn("IranEnsheab.exe", open(bat).read())

    def test_windows_launch_failure_is_logged(self):
        from unittest import mock
        with mock.patch.object(os, "startfile", create=True, side_effect=OSError("boom")):
            with self.assertRaises(OSError):
                updater.launch_windows_update(self.app)
        self.assertIn("boom", open(os.path.join(self.root, "updates", "launch.log"), encoding="utf-8").read())

    def test_vbs_failure_falls_back_to_bat(self):
        from unittest import mock
        calls = []
        def fake(p):
            calls.append(p)
            if p.endswith(".vbs"):
                raise OSError("no vbs")
        with mock.patch.object(os, "startfile", create=True, side_effect=fake):
            updater.launch_windows_update(self.app)
        self.assertTrue(calls[0].endswith(".vbs") and calls[1].endswith(".bat"))


class DnsFallbackTests(unittest.TestCase):
    def test_gaierror_falls_back_to_doh(self):
        import socket, urllib.error
        from unittest import mock
        from app import updater
        err = urllib.error.URLError(socket.gaierror(11001, "getaddrinfo failed"))
        with mock.patch("urllib.request.urlopen", side_effect=err), \
             mock.patch.object(updater, "_doh_resolve", return_value=["1.2.3.4"]) as d, \
             mock.patch.object(updater, "_open_via_ip", return_value="OK") as v:
            self.assertEqual(updater._open("https://example.com/x", 5), "OK")
            d.assert_called_once_with("example.com")
            v.assert_called_once()

    def test_other_errors_are_not_retried(self):
        import urllib.error
        from unittest import mock
        from app import updater
        with mock.patch("urllib.request.urlopen", side_effect=urllib.error.URLError("refused")):
            with self.assertRaises(urllib.error.URLError):
                updater._open("https://example.com/x", 5)


class SlowMirrorTests(UpdateTests):
    def test_progress_text_and_download_ok(self):
        self.publish()
        st = updater.status(self.app, force=True)
        seen = []
        pkg = updater.download(self.app, st["file"], progress=lambda f, t="": seen.append((f, t)))
        self.assertTrue(os.path.exists(pkg))
        self.assertTrue(seen and "مگابایت" in seen[-1][1])

    def test_slow_first_source_falls_to_next(self):
        self.publish()
        st = updater.status(self.app, force=True)
        calls = []
        real = updater._fetch_one

        def fake(base, name, part, progress, enforce):
            calls.append((base, enforce))
            if len(calls) == 1:
                raise updater._Slow()
            return real(base, name, part, progress, enforce)
        updater._fetch_one = fake
        try:
            updater.bases = lambda app, _b=updater.bases: [_b(app)[0], _b(app)[0]]
            pkg = updater.download(self.app, st["file"])
        finally:
            updater._fetch_one = real
            import importlib
            importlib.reload(updater)
        self.assertEqual(len(calls), 2)
        self.assertTrue(os.path.exists(pkg))

    def test_all_sources_down_gives_clear_error(self):
        self.publish()
        st = updater.status(self.app, force=True)
        self.app.config["UPDATE_URL"] = "http://127.0.0.1:9"
        with self.assertRaises(updater.UpdateError):
            updater.download(self.app, st["file"])
