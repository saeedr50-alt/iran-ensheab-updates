"""دسترسی فیلد به فیلد برای هر کاربر: مدیر مشخص می‌کند هر کاربر کدام فیلدها را می‌تواند تغییر بدهد.

- پیش‌فرض: همهٔ فیلدها قابل ویرایش است. فیلد «قفل‌شده» برای آن کاربر دیده می‌شود ولی تغییر نمی‌کند.
- مدیر (admin) هیچ محدودیتی ندارد.
- کنترل اصلی سمت سرور است (حتی اگر فرم دستکاری شود، مقدار قبلی می‌ماند و تلاش در گزارش فعالیت ثبت می‌شود).
"""
import sqlite3

from werkzeug.datastructures import MultiDict

from . import case_data, config, profile
from .jalali import to_fa_digits

TABLE_KEYS = (("products", "جدول محصولات (افزودن و ویرایش ردیف‌ها)"), ("competitors", "جدول رقیب / رقبا"))
PRICES_KEY = "p_prices"


TYPE_KEYS = (("type_tender", "مناقصه", "مناقصه"), ("type_inquiry", "استعلام", "استعلام"), ("type_auction", "مزایده", "مزایده"))
UI_KEYS = (("ui_edit", "دکمهٔ «ویرایش» (و امکان ویرایش پرونده)"), ("ui_view", "دکمهٔ «نمایش» (نمای شناسنامه)"))


def type_key(case_type: str) -> str:
    """کلید دسترسی نوعِ یک پرونده (مناقصه/استعلام/مزایده)؛ نوع‌ها با چک‌باکس همان گروه اصلی‌اند."""
    grp = config.CASE_GROUPS.get(case_type, "")
    for k, _, g in TYPE_KEYS:
        if g == grp:
            return k
    return ""


def type_allowed(locked, case_type: str) -> bool:
    k = type_key(case_type)
    return not k or k not in locked


def can_create_any(locked) -> bool:
    return any(k not in locked for k, _, _ in TYPE_KEYS) and "case_type" not in locked


def groups() -> list:
    """[(عنوان گروه، [(کلید، عنوان)])] برای صفحهٔ کاربران."""
    main = [("case_type", "نوع پرونده (تغییر هنگام ویرایش)")] + [
        (f, case_data.FIELD_LABELS[f]) for f in case_data.TEXT_FIELDS if f not in ("notes", "sent_at")]
    prof = [("p_" + k, label) for k, label, _ in profile.PROFILE_FIELDS if k != "announce_date"] + [
        (PRICES_KEY, "قیمت محصولات (در شناسنامه)")]
    return [("نوع پرونده (کدام نوع را می‌تواند ثبت یا انتخاب کند)", [(k, t) for k, t, _ in TYPE_KEYS]),
            ("دکمه‌های لیست پرونده‌ها", list(UI_KEYS)),
            ("فرم اصلی", main), ("جدول‌ها", list(TABLE_KEYS)), ("اطلاعات شناسنامه", prof)]


def all_keys() -> set:
    return {k for _, items in groups() for k, _ in items}


def label_of(key: str) -> str:
    for _, items in groups():
        for k, t in items:
            if k == key:
                return t
    return key


def locked_for(user) -> frozenset:
    if user is None or user["role"] == "admin":
        return frozenset()
    raw = user["field_locked"] if "field_locked" in user.keys() else ""
    return frozenset(k for k in (raw or "").split(",") if k)


def set_locked(db: sqlite3.Connection, user_id: int, locked: list) -> list:
    valid = all_keys()
    clean = [k for k in locked if k in valid]
    db.execute("UPDATE users SET field_locked = ? WHERE id = ?", (",".join(clean), user_id))
    return clean


# ------------------------------------------------------------ اعمال روی فرم اصلی
def apply_locks(form, existing: dict | None, locked) -> tuple:
    """فرمِ ارسال‌شده را کپی می‌کند و مقدار فیلدهای قفل‌شده را با مقدار ذخیره‌شده عوض می‌کند.
    خروجی: (فرم تازه، فهرست عنوان فیلدهایی که کاربر سعی کرده تغییر بدهد)."""
    if not locked:
        return form, []
    old = existing or {}
    f2 = MultiDict(form)
    denied = []
    for f in case_data.TEXT_FIELDS:
        if f not in locked:
            continue
        oldv = old.get(f, "") or ""
        if f in form and to_fa_digits(" ".join(form.get(f, "").split())) != to_fa_digits(oldv):
            denied.append(case_data.FIELD_LABELS[f])
        f2[f] = oldv
    if "case_type" in locked and existing and "case_type" in form and form.get("case_type") != old.get("case_type"):
        denied.append("نوع پرونده")
    ct = form.get("case_type", "")
    if ct and not type_allowed(locked, ct) and (not existing or ct != old.get("case_type")):
        denied.append("نوع پرونده (" + config.CASE_TYPES.get(ct, ct) + ")")
        f2.pop("case_type", None)
    if "case_type" in locked:
        f2.pop("case_type", None)
    return f2, denied


def restore_tables(data: dict, existing: dict | None, locked, form) -> list:
    """جدول‌های قفل‌شده همان ردیف‌های ذخیره‌شده می‌مانند. خروجی: عنوان جدول‌هایی که تلاش برای تغییرشان شده."""
    old = existing or {}
    denied = []
    if "products" in locked:
        if any(not str(u).isdigit() for u in form.getlist("prod_uid")):
            denied.append("جدول محصولات")
        data["products"] = [dict(p, uid=str(p["id"])) for p in old.get("products", [])]
    if "competitors" in locked:
        if any(not str(u).isdigit() for u in form.getlist("comp_uid")):
            denied.append("جدول رقبا")
        keep = config.matches(data.get("result", ""), config.LOSER_VALUE)
        data["competitors"] = [dict(c, uid=str(c["id"]), won=bool(c["won"])) for c in old.get("competitors", [])] if keep else []
    return denied


# ------------------------------------------------------------ شناسنامه
def profile_denied(form, old: dict, locked, products) -> list:
    out = []
    for k, label, kind in profile.PROFILE_FIELDS:
        if "p_" + k in locked and k in form and to_fa_digits((form.get(k) or "").strip()) != to_fa_digits(old.get(k, "") or ""):
            out.append(label)
    if PRICES_KEY in locked:
        for p in products:
            raw = to_fa_digits((form.get(f"price_{p['id']}") or "").strip())
            if f"price_{p['id']}" in form and raw not in ("", str(p.get("price", 0))):
                out.append("قیمت محصولات")
                break
    return out
