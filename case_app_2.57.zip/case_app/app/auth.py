import os
import functools
import secrets

from flask import (Blueprint, abort, flash, g, redirect, render_template,
                   request, session, url_for)
from werkzeug.security import check_password_hash, generate_password_hash

from . import audit, config, seats
from .db import get_db

bp = Blueprint("auth", __name__)


# ---------- کاربر جاری و محافظ‌ها ----------

def load_current_user():
    user_id = session.get("user_id")
    g.user = None
    if user_id is not None:
        g.user = get_db().execute(
            "SELECT id, username, full_name, role, active, dash_hidden, field_locked FROM users WHERE id = ?", (user_id,)
        ).fetchone()
        if g.user is None or not g.user["active"]:        # کاربر غیرفعال‌شده فوراً بیرون می‌افتد
            g.user = None
            session.clear()


def login_required(view):
    @functools.wraps(view)
    def wrapped(*args, **kwargs):
        if g.user is None:
            return redirect(url_for("auth.login", next=request.path))
        return view(*args, **kwargs)
    return wrapped


def roles_required(*roles):
    def decorator(view):
        @functools.wraps(view)
        def wrapped(*args, **kwargs):
            if g.user is None:
                return redirect(url_for("auth.login", next=request.path))
            if g.user["role"] not in roles:
                abort(403)
            return view(*args, **kwargs)
        return wrapped
    return decorator


# ---------- CSRF (جلوگیری از ارسال فرم جعلی از سایت دیگر) ----------

def csrf_token() -> str:
    if "csrf" not in session:
        session["csrf"] = secrets.token_hex(16)
    return session["csrf"]


def check_csrf():
    sent = request.form.get("csrf", "")
    if not sent or not secrets.compare_digest(sent, session.get("csrf", "")):
        abort(400, "درخواست نامعتبر است. صفحه را دوباره باز کنید.")


# ---------- کاربران ----------

def create_user(db, username: str, password: str, role: str) -> int:
    if role not in config.ROLES:
        raise ValueError("نقش نامعتبر")
    if len(password) < 6:
        raise ValueError("رمز عبور باید حداقل ۶ کاراکتر باشد")
    cur = db.execute(
        "INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)",
        (username.strip(), generate_password_hash(password), role),
    )
    return cur.lastrowid


# ---------- صفحه‌ها ----------

def _no_users() -> bool:
    return get_db().execute("SELECT 1 FROM users LIMIT 1").fetchone() is None


@bp.route("/setup", methods=["GET", "POST"])
def setup():
    """راه‌اندازی اولیه (نسخهٔ خام): فقط وقتی هنوز هیچ کاربری نیست، مدیر اول را می‌سازد."""
    db = get_db()
    if not _no_users():
        return redirect(url_for("auth.login"))
    if request.method == "POST":
        check_csrf()
        from . import audit, users
        pw = request.form.get("password", "")
        if pw != request.form.get("password2", ""):
            flash("دو رمز عبور یکسان نیستند.", "error")
        else:
            try:
                uid = users.create(db, request.form.get("username", ""), pw, "admin",
                                   request.form.get("full_name", ""))
            except (users.UserError, ValueError) as e:
                flash(str(e), "error")
            else:
                audit.log(db, "user_create", "راه‌اندازی اولیه: مدیر اول ساخته شد",
                          user=db.execute("SELECT * FROM users WHERE id = ?", (uid,)).fetchone())
                flash("مدیر ساخته شد. اکنون وارد شوید.", "success")
                return redirect(url_for("auth.login"))
    return render_template("setup.html")


@bp.route("/login", methods=["GET", "POST"])
def login():
    if _no_users():
        return redirect(url_for("auth.setup"))
    if request.method == "POST":
        check_csrf()
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        user = get_db().execute(
            "SELECT * FROM users WHERE username = ?", (username,)
        ).fetchone()
        if user is None or not check_password_hash(user["password_hash"], password):
            flash("نام کاربری یا رمز عبور اشتباه است.", "error")
            audit.log(get_db(), "login_fail", f"نام کاربری واردشده: «{username[:40]}»", user=user)
        elif not user["active"]:
            flash("این حساب غیرفعال شده است. با مدیر تماس بگیرید.", "error")
        else:
            get_db().execute("UPDATE users SET last_login = datetime('now') WHERE id = ?", (user["id"],))
            session.clear()
            session["user_id"] = user["id"]
            session["welcome"] = 1
            audit.log(get_db(), "login", "", user=user)
            nxt = request.args.get("next", "")
            # فقط مسیرهای داخلی سایت مجاز است
            if not nxt.startswith("/") or nxt.startswith("//"):
                nxt = url_for("main.dashboard")
            return redirect(nxt)
    return render_template("login.html")


@bp.route("/logout", methods=["POST"])
def logout():
    check_csrf()
    shutdown = False
    if g.user is not None:
        seats.release(get_db(), g.user["id"])      # جای ویرایش با خروج آزاد می‌شود
        audit.log(get_db(), "logout", "")
        # مدیر در نسخهٔ ویندوز: خروج یعنی خاموش‌شدن کامل برنامه
        from . import updater
        shutdown = g.user["role"] == "admin" and updater.is_frozen() and os.name == "nt"
    session.clear()
    if request.form.get("exit"):
        if shutdown:
            import threading, time
            threading.Thread(target=lambda: (time.sleep(1.5), os._exit(0)), daemon=True).start()
        return render_template("bye.html", shutdown=shutdown)
    return redirect(url_for("auth.login"))
