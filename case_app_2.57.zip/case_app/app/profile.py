"""فرم شناسنامه (پاپ‌آپ فرم اصلی): اطلاعات تکمیلی هر پرونده + قیمت هر محصول + گزارش چاپی.

برای اضافه/حذف/تغییر فیلدهای این فرم فقط فهرست PROFILE_FIELDS را عوض کنید؛
ستون دیتابیس، پاپ‌آپ، اعتبارسنجی و ذخیره خودکار با آن هماهنگ می‌شوند.
(فیلدهایی که در فرم اصلی هستند اینجا نمی‌آیند.)
"""
import re
import sqlite3

from . import case_data, config, options
from .jalali import fa_num, normalize_jdate, to_fa_digits, today_jalali

# (کلید، عنوان، نوع)   نوع: text | long | date | money(عدد با جداکنندهٔ سه‌رقمی) | combo(کلید = نام گروه گزینه)
PROFILE_FIELDS = [
    ("issue_date", "تاریخ صدور شناسنامه", "date"),
    ("subject", "موضوع مناقصه", "long"),
    ("call_no", "شماره فراخوان", "text"),
    ("need_no", "شماره نیاز", "text"),
    ("tender_no", "شماره مناقصه", "text"),
    ("announce_date", "تاریخ اعلام آگهی", "date"),
    ("send_method", "نحوه ارسال اسناد", "combo"),
    ("contract_period", "مدت قرارداد", "text"),
    ("payment_method", "نحوه پرداخت", "combo"),
    ("advance", "پیش پرداخت", "combo"),
    ("inspection", "بازرسی", "combo"),
    ("shipping", "حمل", "combo"),
    ("unloading", "تخلیه", "combo"),
    ("delivery_place", "محل تحویل کالا", "text"),
    ("warranty", "مدت گارانتی", "text"),
    ("after_sales", "مدت خدمات پس از فروش", "text"),
    ("clearance", "مفاصا حساب", "combo"),
    ("bid_guarantee", "مبلغ ضمانت نامه شرکت در مناقصه", "money"),
    ("perf_guarantee", "مبلغ ضمانت نامه حسن انجام تعهدات", "money"),
    ("doc_notes", "توضیحات مهم در اسناد", "long"),
    ("commercial_notes", "توضیحات واحد بازرگانی", "long"),
    ("expert_sign", "امضا کارشناس بازرگانی", "text"),
    ("manager_sign", "امضا مدیر بازرگانی یا مدیر فروش", "text"),
    ("ceo_notes", "توضیحات و امضا مدیرعامل", "long"),
]
# فیلدهایی که برای هر گروه پرونده نیازی نیست (در فرم و گزارش نمی‌آیند)
INQUIRY_HIDDEN = {"subject", "call_no", "tender_no", "contract_period", "advance", "clearance",
                  "bid_guarantee", "perf_guarantee"}          # استعلام: فقط «شماره نیاز» می‌ماند
NON_INQUIRY_HIDDEN = {"need_no"}                              # مناقصه و مزایده: «شماره نیاز» لازم نیست


def hidden_keys(case_type: str) -> set:
    return INQUIRY_HIDDEN if config.CASE_GROUPS.get(case_type) == "استعلام" else NON_INQUIRY_HIDDEN


def fields_for(case_type: str) -> list:
    hide = hidden_keys(case_type)
    return [f for f in PROFILE_FIELDS if f[0] not in hide]


KEYS = [k for k, _, _ in PROFILE_FIELDS]
LABELS = {k: l for k, l, _ in PROFILE_FIELDS}
KINDS = {k: t for k, _, t in PROFILE_FIELDS}
MAX = {"text": 200, "long": 2000, "money": 200}


class Conflict(Exception):
    pass


def ensure_columns(conn: sqlite3.Connection) -> None:
    existing = {r["name"] for r in conn.execute("PRAGMA table_info(case_profile)")}
    for k in KEYS:
        if k not in existing:
            conn.execute(f"ALTER TABLE case_profile ADD COLUMN {k} TEXT NOT NULL DEFAULT ''")


def load(db: sqlite3.Connection, case_id: int) -> dict:
    row = db.execute("SELECT * FROM case_profile WHERE case_id = ?", (case_id,)).fetchone()
    data = {k: (row[k] if row else "") for k in KEYS}
    for k in KEYS:
        if KINDS[k] == "money":                 # مبلغ همیشه سه‌رقم‌سه‌رقم نشان داده می‌شود (حتی دادهٔ قدیمی)
            data[k] = fa_num(data[k])
    crow = db.execute("SELECT announce_date FROM cases WHERE id = ?", (case_id,)).fetchone()
    data["announce_date"] = crow["announce_date"] if crow else ""      # از فرم اصلی می‌آید (فقط‌خواندنی)
    data["version"] = row["version"] if row else 0
    data["exists"] = row is not None
    return data


def parse(form, db: sqlite3.Connection, case: dict, old: dict, locked=()) -> tuple[dict, dict, list[str]]:
    """خروجی: (مقدارهای فیلدها، قیمت هر محصول {id: عدد}، خطاها)"""
    errors: list[str] = []
    opts = options.options_for_form(db)
    vals: dict = {}
    hide = hidden_keys(case.get("case_type", ""))
    for k, label, kind in PROFILE_FIELDS:
        if k in hide or k == "announce_date" or ("p_" + k) in locked:     # در این نوع نیست / از فرم اصلی می‌آید / برای این کاربر قفل است
            vals[k] = old.get(k, "")
            continue
        raw = to_fa_digits((form.get(k) or "").strip())
        if kind in ("text", "long", "combo"):
            raw = raw.replace("ي", "ی").replace("ك", "ک")
        if kind == "money":
            raw = fa_num(re.sub(r"[^0-9۰-۹٠-٩]", "", raw))       # فقط رقم؛ با جداکنندهٔ سه‌رقمی ذخیره می‌شود
        if raw and kind == "date":
            norm = normalize_jdate(raw)
            if norm:
                raw = to_fa_digits(norm)
            elif raw != to_fa_digits(old.get(k)):
                errors.append(f"«{label}» معتبر نیست. تاریخ شمسی را مثل ۱۴۰۵/۰۷/۱۶ وارد کنید.")
        elif raw and kind == "combo":
            canon = case_data._canon(raw, set(opts.get(k, [])) | {old.get(k, "")})
            if canon is None:
                errors.append(f"مقدار انتخاب‌شده برای «{label}» مجاز نیست.")
            else:
                raw = canon
        if len(raw) > MAX.get(kind, 200):
            errors.append(f"«{label}» بیش از حد طولانی است.")
        vals[k] = raw
    prices: dict[int, int] = {}
    for p in case["products"]:
        if "p_prices" in locked:                  # قیمت‌ها برای این کاربر قفل است: همان مقدار قبلی
            prices[p["id"]] = p.get("price", 0)
            continue
        raw = to_fa_digits((form.get(f"price_{p['id']}") or "").strip())
        n = case_data._to_int(raw)
        if n is None or n > case_data.MAX_PRICE:
            errors.append("«قیمت» باید یک عدد صحیح باشد.")
            n = p.get("price", 0)
        prices[p["id"]] = n
    return vals, prices, errors


def save(db: sqlite3.Connection, case_id: int, vals: dict, prices: dict, user_id: int, expected: int) -> int:
    """همه یا هیچ. اگر کاربر دیگری در این فاصله ذخیره کرده باشد Conflict می‌دهد. خروجی: نسخهٔ جدید."""
    db.execute("BEGIN IMMEDIATE")
    try:
        row = db.execute("SELECT version FROM case_profile WHERE case_id = ?", (case_id,)).fetchone()
        cols = ", ".join(KEYS)
        if row is None:
            if expected != 0:
                raise Conflict()
            db.execute(f"INSERT INTO case_profile (case_id, {cols}, version, updated_at, updated_by) "
                       f"VALUES (?, {', '.join('?' * len(KEYS))}, 1, datetime('now'), ?)",
                       [case_id] + [vals[k] for k in KEYS] + [user_id])
            version = 1
        else:
            if row["version"] != expected:
                raise Conflict()
            sets = ", ".join(f"{k} = ?" for k in KEYS)
            db.execute(f"UPDATE case_profile SET {sets}, version = version + 1, updated_at = datetime('now'), "
                       f"updated_by = ? WHERE case_id = ?", [vals[k] for k in KEYS] + [user_id, case_id])
            version = row["version"] + 1
        for pid, price in prices.items():
            db.execute("UPDATE case_products SET price = ? WHERE id = ? AND case_id = ?", (price, pid, case_id))
        db.execute("COMMIT")
        return version
    except BaseException:
        db.execute("ROLLBACK")
        raise


# ---------------------------------------------------------------- گزارش
def size_text(size: str) -> str:
    """1.2 -> 1/2 ، 1-1.4 -> 1-1/4 (سایزها اینچ هستند)"""
    return re.sub(r"(?<=\d)\.(?=\d)", "/", size or "")


def product_name(p: dict) -> str:
    name = p.get("product_type") or ""
    if p.get("size"):
        name += f" سایز {size_text(p['size'])} اینچ"
    return name.strip()


def report_context(db: sqlite3.Connection, case: dict) -> dict:
    prof = load(db, case["id"])
    samples = []
    for p in case["products"]:
        if p.get("sample") and p["sample"] not in samples:
            samples.append(p["sample"])
    return dict(prof=prof, hide=hidden_keys(case["case_type"]), samples="، ".join(samples),
                products=[dict(name=product_name(p), model=p.get("model", ""), quantity=p["quantity"],
                               price=p.get("price") or 0) for p in case["products"]],
                today=to_fa_digits(today_jalali()))
