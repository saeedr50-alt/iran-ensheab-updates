"""خواندن، اعتبارسنجی و ذخیره اطلاعات فرم پرونده (به‌همراه ردیف‌های محصولات و رقبا)."""
import sqlite3
from datetime import datetime

import re

from . import config, options
from .jalali import normalize_jdate, to_ascii_digits, to_fa_digits, today_jalali

TEXT_FIELDS = (
    "received_date", "announce_date", "source", "organization", "tender_type", "status",
    "send_deadline", "physical_upload", "opening_time", "decision", "archive_reason",
    "result", "result_date", "notes", "sent_at", "sent_guarantee", "sent_sample", "sent_docs",
)
DATE_FIELDS = ("received_date", "announce_date", "send_deadline", "opening_time", "result_date")
TIME_FIELDS = ("physical_upload",)          # ساعت به شکل 14:30
_TIME_RE = re.compile(r"^([01]?\d|2[0-3]):([0-5]\d)$")
# فیلدهایی که باید از گزینه‌های مدیریت‌شده انتخاب شوند: فیلد -> گروه گزینه
OPTION_FIELDS = {
    "source": "source", "organization": "organization", "tender_type": "tender_type",
    "status": "status", "decision": "decision", "result": "result",
}
PRODUCT_OPTION_FIELDS = ("product_type", "r_size", "size", "model", "sample")

FIELD_LABELS = {
    "received_date": "تاریخ دریافت", "announce_date": "تاریخ اعلان آگهی", "source": "منبع دریافت", "organization": "سازمان / شرکت",
    "tender_type": "نوع برگزاری", "status": "وضعیت پرونده", "send_deadline": "مهلت ارسال",
    "physical_upload": "ساعت مهلت ارسال اسناد", "opening_time": "زمان بازگشایی",
    "decision": "تصمیم مدیریتی", "archive_reason": "علت بایگانی", "result": "نتیجه", "result_date": "تاریخ اعلام نتایج", "notes": "توضیحات",
    "sent_at": "تاریخ ارسال", "sent_guarantee": "ارسال: ضمانت‌نامه", "sent_sample": "ارسال: نمونه", "sent_docs": "ارسال: مدارک",
    "product_type": "نام محصول", "r_size": "اندازه R", "size": "سایز", "model": "مدل", "sample": "نمونه", "sample_qty": "تعداد نمونه",
}
MAX_LEN = {"notes": 2000}
SENT_FIELDS = ("sent_at", "sent_guarantee", "sent_sample", "sent_docs")
MAX_QUANTITY = 10**9
MAX_PRICE = 10**13
MAX_NAME_LEN = 200
MAX_NOTE_LEN = 500


class ConflictError(Exception):
    """پرونده بین باز کردن فرم و ذخیره، توسط کاربر دیگری تغییر کرده است."""


def empty_case() -> dict:
    case = {f: "" for f in TEXT_FIELDS}
    case.update(case_type="", serial_no=None, year=0, id=None, version=1, products=[], competitors=[])
    return case


def _canon(raw: str, allowed) -> str | None:
    """مقدار انتخاب‌شده را با گزینه‌های مجاز مقایسه می‌کند (ارقام فارسی/انگلیسی یکی حساب می‌شوند)
    و همان گزینهٔ ثبت‌شده را برمی‌گرداند؛ اگر مجاز نبود None."""
    key = to_fa_digits(raw)
    for a in allowed:
        if to_fa_digits(a) == key:
            return a
    return None


def _at(values: list, i: int) -> str:
    return values[i] if i < len(values) else ""


def _to_int(text: str) -> int | None:
    s = to_ascii_digits(text or "")
    for ch in (",", "،", " ", "٬"):
        s = s.replace(ch, "")
    if s == "":
        return 0
    return int(s) if s.isdigit() else None


# ---------------------------------------------------------------- خواندن فرم

def _parse_competitors(form, old: dict, errors: list[str]) -> list[dict]:
    rows: list[dict] = []
    old_comps = {str(c["id"]): c for c in old.get("competitors", [])}
    won_uids = set(form.getlist("comp_won"))
    for i, uid in enumerate(form.getlist("comp_uid")):
        saved = old_comps.get(uid)
        if uid.isdigit() and saved is None:
            errors.append("ردیف رقیب نامعتبر است. صفحه را دوباره باز کنید.")
            continue
        name = to_fa_digits(_at(form.getlist("comp_name"), i).strip())
        praw = to_fa_digits(_at(form.getlist("comp_price"), i).strip())
        note = to_fa_digits(_at(form.getlist("comp_note"), i).strip())
        price = _to_int(praw)
        if price is None or price > MAX_PRICE:
            errors.append("«قیمت» باید یک عدد صحیح باشد.")
            price = 0
        won = uid in won_uids
        row = {"id": int(uid) if saved else None, "uid": uid, "name": name, "price": price,
               "price_raw": praw, "won": won, "note": note}
        if len(name) > MAX_NAME_LEN or len(note) > MAX_NOTE_LEN:
            errors.append("نام یا یادداشت رقیب بیش از حد طولانی است.")
        if not name and (price or won or note):
            errors.append("برای هر ردیف رقبا «نام رقیب» را وارد کنید.")
        if not name and not price and not won and not note:
            if saved:
                errors.append("ردیف رقیبِ ذخیره‌شده نمی‌تواند خالی شود.")
            continue
        rows.append(row)
    return rows


def parse_form(form, db: sqlite3.Connection, existing: dict | None = None) -> tuple[dict, list[str]]:
    """فرم ارسال‌شده را اعتبارسنجی می‌کند. خروجی: (داده‌ها، فهرست خطاها).

    existing = پرونده ذخیره‌شده (هنگام ویرایش). مقدار قبلی یک گزینه حتی اگر بعداً غیرفعال شده
    باشد مجاز می‌ماند، تا ویرایش پرونده‌های قدیمی گیر نکند.
    """
    errors: list[str] = []
    old = existing or {}
    opts = options.options_for_form(db)
    data: dict = {}

    # ---- تغییر «نوع پرونده» هنگام ویرایش (اگر اشتباه انتخاب شده بود)
    new_type = (form.get("case_type") or "").strip() if existing else ""
    if new_type and new_type != old.get("case_type"):
        if new_type not in config.SELECTABLE_TYPES:
            errors.append("نوع پرونده انتخاب‌شده معتبر نیست.")
        else:
            data["case_type"] = new_type

    for f in TEXT_FIELDS:
        if f in SENT_FIELDS:
            continue                      # پایین‌تر، بعد از دانستن وضعیت و محصولات، تنظیم می‌شوند
        if f == "notes" and f not in form:      # این فیلدها از فرم برداشته شده‌اند؛ مقدار قبلی می‌ماند
            data[f] = old.get(f, "")
            continue
        raw = to_fa_digits((form.get(f) or "").strip())
        label = FIELD_LABELS[f]
        if f == "archive_reason":
            continue                      # پایین‌تر، بعد از دانستن «تصمیم مدیریتی»، بررسی می‌شود
        if raw and f in DATE_FIELDS:
            norm = normalize_jdate(raw)
            if norm is not None:
                raw = to_fa_digits(norm)
            elif raw != to_fa_digits(old.get(f)):       # مقدار قدیمیِ ذخیره‌شده (از نسخه‌های قبل) دست‌نخورده می‌ماند
                errors.append(f"«{label}» معتبر نیست. تاریخ شمسی را مثل ۱۴۰۵/۰۷/۱۶ وارد کنید.")
        elif raw and f in TIME_FIELDS:
            m = _TIME_RE.match(to_ascii_digits(raw))
            if m:
                raw = to_fa_digits(f"{int(m.group(1)):02d}:{m.group(2)}")
            elif raw != to_fa_digits(old.get(f)):
                errors.append(f"«{label}» معتبر نیست. ساعت را مثل 14:30 وارد کنید.")
        elif raw and f in OPTION_FIELDS:
            canon = _canon(raw, set(opts[OPTION_FIELDS[f]]) | {old.get(f, "")})
            if canon is None:
                errors.append(f"مقدار انتخاب‌شده برای «{label}» مجاز نیست.")
            else:
                raw = canon
        if len(raw) > MAX_LEN.get(f, 200):
            errors.append(f"«{label}» بیش از حد طولانی است.")
        data[f] = raw

    # ---- استعلام «نوع برگزاری» ندارد (به جایش «منبع دریافت» است)
    if config.CASE_GROUPS.get(form.get("case_type") or old.get("case_type") or "") == "استعلام":
        data["tender_type"] = ""

    # ---- ساعت مهلت ارسال: خودکار است. با مهلت پر می‌شود؛ بدون مهلت خالی می‌ماند
    if not data["send_deadline"]:
        data["physical_upload"] = ""

    # ---- علت بایگانی: فقط وقتی «تصمیم مدیریتی = عدم تایید و بایگانی» است معنی دارد (کمبوباکسِ قابل افزودن)
    reason = to_fa_digits(" ".join((form.get("archive_reason") or "").split()))
    if config.matches(data["decision"], config.ARCHIVE_VALUE):
        if not reason:
            errors.append(f"چون تصمیم مدیریتی «{config.ARCHIVE_VALUE}» است، «علت بایگانی» را انتخاب کنید.")
        elif len(reason) > options.MAX_LABEL_LEN:
            errors.append("«علت بایگانی» بیش از حد طولانی است.")
        data["archive_reason"] = reason
        # پرونده عدم‌تاییدشده وارد جریان کار نمی‌شود: وضعیت و نتیجه ندارد (تاریخ بازگشایی آزاد است)
        data["status"] = data["result"] = data["result_date"] = ""
    else:
        data["archive_reason"] = ""
        # زنجیرهٔ وضعیت: نتیجه انتخاب شود ← وضعیت «نتیجه اعلام شد» و تاریخ اعلام نتایج (پیش‌فرض: امروز)
        if data["result"]:
            data["status"] = config.STATUS_RESULT
            if not data["result_date"]:
                data["result_date"] = to_fa_digits(today_jalali())
        else:
            data["result_date"] = ""
    if config.CASE_GROUPS.get(form.get("case_type") or old.get("case_type") or "") == "استعلام":
        data["opening_time"] = ""                      # زمان بازگشایی در استعلام نیست

    # ---- محصولات
    old_products = {str(p["id"]): p for p in old.get("products", [])}
    data["products"] = []
    uids = form.getlist("prod_uid")
    for i, uid in enumerate(uids):
        saved = old_products.get(uid)
        if uid.isdigit() and saved is None:
            errors.append("ردیف محصول نامعتبر است. صفحه را دوباره باز کنید.")
            continue
        row = {"id": int(uid) if saved else None, "uid": uid}
        for key in PRODUCT_OPTION_FIELDS:
            val = to_fa_digits(_at(form.getlist(f"prod_{key}"), i).strip())
            allowed = set(opts[key]) | ({saved[key]} if saved else set())
            if val:
                canon = _canon(val, allowed)
                if canon is None:
                    errors.append(f"مقدار انتخاب‌شده برای «{FIELD_LABELS[key]}» در ردیف محصولات مجاز نیست.")
                else:
                    val = canon
            row[key] = val
        sq = 0
        if config.sample_is_yes(row["sample"]):          # «تعداد نمونه» فقط وقتی نمونه = دارد
            sq = _to_int(to_fa_digits(_at(form.getlist("prod_sample_qty"), i).strip()))
            if sq is None or sq > MAX_QUANTITY:
                errors.append("«تعداد نمونه» باید یک عدد صحیح باشد.")
                sq = 0
        row["sample_qty"] = sq
        qraw = to_fa_digits(_at(form.getlist("prod_quantity"), i).strip())
        qty = _to_int(qraw)
        row["quantity_raw"] = qraw
        if qty is None or qty > MAX_QUANTITY:
            errors.append("«تعداد» باید یک عدد صحیح باشد.")
            qty = 0
        row["quantity"] = qty
        is_empty = qty == 0 and not any(row[k] for k in PRODUCT_OPTION_FIELDS)
        if is_empty:
            if saved:
                errors.append("ردیف محصولِ ذخیره‌شده نمی‌تواند خالی شود.")
            continue
        data["products"].append(row)

    # ---- بخش «ارسال»: تاریخ لحظهٔ ارسال خودکار است و بعد از ثبت تغییر نمی‌کند؛ سه چک‌باکس فقط وقتی وضعیت
    #      «ارسال شد» (یا بعد از آن «نتیجه اعلام شد») است معنی دارند؛ «نمونه» فقط وقتی نمونه = دارد
    in_sent = config.matches(data["status"], config.STATUS_SENT) or config.matches(data["status"], config.STATUS_RESULT)
    data["sent_at"] = old.get("sent_at", "") or ""
    if in_sent and not data["sent_at"]:
        data["sent_at"] = to_fa_digits(f"{today_jalali()} {datetime.now().strftime('%H:%M')}")
    has_sample = any(config.sample_is_yes(p["sample"]) for p in data["products"])
    data["sent_guarantee"] = "۱" if in_sent and form.get("sent_guarantee") else ""
    data["sent_docs"] = "۱" if in_sent and form.get("sent_docs") else ""
    data["sent_sample"] = "۱" if in_sent and has_sample and form.get("sent_sample") else ""

    # ---- رقبا
    # رقبا فقط وقتی «نتیجه = بازنده» است ثبت می‌شوند؛ در غیر این‌صورت بخش رقبا در فرم نیست و
    # هر چه فرستاده شود نادیده گرفته می‌شود (ردیف‌های ذخیره‌شده قبلی دست نمی‌خورند).
    data["competitors"] = []
    if config.matches(data["result"], config.LOSER_VALUE):
        data["competitors"] = _parse_competitors(form, old, errors)

    return data, errors


# ---------------------------------------------------------------- ذخیره

def apply_details(db: sqlite3.Connection, case_id: int, data: dict, user_id: int,
                  expected_version: int | None = None, bump_version: bool = True) -> None:
    """اطلاعات فرم را روی پرونده می‌نویسد. باید داخل یک تراکنش صدا زده شود."""
    sets = ", ".join(f"{f} = ?" for f in TEXT_FIELDS)
    sql = (f"UPDATE cases SET {sets}, version = version + ?, "
           f"updated_at = datetime('now'), updated_by = ? WHERE id = ?")
    params = [data[f] for f in TEXT_FIELDS] + [1 if bump_version else 0, user_id, case_id]
    if expected_version is not None:
        sql += " AND version = ?"
        params.append(expected_version)
    if db.execute(sql, params).rowcount != 1:
        raise ConflictError()

    if data.get("archive_reason"):     # علت‌های تازه برای پرونده‌های بعدی هم در دسترس می‌مانند
        options.remember_label(db, "archive_reason", data["archive_reason"])

    for pos, p in enumerate(data["products"], start=1):      # ترتیب ردیف‌ها همان ترتیب نمایش در فرم است
        values = (p["product_type"], p["r_size"], p["size"], p["quantity"], p["model"], p["sample"], p["sample_qty"], pos)
        if p["id"]:
            cur = db.execute(
                "UPDATE case_products SET product_type=?, r_size=?, size=?, quantity=?, model=?, sample=?, sample_qty=?, pos=? "
                "WHERE id = ? AND case_id = ?", values + (p["id"], case_id))
            if cur.rowcount != 1:
                raise ConflictError()
        else:
            db.execute(
                "INSERT INTO case_products (product_type, r_size, size, quantity, model, sample, sample_qty, pos, case_id) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)", values + (case_id,))

    for c in data["competitors"]:
        values = (c["name"], c["price"], 1 if c["won"] else 0, c["note"])
        if c["id"]:
            cur = db.execute(
                "UPDATE case_competitors SET name=?, price=?, won=?, note=? WHERE id = ? AND case_id = ?",
                values + (c["id"], case_id))
            if cur.rowcount != 1:
                raise ConflictError()
        else:
            db.execute(
                "INSERT INTO case_competitors (name, price, won, note, case_id) VALUES (?, ?, ?, ?, ?)",
                values + (case_id,))


def _move_type(db: sqlite3.Connection, case_id: int, new_type: str):
    """نوع پرونده را عوض می‌کند و شمارهٔ بعدیِ نوع تازه (در همان سال) را می‌دهد؛ شمارهٔ قبلی دوباره
    استفاده نمی‌شود (فقط در گزارش فعالیت می‌ماند). باید داخل تراکنش BEGIN IMMEDIATE صدا زده شود."""
    row = db.execute("SELECT case_type, year, serial_no FROM cases WHERE id = ?", (case_id,)).fetchone()
    if row is None or row["case_type"] == new_type:
        return None
    c = db.execute("SELECT last_no FROM counters WHERE case_type = ? AND year = ?", (new_type, row["year"])).fetchone()
    number = (c["last_no"] if c else 0) + 1
    if c is None:
        db.execute("INSERT INTO counters (case_type, year, last_no) VALUES (?, ?, ?)", (new_type, row["year"], number))
    else:
        db.execute("UPDATE counters SET last_no = ? WHERE case_type = ? AND year = ?", (number, new_type, row["year"]))
    db.execute("INSERT INTO settings (key, value) VALUES ('type_change_ok', ?) "
               "ON CONFLICT(key) DO UPDATE SET value = excluded.value", (str(case_id),))
    try:
        db.execute("UPDATE cases SET case_type = ?, serial_no = ? WHERE id = ?", (new_type, number, case_id))
    finally:
        db.execute("DELETE FROM settings WHERE key = 'type_change_ok'")
    return {"old_type": row["case_type"], "new_type": new_type, "old_serial": row["serial_no"], "new_serial": number}


def save_changes(db: sqlite3.Connection, case_id: int, data: dict, user_id: int, expected_version: int):
    """خروجی: اگر نوع پرونده عوض شد، دیکشنری {old_type, new_type, old_serial, new_serial}؛ وگرنه None."""
    """ویرایش پرونده موجود. اگر کاربر دیگری در این فاصله آن را تغییر داده باشد ConflictError می‌دهد
    و هیچ چیز ذخیره نمی‌شود (همه یا هیچ)."""
    db.execute("BEGIN IMMEDIATE")
    try:
        moved = None
        if data.get("case_type"):
            moved = _move_type(db, case_id, data["case_type"])
        apply_details(db, case_id, data, user_id, expected_version=expected_version)
        db.execute("COMMIT")
    except BaseException:
        db.execute("ROLLBACK")
        raise
    return moved


# ---------------------------------------------------------------- بارگذاری

def load_case(db: sqlite3.Connection, case_id: int) -> dict | None:
    row = db.execute("SELECT * FROM cases WHERE id = ?", (case_id,)).fetchone()
    if row is None:
        return None
    case = dict(row)
    case["products"] = [dict(r) for r in db.execute(
        "SELECT * FROM case_products WHERE case_id = ? ORDER BY pos, id", (case_id,))]
    case["competitors"] = [dict(r) for r in db.execute(
        "SELECT * FROM case_competitors WHERE case_id = ? ORDER BY id", (case_id,))]
    return case
