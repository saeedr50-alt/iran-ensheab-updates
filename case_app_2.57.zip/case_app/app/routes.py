import os
import time

from flask import (Blueprint, Response, abort, current_app, flash, g, jsonify, redirect,
                   render_template, request, send_from_directory, session, url_for)

from . import audit, backups, case_data, config, dashboard as dash, options, perms, profile, seats, updater, users
from .auth import check_csrf, login_required, roles_required
from .db import get_db
from .jalali import to_fa_digits, today_jalali
from .numbering import InvalidCaseType, create_case, peek_next_number

bp = Blueprint("main", __name__)


def _form_context(case: dict, *, readonly: bool, errors=None, is_new: bool, seat_msg=None):
    return dict(
        c=case, is_new=is_new, readonly=readonly, errors=errors or [], seat_msg=seat_msg,
        opts=options.options_for_form(get_db()), OPTION_GROUPS=config.OPTION_GROUPS,
        FROZEN_WIN=(updater.is_frozen() and os.name == "nt"), matches=config.matches, same=config.same, sample_is_yes=config.sample_is_yes, ARCHIVE_VALUE=config.ARCHIVE_VALUE, APPROVE_VALUE=config.APPROVE_VALUE, STATUS_SENT=config.STATUS_SENT, STATUS_RESULT=config.STATUS_RESULT, LOSER_VALUE=config.LOSER_VALUE, SAMPLE_YES=config.SAMPLE_YES,
        PROFILE_FIELDS=profile.fields_for(case.get("case_type", "")),
        prof=(profile.load(get_db(), case["id"]) if case.get("id") else None),
        today_j=to_fa_digits(today_jalali()), size_text=profile.size_text,
        perm_locked=sorted(perms.locked_for(g.user)),
    )


def _has_seat() -> bool:
    """آیا این کاربر (که نقشش اجازهٔ ویرایش دارد) الان جای ویرایش دارد؟ (اگر جا خالی باشد می‌گیرد)"""
    return g.user["role"] in config.ROLES_CAN_CREATE and seats.acquire(get_db(), g.user["id"])


def _no_seat_json():
    msg = seats.full_message(get_db())
    return jsonify({"ok": False, "error": msg, "errors": [msg]}), 423


@bp.route("/api/news/seen", methods=["POST"])
@login_required
def news_seen():
    check_csrf()
    get_db().execute("INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value",
                     (f"news_seen_{g.user['id']}", config.WHATS_NEW["version"]))
    return jsonify(ok=True)


@bp.route("/api/seat/ping", methods=["POST"])
@login_required
def seat_ping():
    """ضربان صفحهٔ باز: جای ویرایش را نگه می‌دارد. بدون CSRF خطا می‌دهد."""
    check_csrf()
    held = _has_seat()
    return jsonify(ok=True, held=held, holders=[h["name"] for h in seats.holders(get_db())])


def _filter_types() -> dict:
    """نوع‌هایی که در فیلتر دیده می‌شوند: پنج نوع جدید + نوع قدیمی فقط اگر پروندهٔ قدیمی دارد."""
    used = {r[0] for r in get_db().execute("SELECT DISTINCT case_type FROM cases")}
    return {k: v for k, v in config.CASE_TYPES.items() if k not in config.LEGACY_TYPES or k in used}


@bp.route("/")
@login_required
def dashboard():
    hidden = [k for k in (g.user["dash_hidden"] or "").split(",") if k] if g.user["role"] != "admin" else []
    return render_template("dashboard.html", case_types=_filter_types(), dash_hidden=hidden)


# ------------------------------------------------------------------ تیکت پشتیبانی

def _ticket_visible(t) -> bool:
    return t is not None and (g.user["role"] == "admin" or t["user_id"] == g.user["id"])


@bp.route("/tickets", methods=["GET", "POST"])
@login_required
def tickets_page():
    from . import company, tickets as tk
    db, app = get_db(), current_app._get_current_object()
    cname = company.get(db)["name"]
    if request.method == "POST":
        check_csrf()
        subject = " ".join(request.form.get("subject", "").split())[:120]
        body = request.form.get("body", "").strip()[:5000]
        contact = " ".join(request.form.get("contact", "").split())[:80]
        if not subject or not body:
            flash("موضوع و متن تیکت را بنویسید.", "error")
            return redirect(url_for("main.tickets_page"))
        try:
            up = tk.check_upload(request.files.get("file"))
        except tk.TicketError as e:
            flash(str(e), "error")
            return redirect(url_for("main.tickets_page"))
        cur = db.execute("INSERT INTO tickets (user_id, username, subject, body, contact) VALUES (?,?,?,?,?)",
                         (g.user["id"], g.user["full_name"] or g.user["username"], subject, body, contact))
        tid = cur.lastrowid
        if up:
            tk.add_file(db, tid, up[0], up[1])
        db.commit()
        audit.log(db, "ticket_new", f"تیکت «{subject}»")
        db.commit()
        if tk.send(app, db, tid, cname):
            unsent = db.execute("SELECT COUNT(*) FROM ticket_files WHERE ticket_id = ? AND gh_url = ''", (tid,)).fetchone()[0]
            if unsent:
                flash("تیکت ارسال شد ولی پیوست ارسال نشد: " + tk.LAST_FILE_ERROR.pop(tid, "خطای ناشناخته"), "error")
            else:
                flash("تیکت شما ثبت و برای پشتیبانی ارسال شد.", "success")
        else:
            flash("تیکت ثبت شد ولی ارسال نشد (اینترنت یا کلید ارسال). بعداً خودکار دوباره تلاش می‌شود.", "error")
        return redirect(url_for("main.ticket_view", tid=tid))
    where, args = ("", ()) if g.user["role"] == "admin" else ("WHERE user_id = ?", (g.user["id"],))
    rows = db.execute(f"SELECT * FROM tickets {where} ORDER BY id DESC LIMIT 200", args).fetchall()
    for r in rows:                                   # تیکت‌های ارسال‌نشده را دوباره بفرست
        if not r["gh_number"]:
            tk.send(app, db, r["id"], cname)
    rows = db.execute(f"SELECT * FROM tickets {where} ORDER BY id DESC LIMIT 200", args).fetchall()
    return render_template("tickets.html", rows=rows)


@bp.route("/tickets/<int:tid>", methods=["GET", "POST"])
@login_required
def ticket_view(tid):
    from . import tickets as tk
    db, app = get_db(), current_app._get_current_object()
    t = db.execute("SELECT * FROM tickets WHERE id = ?", (tid,)).fetchone()
    if not _ticket_visible(t):
        abort(404)
    if request.method == "POST":
        check_csrf()
        text = request.form.get("body", "").strip()[:5000]
        try:
            up = tk.check_upload(request.files.get("file"))
        except tk.TicketError as e:
            flash(str(e), "error")
            return redirect(url_for("main.ticket_view", tid=tid))
        if text:
            if tk.post_reply(app, db, tid, g.user["full_name"] or g.user["username"], text, up):
                flash("پیام شما ارسال شد.", "success")
            else:
                flash("پیام ارسال نشد؛ " + (tk.LAST_FILE_ERROR.pop(tid, "") or "اینترنت را بررسی و دوباره تلاش کنید."), "error")
        return redirect(url_for("main.ticket_view", tid=tid))
    tk.sync(app, db, tid)
    t = db.execute("SELECT * FROM tickets WHERE id = ?", (tid,)).fetchone()
    comments = db.execute("SELECT * FROM ticket_comments WHERE ticket_id = ? ORDER BY created_at, id", (tid,)).fetchall()
    files = db.execute("SELECT id, comment_id, name, size FROM ticket_files WHERE ticket_id = ? ORDER BY id", (tid,)).fetchall()
    return render_template("ticket_view.html", t=t, comments=comments, files=files)


@bp.route("/tickets/<int:tid>/file/<int:fid>")
@login_required
def ticket_file(tid, fid):
    db = get_db()
    t = db.execute("SELECT * FROM tickets WHERE id = ?", (tid,)).fetchone()
    if not _ticket_visible(t):
        abort(404)
    f = db.execute("SELECT * FROM ticket_files WHERE id = ? AND ticket_id = ?", (fid, tid)).fetchone()
    if f is None:
        abort(404)
    from urllib.parse import quote
    r = Response(bytes(f["data"]), mimetype="application/octet-stream")
    r.headers["Content-Disposition"] = "attachment; filename*=UTF-8''" + quote(f["name"])
    r.headers["X-Content-Type-Options"] = "nosniff"
    return r


@bp.route("/help")
@login_required
def help_page():
    from . import help_content
    is_admin = g.user["role"] == "admin"
    sections = [s for s in help_content.SECTIONS if is_admin or not s[2]]
    return render_template("help.html", sections=sections, changelog=help_content.CHANGELOG)


@bp.route("/settings")
@roles_required("admin")
def settings():
    return render_template("settings.html")


@bp.route("/settings/company", methods=["GET", "POST"])
@roles_required("admin")
def settings_company():
    from . import company
    db = get_db()
    if request.method == "POST":
        check_csrf()
        changes = company.save(db, request.form)
        if changes:
            audit.log(db, "company_info", "اطلاعات شرکت تغییر کرد", changes=changes)
        db.commit()
        flash("اطلاعات شرکت ذخیره شد.", "success")
        return redirect(url_for("main.settings_company"))
    return render_template("settings_company.html", info=company.get(db), fields=config.COMPANY_FIELDS)


@bp.route("/api/dashboard")
@login_required
def dashboard_data():
    """داده‌های زندهٔ داشبورد (JSON). فیلترها از آدرس خوانده می‌شوند."""
    resp = jsonify(dash.build(get_db(), request.args))
    resp.headers["Cache-Control"] = "no-store"
    return resp


# ------------------------------------------------------------------ لیست

def _like(text: str) -> str:
    return "%" + text.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"


# ستون‌های قابل مرتب‌سازی: نام در آدرس -> عبارت مرتب‌سازی (فقط همین مقدارها مجازند)
# تاریخ‌ها به شکل 1405/07/16 ذخیره می‌شوند، پس مرتب‌سازی متنی همان ترتیب زمانی است.
SORT_COLUMNS = {
    "type": "c.case_type",
    "serial": "c.year, c.serial_no",
    "received": "c.received_date",
    "deadline": "c.send_deadline",
    "status": "c.status",
    "org": "c.organization",
    "notes": "c.notes",
    "profile": "has_profile",
}
EMPTY_LAST = {"received", "deadline", "status", "org", "notes"}


@bp.route("/cases")
@login_required
def case_list():
    sort = request.args.get("sort", "")
    direction = "ASC" if request.args.get("dir") == "asc" else "DESC"
    if sort not in SORT_COLUMNS:
        sort, direction = "", "DESC"
    case_type = request.args.get("type", "")
    q = to_fa_digits(request.args.get("q", "").strip()[:100])       # ارقام در دیتابیس فارسی ذخیره می‌شوند
    where, params = [], []
    if case_type in config.CASE_TYPES:
        where.append("c.case_type = ?")
        params.append(case_type)
    if q:
        where.append("(c.organization LIKE ? ESCAPE '\\' OR c.notes LIKE ? ESCAPE '\\' "
                     "OR c.status LIKE ? ESCAPE '\\')")
        params += [_like(q)] * 3
    sql = ("SELECT c.id, c.case_type, c.year, c.serial_no, c.organization, c.received_date, "
           "c.send_deadline, c.status, c.notes, "
           "EXISTS(SELECT 1 FROM case_profile pf WHERE pf.case_id = c.id) AS has_profile FROM cases c")
    if where:
        sql += " WHERE " + " AND ".join(where)
    if sort:
        cols = SORT_COLUMNS[sort]
        order = ""
        if sort in EMPTY_LAST:               # خالی‌ها همیشه آخر لیست بروند
            order = f"({cols} = '') ASC, "
        order += ", ".join(f"{c.strip()} {direction}" for c in cols.split(","))
        sql += f" ORDER BY {order}, c.id DESC LIMIT 500"
    else:
        sql += " ORDER BY c.id DESC LIMIT 500"
    rows = get_db().execute(sql, params).fetchall()
    return render_template("case_list.html", rows=rows, type_filter=case_type, q=q, btn_edit=(g.user["role"] in config.ROLES_CAN_CREATE and "ui_edit" not in perms.locked_for(g.user)), btn_view="ui_view" not in perms.locked_for(g.user), filter_types=_filter_types(),
                           sort=sort, dir=direction.lower())


# ------------------------------------------------------------------ فرم پرونده

@bp.route("/cases/new", methods=["GET", "POST"])
@roles_required(*config.ROLES_CAN_CREATE)
def case_new():
    db = get_db()
    if not perms.can_create_any(perms.locked_for(g.user)):      # کاربری که نوع پرونده برایش قفل است نمی‌تواند پروندهٔ جدید بسازد
        flash("شما اجازهٔ ایجاد پروندهٔ جدید را ندارید؛ پرونده‌های موجود را از لیست باز کنید.", "error")
        return redirect(url_for("main.case_list"))
    if request.method == "GET" and not _has_seat():
        flash(seats.full_message(db), "error")
        return redirect(url_for("main.case_list"))
    if request.method == "POST":
        check_csrf()
        no_seat = not _has_seat()
        case_type = request.form.get("case_type", "")
        locked = perms.locked_for(g.user)
        form, denied = perms.apply_locks(request.form, None, locked)
        data, errors = case_data.parse_form(form, db)
        denied += perms.restore_tables(data, None, locked, request.form)
        if denied:
            audit.log(db, "perm_denied", "تلاش برای تغییر فیلد قفل‌شده در پروندهٔ جدید: " + "، ".join(denied))
        if no_seat:
            errors.insert(0, seats.full_message(db))
        # قانون اصلی: بدون انتخاب «نوع پرونده» هیچ پرونده‌ای ثبت نمی‌شود
        # (سمت سرور هم چک می‌شود، نه فقط در مرورگر)
        if case_type not in config.SELECTABLE_TYPES:
            errors.insert(0, "ابتدا «نوع پرونده» را انتخاب کنید.")
        elif not perms.type_allowed(locked, case_type):
            errors.insert(0, "شما اجازهٔ ثبت پروندهٔ این نوع را ندارید.")
        if errors:
            case = {**case_data.empty_case(), **data, "case_type": case_type}
            return render_template("case_form.html",
                                   **_form_context(case, readonly=False, errors=errors, is_new=True)), (423 if no_seat else 400)
        case = create_case(db, case_type, g.user["id"], data=data)
        audit.log(db, "case_create", "پرونده جدید ثبت شد", case={**case, "id": case["id"]})
        flash(f"پرونده {config.CASE_TYPES[case_type]} ثبت شد. شماره شناسنامه: {case['serial_no']}", "success")
        session["saved_popup"] = f"پرونده {config.CASE_TYPES[case_type]} با شماره {to_fa_digits(str(case['serial_no']))} ثبت شد."
        # redirect تا با Refresh صفحه، پرونده دوباره ثبت نشود
        return redirect(url_for("main.case_edit", case_id=case["id"]))
    return render_template("case_form.html",
                           **_form_context(case_data.empty_case(), readonly=False, is_new=True))


@bp.route("/cases/<int:case_id>", methods=["GET", "POST"])
@login_required
def case_edit(case_id: int):
    db = get_db()
    case = case_data.load_case(db, case_id)
    if case is None:
        abort(404)
    role_ok = g.user["role"] in config.ROLES_CAN_CREATE and "ui_edit" not in perms.locked_for(g.user)
    can_edit = role_ok and seats.acquire(db, g.user["id"])      # جای ویرایش همزمان
    no_seat = role_ok and not can_edit

    if request.method == "POST":
        if not role_ok:
            abort(403)
        check_csrf()
        locked = perms.locked_for(g.user)
        form, denied = perms.apply_locks(request.form, case, locked)
        data, errors = case_data.parse_form(form, db, existing=case)
        denied += perms.restore_tables(data, case, locked, request.form)
        if denied:
            audit.log(db, "perm_denied", "تلاش برای تغییر فیلد قفل‌شده: " + "، ".join(denied), case=case)
        if no_seat:
            errors.insert(0, seats.full_message(db))
        try:
            expected = int(request.form.get("version", ""))
        except ValueError:
            abort(400)
        conflict = False
        if not errors:
            try:
                changes = audit.case_changes(case, data)
                moved = case_data.save_changes(db, case_id, data, g.user["id"], expected)
                if moved:
                    changes = [["نوع پرونده", config.CASE_TYPES.get(moved["old_type"], moved["old_type"]),
                                config.CASE_TYPES.get(moved["new_type"], moved["new_type"])],
                               ["شماره شناسنامه", str(moved["old_serial"]), str(moved["new_serial"])]] + changes
                if changes:
                    audit.log(db, "case_edit", f"{len(changes)} تغییر", case=case, changes=changes)
            except case_data.ConflictError:
                conflict = True
                errors.append("این پرونده در همین فاصله توسط کاربر دیگری تغییر کرد و تغییرات شما "
                              "ذخیره نشد. صفحه را دوباره باز کنید و تغییرات را مجدد وارد کنید.")
            else:
                flash("تغییرات ذخیره شد.", "success")
                shown_type = moved["new_type"] if moved else case["case_type"]
                shown_no = moved["new_serial"] if moved else case["serial_no"]
                session["saved_popup"] = (f"تغییرات پرونده {config.CASE_TYPES.get(shown_type, '')} "
                                          f"با شماره {to_fa_digits(str(shown_no))} ذخیره شد."
                                          + (f" (شمارهٔ قبلی {to_fa_digits(str(moved['old_serial']))} دیگر استفاده نمی‌شود.)" if moved else ""))
                return redirect(url_for("main.case_edit", case_id=case_id))
        shown = {**case, **data, "version": expected}
        if not config.matches(data["result"], config.LOSER_VALUE):
            shown["competitors"] = case["competitors"]     # ردیف‌های ذخیره‌شده پنهان می‌مانند، گم نمی‌شوند
        return render_template("case_form.html",
                               **_form_context(shown, readonly=False, errors=errors, is_new=False)
                               ), (423 if no_seat else 409 if conflict else 400)

    return render_template("case_form.html",
                           **_form_context(case, readonly=not can_edit, is_new=False,
                                           seat_msg=seats.full_message(db) if no_seat else None))


@bp.route("/cases/<int:case_id>/profile", methods=["POST"])
@roles_required(*config.ROLES_CAN_CREATE)
def profile_save(case_id: int):
    """ذخیرهٔ پاپ‌آپ «اطلاعات شناسنامه» (با fetch؛ جواب JSON)."""
    db = get_db()
    check_csrf()
    if not _has_seat():
        return _no_seat_json()
    case = case_data.load_case(db, case_id)
    if case is None:
        abort(404)
    old = profile.load(db, case_id)
    try:
        expected = int(request.form.get("pversion", ""))
    except ValueError:
        abort(400)
    locked = perms.locked_for(g.user)
    denied = perms.profile_denied(request.form, old, locked, case["products"])
    if denied:
        audit.log(db, "perm_denied", "تلاش برای تغییر فیلد قفل‌شدهٔ شناسنامه: " + "، ".join(denied), case=case)
    vals, prices, errors = profile.parse(request.form, db, case, old, locked=locked)
    if errors:
        return jsonify(ok=False, errors=errors), 400
    try:
        changes = audit.profile_changes(old, vals, case["products"], prices)
        version = profile.save(db, case_id, vals, prices, g.user["id"], expected)
        if changes:
            audit.log(db, "profile_edit", f"{len(changes)} تغییر در شناسنامه", case=case, changes=changes)
    except profile.Conflict:
        return jsonify(ok=False, errors=["اطلاعات شناسنامه در این فاصله توسط کاربر دیگری تغییر کرد. "
                                         "صفحه را دوباره باز کنید."]), 409
    return jsonify(ok=True, version=version)


@bp.route("/cases/<int:case_id>/report")
@login_required
def case_report(case_id: int):
    case = case_data.load_case(get_db(), case_id)
    if case is None:
        abort(404)
    return render_template("report.html", c=case, form_code=config.REPORT_FORM_CODE,
                           **profile.report_context(get_db(), case))


def _log_report(case_id: int) -> None:
    db = get_db()
    audit.log(db, "report", "گزارش شناسنامه ساخته/باز شد", case=case_data.load_case(db, case_id))


def _report_pdf(case_id: int):
    """PDF گزارش شناسنامه را می‌سازد. خروجی: (bytes, نام فایل) یا None اگر reportlab نصب نباشد."""
    case = case_data.load_case(get_db(), case_id)
    if case is None:
        abort(404)
    try:
        from . import pdfreport
        title = f"شناسنامه {config.report_title(case['case_type'])}"
        data = pdfreport.build_pdf(case, profile.report_context(get_db(), case), title, config.REPORT_FORM_CODE)
    except ImportError:
        return None, None
    return data, f"shenasname_{case['case_type']}_{case['year']}_{case['serial_no']}.pdf"


@bp.route("/cases/<int:case_id>/report.pdf")
@login_required
def case_report_pdf(case_id: int):
    _log_report(case_id)
    data, name = _report_pdf(case_id)
    if data is None:
        return redirect(url_for("main.case_report", case_id=case_id))
    return Response(data, mimetype="application/pdf", headers={"Content-Disposition": f'inline; filename="{name}"'})


@bp.route("/cases/<int:case_id>/report/open", methods=["POST"])
@login_required
def case_report_open(case_id: int):
    """PDF را می‌سازد، در پوشهٔ reports ذخیره می‌کند و (اگر برنامه روی همین کامپیوتر اجراست) با
    برنامهٔ PDFِ خود سیستم باز می‌کند. در غیر این‌صورت آدرس دانلود را برمی‌گرداند."""
    check_csrf()
    _log_report(case_id)
    data, name = _report_pdf(case_id)
    if data is None:
        return jsonify(ok=False, fallback=url_for("main.case_report", case_id=case_id))
    folder = os.path.join(os.path.dirname(current_app.config["DATABASE"]), "reports")
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, name)
    with open(path, "wb") as fh:
        fh.write(data)
    opened = False
    if request.remote_addr in ("127.0.0.1", "::1") and not current_app.testing:
        try:
            import subprocess
            import sys
            if sys.platform == "darwin":
                subprocess.Popen(["open", path])
            elif sys.platform.startswith("win"):
                os.startfile(path)                   # noqa: S606
            else:
                subprocess.Popen(["xdg-open", path])
            opened = True
        except Exception:                            # noqa: BLE001
            opened = False
    return jsonify(ok=True, opened=opened, path=path, url=url_for("main.case_report_pdf", case_id=case_id))


@bp.route("/api/next-number")
@roles_required(*config.ROLES_CAN_CREATE)
def next_number():
    try:
        yr = request.args.get("year", "")
        n = peek_next_number(get_db(), request.args.get("case_type", ""), int(yr) if yr.isdigit() else None)
    except InvalidCaseType:
        abort(400)
    return jsonify({"next": n})


@bp.route("/api/options/add", methods=["POST"])
@roles_required(*config.ROLES_CAN_CREATE)
def option_add():
    """افزودن سریع یک گزینه به کمبوباکس از داخل فرم (دکمهٔ +). گزینهٔ تکراری دوباره اضافه نمی‌شود."""
    check_csrf()
    if not _has_seat():
        return _no_seat_json()
    grp = request.form.get("grp", "")
    label = options.clean_label(request.form.get("label", ""))
    if grp not in config.OPTION_GROUPS:
        abort(400)
    if not label:
        return jsonify({"ok": False, "error": "متن گزینه را بنویسید."}), 400
    db = get_db()
    existed = label in options.active_labels(db, grp)
    options.add_labels(db, grp, label)
    if not existed:
        audit.log(db, "option_add", f"«{label}» به «{config.OPTION_GROUPS[grp]}» اضافه شد")
    return jsonify({"ok": True, "label": label, "existed": existed})


@bp.route("/api/options/rename", methods=["POST"])
@roles_required(*config.ROLES_CAN_CREATE)
def option_rename():
    """ویرایش نام یک گزینه از داخل فرم (دکمهٔ مداد). در همهٔ پرونده‌ها هم اصلاح می‌شود."""
    check_csrf()
    if not _has_seat():
        return _no_seat_json()
    grp = request.form.get("grp", "")
    try:
        new = options.clean_label(request.form.get("label", ""))
        count = options.rename_label(get_db(), grp, request.form.get("old", ""), new)
    except options.RenameError as e:
        return jsonify({"ok": False, "error": str(e)}), 400
    old_label = options.clean_label(request.form.get("old", ""))
    if new != old_label:
        audit.log(get_db(), "option_rename", f"در «{config.OPTION_GROUPS.get(grp, grp)}»: «{old_label}» ← «{new}» "
                  f"({count} ردیف اصلاح شد)")
    state = None
    if request.form.get("active") in ("0", "1"):
        want = request.form["active"] == "1"
        row = get_db().execute("SELECT id, active FROM options WHERE grp = ? AND label = ?", (grp, new)).fetchone()
        if row is not None:
            if bool(row["active"]) != want:
                options.set_active(get_db(), row["id"], want)
                audit.log(get_db(), "option_active", f"در «{config.OPTION_GROUPS.get(grp, grp)}»: «{new}» "
                          f"{'فعال' if want else 'غیرفعال'} شد")
            state = want
    return jsonify({"ok": True, "label": new, "updated": count, "active": state})


# ------------------------------------------------------------------ صفحهٔ شرکت‌ها

def _org_fields(db, oid: int) -> dict:
    d = {k: "" for k, _ in config.ORG_FIELDS}
    for r in db.execute("SELECT key, value FROM org_fields WHERE option_id = ?", (oid,)):
        if r["key"] in d:
            d[r["key"]] = r["value"]
    return d


def _org_contacts(db, oid: int) -> list:
    keys = [k for k, _ in config.ORG_CONTACT_FIELDS]
    return [{"id": r["id"], **{k: r[k] for k in keys}}
            for r in db.execute(f"SELECT id, {', '.join(keys)} FROM org_contacts WHERE option_id = ? ORDER BY id", (oid,))]


def _save_org(db, oid: int, label: str, form) -> None:
    """ذخیرهٔ فیلدها و نفرات یک سازمان (حذف نداریم: ردیف خالی‌شده فقط خالی می‌ماند)."""
    old = _org_fields(db, oid)
    new = {k: to_fa_digits(form.get(k, "").strip()[:300]) for k, _ in config.ORG_FIELDS}
    changes = [[t, old[k], new[k]] for k, t in config.ORG_FIELDS if old[k] != new[k]]
    for k, v in new.items():
        db.execute("INSERT INTO org_fields (option_id, key, value) VALUES (?, ?, ?) "
                   "ON CONFLICT(option_id, key) DO UPDATE SET value = excluded.value", (oid, k, v))
    keys = [k for k, _ in config.ORG_CONTACT_FIELDS]
    ids = form.getlist("contact_id")
    cols = {k: form.getlist("contact_" + k) for k in keys}
    existing = {c["id"]: c for c in _org_contacts(db, oid)}
    for i, cid in enumerate(ids):
        vals = {k: to_fa_digits((cols[k][i] if i < len(cols[k]) else "").strip()[:200]) for k in keys}
        if cid.isdigit() and int(cid) in existing:
            o = existing[int(cid)]
            for k, t in config.ORG_CONTACT_FIELDS:
                if o[k] != vals[k]:
                    changes.append([f"نفر «{o['name'] or vals['name']}» — {t}", o[k], vals[k]])
            db.execute("UPDATE org_contacts SET " + ", ".join(f"{k} = ?" for k in keys) + " WHERE id = ? AND option_id = ?",
                       [vals[k] for k in keys] + [int(cid), oid])
        elif any(vals.values()):
            db.execute("INSERT INTO org_contacts (option_id, " + ", ".join(keys) + ") VALUES (?, " + ", ".join("?" for _ in keys) + ")",
                       [oid] + [vals[k] for k in keys])
            changes.append([f"نفر جدید «{vals['name']}»", "", " | ".join(v for v in vals.values() if v)])
    if changes:
        audit.log(db, "org_edit", f"اطلاعات «{label}» ویرایش شد", changes=changes)


@bp.route("/organizations")
@login_required
def org_list():
    db = get_db()
    rows = []
    for o in db.execute("SELECT id, label, active FROM options WHERE grp = 'organization' ORDER BY label"):
        f = _org_fields(db, o["id"])
        n = db.execute("SELECT COUNT(*) FROM cases WHERE organization = ?", (o["label"],)).fetchone()[0]
        k = db.execute("SELECT COUNT(*) FROM org_contacts WHERE option_id = ?", (o["id"],)).fetchone()[0]
        rows.append({"id": o["id"], "label": o["label"], "active": o["active"], "f": f, "n": n, "k": k})
    return render_template("org_list.html", rows=rows,
                           fields=[f for f in config.ORG_FIELDS if f[0] in ("address", "phone", "email")])


@bp.route("/organizations/by-name")
@login_required
def org_by_name():
    row = get_db().execute("SELECT id FROM options WHERE grp = 'organization' AND label = ?",
                           (request.args.get("name", "").strip(),)).fetchone()
    if not row:
        flash("این سازمان هنوز در فهرست نیست؛ اول پرونده را ذخیره کنید.", "error")
        return redirect(url_for("main.org_list"))
    return redirect(url_for("main.org_page", oid=row["id"]))


@bp.route("/api/org")
@login_required
def org_api():
    """اطلاعات یک سازمان برای پاپ‌آپِ داخل فرم پرونده."""
    db = get_db()
    row = db.execute("SELECT id, label FROM options WHERE grp = 'organization' AND label = ?",
                     (request.args.get("name", "").strip(),)).fetchone()
    if not row:
        return jsonify(ok=False, error="این سازمان هنوز در فهرست نیست؛ اول پرونده را ذخیره کنید."), 404
    f = _org_fields(db, row["id"])
    return jsonify(ok=True, id=row["id"], label=row["label"], can_edit=g.user["role"] in config.ROLES_CAN_CREATE,
                   fields=[{"key": k, "title": t, "value": f[k]} for k, t in config.ORG_FIELDS],
                   contact_cols=[{"key": k, "title": t} for k, t in config.ORG_CONTACT_FIELDS],
                   contacts=_org_contacts(db, row["id"]),
                   page=url_for("main.org_page", oid=row["id"]))


@bp.route("/organizations/<int:oid>", methods=["GET", "POST"])
@login_required
def org_page(oid: int):
    db = get_db()
    org = db.execute("SELECT id, label FROM options WHERE grp = 'organization' AND id = ?", (oid,)).fetchone()
    if not org:
        abort(404)
    can_edit = g.user["role"] in config.ROLES_CAN_CREATE
    old = _org_fields(db, oid)
    if request.method == "POST":
        if not can_edit:
            abort(403)
        check_csrf()
        _save_org(db, oid, org["label"], request.form)
        if request.headers.get("X-Requested-With") == "fetch":
            return jsonify(ok=True)
        session["saved_popup"] = f"اطلاعات «{org['label']}» ذخیره شد."
        return redirect(url_for("main.org_page", oid=oid))
    cases = db.execute("SELECT id, case_type, year, serial_no, status, result, received_date FROM cases "
                       "WHERE organization = ? ORDER BY id DESC LIMIT 200", (org["label"],)).fetchall()
    return render_template("org_page.html", org=org, f=old, fields=config.ORG_FIELDS, cases=cases, can_edit=can_edit,
                           ccols=config.ORG_CONTACT_FIELDS, contacts=_org_contacts(db, oid))


# ------------------------------------------------------------------ کاربران و دسترسی (فقط مدیر)

def _uname(db, uid: int) -> str:
    r = db.execute("SELECT username, full_name FROM users WHERE id = ?", (uid,)).fetchone()
    return f"«{r['full_name'] or r['username']}»" if r else "کاربر"


@bp.route("/admin/users", methods=["GET", "POST"])
@roles_required("admin")
def admin_users():
    db = get_db()
    if request.method == "POST":
        check_csrf()
        action = request.form.get("action", "")
        uid = request.form.get("user_id", "")
        uid = int(uid) if uid.isdigit() else 0
        try:
            if action == "create":
                users.create(db, request.form.get("username", ""), request.form.get("password", ""),
                             request.form.get("role", ""), request.form.get("full_name", ""))
                audit.log(db, "user_create", f"کاربر «{request.form.get('username', '').strip()}» با نقش "
                          f"{config.ROLES.get(request.form.get('role', ''), '')} ساخته شد")
                flash("کاربر ساخته شد.", "success")
            elif action == "set_role":
                users.set_role(db, g.user["id"], uid, request.form.get("role", ""))
                audit.log(db, "user_role", f"نقش {_uname(db, uid)} ← {config.ROLES.get(request.form.get('role', ''), '')}")
                flash("نقش کاربر تغییر کرد.", "success")
            elif action in ("enable", "disable"):
                users.set_active(db, g.user["id"], uid, action == "enable")
                audit.log(db, "user_active", f"{_uname(db, uid)} " + ("فعال شد" if action == "enable" else "غیرفعال شد"))
                flash("کاربر فعال شد." if action == "enable" else "کاربر غیرفعال شد.", "success")
            elif action == "reset_password":
                users.reset_password(db, uid, request.form.get("password", ""))
                audit.log(db, "user_password", f"رمز {_uname(db, uid)} تغییر کرد")
                flash("رمز عبور تغییر کرد.", "success")
            elif action == "set_name":
                users.set_full_name(db, uid, request.form.get("full_name", ""))
                audit.log(db, "user_name", f"نام نمایشی {_uname(db, uid)} ← «{request.form.get('full_name', '').strip()}»")
                flash("نام ذخیره شد.", "success")
            elif action == "set_dash":
                shown = set(request.form.getlist("show"))
                hidden = [k for k, _ in config.DASH_SECTIONS if k not in shown]
                users.set_dash_hidden(db, uid, hidden)
                audit.log(db, "user_dash", f"دسترسی داشبورد {_uname(db, uid)} تغییر کرد ({len(hidden)} بخش پنهان)")
                flash("دسترسی داشبورد ذخیره شد.", "success")
            elif action == "set_fields":
                allowed = set(request.form.getlist("allow"))
                before = perms.locked_for(db.execute("SELECT * FROM users WHERE id = ? AND role != 'admin'", (uid,)).fetchone())
                locked = [k for k in sorted(perms.all_keys()) if k not in allowed]
                perms.set_locked(db, uid, locked)
                now_l, was = set(locked), set(before)
                changes = [[perms.label_of(k), "قابل ویرایش", "قفل"] for k in sorted(now_l - was)] + \
                          [[perms.label_of(k), "قفل", "قابل ویرایش"] for k in sorted(was - now_l)]
                audit.log(db, "user_fields", f"دسترسی فیلدهای {_uname(db, uid)} تغییر کرد ({len(locked)} فیلد قفل)", changes=changes)
                flash("دسترسی فیلدها ذخیره شد.", "success")
            elif action == "free_seat":
                seats.release(db, uid)
                audit.log(db, "seat_free", f"جای ویرایش {_uname(db, uid)} آزاد شد")
                flash("جای ویرایش آزاد شد.", "success")
            elif action == "set_max":
                seats.set_max(db, int(request.form.get("max_editors", "0") or 0))
                audit.log(db, "seats_max", f"حداکثر ویرایش همزمان ← {seats.get_max(db)}")
                flash("حداکثر ویرایش همزمان ذخیره شد.", "success")
            else:
                abort(400)
        except (users.UserError, ValueError) as e:
            flash(str(e), "error")
        return redirect(url_for("main.admin_users"))
    return render_template("admin_users.html", user_rows=users.list_users(db), holders=seats.holders(db),
                           max_editors=seats.get_max(db), max_limit=config.MAX_EDITORS_LIMIT,
                           caps=config.ROLE_CAPS, timeout_min=config.SEAT_TIMEOUT_SECONDS // 60, perm_groups=perms.groups())


# ------------------------------------------------------------------ مدیریت گزینه‌ها (فقط مدیر)

@bp.route("/admin/options", methods=["GET", "POST"])
@roles_required("admin")
def admin_options():
    db = get_db()
    if request.method == "POST":
        check_csrf()
        action = request.form.get("action", "")
        grp = request.form.get("grp", "")
        if action == "add" and grp in config.OPTION_GROUPS:
            n = options.add_labels(db, grp, request.form.get("lines", ""))
            audit.log(db, "option_add", f"{n} گزینه به «{config.OPTION_GROUPS[grp]}» اضافه یا فعال شد: "
                      + "، ".join(options.clean_label(x) for x in request.form.get("lines", "").splitlines() if x.strip())[:300])
            flash(f"{n} گزینه به «{config.OPTION_GROUPS[grp]}» اضافه یا فعال شد.", "success")
        elif action in ("enable", "disable"):
            try:
                oid = int(request.form.get("option_id", ""))
                options.set_active(db, oid, action == "enable")
                o = db.execute("SELECT grp, label FROM options WHERE id = ?", (oid,)).fetchone()
                if o:
                    audit.log(db, "option_toggle", f"«{o['label']}» در «{config.OPTION_GROUPS.get(o['grp'], o['grp'])}» "
                              + ("فعال شد" if action == "enable" else "غیرفعال شد"))
            except ValueError:
                abort(400)
        else:
            abort(400)
        return redirect(url_for("main.admin_options") + (f"#g-{grp}" if grp else ""))
    groups = [(grp, label, options.all_options(db, grp)) for grp, label in config.OPTION_GROUPS.items()]
    return render_template("admin_options.html", groups=groups)


# ------------------------------------------------------------------ بکاپ (فقط مدیر)

def _backup_state():
    cfg = current_app.config
    st = backups.read_settings(cfg["BACKUP_SETTINGS_FILE"], cfg["BACKUP_DIR"])
    return cfg, st


@bp.route("/admin/backup", methods=["GET", "POST"])
@roles_required("admin")
def admin_backup():
    cfg, st = _backup_state()
    if request.method == "POST":
        check_csrf()
        action = request.form.get("action", "")
        if action == "settings":
            main_dir, err = backups.check_folder(request.form.get("dir", "") or cfg["BACKUP_DIR"])
            if main_dir is None:
                flash(f"پوشهٔ اصلی بکاپ ذخیره نشد ({err}).", "error")
                main_dir = st["dir"]
            good, targets = [], {}
            for key, (title, _n, _m) in backups.CLOUD_TARGETS.items():
                on = request.form.get(f"t_{key}_on") == "1"
                raw = request.form.get(f"t_{key}_path", "").strip()
                targets[key] = {"on": on, "path": raw}
                if on:
                    p, err = backups.check_folder(raw) if raw else (None, "مسیر خالی است")
                    if p:
                        good.append(p)
                        targets[key]["path"] = p
                    else:
                        targets[key]["on"] = False
                        flash(f"{title} فعال نشد ({err}).", "error")
            for line in request.form.get("folders", "").splitlines():
                if line.strip():
                    p, err = backups.check_folder(line)
                    if p:
                        good.append(p)
                    else:
                        flash(f"ذخیره نشد: {line.strip()} ({err})", "error")
            backups.write_settings(cfg["BACKUP_SETTINGS_FILE"], main_dir, good, targets)
            audit.log(get_db(), "backup_settings", f"پوشهٔ اصلی: {main_dir}؛ {len(good)} پوشهٔ اضافی")
            flash("تنظیمات بکاپ ذخیره شد.", "success")
        elif action == "run":
            try:
                path, results = backups.run_backup(cfg["DATABASE"], cfg["BACKUP_SETTINGS_FILE"], cfg["BACKUP_DIR"])
            except FileNotFoundError as e:
                flash(str(e), "error")
            else:
                audit.log(get_db(), "backup_run", f"بکاپ ساخته شد: {os.path.basename(path)}")
                flash(f"بکاپ ساخته شد: {os.path.basename(path)}", "success")
                for raw, ok, err in results:
                    flash(f"کپی در {raw}: " + ("انجام شد" if ok else f"انجام نشد ({err})"),
                          "success" if ok else "error")
        elif action == "restore":
            return _do_restore(cfg, st)
        else:
            abort(400)
        return redirect(url_for("main.admin_backup"))
    return render_template("admin_backup.html", items=backups.list_backups(st["dir"]),
                           view=backups.cloud_view(st), folder=st["dir"])


@bp.route("/admin/backup/pick", methods=["POST"])
@roles_required("admin")
def backup_pick_folder():
    """باز کردن پنجرهٔ انتخاب پوشه روی همین کامپیوتر (فقط وقتی مرورگر همین‌جاست؛ روی سرور بی‌معنی است)."""
    check_csrf()
    if request.remote_addr not in ("127.0.0.1", "::1"):
        return jsonify(ok=False, error="انتخاب پوشه فقط روی خود کامپیوتری که برنامه روی آن اجراست ممکن است؛ مسیر را تایپ کنید."), 400
    path = backups.pick_folder_dialog()
    return jsonify(ok=bool(path), path=path or "")


def _do_restore(cfg, st):
    """بازگردانی از یکی از بکاپ‌های لیست یا از فایل آپلودشده. نیاز به تایپ YES دارد."""
    if request.form.get("confirm", "").strip() != "YES":
        flash("برای بازگردانی باید کلمهٔ YES را بنویسید. هیچ تغییری انجام نشد.", "error")
        return redirect(url_for("main.admin_backup"))
    upload = request.files.get("file")
    tmp = None
    try:
        if upload is not None and upload.filename:
            os.makedirs(st["dir"], exist_ok=True)
            import tempfile
            fd, tmp = tempfile.mkstemp(suffix=".sqlite", dir=st["dir"])
            os.close(fd)
            upload.save(tmp)
            source = tmp
        else:
            name = request.form.get("name", "")
            if not backups.NAME_RE.match(name) or not os.path.exists(os.path.join(st["dir"], name)):
                abort(400)
            source = os.path.join(st["dir"], name)
        safety = backups.restore_backup(source, cfg["DATABASE"], st["dir"])
    except backups.RestoreError as e:
        flash(f"بازگردانی انجام نشد: {e}. اطلاعات فعلی دست‌نخورده است.", "error")
        return redirect(url_for("main.admin_backup"))
    finally:
        if tmp and os.path.exists(tmp):
            os.remove(tmp)                   # فقط فایل موقت آپلود، نه بکاپ‌ها
    from .db import connect                    # دیتابیس جایگزین شده؛ اتصال تازه
    audit.log(connect(cfg["DATABASE"]), "backup_restore", "بازگردانی از " + (upload.filename if upload is not None and upload.filename
              else request.form.get("name", "")) + " (نسخهٔ ایمنی: " + os.path.basename(safety) + ")")
    flash("اطلاعات از بکاپ بازگردانی شد. از اطلاعات قبلی هم نسخهٔ ایمنی ساخته شد: "
          + os.path.basename(safety), "success")
    return redirect(url_for("main.admin_backup"))


@bp.route("/admin/backup/download/<name>")
@roles_required("admin")
def backup_download(name: str):
    if not backups.NAME_RE.match(name):
        abort(404)
    _, st = _backup_state()
    audit.log(get_db(), "backup_download", f"دانلود {name}")
    return send_from_directory(st["dir"], name, as_attachment=True)


# ------------------------------------------------------------------ لاگ فعالیت‌ها (فقط مدیر)

def _log_filters() -> dict:
    from .jalali import jdate_to_date
    a = request.args
    f = {"user_id": int(a["user"]) if a.get("user", "").isdigit() else 0,
         "category": a.get("cat", ""), "action": a.get("act", ""), "q": a.get("q", "").strip()}
    for key, arg in (("date_from", "from"), ("date_to", "to")):
        d = jdate_to_date((a.get(arg) or "").strip()) if a.get(arg) else None
        f[key] = d.isoformat() if d else ""
    return f


@bp.route("/admin/logs")
@roles_required("admin")
def admin_logs():
    db = get_db()
    f = _log_filters()
    page = int(request.args.get("page", "1")) if request.args.get("page", "1").isdigit() else 1
    rows, total = audit.query(db, f, page)
    from .jalali import gregorian_to_jalali
    for r in rows:
        y, m, d = (int(x) for x in r["at"][:10].split("-"))
        r["jdate"] = "%04d/%02d/%02d" % gregorian_to_jalali(y, m, d)
        r["time"] = r["at"][11:]
    pages = max(1, -(-total // audit.PAGE))
    return render_template("admin_logs.html", rows=rows, total=total, page=page, pages=pages, f=f,
                           args={k: v for k, v in request.args.items() if k != "page"},
                           users=db.execute("SELECT id, username, full_name FROM users ORDER BY id").fetchall(),
                           actions=audit.ACTIONS, categories=audit.CATEGORIES)


@bp.route("/admin/logs.csv")
@roles_required("admin")
def admin_logs_csv():
    import csv
    import io
    from .jalali import gregorian_to_jalali
    rows, _ = audit.query(get_db(), _log_filters(), limit=None)
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["تاریخ شمسی", "ساعت", "کاربر", "عملیات", "پرونده", "خلاصه", "جزئیات (قبل ← بعد)", "IP"])
    for r in rows:
        y, m, d = (int(x) for x in r["at"][:10].split("-"))
        det = " | ".join(f"{c[0]}: {c[1]} ← {c[2]}" for c in r["changes"])
        w.writerow(["%04d/%02d/%02d" % gregorian_to_jalali(y, m, d), r["at"][11:], r["username"], r["title"],
                    r["case_label"], r["summary"], det, r["ip"]])
    return Response("\ufeff" + buf.getvalue(), mimetype="text/csv",
                    headers={"Content-Disposition": "attachment; filename=activity_log.csv"})


# ------------------------------------------------------------------ به‌روزرسانی برنامه (فقط مدیر)

@bp.route("/admin/update/status")
@roles_required("admin")
def admin_update_status():
    st = updater.status(current_app)
    return jsonify(newer=st["newer"], latest=st["latest"])


def _schedule_restart(app) -> None:
    import threading

    def go():
        time.sleep(1.5)
        if app.config.get("UPDATE_NO_RESTART"):
            return
        try:
            if updater.is_frozen() and os.name == "nt":
                updater.launch_windows_update(app)
                time.sleep(1)
                os._exit(0)
            updater.restart_source()
        except Exception as e:                       # علت در updates/launch.log می‌ماند
            try:
                with open(os.path.join(updater.updates_dir(app), "launch.log"), "a", encoding="utf-8") as f:
                    f.write(f"restart failed: {type(e).__name__}: {e}\n")
            except Exception:
                pass
    threading.Thread(target=go, daemon=True).start()


_JOB = {"state": "idle", "pct": 0, "text": "", "error": ""}


def _job_set(**kw):
    _JOB.update(kw)


def _run_update_job(app, st):
    """به‌روزرسانی در پس‌زمینه؛ صفحه با /admin/update/progress درصد را می‌خواند."""
    import threading

    def work():
        try:
            with app.app_context():
                cfg = app.config
                _job_set(state="running", pct=3, text="در حال گرفتن بکاپ از اطلاعات…", error="")
                try:
                    backups.run_backup(cfg["DATABASE"], cfg["BACKUP_SETTINGS_FILE"], cfg["BACKUP_DIR"])
                except FileNotFoundError:
                    pass
                _job_set(pct=10, text="در حال دانلود نسخهٔ جدید…")
                pkg = updater.download(app, st["file"], progress=lambda f, t="": _job_set(pct=10 + int(f * 60), **({"text": t} if t else {})))
                _job_set(pct=75, text="در حال بررسی فایل…")
                audit.log(get_db(), "app_update", f"{config.APP_VERSION} ← {st['latest']}", user=None)
                if updater.is_frozen() and os.name == "nt":
                    _job_set(pct=90, text="آماده‌سازی نصب…")
                else:
                    _job_set(pct=85, text="در حال جایگزینی فایل‌ها…")
                    updater.apply_source(updater.app_root(app), pkg, os.path.join(updater.updates_dir(app), "previous"))
                _job_set(pct=97, text="برنامه دوباره باز می‌شود…", state="restarting")
            _schedule_restart(app)
        except updater.UpdateError as e:
            _job_set(state="error", error=str(e))
        except Exception as e:                                     # noqa: BLE001
            _job_set(state="error", error=f"خطا در به‌روزرسانی ({type(e).__name__}).")
    threading.Thread(target=work, daemon=True).start()


@bp.route("/admin/update/start", methods=["POST"])
@roles_required("admin")
def admin_update_start():
    check_csrf()
    app = current_app._get_current_object()
    if _JOB["state"] in ("running", "restarting"):
        return jsonify(ok=True)
    st = updater.status(app, force=True)
    if not st["newer"]:
        return jsonify(ok=False, error=st["error"] or "نسخهٔ جدیدتری وجود ندارد."), 400
    _job_set(state="running", pct=1, text="شروع…", error="")
    _run_update_job(app, st)
    return jsonify(ok=True)


@bp.route("/admin/update/progress")
@roles_required("admin")
def admin_update_progress():
    return jsonify(**_JOB)


@bp.route("/admin/shutdown", methods=["POST"])
@roles_required("admin")
def admin_shutdown():
    """خاموش‌کردن کامل برنامه (نسخهٔ ویندوز بدون پنجرهٔ کنسول)."""
    check_csrf()
    if not (updater.is_frozen() and os.name == "nt"):
        abort(404)
    import threading
    audit.log(get_db(), "app_shutdown", "برنامه خاموش شد")
    threading.Thread(target=lambda: (time.sleep(1), os._exit(0)), daemon=True).start()
    return "برنامه خاموش شد؛ این پنجره را ببندید."


@bp.route("/admin/update", methods=["GET", "POST"])
@roles_required("admin")
def admin_update():
    app = current_app._get_current_object()
    if request.method == "POST":
        check_csrf()
        action = request.form.get("action", "")
        if action == "check":
            st = updater.status(app, force=True)
            flash("بررسی انجام شد." if not st["error"] else st["error"], "error" if st["error"] else "success")
            return redirect(url_for("main.admin_update"))
        if action == "apply":
            st = updater.status(app, force=True)
            if not st["newer"]:
                flash(st["error"] or "نسخهٔ جدیدتری وجود ندارد.", "error")
                return redirect(url_for("main.admin_update"))
            cfg = current_app.config
            try:
                try:                                    # ۱) بکاپ از اطلاعات
                    backups.run_backup(cfg["DATABASE"], cfg["BACKUP_SETTINGS_FILE"], cfg["BACKUP_DIR"])
                except FileNotFoundError:
                    pass
                pkg = updater.download(app, st["file"])      # ۲) دانلود و تأیید
                audit.log(get_db(), "app_update", f"{config.APP_VERSION} ← {st['latest']}")
                if updater.is_frozen() and os.name == "nt":
                    count = 0                                # ۳) ویندوز: اسکریپت بعد از بسته‌شدن جایگزین می‌کند
                else:
                    root = updater.app_root(app)
                    count = updater.apply_source(root, pkg, os.path.join(updater.updates_dir(app), "previous"))
            except updater.UpdateError as e:
                flash(str(e), "error")
                return redirect(url_for("main.admin_update"))
            _schedule_restart(app)
            return render_template("admin_update.html", st=st, restarting=True, count=count)
        abort(400)
    return render_template("admin_update.html", st=updater.status(app), restarting=False, count=0,
                           frozen_win=updater.is_frozen() and os.name == "nt")
