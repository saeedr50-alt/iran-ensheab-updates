import os
import secrets

from flask import Flask, render_template

from datetime import date

from . import auth, backups, config, db, routes, seats
from .jalali import fa_num, to_fa_digits


def _load_secret_key(instance_path: str) -> str:
    env = os.environ.get("CASE_APP_SECRET")
    if env:
        return env
    path = os.path.join(instance_path, "secret.key")
    if not os.path.exists(path):
        with open(path, "w") as f:
            f.write(secrets.token_hex(32))
    with open(path) as f:
        return f.read().strip()


def create_app(test_config: dict | None = None, instance_path: str | None = None) -> Flask:
    app = Flask(__name__, instance_relative_config=True, instance_path=instance_path)
    os.makedirs(app.instance_path, exist_ok=True)

    app.config["DATABASE"] = os.path.join(app.instance_path, "cases.sqlite")
    app.config["SESSION_COOKIE_HTTPONLY"] = True
    app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
    if test_config:
        app.config.update(test_config)
    # توجه: Flask خودش SECRET_KEY=None را در تنظیمات می‌گذارد، پس باید مقدار خالی را چک کنیم
    if not app.config.get("SECRET_KEY"):
        app.config["SECRET_KEY"] = _load_secret_key(app.instance_path)

    # پوشهٔ بکاپ‌ها: در حالت عادی همان پوشهٔ backups کنار برنامه (مثل backup.py)
    project = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    if os.path.abspath(app.config["DATABASE"]) == os.path.join(project, "instance", "cases.sqlite"):
        default_backup_dir = os.path.join(project, "backups")
    else:
        default_backup_dir = os.path.join(os.path.dirname(app.config["DATABASE"]), "backups")
    app.config.setdefault("BACKUP_DIR", default_backup_dir)
    app.config.setdefault("BACKUP_SETTINGS_FILE", os.path.join(os.path.dirname(app.config["DATABASE"]),
                                                               "backup_settings.json"))
    app.config.setdefault("AUTO_BACKUP", not app.testing)

    db.init_db(app.config["DATABASE"])
    if app.config["AUTO_BACKUP"]:               # هر بار که برنامه باز می‌شود، یک بکاپ
        try:
            backups.run_backup(app.config["DATABASE"], app.config["BACKUP_SETTINGS_FILE"],
                               app.config["BACKUP_DIR"])
        except Exception:                      # noqa: BLE001
            app.logger.exception("بکاپ هنگام باز شدن برنامه انجام نشد")
        backups.start_periodic(app.config["DATABASE"], app.config["BACKUP_SETTINGS_FILE"], app.config["BACKUP_DIR"],
                               config.BACKUP_INTERVAL_SECONDS, app.logger)
    app.teardown_appcontext(db.close_db)
    app.before_request(auth.load_current_user)

    state = {"day": None}

    @app.before_request
    def daily_backup():
        """اولین درخواستِ هر روز: اگر هنوز بکاپ امروز نیست، خودکار می‌سازد (خطا هرگز کار را متوقف نمی‌کند)."""
        if not app.config["AUTO_BACKUP"] or state["day"] == date.today():
            return
        state["day"] = date.today()
        try:
            st = backups.read_settings(app.config["BACKUP_SETTINGS_FILE"], app.config["BACKUP_DIR"])
            if not backups.has_backup_today(st["dir"]):
                backups.run_backup(app.config["DATABASE"], app.config["BACKUP_SETTINGS_FILE"],
                                   app.config["BACKUP_DIR"])
        except Exception:                      # noqa: BLE001
            app.logger.exception("بکاپ خودکار انجام نشد")

    app.register_blueprint(auth.bp)
    app.register_blueprint(routes.bp)

    app.jinja_env.filters["fa"] = to_fa_digits
    app.jinja_env.filters["fa_num"] = fa_num
    app.jinja_env.globals.update(
        csrf_token=auth.csrf_token,
        CASE_TYPES=config.CASE_TYPES,
        SELECTABLE_TYPES=config.SELECTABLE_TYPES,
        CASE_GROUPS=config.CASE_GROUPS,
        TYPE_FLAGS=config.TYPE_FLAGS,
        FLAG_LABELS=config.FLAG_LABELS,
        report_title=config.report_title,
        report_flag=config.report_flag,
        ROLES=config.ROLES,
        CAN_CREATE=config.ROLES_CAN_CREATE,
    )

    @app.context_processor
    def seat_context():
        def seat_status():
            from flask import g
            if getattr(g, "user", None) is None:
                return None
            hs = seats.holders(db.get_db())
            return dict(max=seats.get_max(db.get_db()), holders=hs,
                        mine=any(h["user_id"] == g.user["id"] for h in hs),
                        can_edit=g.user["role"] in config.ROLES_CAN_CREATE)
        return dict(seat_status=seat_status)

    @app.context_processor
    def app_info():
        from flask import g, session

        def saved_popup():               # پیام پاپ‌آپ بعد از ذخیرهٔ پرونده (فقط یک بار)
            return session.pop("saved_popup", None)

        def news_items():                # موارد تازهٔ نسخه، اگر این کاربر «دیگر نمایش نده» را نزده باشد
            from . import db as _db
            if not g.user or not config.WHATS_NEW.get("items"):
                return []
            row = _db.get_db().execute("SELECT value FROM settings WHERE key = ?", (f"news_seen_{g.user['id']}",)).fetchone()
            return [] if row and row["value"] == config.WHATS_NEW["version"] else config.WHATS_NEW["items"]

        def can_new():                   # دکمه/منوی «ایجاد پرونده» (کاربر با نوع پروندهٔ قفل‌شده پرونده نمی‌سازد)
            from . import perms as _perms
            return bool(g.user and g.user["role"] in config.ROLES_CAN_CREATE and _perms.can_create_any(_perms.locked_for(g.user)))

        def welcome_once():              # فقط یک بار بعد از هر ورود
            return bool(session.pop("welcome", None))
        def company():
            from . import company as _co, db as _db
            return _co.get(_db.get_db())
        return dict(APP_VERSION=config.APP_VERSION, COMPANY_NAME=config.COMPANY_NAME, DEVELOPER_NAME=config.DEVELOPER_NAME,
                    company=company, DASH_SECTIONS=config.DASH_SECTIONS, SETTINGS_ENDPOINTS=("main.settings", "main.settings_company", "main.admin_users",
                                                         "main.admin_options", "main.admin_logs", "main.admin_update", "main.tickets_page", "main.ticket_view"),
                    APP_TITLE=config.APP_TITLE, welcome_once=welcome_once, news_items=news_items, saved_popup=saved_popup, can_new=can_new)

    @app.errorhandler(403)
    def forbidden(_e):
        return render_template("error.html", code=403,
                               message="شما به این بخش دسترسی ندارید."), 403

    @app.errorhandler(400)
    def bad_request(e):
        return render_template("error.html", code=400,
                               message=getattr(e, "description", "درخواست نامعتبر")), 400

    return app
