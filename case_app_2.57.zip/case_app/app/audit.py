"""لاگ رویدادها: چه کسی، در چه زمانی، چه کاری کرد. فقط افزوده می‌شود (حذف و ویرایش لاگ ممکن نیست).

نکتهٔ مهم: اگر ثبت لاگ به هر دلیل خطا بدهد، کار اصلی کاربر متوقف نمی‌شود.
"""
import json
import sqlite3
from datetime import datetime

from flask import g, has_request_context, request

from . import config

# کلید: (عنوان فارسی، دسته)
ACTIONS = {
    "login": ("ورود", "ورود و خروج"),
    "login_fail": ("ورود ناموفق", "ورود و خروج"),
    "logout": ("خروج", "ورود و خروج"),
    "case_create": ("ثبت پرونده", "پرونده"),
    "case_edit": ("ویرایش پرونده", "پرونده"),
    "profile_edit": ("ویرایش شناسنامه", "پرونده"),
    "report": ("گزارش شناسنامه (PDF)", "پرونده"),
    "app_shutdown": ("خاموش‌کردن برنامه", "برنامه"),
    "org_edit": ("ویرایش اطلاعات شرکت", "شرکت‌ها"),
    "option_add": ("افزودن گزینه", "گزینه‌ها"),
    "option_active": ("فعال/غیرفعال‌کردن گزینه", "گزینه‌ها"),
    "option_rename": ("تغییر نام گزینه", "گزینه‌ها"),
    "option_toggle": ("فعال/غیرفعال‌کردن گزینه", "گزینه‌ها"),
    "user_create": ("ساخت کاربر", "کاربران"),
    "user_role": ("تغییر نقش", "کاربران"),
    "user_active": ("فعال/غیرفعال‌کردن کاربر", "کاربران"),
    "user_password": ("تغییر رمز", "کاربران"),
    "ticket_new": ("ثبت تیکت پشتیبانی", "پشتیبانی"),
    "company_info": ("تغییر اطلاعات شرکت", "تنظیمات"),
    "user_dash": ("تغییر دسترسی داشبورد", "کاربران"),
    "user_fields": ("تغییر دسترسی فیلدها", "کاربران"),
    "perm_denied": ("تلاش برای تغییر فیلد قفل‌شده", "کاربران"),
    "user_name": ("تغییر نام کاربر", "کاربران"),
    "seat_free": ("آزاد کردن جای ویرایش", "کاربران"),
    "seats_max": ("تغییر حداکثر ویرایش همزمان", "کاربران"),
    "backup_run": ("ساخت بکاپ", "بکاپ"),
    "backup_settings": ("تنظیمات بکاپ", "بکاپ"),
    "backup_restore": ("بازگردانی بکاپ", "بکاپ"),
    "backup_download": ("دانلود بکاپ", "بکاپ"),
    "app_update": ("به‌روزرسانی برنامه", "برنامه"),
}
CATEGORIES = sorted({c for _, c in ACTIONS.values()}, key=lambda c: list(c for _, c in ACTIONS.values()).index(c))


def now_text() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def case_label(case: dict | None) -> str:
    if not case:
        return ""
    return f"{config.CASE_TYPES.get(case.get('case_type'), '')} {case.get('serial_no')}/{case.get('year')}"


def log(db: sqlite3.Connection, action: str, summary: str = "", case: dict | None = None,
        changes: list | None = None, user=None) -> None:
    """changes: فهرست [عنوان، مقدار قبلی، مقدار جدید]. خارج از تراکنش باز صدا زده شود."""
    try:
        if user is None and has_request_context():
            user = g.get("user")
        uid = user["id"] if user is not None else None
        uname = ""
        if user is not None:
            uname = user["full_name"] if "full_name" in user.keys() and user["full_name"] else user["username"]
        ip = request.remote_addr if has_request_context() else ""
        db.execute(
            "INSERT INTO audit_log (at, user_id, username, ip, action, case_id, case_label, summary, detail) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (now_text(), uid, uname, ip or "", action, case.get("id") if case else None,
             case_label(case), summary, json.dumps(changes, ensure_ascii=False) if changes else ""))
    except Exception:                                  # noqa: BLE001  لاگ نباید کار اصلی را خراب کند
        pass


# ------------------------------------------------------------------ تفاوت قبل و بعد
def _s(v) -> str:
    return "" if v is None else str(v)


def case_changes(old: dict, data: dict) -> list:
    """تفاوت اطلاعات فرم اصلی (فیلدها، محصولات، رقبا) قبل و بعد از ذخیره."""
    from .case_data import FIELD_LABELS, TEXT_FIELDS
    out = []
    for f in TEXT_FIELDS:
        if _s(old.get(f)) != _s(data.get(f)):
            out.append([FIELD_LABELS.get(f, f), _s(old.get(f)), _s(data.get(f))])
    olds = {p["id"]: p for p in old.get("products", [])}
    for p in data.get("products", []):
        name = " ".join(x for x in (_s(p.get("product_type")), _s(p.get("size"))) if x) or "محصول"
        if p.get("id") and p["id"] in olds:
            o = olds[p["id"]]
            for k, lab in (("product_type", "نام محصول"), ("r_size", "اندازه R"), ("size", "سایز"), ("quantity", "تعداد"),
                           ("model", "مدل"), ("sample", "نمونه"), ("sample_qty", "تعداد نمونه")):
                if _s(o.get(k)) != _s(p.get(k)):
                    out.append([f"محصول «{name}» ← {lab}", _s(o.get(k)), _s(p.get(k))])
        else:
            out.append(["محصول جدید", "", f"{name} × {_s(p.get('quantity'))}"])
    oldc = {c["id"]: c for c in old.get("competitors", [])}
    for c in data.get("competitors", []):
        if c.get("id") and c["id"] in oldc:
            o = oldc[c["id"]]
            for k, lab in (("name", "نام"), ("price", "قیمت"), ("note", "توضیح")):
                if _s(o.get(k)) != _s(c.get(k)):
                    out.append([f"رقیب «{_s(o.get('name'))}» ← {lab}", _s(o.get(k)), _s(c.get(k))])
            if bool(o.get("won")) != bool(c.get("won")):
                out.append([f"رقیب «{_s(o.get('name'))}» ← برنده", "بله" if o.get("won") else "خیر",
                            "بله" if c.get("won") else "خیر"])
        else:
            out.append(["رقیب جدید", "", f"{_s(c.get('name'))} ({_s(c.get('price'))})"])
    return out


def profile_changes(old: dict, vals: dict, old_products: list, prices: dict) -> list:
    from . import profile
    out = []
    for k in profile.KEYS:
        if _s(old.get(k)) != _s(vals.get(k)):
            out.append([profile.LABELS[k], _s(old.get(k)), _s(vals.get(k))])
    for p in old_products:
        if p["id"] in prices and int(prices[p["id"]] or 0) != int(p.get("price") or 0):
            out.append([f"قیمت «{profile.product_name(p)}»", _s(p.get("price")), _s(prices[p["id"]])])
    return out


# ------------------------------------------------------------------ جستجو
PAGE = 50


def query(db: sqlite3.Connection, f: dict, page: int = 1, limit: int | None = PAGE):
    """f: user_id, category, action, date_from, date_to (میلادی YYYY-MM-DD)، q."""
    where, args = [], []
    if f.get("user_id"):
        where.append("user_id = ?"); args.append(f["user_id"])
    if f.get("action") in ACTIONS:
        where.append("action = ?"); args.append(f["action"])
    elif f.get("category"):
        acts = [a for a, (_, c) in ACTIONS.items() if c == f["category"]]
        where.append("action IN (%s)" % ",".join("?" * len(acts)) if acts else "0"); args += acts
    if f.get("date_from"):
        where.append("at >= ?"); args.append(f["date_from"] + " 00:00:00")
    if f.get("date_to"):
        where.append("at <= ?"); args.append(f["date_to"] + " 23:59:59")
    if f.get("q"):
        like = "%" + f["q"].replace("%", "").replace("_", "") + "%"
        where.append("(summary LIKE ? OR case_label LIKE ? OR detail LIKE ? OR username LIKE ?)")
        args += [like] * 4
    w = (" WHERE " + " AND ".join(where)) if where else ""
    total = db.execute("SELECT COUNT(*) FROM audit_log" + w, args).fetchone()[0]
    sql = "SELECT * FROM audit_log" + w + " ORDER BY id DESC"
    if limit:
        sql += " LIMIT ? OFFSET ?"
        args = args + [limit, (max(page, 1) - 1) * limit]
    rows = []
    for r in db.execute(sql, args):
        d = dict(r)
        d["title"] = ACTIONS.get(d["action"], (d["action"], ""))[0]
        d["changes"] = json.loads(d["detail"]) if d["detail"] else []
        rows.append(d)
    return rows, total
