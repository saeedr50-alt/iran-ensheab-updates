/* پاپ‌آپ شیشه‌ای پیام + حرکت با Enter به فیلد بعدی (فرم‌هایی که data-enter-next دارند) */
(function () {
  window.svPopup = function (text, bad) {
    var old = document.getElementById('sv-dyn'); if (old) old.remove();
    var m = document.createElement('div');
    m.className = 'sv-modal sv-toast' + (bad ? ' sv-bad' : ''); m.id = 'sv-dyn'; m.setAttribute('role', 'alertdialog'); m.setAttribute('aria-modal', 'true');
    var ico = bad ? '<path d="M12 7v6M12 17h.01"/>' : '<path d="M5 12.5l4.5 4.5L19 7.5"/>';
    m.innerHTML = '<div class="sv-card"><div class="sv-ico" aria-hidden="true"><svg viewBox="0 0 24 24" width="30" height="30" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">' + ico + '</svg></div><p class="sv-text"></p></div>';
    m.querySelector('p').textContent = text;
    document.body.appendChild(m);
    var timer;
    function close() { clearTimeout(timer); m.remove(); document.removeEventListener('keydown', key, true); }
    function key(e) { if (e.key === 'Escape' || e.key === 'Enter') { e.preventDefault(); e.stopPropagation(); close(); } }
    m.addEventListener('click', close);
    document.addEventListener('keydown', key, true);
    timer = setTimeout(close, bad ? 8000 : 4500);
  };

  function usable(el) {
    if (el.disabled || el.readOnly || el.tabIndex < 0 || el.type === 'hidden' || el.type === 'checkbox') return false;
    var cs = getComputedStyle(el);
    return cs.display !== 'none' && cs.visibility !== 'hidden' && el.getClientRects().length > 0;
  }
  document.addEventListener('keydown', function (e) {
    if (e.key !== 'Enter' || e.isComposing) return;
    var el = e.target;
    if (!el || el.tagName !== 'INPUT') return;
    if (e.defaultPrevented && !el.classList.contains('jdate')) return;
    var form = el.closest('form[data-enter-next]');
    if (!form) return;
    if (document.querySelector('.ss-modal:not([hidden]), .ss-pop:not([hidden])')) return;
    e.preventDefault();
    setTimeout(function () { window.svFocusNext(el); }, 30);     // بگذار تاریخ تایپ‌شده اول بررسی/اصلاح شود
  }, true);

  // رفتن به فیلد بعدی فرم (بعد از Enter یا بعد از انتخاب یک گزینه در کمبوباکس)
  window.svFocusNext = function (el) {
    var form = el.closest('form[data-enter-next]');
    if (!form) return;
    var list = Array.prototype.filter.call(form.querySelectorAll('input, textarea, button.ss-btn, select'), function (x) {
      if (x.tagName === 'SELECT' && x.classList.contains('ss-native')) return false;
      return usable(x) && !(x.tagName === 'SELECT' && x.parentNode.querySelector('button.ss-btn'));
    });
    var i = list.indexOf(el);
    var next = i >= 0 ? list[i + 1] : null;
    if (!next) next = form.querySelector('#save-btn, #pf-save, button[type=submit]');
    if (next) next.focus();
  };
})();
