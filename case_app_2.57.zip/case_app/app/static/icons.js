/* آیکون خودکار برای دکمه‌ها بر اساس متن (یکسان در همهٔ صفحه‌ها و پروژه‌های بعدی) */
(function () {
  var P = {
    save: '<path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><path d="M17 21v-8H7v8M7 3v5h8"/>',
    x: '<path d="M18 6 6 18M6 6l12 12"/>',
    list: '<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    imp: '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5M12 11v6M9 14l3 3 3-3"/>',
    out: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/>',
    undo: '<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/>',
    cloud: '<path d="M12 16V8M9 11l3-3 3 3"/><path d="M20 16.5A4.5 4.5 0 0 0 17.5 8H16A6 6 0 1 0 4 14.3"/>',
    send: '<path d="m22 2-7 20-4-9-9-4zM22 2 11 13"/>',
    refresh: '<path d="M21 12a9 9 0 1 1-3-6.7L21 8"/><path d="M21 3v5h-5"/>',
    folder: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
    print: '<path d="M6 9V3h12v6M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><path d="M6 14h12v7H6z"/>',
    edit: '<path d="M12 20h9M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/>',
    filter: '<path d="M3 5h18l-7 8v6l-4 2v-8z"/>',
    check: '<path d="m5 12 5 5 9-10"/>',
    eye: '<path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
    key: '<circle cx="8" cy="15" r="4"/><path d="m11 12 9-9M16 7l3 3"/>',
    user: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
    doc: '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/>'
  };
  var MAP = [
    [/ذخیره/, 'save'], [/بستن|انصراف|لغو|ندارم/, 'x'], [/فهرست|لیست/, 'list'],
    [/وارد کردن|ورود از|بارگذاری|آپلود/, 'imp'], [/ورود|تأیید و ورود/, 'key'], [/خروج|ببند/, 'out'],
    [/جستجو/, 'search'], [/بازگردانی|برگرد|بازگشت/, 'undo'], [/بکاپ/, 'cloud'], [/ارسال|تیکت/, 'send'],
    [/به‌?روز ?رسانی|بروزرسانی|تازه/, 'refresh'], [/پوشه/, 'folder'], [/چاپ|گزارش|PDF/, 'print'],
    [/ویرایش/, 'edit'], [/^نمایش$|مشاهده/, 'eye'], [/فیلتر/, 'filter'], [/ایجاد|افزودن|اضافه|جدید|محصولات را/, 'plus'],
    [/کاربر/, 'user'], [/تأیید|اعمال|تایید|ثبت/, 'check']
  ];
  function pick(t) { for (var i = 0; i < MAP.length; i++) if (MAP[i][0].test(t)) return MAP[i][1]; return ''; }
  function run(root) {
    (root || document).querySelectorAll('button.btn, a.btn, button.btn-icon-auto').forEach(function (b) {
      if (b.dataset.icoDone || b.querySelector('svg')) return;
      var t = (b.textContent || '').trim();
      if (t.length < 2) return;
      var k = b.dataset.icon || pick(t);
      b.dataset.icoDone = '1';
      if (!k || !P[k]) return;
      var s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
      s.setAttribute('viewBox', '0 0 24 24'); s.setAttribute('class', 'btn-ico'); s.setAttribute('aria-hidden', 'true');
      s.innerHTML = P[k];
      b.insertBefore(s, b.firstChild);
    });
  }
  window.svIcons = run;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { run(); });
  else run();
  new MutationObserver(function () { run(); }).observe(document.documentElement, { childList: true, subtree: true });
})();
