"""تیکت پشتیبانی: هر تیکت یک Issue در مخزن خصوصی گیت‌هاب است؛ پاسخ پشتیبان از همان Issue خوانده می‌شود.
کلید (توکن) هرگز در Git نمی‌رود؛ از فایل ticket_token.txt کنار برنامه خوانده می‌شود."""
import base64
import json
import os
import sys
import time
import urllib.error
import urllib.request

from . import config, updater

API = "https://api.github.com"
MAX_FILE = 10 * 1024 * 1024      # حداکثر حجم هر پیوست
FILE_EXTS = {"png", "jpg", "jpeg", "gif", "webp", "pdf", "txt", "log", "csv", "xlsx", "xls", "docx", "doc", "zip"}
SYNC_EVERY = 60          # ثانیه: حداقل فاصلهٔ دو بار همگام‌سازی یک تیکت


LAST_FILE_ERROR = {}     # شمارهٔ تیکت ← دلیل ارسال‌نشدن پیوست (فقط برای نمایش پیام)


class TicketError(Exception):
    pass


def token(app=None) -> str:
    t = os.environ.get("IE_TICKET_TOKEN", "").strip()
    if t:
        return t
    dirs = []
    if app is not None:
        dirs.append(os.path.dirname(app.config["DATABASE"]))
    dirs += [updater.app_root(app), os.path.dirname(updater.app_root(app)), os.path.dirname(os.path.abspath(sys.executable))]
    for d in dirs:
        try:
            with open(os.path.join(d, "ticket_token.txt"), encoding="utf-8") as f:
                t = f.read().strip()
            if t:
                return t
        except OSError:
            continue
    return ""


def _call(app, method: str, path: str, payload=None, timeout=15):
    tk = token(app)
    if not tk:
        raise TicketError("کلید ارسال تیکت روی این سیستم نیست.")
    data = json.dumps(payload).encode("utf-8") if payload is not None else None
    req = urllib.request.Request(API + path, data=data, method=method, headers={
        "Authorization": f"Bearer {tk}", "Accept": "application/vnd.github+json",
        "User-Agent": "IranEnsheab-Tickets", "X-GitHub-Api-Version": "2022-11-28",
        "Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=timeout, context=updater._ssl_context()) as r:
            return json.loads(r.read().decode("utf-8") or "null")
    except urllib.error.HTTPError as e:
        if method == "PUT" and e.code in (401, 403, 404):
            raise TicketError("کلید تیکت اجازهٔ ذخیرهٔ فایل را ندارد (در گیت‌هاب باید Contents: Read and write داده شود).") from e
        if e.code == 413:
            raise TicketError("حجم فایل برای ارسال زیاد است.") from e
        raise TicketError(f"گیت‌هاب خطا داد ({e.code}).") from e
    except Exception as e:                       # noqa: BLE001 — اینترنت، DNS، SSL
        raise TicketError("اتصال به اینترنت برقرار نشد.") from e


def check_upload(fs):
    """فایل انتخاب‌شده را بررسی می‌کند؛ (نام، بایت‌ها) یا None اگر فایلی نبود. خطا → TicketError با پیام فارسی."""
    if fs is None or not getattr(fs, "filename", ""):
        return None
    name = os.path.basename(fs.filename.replace("\\", "/")).strip()[:100]
    ext = name.rsplit(".", 1)[-1].lower() if "." in name else ""
    if ext not in FILE_EXTS:
        raise TicketError("نوع فایل مجاز نیست (عکس، PDF، اکسل، ورد، متن و zip).")
    data = fs.read(MAX_FILE + 1)
    if not data:
        return None
    if len(data) > MAX_FILE:
        raise TicketError("حجم فایل بیشتر از ۱۰ مگابایت است.")
    return name, data


def add_file(db, tid: int, name: str, data: bytes, comment_id=None) -> int:
    cur = db.execute("INSERT INTO ticket_files (ticket_id, comment_id, name, size, data) VALUES (?,?,?,?,?)",
                     (tid, comment_id, name, len(data), data))
    return cur.lastrowid


def upload_file(app, db, fid: int) -> str:
    """فایل را در مخزن خصوصی تیکت‌ها می‌گذارد و لینکش را برمی‌گرداند (خطا: TicketError)."""
    f = db.execute("SELECT * FROM ticket_files WHERE id = ?", (fid,)).fetchone()
    if f["gh_url"]:
        return f["gh_url"]
    ext = f["name"].rsplit(".", 1)[-1].lower() if "." in f["name"] else "bin"
    path = f"attachments/ticket-{f['ticket_id']}/{fid}.{ext}"
    r = _call(app, "PUT", f"/repos/{config.TICKET_REPO}/contents/{path}",
              {"message": f"پیوست تیکت {f['ticket_id']}", "content": base64.b64encode(f["data"]).decode("ascii")}, timeout=90)
    url = ((r or {}).get("content") or {}).get("html_url") or f"https://github.com/{config.TICKET_REPO}/blob/main/{path}"
    db.execute("UPDATE ticket_files SET gh_url = ? WHERE id = ?", (url, fid))
    db.commit()
    return url


def _issue_body(t, company_name: str) -> str:
    return (f"{t['body']}\n\n---\nشرکت: {company_name}\nکاربر: {t['username']}\n"
            f"تماس: {t['contact'] or '—'}\nنسخهٔ برنامه: {config.APP_VERSION}\nشمارهٔ تیکت در برنامه: {t['id']}")


def send(app, db, tid: int, company_name: str) -> bool:
    """ارسال یک تیکت هنوز-ارسال‌نشده؛ خروجی True اگر رفت. خطا هرگز استثنا نمی‌دهد."""
    t = db.execute("SELECT * FROM tickets WHERE id = ?", (tid,)).fetchone()
    if t is None or t["gh_number"]:
        return bool(t and t["gh_number"])
    links, failed = [], []
    for f in db.execute("SELECT id, name FROM ticket_files WHERE ticket_id = ? AND comment_id IS NULL ORDER BY id", (tid,)).fetchall():
        try:
            links.append(f"[{f['name']}]({upload_file(app, db, f['id'])})")
        except TicketError as e:               # خطای فایل نباید جلوی ارسال خود تیکت را بگیرد
            failed.append((f["name"], str(e)))
            LAST_FILE_ERROR[tid] = str(e)
    try:
        body = _issue_body(t, company_name) + ("\nپیوست: " + " ، ".join(links) if links else "")
        if failed:
            body += "\nپیوست ارسال نشد (در برنامهٔ کاربر ذخیره است): " + " ، ".join(n for n, _ in failed)
        r = _call(app, "POST", f"/repos/{config.TICKET_REPO}/issues",
                  {"title": f"[{company_name}] {t['subject']}", "body": body})
    except TicketError:
        return False
    db.execute("UPDATE tickets SET gh_number = ? WHERE id = ?", (int(r["number"]), tid))
    db.commit()
    return True


def post_reply(app, db, tid: int, user_name: str, text: str, upload=None) -> bool:
    t = db.execute("SELECT * FROM tickets WHERE id = ?", (tid,)).fetchone()
    if t is None or not t["gh_number"]:
        return False
    fid = None
    try:
        body = f"**{user_name}:**\n{text}"
        if upload:
            fid = add_file(db, tid, upload[0], upload[1])
            body += f"\n\nپیوست: [{upload[0]}]({upload_file(app, db, fid)})"
        r = _call(app, "POST", f"/repos/{config.TICKET_REPO}/issues/{t['gh_number']}/comments", {"body": body})
    except TicketError as e:
        LAST_FILE_ERROR[tid] = str(e)
        if fid:
            db.execute("DELETE FROM ticket_files WHERE id = ?", (fid,))
            db.commit()
        return False
    cur = db.execute("INSERT OR IGNORE INTO ticket_comments (ticket_id, gh_id, author, body, created_at) VALUES (?,?,?,?,?)",
                     (tid, r["id"], "user", text, (r.get("created_at") or "")[:16].replace("T", " ")))
    if fid and cur.lastrowid:
        db.execute("UPDATE ticket_files SET comment_id = ? WHERE id = ?", (cur.lastrowid, fid))
    db.execute("UPDATE tickets SET gh_state = 'open' WHERE id = ?", (tid,))
    db.commit()
    return True


def sync(app, db, tid: int, force: bool = False) -> None:
    """وضعیت و پاسخ‌های پشتیبان را از گیت‌هاب می‌گیرد (بی‌صدا؛ اگر اینترنت نبود همان قبلی می‌ماند)."""
    t = db.execute("SELECT * FROM tickets WHERE id = ?", (tid,)).fetchone()
    if t is None or not t["gh_number"] or (not force and time.time() - t["last_sync"] < SYNC_EVERY):
        return
    try:
        issue = _call(app, "GET", f"/repos/{config.TICKET_REPO}/issues/{t['gh_number']}")
        comments = _call(app, "GET", f"/repos/{config.TICKET_REPO}/issues/{t['gh_number']}/comments?per_page=100")
    except TicketError:
        return
    for c in comments or []:
        who = (c.get("user") or {}).get("login", "")
        if who.lower() != config.TICKET_SUPPORT_LOGIN.lower():
            continue                              # پیام‌های خود کاربر قبلاً از داخل برنامه ثبت شده‌اند
        db.execute("INSERT OR IGNORE INTO ticket_comments (ticket_id, gh_id, author, body, created_at) VALUES (?,?,?,?,?)",
                   (tid, c["id"], "support", c.get("body") or "", (c.get("created_at") or "")[:16].replace("T", " ")))
    db.execute("UPDATE tickets SET gh_state = ?, last_sync = ? WHERE id = ?",
               (issue.get("state", "open"), time.time(), tid))
    db.commit()
