"""پاک‌سازی اطلاعات آزمایشی (پرونده‌ها و شماره‌ها) با یک دستور:

    python3 reset_data.py

- ابتدا از کل دیتابیس بکاپ کامل در پوشه backups ساخته می‌شود (چیزی واقعاً از بین نمی‌رود).
- کاربران (با دسترسی‌ها)، گزینه‌ها، سازمان‌ها و مخاطبین، تنظیمات و تیکت‌ها می‌مانند.
- پرونده‌ها، ردیف محصولات و رقبا و شمارنده‌ها خالی می‌شوند؛ شماره‌گذاری دوباره از ۱ شروع می‌شود.
- قبل از اجرا، برنامه (run.py) را با Control+C متوقف کنید.
"""
import os
import sqlite3
import sys

from backup import SOURCE, HERE, make_backup


def reset(source: str = SOURCE, folder: str | None = None, ask=input) -> str | None:
    if not os.path.exists(source):
        raise FileNotFoundError(f"دیتابیس پیدا نشد: {source}")
    if ask("همهٔ پرونده‌ها خالی شود؟ (کاربران، گزینه‌ها، سازمان‌ها و مخاطبین، تنظیمات و تیکت‌ها می‌مانند) برای تأیید بنویسید YES: ").strip() != "YES":
        print("لغو شد؛ هیچ چیز تغییر نکرد.")
        return None
    backup_path = make_backup(source, folder)
    print("بکاپ کامل ساخته شد:", backup_path)

    # دیتابیس تازه با همان ساختار، فقط با کاربران و گزینه‌های قبلی
    from app.db import connect, init_db
    fresh = source + ".new"
    for ext in ("", "-wal", "-shm"):
        if os.path.exists(fresh + ext):
            os.remove(fresh + ext)
    init_db(fresh)
    old = sqlite3.connect(source)
    new = connect(fresh)
    try:
        new.execute("BEGIN")
        skip = {"counters", "cases", "case_products", "case_competitors", "case_profile",
                "audit_log", "edit_seats", "sqlite_sequence"}
        tables = [r[0] for r in old.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")]
        for t in tables:
            if t in skip:
                continue
            ncols = [r[1] for r in new.execute(f"PRAGMA table_info({t})")]
            ocols = [r[1] for r in old.execute(f"PRAGMA table_info({t})")]
            cols = [c for c in ocols if c in ncols]
            if not ncols or not cols:
                continue
            lst = ", ".join(cols)
            ph = ", ".join("?" for _ in cols)
            if t == "options":       # حذف گزینه ممنوع است؛ فقط وضعیت فعال/غیرفعال منتقل می‌شود
                for r in old.execute("SELECT grp, label, active FROM options ORDER BY id"):
                    new.execute("INSERT INTO options (grp, label, active) VALUES (?, ?, ?) "
                                "ON CONFLICT(grp, label) DO UPDATE SET active = excluded.active", r)
                continue
            new.execute(f"DELETE FROM {t}")
            for r in old.execute(f"SELECT {lst} FROM {t}"):
                new.execute(f"INSERT OR REPLACE INTO {t} ({lst}) VALUES ({ph})", r)
        new.execute("DELETE FROM settings WHERE key = 'type_change_ok'")
        new.execute("COMMIT")
    finally:
        old.close()
        new.close()
    for ext in ("-wal", "-shm"):             # فایل‌های جانبی دیتابیس قدیمی
        if os.path.exists(source + ext):
            os.remove(source + ext)
    os.replace(fresh, source)
    for ext in ("-wal", "-shm"):
        if os.path.exists(fresh + ext):
            os.remove(fresh + ext)
    print("تمام شد. پرونده‌ها خالی شدند؛ شمارهٔ بعدی دوباره ۱ است.")
    return backup_path


if __name__ == "__main__":
    try:
        reset()
    except FileNotFoundError as e:
        sys.exit(str(e))
