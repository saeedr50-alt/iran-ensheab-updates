#!/bin/bash
# اجرای برنامه با یک دستور (مک/لینوکس):  bash start.sh
cd "$(dirname "$0")" || exit 1
PY=python3
command -v python3 >/dev/null 2>&1 || PY=python
$PY -c "import flask" 2>/dev/null || $PY -m pip install flask
$PY -c "import reportlab" 2>/dev/null || $PY -m pip install reportlab   # برای گزارش PDF شناسنامه
$PY -c "import certifi" 2>/dev/null || $PY -m pip install certifi
if [ ! -f instance/cases.sqlite ]; then
  echo "اولین اجرا: یک کاربر مدیر بسازید"
  $PY create_user.py
else
  $PY backup.py || true      # قبل از هر اجرا یک بکاپ از اطلاعات
fi
echo "برنامه روی  http://localhost:5001  اجرا می‌شود (برای توقف: Control+C)"
# وقتی برنامه بالا آمد، مرورگر را خودش باز کن (لازم نیست آدرس را کپی کنید)
(
  for i in $(seq 1 60); do
    if curl -s -o /dev/null http://localhost:5001/login; then
      if command -v open >/dev/null 2>&1; then open "http://localhost:5001"
      elif command -v xdg-open >/dev/null 2>&1; then xdg-open "http://localhost:5001" >/dev/null 2>&1
      fi
      break
    fi
    sleep 0.5
  done
) &
$PY run.py
